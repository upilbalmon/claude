// D61 — Tahap 6 modul Belanja: konstanta & alur status bersama (server + UI).
// Alur status mengikuti item rencana Tahap 6:
//  - 6.1 Pre-Order  : Pending → Dipesan → Tiba → Diambil, + Batal
//  - 6.2 Barang Pesanan : Baru → Dipesan → Tersedia / Ditolak
// Transisi di-validasi SERVER (PATCH) dan dipakai UI untuk menampilkan tombol
// langkah berikutnya — satu sumber kebenaran agar tidak pernah berbeda.

export const PREORDER_STATUS_ORDER = ["Pending", "Dipesan", "Tiba", "Diambil", "Batal"] as const;
export const REQUESTED_STATUS_ORDER = ["Baru", "Dipesan", "Tersedia", "Ditolak"] as const;

// Transisi yang sah (dari → ke). Diambil & Batal/Ditolak = status akhir.
export const PREORDER_TRANSITIONS: Record<string, string[]> = {
  Pending: ["Dipesan", "Batal"],
  Dipesan: ["Tiba", "Batal"],
  Tiba: ["Diambil", "Batal"],
  Diambil: [], // selesai — nota sudah dibuat (batal via void nota di Kasir)
  Batal: [],
};

export const REQUESTED_TRANSITIONS: Record<string, string[]> = {
  Baru: ["Dipesan", "Ditolak"],
  Dipesan: ["Tersedia", "Ditolak"],
  Tersedia: [], // selesai — barang sudah bisa masuk inventaris
  Ditolak: [],
};

export function bisaTransisiPreorder(from: string, to: string): boolean {
  return (PREORDER_TRANSITIONS[from] ?? []).includes(to);
}

export function bisaTransisiRequested(from: string, to: string): boolean {
  return (REQUESTED_TRANSITIONS[from] ?? []).includes(to);
}

// Label tampilan (status sudah bahasa Indonesia — dipetakan eksplisit agar
// konsisten bila kelak teksnya dirapikan di satu tempat saja).
export const PREORDER_STATUS_LABEL: Record<string, string> = {
  Pending: "Pending",
  Dipesan: "Dipesan",
  Tiba: "Tiba",
  Diambil: "Diambil",
  Batal: "Batal",
};

export const REQUESTED_STATUS_LABEL: Record<string, string> = {
  Baru: "Baru",
  Dipesan: "Dipesan",
  Tersedia: "Tersedia",
  Ditolak: "Ditolak",
};

// Kelompok "aktif" = pesanan yang masih berjalan (untuk kartu statistik & DP tertahan)
export const PREORDER_STATUS_AKTIF = ["Pending", "Dipesan", "Tiba"];
export const REQUESTED_STATUS_AKTIF = ["Baru", "Dipesan"];

// Pre-Order yang bisa diedit isinya (belum diproses ke supplier / belum tiba)
export const PREORDER_BISA_EDIT = ["Pending", "Dipesan"];
export const REQUESTED_BISA_EDIT = ["Baru", "Dipesan"];

// Metode bayar pelunasan pre-order — identik whitelist checkout kasir
export const BELANJA_PAYMENT_METHODS = ["Tunai", "Transfer", "QRIS", "E-Wallet", "Kartu"] as const;

// D61 — tunda saran restock (abaikan) maksimal 90 hari; UI menawarkan 7 hari
export const MAX_IGNORE_DAYS = 90;
