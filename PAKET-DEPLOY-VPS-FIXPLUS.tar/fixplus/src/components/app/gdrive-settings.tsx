"use client";

// D67 — Kartu "Sinkronisasi Google Drive" di Pengaturan → Data & Backup.
// Dua jalur koneksi sekaligus:
//   A. OAuth "Hubungkan Google" — Client ID + Secret → popup persetujuan
//      → folder "Fixplus Backup" otomatis dibuat di Drive pengguna.
//   B. Service Account — kunci JSON + Folder ID dibagikan (tanpa popup),
//      cocok untuk auto-backup harian yang berjalan sendiri di server.
// Fitur umum: backup manual sekarang, pengaturan auto-backup harian
// (jam Jakarta, jalur, keep-last), daftar cadangan di Drive dengan aksi
// Pulihkan (ganti database) / Unduh / Hapus, plus panduan setup ringkas.
// Server tetap penjaga utama: semua route /api/gdrive/* wajib Admin.
import { useCallback, useEffect, useRef, useState } from "react";
import {
  CheckCircle2,
  ChevronDown,
  CloudUpload,
  Copy,
  Download,
  ExternalLink,
  HardDriveDownload,
  HelpCircle,
  Info,
  KeyRound,
  Link2,
  RefreshCw,
  Trash2,
  Undo2,
  Unplug,
  XCircle,
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import type { SafeUser } from "@/lib/app-types";

type DriveFile = {
  id: string;
  name: string;
  size: string | null;
  createdTime: string;
  modifiedTime: string;
};
type Status = {
  oauth: { configured: boolean; connected: boolean; email: string | null; folderId: string | null };
  sa: { configured: boolean; clientEmail: string | null; folderId: string | null };
  auto: { enabled: boolean; hour: number; method: "auto" | "oauth" | "sa"; keepLast: number };
  lastBackupAt: string | null;
  lastAutoBackupDate: string | null;
  lastBackupFile: string | null;
};

async function apiJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init);
  const data = (await res.json().catch(() => ({}))) as T & { error?: string };
  if (!res.ok) throw new Error(data.error ?? "Terjadi kesalahan");
  return data as T;
}

const fmtBytes = (n: number) =>
  n >= 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(1)} MB` : `${Math.ceil(n / 1024)} KB`;
const fmtDate = (iso: string) => {
  if (!iso) return "-";
  try {
    return new Intl.DateTimeFormat("id-ID", {
      dateStyle: "medium",
      timeStyle: "short",
      timeZone: "Asia/Jakarta",
    }).format(new Date(iso));
  } catch {
    return iso;
  }
};

export function GdriveCard({ user }: { user: SafeUser }) {
  const { toast } = useToast();
  const isAdmin = user.role === "Admin";
  const uname = encodeURIComponent(user.username);

  const [status, setStatus] = useState<Status | null>(null);
  const [loading, setLoading] = useState(true);
  const [origin, setOrigin] = useState("");

  // Jalur A — OAuth
  const [clientId, setClientId] = useState("");
  const [clientSecret, setClientSecret] = useState("");
  const [oauthBusy, setOauthBusy] = useState(false);
  const [redirectUri, setRedirectUri] = useState("");

  // Jalur B — Service Account
  const [saKey, setSaKey] = useState("");
  const [saFolder, setSaFolder] = useState("");
  const [saBusy, setSaBusy] = useState(false);

  // Backup & auto
  const [backupMethod, setBackupMethod] = useState<"auto" | "oauth" | "sa">("auto");
  const [backupBusy, setBackupBusy] = useState(false);
  const [autoEnabled, setAutoEnabled] = useState(false);
  const [autoHour, setAutoHour] = useState("21");
  const [autoMethod, setAutoMethod] = useState<"auto" | "oauth" | "sa">("auto");
  const [autoKeep, setAutoKeep] = useState("7");
  const [autoBusy, setAutoBusy] = useState(false);

  // Daftar cadangan + aksi
  const [files, setFiles] = useState<DriveFile[] | null>(null);
  const [filesBusy, setFilesBusy] = useState(false);
  const [filesMethod, setFilesMethod] = useState<"auto" | "oauth" | "sa">("auto");
  const [restoreTarget, setRestoreTarget] = useState<DriveFile | null>(null);
  const [restoreBusy, setRestoreBusy] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<DriveFile | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const [guideOpen, setGuideOpen] = useState(false);
  const refreshTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const loadStatus = useCallback(async () => {
    try {
      const s = await apiJson<Status>(`/api/gdrive/status?requesterUsername=${uname}`);
      setStatus(s);
      setAutoEnabled(s.auto.enabled);
      setAutoHour(String(s.auto.hour));
      setAutoMethod(s.auto.method);
      setAutoKeep(String(s.auto.keepLast));
      const available = [
        ...(s.oauth.connected ? ["oauth" as const] : []),
        ...(s.sa.configured ? ["sa" as const] : []),
      ];
      if (available.length === 1) {
        setBackupMethod(available[0]);
        setFilesMethod(available[0]);
      }
    } catch (e) {
      toast({
        title: "Gagal memuat status Google Drive",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [uname]);

  const loadFiles = useCallback(async () => {
    setFilesBusy(true);
    try {
      const r = await apiJson<{ files: DriveFile[] }>(
        `/api/gdrive/files?requesterUsername=${uname}&method=${filesMethod}`
      );
      setFiles(r.files);
    } catch (e) {
      setFiles(null);
      toast({
        title: "Gagal memuat daftar cadangan",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setFilesBusy(false);
    }
  }, [uname, filesMethod]);

  useEffect(() => {
    setOrigin(window.location.origin);
    void loadStatus();
    // Popup Google mempostMessage hasil koneksi — tangkap di sini
    const onMsg = (ev: MessageEvent) => {
      const d = ev.data as { type?: string; status?: string; message?: string } | null;
      if (!d || d.type !== "fixplus-gdrive") return;
      if (d.status === "ok") {
        toast({
          title: "Google Drive tersambung",
          description: d.message ?? "Folder cadangan siap digunakan.",
        });
        setRedirectUri("");
      } else {
        toast({
          title: "Koneksi Google Drive gagal",
          description: d.message ?? "Coba lagi.",
          variant: "destructive",
        });
      }
      void loadStatus();
    };
    window.addEventListener("message", onMsg);
    return () => window.removeEventListener("message", onMsg);
  }, []);

  const uri = `${origin}/api/gdrive/oauth/callback`;

  // ===== Aksi jalur A =====
  async function simpanOauth() {
    setOauthBusy(true);
    try {
      const r = await apiJson<{ redirectUri: string }>("/api/gdrive/oauth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requesterUsername: user.username, clientId, clientSecret }),
      });
      setRedirectUri(r.redirectUri);
      toast({
        title: "Client ID tersimpan",
        description: "Daftarkan Redirect URI di bawah, lalu klik Hubungkan Google.",
      });
      void loadStatus();
    } catch (e) {
      toast({
        title: "Gagal menyimpan kredensial",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setOauthBusy(false);
    }
  }

  function bukaGoogle() {
    window.open(
      `/api/gdrive/oauth/start?requesterUsername=${uname}`,
      "fixplus-gdrive-oauth",
      "width=520,height=680,menubar=no,toolbar=no"
    );
  }

  async function putuskanOauth() {
    setOauthBusy(true);
    try {
      await apiJson("/api/gdrive/oauth", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requesterUsername: user.username }),
      });
      toast({ title: "OAuth diputus", description: "Kredensial Client ID tetap tersimpan." });
      void loadStatus();
    } catch (e) {
      toast({
        title: "Gagal memutus",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setOauthBusy(false);
    }
  }

  // ===== Aksi jalur B =====
  async function simpanSa() {
    setSaBusy(true);
    try {
      const r = await apiJson<{ clientEmail: string; folderName: string }>("/api/gdrive/sa", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requesterUsername: user.username,
          keyJson: saKey,
          folderId: saFolder,
        }),
      });
      toast({
        title: "Service Account aktif",
        description: `${r.clientEmail} — folder "${r.folderName}" terverifikasi.`,
      });
      setSaKey("");
      void loadStatus();
    } catch (e) {
      toast({
        title: "Gagal menyimpan Service Account",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setSaBusy(false);
    }
  }

  async function hapusSa() {
    setSaBusy(true);
    try {
      await apiJson("/api/gdrive/sa", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requesterUsername: user.username }),
      });
      toast({ title: "Service Account dihapus" });
      void loadStatus();
    } catch (e) {
      toast({
        title: "Gagal menghapus",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setSaBusy(false);
    }
  }

  // ===== Backup / auto / daftar =====
  async function backupSekarang() {
    setBackupBusy(true);
    try {
      const r = await apiJson<{ fileName: string; size: number; pruned: number; method: string }>(
        "/api/gdrive/backup",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ requesterUsername: user.username, method: backupMethod }),
        }
      );
      toast({
        title: "Backup terunggah ke Drive",
        description: `${r.fileName} (${fmtBytes(r.size)})${r.pruned ? ` — ${r.pruned} cadangan lama dipangkas` : ""}`,
      });
      void loadStatus();
      setFilesMethod(r.method === "oauth" ? "oauth" : "sa");
    } catch (e) {
      toast({
        title: "Backup ke Drive gagal",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setBackupBusy(false);
    }
  }

  async function simpanAuto() {
    setAutoBusy(true);
    try {
      await apiJson("/api/gdrive/auto", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requesterUsername: user.username,
          auto: {
            enabled: autoEnabled,
            hour: Number(autoHour),
            method: autoMethod,
            keepLast: Number(autoKeep),
          },
        }),
      });
      toast({
        title: autoEnabled ? "Auto-backup aktif" : "Auto-backup dimatikan",
        description: autoEnabled
          ? `Setiap hari pukul ${String(autoHour).padStart(2, "0")}:00 WIB${autoKeep ? `, menyimpan ${autoKeep} cadangan terakhir` : ""}.`
          : undefined,
      });
      void loadStatus();
    } catch (e) {
      toast({
        title: "Gagal menyimpan pengaturan otomatis",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setAutoBusy(false);
    }
  }

  async function pulihkan() {
    if (!restoreTarget) return;
    setRestoreBusy(true);
    try {
      const r = await apiJson<{ summary: string; sessionInvalid: boolean }>("/api/gdrive/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requesterUsername: user.username,
          fileId: restoreTarget.id,
          method: filesMethod,
        }),
      });
      toast({ title: "Database dipulihkan", description: r.summary });
      setRestoreTarget(null);
      if (refreshTimer.current) clearTimeout(refreshTimer.current);
      // Beri waktu toast tampil, lalu muat ulang agar seluruh data baru terbaca
      refreshTimer.current = setTimeout(() => window.location.reload(), 1800);
    } catch (e) {
      toast({
        title: "Pulihkan dari Drive gagal",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setRestoreBusy(false);
    }
  }

  async function hapusFile() {
    if (!deleteTarget) return;
    setDeleteBusy(true);
    try {
      await apiJson(
        `/api/gdrive/files/${deleteTarget.id}?requesterUsername=${uname}&method=${filesMethod}`,
        { method: "DELETE" }
      );
      toast({ title: "Cadangan dihapus dari Drive", description: deleteTarget.name });
      setDeleteTarget(null);
      void loadFiles();
    } catch (e) {
      toast({
        title: "Gagal menghapus cadangan",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setDeleteBusy(false);
    }
  }

  function unduh(f: DriveFile) {
    const a = document.createElement("a");
    a.href = `/api/gdrive/files/${f.id}?requesterUsername=${uname}&method=${filesMethod}&download=1`;
    a.download = f.name;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  const bothReady = Boolean(status?.oauth.connected && status?.sa.configured);
  const anyReady = Boolean(status?.oauth.connected || status?.sa.configured);

  return (
    <div className="space-y-4 rounded-2xl border bg-card p-5">
      <div className="flex flex-wrap items-center gap-2">
        <CloudUpload className="size-4 text-primary" aria-hidden />
        <h2 className="text-sm font-bold uppercase tracking-wide">Sinkronisasi Google Drive</h2>
        <span className="flex-1" />
        <Button
          variant="ghost"
          size="sm"
          className="h-8 gap-1.5 rounded-lg px-2 text-[11px]"
          onClick={() => {
            setLoading(true);
            void loadStatus();
            void loadFiles();
          }}
          disabled={loading || filesBusy}
        >
          <RefreshCw className={`size-3.5 ${loading || filesBusy ? "animate-spin" : ""}`} aria-hidden />
          Segarkan
        </Button>
      </div>
      <p className="text-xs text-muted-foreground">
        Simpan cadangan database langsung ke Google Drive — manual maupun otomatis harian, dan
        pulihkan kembali kapan saja dari daftar cadangan.
      </p>

      {!isAdmin ? (
        <p className="rounded-xl bg-muted/40 px-3 py-2.5 text-xs font-semibold">
          Hanya Admin yang dapat mengatur Google Drive.
        </p>
      ) : (
        <>
          {/* ===== Status badge ===== */}
          <div className="flex flex-wrap items-center gap-2">
            {loading ? (
              <span className="text-xs text-muted-foreground">Memuat status…</span>
            ) : (
              <>
                <Badge
                  variant="outline"
                  className={`gap-1.5 rounded-lg ${status?.oauth.connected ? "border-emerald-300 bg-emerald-50 text-emerald-800" : "bg-muted/40 text-muted-foreground"}`}
                >
                  {status?.oauth.connected ? (
                    <CheckCircle2 className="size-3.5" aria-hidden />
                  ) : (
                    <XCircle className="size-3.5" aria-hidden />
                  )}
                  OAuth{status?.oauth.connected && status?.oauth.email ? `: ${status.oauth.email}` : ": belum terhubung"}
                </Badge>
                <Badge
                  variant="outline"
                  className={`gap-1.5 rounded-lg ${status?.sa.configured ? "border-emerald-300 bg-emerald-50 text-emerald-800" : "bg-muted/40 text-muted-foreground"}`}
                >
                  {status?.sa.configured ? (
                    <CheckCircle2 className="size-3.5" aria-hidden />
                  ) : (
                    <XCircle className="size-3.5" aria-hidden />
                  )}
                  Service Account{status?.sa.configured ? ": aktif" : ": belum ada"}
                </Badge>
                {status?.lastBackupAt && (
                  <span className="text-[11px] text-muted-foreground">
                    Backup terakhir: {fmtDate(status.lastBackupAt)}
                    {status.lastBackupFile ? ` (${status.lastBackupFile})` : ""}
                  </span>
                )}
              </>
            )}
          </div>

          {/* ===== Jalur A — OAuth ===== */}
          <div className="rounded-xl border p-4">
            <div className="mb-1 flex flex-wrap items-center gap-2">
              <Link2 className="size-4 text-primary" aria-hidden />
              <h3 className="text-[13px] font-bold">Cara A — Hubungkan Google (OAuth)</h3>
              {status?.oauth.connected && (
                <Button
                  variant="outline"
                  size="sm"
                  className="ml-auto h-8 gap-1 rounded-lg px-2 text-[11px]"
                  onClick={() => void putuskanOauth()}
                  disabled={oauthBusy}
                >
                  <Unplug className="size-3.5" aria-hidden /> Putuskan
                </Button>
              )}
            </div>
            <p className="mb-3 text-xs text-muted-foreground">
              Satu klik menghubungkan Drive milik Anda sendiri; cadangan masuk folder
              &quot;Fixplus Backup&quot; di Google Drive Anda.
            </p>
            {!status?.oauth.connected ? (
              <div className="space-y-2">
                <div className="grid gap-2 sm:grid-cols-2">
                  <div className="space-y-1">
                    <Label htmlFor="gdrive-client-id" className="text-[11px]">
                      Client ID
                    </Label>
                    <Input
                      id="gdrive-client-id"
                      value={clientId}
                      onChange={(e) => setClientId(e.target.value)}
                      placeholder="xxxx.apps.googleusercontent.com"
                      className="h-9 rounded-lg text-xs"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="gdrive-client-secret" className="text-[11px]">
                      Client Secret
                    </Label>
                    <Input
                      id="gdrive-client-secret"
                      type="password"
                      value={clientSecret}
                      onChange={(e) => setClientSecret(e.target.value)}
                      placeholder="GOCSPX-…"
                      className="h-9 rounded-lg text-xs"
                    />
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <Button
                    size="sm"
                    className="h-9 gap-1.5 rounded-lg"
                    onClick={() => void simpanOauth()}
                    disabled={oauthBusy || !clientId.trim() || !clientSecret.trim()}
                  >
                    <KeyRound className="size-3.5" aria-hidden />
                    {oauthBusy ? "Memproses…" : "Simpan Kredensial"}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-9 gap-1.5 rounded-lg"
                    onClick={bukaGoogle}
                    disabled={!status?.oauth.configured}
                  >
                    <ExternalLink className="size-3.5" aria-hidden /> Hubungkan Google
                  </Button>
                </div>
                {status?.oauth.configured && redirectUri && (
                  <div className="rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-[11px] leading-relaxed text-amber-900">
                    <p className="font-bold">Wajib sebelum menghubungkan:</p>
                    <p>
                      Buka Google Cloud Console → Credentials → OAuth client Anda → Authorized
                      redirect URIs → tambahkan persis URI ini:
                    </p>
                    <div className="mt-1.5 flex items-center gap-1.5">
                      <code className="min-w-0 flex-1 truncate rounded bg-amber-100 px-1.5 py-0.5 font-mono text-[10px]">
                        {redirectUri}
                      </code>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 gap-1 rounded-md px-1.5 text-[10px]"
                        onClick={() => {
                          void navigator.clipboard.writeText(redirectUri);
                          toast({ title: "Redirect URI disalin" });
                        }}
                      >
                        <Copy className="size-3" aria-hidden /> Salin
                      </Button>
                    </div>
                  </div>
                )}
                {status?.oauth.configured && !redirectUri && (
                  <p className="text-[11px] text-muted-foreground">
                    Kredensial tersimpan. Bila popup Google menolak (
                    <span className="font-mono">redirect_uri_mismatch</span>), salin URI ini ke
                    Authorized redirect URIs: <code className="font-mono">{uri}</code>
                  </p>
                )}
              </div>
            ) : (
              <p className="text-xs">
                <b>Tersambung</b> — akun {status?.oauth.email ?? "-"}, folder{" "}
                <code className="font-mono text-[10px]">{status?.oauth.folderId}</code>. Cadangan
                OAuth dihitung terhadap kuota 15 GB Drive Anda.
              </p>
            )}
          </div>

          {/* ===== Jalur B — Service Account ===== */}
          <div className="rounded-xl border p-4">
            <div className="mb-1 flex flex-wrap items-center gap-2">
              <HardDriveDownload className="size-4 text-primary" aria-hidden />
              <h3 className="text-[13px] font-bold">Cara B — Service Account (tanpa popup)</h3>
              {status?.sa.configured && (
                <Button
                  variant="outline"
                  size="sm"
                  className="ml-auto h-8 gap-1 rounded-lg px-2 text-[11px]"
                  onClick={() => void hapusSa()}
                  disabled={saBusy}
                >
                  <Trash2 className="size-3.5" aria-hidden /> Hapus
                </Button>
              )}
            </div>
            <p className="mb-3 text-xs text-muted-foreground">
              Server mengunggah cadangan langsung ke folder yang dibagikan ke service account —
              paling pas untuk auto-backup harian sekali setup.
            </p>
            {!status?.sa.configured ? (
              <div className="space-y-2">
                <div className="space-y-1">
                  <Label htmlFor="gdrive-sa-key" className="text-[11px]">
                    Kunci JSON Service Account
                  </Label>
                  <textarea
                    id="gdrive-sa-key"
                    value={saKey}
                    onChange={(e) => setSaKey(e.target.value)}
                    placeholder='Tempel seluruh isi file kunci (mulai dari { "type": "service_account", … })'
                    className="h-24 w-full rounded-lg border p-2.5 font-mono text-[10px] leading-snug"
                    aria-label="Kunci JSON service account"
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="gdrive-sa-folder" className="text-[11px]">
                    Folder ID (folder Drive yang dibagikan ke service account)
                  </Label>
                  <Input
                    id="gdrive-sa-folder"
                    value={saFolder}
                    onChange={(e) => setSaFolder(e.target.value)}
                    placeholder="1AbC… dari URL folder di Drive"
                    className="h-9 rounded-lg text-xs"
                  />
                </div>
                <Button
                  size="sm"
                  className="h-9 gap-1.5 rounded-lg"
                  onClick={() => void simpanSa()}
                  disabled={saBusy || !saKey.trim() || !saFolder.trim()}
                >
                  <KeyRound className="size-3.5" aria-hidden />
                  {saBusy ? "Memverifikasi…" : "Simpan & Verifikasi"}
                </Button>
              </div>
            ) : (
              <p className="text-xs">
                <b>Aktif</b> — {status?.sa.clientEmail}, folder{" "}
                <code className="font-mono text-[10px]">{status?.sa.folderId}</code>.
              </p>
            )}
          </div>

          {/* ===== Panduan setup ===== */}
          <Collapsible open={guideOpen} onOpenChange={setGuideOpen}>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 gap-1.5 rounded-lg px-2 text-[12px]">
                <HelpCircle className="size-3.5" aria-hidden />
                Panduan singkat setup Google (±10 menit, sekali saja)
                <ChevronDown className={`size-3.5 transition-transform ${guideOpen ? "rotate-180" : ""}`} aria-hidden />
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <div className="mt-2 space-y-3 rounded-xl border border-dashed bg-muted/30 p-4 text-xs leading-relaxed">
                <div>
                  <p className="font-bold">Yang perlu disiapkan (untuk kedua cara)</p>
                  <ol className="mt-1 list-decimal space-y-0.5 pl-5 text-muted-foreground">
                    <li>Buka <b>console.cloud.google.com</b> dengan akun Google Anda.</li>
                    <li>Buat project (mis. <i>Fixplus</i>) → menu <b>APIs &amp; Services → Library</b> → cari <b>Google Drive API</b> → <b>Enable</b>.</li>
                    <li>
                      <b>OAuth consent screen</b> → Internal/Testing → tambahkan email Anda sebagai
                      <i> test user</i> (wajib selama aplikasi berstatus Testing).
                    </li>
                  </ol>
                </div>
                <div>
                  <p className="font-bold">Cara A — OAuth (klik &quot;Hubungkan Google&quot;)</p>
                  <ol className="mt-1 list-decimal space-y-0.5 pl-5 text-muted-foreground">
                    <li>Credentials → <b>Create Credentials → OAuth client ID</b> → tipe <b>Web application</b>.</li>
                    <li>
                      Di <b>Authorized redirect URIs</b> tambahkan:
                      <code className="ml-1 break-all rounded bg-background px-1 py-0.5 font-mono text-[10px]">{uri}</code>
                    </li>
                    <li>Salin <b>Client ID</b> &amp; <b>Client Secret</b> ke kolom Cara A di atas.</li>
                    <li>Klik <b>Hubungkan Google</b> → pilih akun → <b>Allow</b> semua izin yang diminta.</li>
                  </ol>
                </div>
                <div>
                  <p className="font-bold">Cara B — Service Account (auto-backup)</p>
                  <ol className="mt-1 list-decimal space-y-0.5 pl-5 text-muted-foreground">
                    <li>IAM &amp; Admin → <b>Service Accounts</b> → <b>Create Service Account</b> (nama bebas, peran tidak perlu).</li>
                    <li>Buka akunnya → <b>Keys</b> → <b>Add Key → Create new key → JSON</b> → unduh file kunci.</li>
                    <li>Di Drive Anda: buat folder (mis. <i>Fixplus Backup</i>) → klik kanan → <b>Share</b> → tempel email service account (…@…iam.gserviceaccount.com) → peran <b>Editor</b>.</li>
                    <li>Salin <b>Folder ID</b> (bagian akhir URL folder) + isi kunci JSON ke kolom Cara B → <b>Simpan &amp; Verifikasi</b>.</li>
                  </ol>
                </div>
                <p className="text-muted-foreground">
                  Tips: aktifkan kedua jalur sekalian — OAuth untuk backup manual/pulihkan, Service
                  Account untuk auto-backup harian yang tak perlu disentuh lagi.
                </p>
              </div>
            </CollapsibleContent>
          </Collapsible>

          {/* ===== Backup & auto-backup ===== */}
          <div className="rounded-xl border p-4">
            <h3 className="mb-1 text-[13px] font-bold">Backup ke Drive &amp; Auto-Backup Harian</h3>
            <div className="mb-3 flex flex-wrap items-end gap-2">
              {bothReady && (
                <div className="space-y-1">
                  <Label className="text-[11px]">Jalur backup manual</Label>
                  <Select value={backupMethod} onValueChange={(v) => setBackupMethod(v as "auto" | "oauth" | "sa")}>
                    <SelectTrigger className="h-9 w-40 rounded-lg text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Otomatis (OAuth dahulu)</SelectItem>
                      <SelectItem value="oauth">OAuth</SelectItem>
                      <SelectItem value="sa">Service Account</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
              <Button
                className="h-9 gap-1.5 rounded-lg"
                onClick={() => void backupSekarang()}
                disabled={backupBusy || !anyReady || loading}
              >
                <CloudUpload className="size-4" aria-hidden />
                {backupBusy ? "Mengunggah…" : "Backup ke Drive Sekarang"}
              </Button>
              <span className="text-[11px] text-muted-foreground">
                File .db penuh (semua data) dengan nama bertanggal WIB.
              </span>
            </div>
            <SeparatorRow />
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <div className="flex items-start gap-2 sm:col-span-2">
                <Switch
                  id="gdrive-auto-enabled"
                  checked={autoEnabled}
                  onCheckedChange={setAutoEnabled}
                  aria-label="Aktifkan auto-backup harian"
                />
                <Label htmlFor="gdrive-auto-enabled" className="text-[13px] font-semibold">
                  Auto-backup setiap hari
                </Label>
                <span className="ml-auto text-[11px] text-muted-foreground">
                  {status?.lastAutoBackupDate ? `Terakhir otomatis: ${status.lastAutoBackupDate}` : "Belum pernah jalan"}
                </span>
              </div>
              <div className="space-y-1">
                <Label className="text-[11px]">Jam (WIB)</Label>
                <Select value={autoHour} onValueChange={setAutoHour}>
                  <SelectTrigger className="h-9 w-full rounded-lg text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="max-h-56">
                    {Array.from({ length: 24 }, (_, h) => (
                      <SelectItem key={h} value={String(h)}>
                        {String(h).padStart(2, "0")}:00
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-[11px]">Jalur auto-backup</Label>
                <Select value={autoMethod} onValueChange={(v) => setAutoMethod(v as "auto" | "oauth" | "sa")}>
                  <SelectTrigger className="h-9 w-full rounded-lg text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="auto">Otomatis (OAuth dahulu)</SelectItem>
                    <SelectItem value="oauth">OAuth</SelectItem>
                    <SelectItem value="sa">Service Account</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-[11px]">Simpan cadangan terakhir (biji)</Label>
                <Input
                  type="number"
                  min={1}
                  max={90}
                  value={autoKeep}
                  onChange={(e) => setAutoKeep(e.target.value)}
                  className="h-9 rounded-lg text-xs"
                />
              </div>
              <div className="flex items-end">
                <Button variant="outline" className="h-9 rounded-lg" onClick={() => void simpanAuto()} disabled={autoBusy}>
                  {autoBusy ? "Menyimpan…" : "Simpan Pengaturan Otomatis"}
                </Button>
              </div>
            </div>
            <p className="mt-2 text-[11px] text-muted-foreground">
              Jadwal berjalan di server — komputer/HP boleh dimatikan. Cadangan melebihi jumlah di
              atas otomatis dihapus dari Drive (kuota terjaga).
            </p>
          </div>

          {/* ===== Daftar cadangan di Drive ===== */}
          <div className="rounded-xl border p-4">
            <div className="mb-2 flex flex-wrap items-center gap-2">
              <h3 className="text-[13px] font-bold">Cadangan Tersimpan di Drive</h3>
              <span className="flex-1" />
              {bothReady && (
                <Select value={filesMethod} onValueChange={(v) => setFilesMethod(v as "auto" | "oauth" | "sa")}>
                  <SelectTrigger className="h-8 w-36 rounded-lg text-[11px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="auto">Otomatis</SelectItem>
                    <SelectItem value="oauth">OAuth</SelectItem>
                    <SelectItem value="sa">Service Account</SelectItem>
                  </SelectContent>
                </Select>
              )}
              <Button variant="outline" size="sm" className="h-8 gap-1 rounded-lg px-2 text-[11px]" onClick={() => void loadFiles()} disabled={filesBusy || !anyReady}>
                <RefreshCw className={`size-3.5 ${filesBusy ? "animate-spin" : ""}`} aria-hidden /> Muat daftar
              </Button>
            </div>
            {!anyReady ? (
              <p className="rounded-lg bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
                Hubungkan salah satu jalur di atas untuk melihat cadangan di Drive.
              </p>
            ) : files === null ? (
              <p className="text-xs text-muted-foreground">Klik “Muat daftar” untuk melihat cadangan.</p>
            ) : files.length === 0 ? (
              <p className="text-xs text-muted-foreground">
                Belum ada cadangan. Klik “Backup ke Drive Sekarang” untuk membuat yang pertama.
              </p>
            ) : (
              <div className="divide-y rounded-lg border">
                {files.map((f) => (
                  <div key={f.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 px-3 py-2">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[12px] font-semibold">{f.name}</p>
                      <p className="text-[10px] text-muted-foreground">
                        {fmtDate(f.createdTime)}
                        {f.size ? ` · ${fmtBytes(Number(f.size))}` : ""}
                      </p>
                    </div>
                    <div className="flex shrink-0 gap-1.5">
                      <Button variant="outline" size="sm" className="h-7 gap-1 rounded-md px-2 text-[10px]" onClick={() => setRestoreTarget(f)}>
                        <Undo2 className="size-3" aria-hidden /> Pulihkan
                      </Button>
                      <Button variant="outline" size="sm" className="h-7 gap-1 rounded-md px-2 text-[10px]" onClick={() => unduh(f)}>
                        <Download className="size-3" aria-hidden /> Unduh
                      </Button>
                      <Button variant="outline" size="sm" className="h-7 gap-1 rounded-md px-2 text-[10px] text-destructive" onClick={() => setDeleteTarget(f)}>
                        <Trash2 className="size-3" aria-hidden /> Hapus
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <p className="flex items-start gap-2 rounded-xl border border-dashed bg-muted/30 px-3 py-2.5 text-[11px] leading-relaxed text-muted-foreground">
            <Info className="mt-0.5 size-3.5 shrink-0" aria-hidden />
            Semua transfer ditangani server aplikasi (kredensial tidak pernah tersimpan di
            perangkat klien), dan setiap aksi backup/pulihkan tercatat di Log Aktivitas.
          </p>
        </>
      )}

      {/* ===== Dialog konfirmasi Pulihkan ===== */}
      <AlertDialog open={!!restoreTarget} onOpenChange={(v) => { if (!restoreBusy) setRestoreTarget(v ? restoreTarget : null); }}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Pulihkan dari Drive — Ganti Seluruh Database?</AlertDialogTitle>
            <AlertDialogDescription>
              Isi database akan DIGANTI dengan &quot;{restoreTarget?.name}&quot; (bukan digabung).
              Database saat ini otomatis disalin dulu sebagai berkas keamanan di server. Bila akun
              Anda tidak ada di file tersebut, sesi berakhir dan Anda login ulang dengan akun dari
              file cadangan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={restoreBusy}>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={(e) => { e.preventDefault(); void pulihkan(); }} disabled={restoreBusy}>
              {restoreBusy ? "Memulihkan…" : "Ya, Pulihkan"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ===== Dialog konfirmasi Hapus cadangan ===== */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => { if (!deleteBusy) setDeleteTarget(v ? deleteTarget : null); }}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Cadangan dari Drive?</AlertDialogTitle>
            <AlertDialogDescription>
              &quot;{deleteTarget?.name}&quot; akan dihapus permanen dari Google Drive. Cadangan
              lain tidak terpengaruh.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteBusy}>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); void hapusFile(); }}
              disabled={deleteBusy}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteBusy ? "Menghapus…" : "Hapus"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function SeparatorRow() {
  return <div className="h-px bg-border" aria-hidden />;
}
