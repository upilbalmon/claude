import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isValidPhone } from "@/lib/phone"; // T3 revisi Tahap 2

// GET /api/customers — daftar semua pelanggan (urut nama, ala repository.allCustomers)
export async function GET() {
  try {
    const customers = await db.customer.findMany({ orderBy: { name: "asc" } });
    return NextResponse.json(customers);
  } catch (e) {
    console.error("customers GET error", e);
    return NextResponse.json({ error: "Gagal memuat pelanggan" }, { status: 500 });
  }
}

// POST /api/customers — simpan pelanggan baru (ala saveCustomer id=0)
// D52: nama wajib, nomor WhatsApp OPSIONAL (boleh kosong) — bila diisi tetap
// divalidasi format (9–15 digit) supaya Blast WA tidak salah sasaran.
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const name = String(body.name ?? "").trim();
    const phone = String(body.phone ?? "").trim();
    if (!name) {
      return NextResponse.json({ error: "Nama pelanggan wajib diisi" }, { status: 400 });
    }
    // D52: nomor WA boleh dikosongkan — divalidasi HANYA bila diisi.
    if (phone && !isValidPhone(phone)) {
      return NextResponse.json(
        { error: "No WhatsApp tidak valid — masukkan 9–15 digit angka (contoh: 08123456789)" },
        { status: 400 }
      );
    }

    const customer = await db.customer.create({
      data: {
        name,
        phone,
        email: String(body.email ?? "").trim(),
        address: String(body.address ?? "").trim(),
        loyaltyPoints: toInt(body.loyaltyPoints, 0), // default Entities.kt: loyaltyPoints = 0
      },
    });

    await db.auditLog.create({
      data: {
        action: "TAMBAH_PELANGGAN",
        details: `${customer.name} (poin ${customer.loyaltyPoints})`,
        performedBy: String(body.performedBy ?? "Tidak diketahui"),
      },
    });

    return NextResponse.json(customer, { status: 201 });
  } catch (e) {
    console.error("customers POST error", e);
    return NextResponse.json({ error: "Gagal menyimpan pelanggan" }, { status: 500 });
  }
}

function toInt(v: unknown, fallback: number): number {
  const n = Math.trunc(Number(v));
  return Number.isFinite(n) && n >= 0 ? n : fallback;
}
