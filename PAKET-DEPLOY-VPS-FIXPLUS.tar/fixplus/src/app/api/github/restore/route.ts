import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { loadCreds, downloadFile, DEFAULT_BRANCH, DEFAULT_FOLDER, BACKUP_FILE_PREFIX, saveCreds } from "@/lib/github-backup";
import { performRestoreDb, isRestoreBusy } from "@/lib/db-restore";

// D68 — POST /api/github/restore — pulihkan database dari file cadangan di
// repo GitHub. Unduh file → prosedur GANTI DATABASE yang persis sama dengan
// unggahan manual (performRestoreDb): validasi SQLite, salinan keamanan,
// rollback otomatis bila gagal, penyembuhan kolom usang. Body:
// { requesterUsername, name }
export async function POST(req: NextRequest) {
  if (isRestoreBusy()) {
    return errAction("Sedang ada proses pulihkan database berjalan. Coba lagi sesaat.", 409);
  }
  const body = (await req.json().catch(() => ({}))) as {
    requesterUsername?: unknown;
    name?: unknown;
  };
  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const name = String(body.name ?? "").trim();
  if (
    !/^[\w.\-]+$/.test(name) ||
    !name.startsWith(BACKUP_FILE_PREFIX) ||
    !name.endsWith(".db")
  ) {
    return errAction("Nama file cadangan tidak valid", 400);
  }

  let buf: Buffer;
  try {
    const c = await loadCreds();
    if (!c.token || !c.repo) {
      return errAction("GitHub belum terhubung — simpan token & repo terlebih dahulu", 400);
    }
    const branch = c.branch ?? DEFAULT_BRANCH;
    const folder = (c.folder ?? DEFAULT_FOLDER).replace(/^\/+|\/+$/g, "");
    const path = folder ? `${folder}/${name}` : name;
    buf = await downloadFile(c.token, c.repo, branch, path);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("github restore download error", e);
    return errAction(msg, 400);
  }

  const result = await performRestoreDb(buf, name, actor.name, actor.username, buf.length);
  if (!result.ok) return errAction(result.error, result.status);
  // D77 — pemulihan manual sukses berarti pemilik sudah memilih versi data;
  // penanda konflik sinkronisasi lama dianggap selesai.
  try {
    await saveCreds({ conflict: null, lastAutoRestoreFile: name });
  } catch (e) {
    console.error("[github] gagal membersihkan penanda konflik:", e);
  }
  return NextResponse.json(result);
}
