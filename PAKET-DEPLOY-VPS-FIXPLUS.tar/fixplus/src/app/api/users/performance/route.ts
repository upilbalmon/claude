import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { err, resolveManager, withHeal } from "@/lib/users-guard";
import { difficultyPoints } from "@/lib/repair-utils";

// GET /api/users/performance?requesterUsername=… (D58)
// Poin kinerja TEKNISI untuk minggu berjalan — sumber kolom POIN di halaman
// Pengguna (Setting). Definisi minggu: Minggu 00:00 → Sabtu 23:59 (waktu
// server) sehingga poin otomatis "reset" setiap hari Minggu saat periodenya
// bergeser. Riwayat per periode lain tetap dilihat di Laporan → 5A.5 Kinerja
// Teknisi (memilih periode bebas).
// Poin per tiket selesai (SELESAI/DIAMBIL) = difficultyPoints(difficulty,
// pointsReward) — override kustom dipakai bila diisi, selain itu otomatis dari
// kesulitan (Rendah 10 / Sedang 25 / Tinggi 50). Tiket tanpa teknisi tidak
// dihitung ke siapa pun sampai Admin menugaskan teknisi lewat Edit tiket
// (penunjukan manual), poin mengikuti periode completedAt tiket.
export async function GET(req: NextRequest) {
  const manager = await resolveManager(
    req.nextUrl.searchParams.get("requesterUsername")
  );
  if (!manager) return err("Tidak berizin melihat kinerja pengguna", 403);
  try {
    return await withHeal(async () => {
      const now = new Date();
      const weekStart = new Date(now);
      weekStart.setHours(0, 0, 0, 0);
      // getDay(): 0 = Minggu — mundur ke Minggu 00:00 terakhir (hari ini bila Minggu)
      weekStart.setDate(now.getDate() - now.getDay());
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekStart.getDate() + 7);

      const repairs = await db.repairRecord.findMany({
        where: {
          status: { in: ["SELESAI", "DIAMBIL"] },
          completedAt: { gte: weekStart, lt: weekEnd },
        },
        select: { technicianName: true, difficulty: true, pointsReward: true },
      });

      const perNama: Record<string, { poin: number; selesai: number }> = {};
      for (const r of repairs) {
        const nama = r.technicianName?.trim();
        if (!nama) continue;
        const row = (perNama[nama] ??= { poin: 0, selesai: 0 });
        row.selesai += 1;
        row.poin += difficultyPoints(r.difficulty, r.pointsReward);
      }
      return NextResponse.json({ weekStart, weekEnd, perNama });
    });
  } catch (e) {
    console.error("users/performance GET error", e);
    return err("Gagal memuat poin kinerja pengguna", 500);
  }
}
