"use client";

// D75 — banner panduan pemulihan darurat (celah #2 rancangan sinkronisasi:
// "token hilang saat reset"). Token GitHub hidup di file terpisah
// (<dir db>/github-credentials.json) sehingga TIDAK hilang saat factory reset
// maupun restart server — tapi bila workspace benar-benar baru (file ikut
// hilang), satu-satunya jalan adalah memasukkan token & repo yang sama SEKALI:
// setelah terhubung, auto-restore langsung menarik cadangan terbaru.
// Banner ini muncul hanya bila: pengguna Admin + semua tabel bisnis kosong
// + (GitHub belum terhubung ATAU Pulihkan Otomatis mati) — persis kondisi di
// mana pemilik toko melihat aplikasi "byong" dan perlu tahu langkah pertama.
// Bisa ditutup satu sesi (sessionStorage) agar tidak mengganggu; muncul lagi
// pada sesi berikutnya selama data belum kembali.
import { useEffect, useRef, useState } from "react";
import { CloudOff, ShieldAlert, Settings2, X } from "lucide-react";
import type { SafeUser } from "@/lib/app-types";

const DISMISS_KEY = "sphp_recovery_banner_dismissed";

type DbStats = {
  customers: number;
  technicians: number;
  spare_parts: number;
  service_products: number;
  repair_records: number;
  transactions: number;
};

type GithubStatus = {
  configured: boolean;
  autoRestore: boolean;
  repo?: string;
};

export function RecoveryBanner({
  user,
  onOpenSettings,
}: {
  user: SafeUser;
  onOpenSettings: () => void;
}) {
  const [dismissed, setDismissed] = useState<boolean>(() => {
    // sessionStorage dibaca sekali saat mount — konsisten pola sidebarMin
    try {
      return typeof window !== "undefined" && sessionStorage.getItem(DISMISS_KEY) === "1";
    } catch {
      return false;
    }
  });
  const [state, setState] = useState<{
    mode: "unconfigured" | "autorestore-off" | null;
  }>({ mode: null });
  const alive = useRef(true);

  useEffect(() => {
    alive.current = true;

    const isAdmin = user.role === "Admin";
    if (!isAdmin) return;

    const check = async () => {
      try {
        const sRes = await fetch("/api/database/stats?requesterUsername=" + encodeURIComponent(user.username));
        if (!sRes.ok) return;
        const s = (await sRes.json()) as DbStats;
        const businessEmpty =
          s.customers === 0 &&
          s.technicians === 0 &&
          s.spare_parts === 0 &&
          s.service_products === 0 &&
          s.repair_records === 0 &&
          s.transactions === 0;
        if (!businessEmpty) {
          if (alive.current) setState({ mode: null });
          return;
        }
        const gRes = await fetch("/api/github/status?requesterUsername=" + encodeURIComponent(user.username));
        if (!gRes.ok) return;
        const g = (await gRes.json()) as GithubStatus;
        const mode = !g.configured
          ? "unconfigured"
          : g.autoRestore !== true
            ? "autorestore-off"
            : null;
        if (alive.current) setState({ mode });
      } catch {
        // jaringan gagal — biarkan state lama
      }
    };

    void check();
    // Auto-restore bisa butuh beberapa detik — periksa ulang agar banner hilang
    // segera setelah data kembali.
    const iv = setInterval(check, 20_000);
    return () => {
      alive.current = false;
      clearInterval(iv);
    };
  }, [user.role, user.username]);

  const dismiss = () => {
    setDismissed(true);
    try {
      sessionStorage.setItem(DISMISS_KEY, "1");
    } catch {
      /* abaikan */
    }
  };

  if (dismissed || !state.mode) return null;

  const unconfigured = state.mode === "unconfigured";

  return (
    <div
      role="alert"
      className="mx-auto mb-4 flex w-full max-w-6xl items-start gap-3 rounded-xl border border-amber-300 bg-amber-50 p-4 text-amber-950 dark:border-amber-500/40 dark:bg-amber-950/40 dark:text-amber-100"
    >
      {unconfigured ? (
        <CloudOff className="mt-0.5 size-5 shrink-0" aria-hidden />
      ) : (
        <ShieldAlert className="mt-0.5 size-5 shrink-0" aria-hidden />
      )}
      <div className="min-w-0 flex-1 text-sm">
        <p className="font-bold">
          {unconfigured
            ? "Data toko kosong & GitHub belum terhubung"
            : "Data toko kosong & Pulihkan Otomatis sedang mati"}
        </p>
        <p className="mt-1 leading-relaxed">
          {unconfigured
            ? "Hubungkan GitHub dengan token & repo yang sama (Pengaturan → Data & Backup). Begitu terhubung, cadangan terakhir otomatis dipulihkan dan semua data toko kembali. Token aman dari reset — ia tersimpan terpisah dari database."
            : "Hubungkan GitHub sudah aktif, tetapi Pulihkan Otomatis mati (biasanya karena factory reset terakhir). Nyalakan kembali di Pengaturan → Data & Backup agar data terakhir dipulihkan dan reset berikutnya pulih sendiri."}
        </p>
        <button
          type="button"
          onClick={onOpenSettings}
          className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-amber-900 px-3 py-1.5 text-xs font-bold text-white transition-colors hover:bg-amber-800 dark:bg-amber-200 dark:text-amber-950 dark:hover:bg-amber-100"
        >
          <Settings2 className="size-4" aria-hidden />
          Buka Pengaturan → Data &amp; Backup
        </button>
      </div>
      <button
        type="button"
        onClick={dismiss}
        aria-label="Tutup"
        className="rounded-lg p-1 transition-colors hover:bg-amber-100 dark:hover:bg-amber-900/50"
      >
        <X className="size-4" aria-hidden />
      </button>
    </div>
  );
}
