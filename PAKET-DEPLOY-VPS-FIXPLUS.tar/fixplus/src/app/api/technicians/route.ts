import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { resolveActor, errAction } from "@/lib/action-guard";
import { isValidPhone } from "@/lib/phone"; // T3 revisi Tahap 2
import { withHeal } from "@/lib/users-guard";

// D71 — daftar Teknisi = profil penugasan tiket yang TERTAUT ke akun Pengguna
// (role Teknisi). Tidak ada lagi dua daftar teknisi yang ambigu: akun dibuat
// Admin di halaman Pengguna, dan profil di sini otomatis dibuat/disinkronkan.
// Tambah/edit profil manual kini HANYA Admin (guard server-side), GET tetap
// terbuka karena kasir/teknisi butuh daftar ini untuk penugasan tiket.

// GET /api/technicians — daftar semua teknisi (urut nama) + info akun tertaut.
export async function GET() {
  try {
    return await withHeal(async () => {
      const technicians = await db.technician.findMany({
        orderBy: { name: "asc" },
        include: { user: { select: { username: true } } },
      });
      return NextResponse.json(
        technicians.map((t) => ({
          id: t.id,
          name: t.name,
          phone: t.phone,
          isAvailable: t.isAvailable,
          userId: t.userId,
          accountUsername: t.user?.username ?? null,
        }))
      );
    });
  } catch (e) {
    console.error("technicians GET error", e);
    return NextResponse.json({ error: "Gagal memuat teknisi" }, { status: 500 });
  }
}

// Cari akun Pengguna role Teknisi dengan nama sama (abaikan besar-kecil) yang
// BELUM tertaut ke profil manapun — untuk taut otomatis profil ↔ akun.
async function findUnlinkedTeknisiUser(name: string) {
  const candidates = await db.user.findMany({
    where: { role: "Teknisi" },
    select: { id: true, name: true, username: true },
  });
  const lower = name.trim().toLowerCase();
  for (const u of candidates) {
    if (u.name.trim().toLowerCase() !== lower) continue;
    const taken = await db.technician.findFirst({ where: { userId: u.id } });
    if (!taken) return u;
  }
  return null;
}

// D71 — tolak nama teknisi dobel (abaikan besar-kecil): satu orang satu entri.
async function findSameNameTechnician(name: string, excludeId?: number) {
  const all = await db.technician.findMany({ select: { id: true, name: true } });
  const lower = name.trim().toLowerCase();
  return (
    all.find((t) => t.name.trim().toLowerCase() === lower && t.id !== excludeId) ?? null
  );
}

// POST /api/technicians — tambah profil teknisi (HANYA Admin, D71).
// Bila sudah ada akun Pengguna role Teknisi dengan nama sama, profil langsung
// tertaut ke akun itu (mencegah dobel entri untuk orang yang sama).
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
    const actor = await resolveActor(body.requesterUsername);
    if (!actor) {
      return errAction("Hanya Admin yang dapat menambah teknisi — akun Teknisi dibuat di halaman Pengguna", 403);
    }
    const name = String(body.name ?? "").trim();
    if (!name) {
      return NextResponse.json({ error: "Nama teknisi wajib diisi" }, { status: 400 });
    }
    // T3 (revisi Tahap 2): telepon opsional — divalidasi hanya bila diisi.
    const phone = String(body.phone ?? "").trim();
    if (phone && !isValidPhone(phone)) {
      return NextResponse.json(
        { error: "Nomor telepon teknisi tidak valid — kosongkan atau isi 9–15 digit angka" },
        { status: 400 }
      );
    }
    const isAvailable = body.isAvailable === undefined ? true : Boolean(body.isAvailable);

    return await withHeal(async () => {
      const dobel = await findSameNameTechnician(name);
      if (dobel) {
        return NextResponse.json(
          { error: `Teknisi "${dobel.name}" sudah terdaftar — satu orang cukup satu entri` },
          { status: 409 }
        );
      }
      const linkUser = await findUnlinkedTeknisiUser(name);
      const technician = await db.technician.create({
        data: { name, phone, isAvailable, userId: linkUser?.id ?? null },
        include: { user: { select: { username: true } } },
      });

      await db.auditLog.create({
        data: {
          action: "TAMBAH_TEKNISI",
          details: `${technician.name} (${technician.isAvailable ? "Tersedia" : "Tidak Tersedia"})${linkUser ? ` — tertaut akun ${linkUser.username}` : " — tanpa akun pengguna"}`,
          performedBy: actor.name,
        },
      });

      return NextResponse.json(
        { ...technician, accountUsername: technician.user?.username ?? null },
        { status: 201 }
      );
    });
  } catch (e) {
    console.error("technicians POST error", e);
    return NextResponse.json({ error: "Gagal menyimpan teknisi" }, { status: 500 });
  }
}
