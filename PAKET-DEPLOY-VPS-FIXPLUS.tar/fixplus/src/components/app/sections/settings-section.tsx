"use client";

// Tahap 7 — Setting: Profil Toko (7.1) · Manajemen Pengguna (7.2) · Log Aktivitas (7.4).
// Ganti PIN sendiri (7.3) tersedia untuk SEMUA role lewat dropdown akun di topbar
// (kasir/teknisi tanpa izin Setting tetap bisa mengganti PIN-nya sendiri).
// Standar tabel mengikuti D10 (fin-table) — desktop tabel keuangan, mobile kartu.
// D39–D41 (parity lengkap SettingsSection.kt referensi):
//   · Tab "Tampilan" — Dark Mode + toggle "Edit Tanggal Transaksi" (ThemeSettings)
//   · Tab "Data & Backup" — statistik, cadangan JSON/.db, pulihkan JSON/CSV,
//     ekspor/impor CSV, reset per tabel (DatabaseSettings)
//   · Gerbang "Akses Terbatas" — tanpa izin Setting: pilih Admin + PIN
//     (SettingsSection.kt baris 102–209, selectUserAndAuthorize)
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  Database,
  Copy,
  Download,
  Eye,
  EyeOff,
  Factory,
  FileDown,
  FileSpreadsheet,
  FileUp,
  Info,
  Inbox,
  KeyRound,
  Lock,
  Moon,
  MoreHorizontal,
  Palette,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  ScrollText,
  Settings,
  Store,
  Sun,
  Trash2,
  Upload,
  Users,
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableHeader } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import {
  FinCountChip,
  FinIndexTd,
  FinRow,
  FinTd,
  FinTh,
} from "@/components/app/fin-table";
import { PHONE_HINT, isValidPhone } from "@/lib/phone";
import { GdriveCard } from "@/components/app/gdrive-settings"; // D67
import { GithubCard } from "@/components/app/github-settings"; // D68
import {
  PERMISSION_LABEL,
  PERMISSION_ORDER,
  USER_ROLES,
  rolePreset,
  validPinBaru,
  validUsername,
  type PermissionField,
} from "@/lib/user-utils";
import type { SafeUser } from "@/lib/app-types";

type AppUser = SafeUser & { createdAt?: string };
type AuditEntry = {
  id: number;
  action: string;
  details: string;
  performedBy: string;
  timestamp: string;
};

async function apiJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init);
  const data = (await res.json().catch(() => ({}))) as T & { error?: string };
  if (!res.ok) throw new Error(data.error ?? "Terjadi kesalahan");
  return data as T;
}

// ============================================================
// Wrapper — sub-tab ala InventorySection (header + Tabs).
// D41 — gerbang "Akses Terbatas": tanpa izin Setting, seluruh halaman
// diganti kartu kunci + pilih Admin + PIN 4-digit (persis referensi).
// ============================================================
export function SettingSection({
  user,
  onShopUpdated,
  onSwitchUser,
}: {
  user: SafeUser;
  onShopUpdated: (shopName: string) => void;
  // D41: sesi berpindah ke Admin yang PIN-nya cocok
  onSwitchUser: (u: SafeUser) => void;
}) {
  // D41 — persis `if (currentUser?.permissionSettings != true)` referensi:
  // halaman Setting hanya untuk pemegang izin "Setting".
  if (!user.permissionSettings) {
    return <RestrictedGate onSwitchUser={onSwitchUser} />;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="flex size-10 items-center justify-center rounded-xl bg-primary/10">
          <Settings className="size-5 text-primary" aria-hidden />
        </div>
        <div>
          <h1 className="text-xl font-bold">Setting</h1>
          <p className="text-sm text-muted-foreground">
            Profil toko, tampilan, data &amp; backup, pengguna &amp; izin, serta log aktivitas
          </p>
        </div>
      </div>

      <Tabs defaultValue="PROFIL">
        <TabsList className="w-full flex-wrap sm:w-auto">
          <TabsTrigger value="PROFIL" className="flex-1 gap-1.5 sm:flex-none">
            <Store className="size-4" aria-hidden />
            Profil Toko
          </TabsTrigger>
          <TabsTrigger value="TAMPILAN" className="flex-1 gap-1.5 sm:flex-none">
            <Palette className="size-4" aria-hidden />
            Tampilan
          </TabsTrigger>
          <TabsTrigger value="DATA" className="flex-1 gap-1.5 sm:flex-none">
            <Database className="size-4" aria-hidden />
            Data &amp; Backup
          </TabsTrigger>
          <TabsTrigger value="PENGGUNA" className="flex-1 gap-1.5 sm:flex-none">
            <Users className="size-4" aria-hidden />
            Pengguna
          </TabsTrigger>
          <TabsTrigger value="LOG" className="flex-1 gap-1.5 sm:flex-none">
            <ScrollText className="size-4" aria-hidden />
            Log Aktivitas
          </TabsTrigger>
        </TabsList>
        <TabsContent value="PROFIL" className="mt-4">
          <ProfilTokoTab user={user} onShopUpdated={onShopUpdated} />
        </TabsContent>
        <TabsContent value="TAMPILAN" className="mt-4">
          <TampilanTab user={user} />
        </TabsContent>
        <TabsContent value="DATA" className="mt-4">
          <DataBackupTab user={user} />
        </TabsContent>
        <TabsContent value="PENGGUNA" className="mt-4">
          <PenggunaTab user={user} />
        </TabsContent>
        <TabsContent value="LOG" className="mt-4">
          <LogAktivitasTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ============================================================
// D41 — Gerbang "Akses Terbatas (Butuh Hak Akses)" — parity referensi
// SettingsSection.kt baris 102–209: perangkat kasir bersama boleh membuka
// halaman Setting dengan memilih akun Admin + memasukkan PIN 4-digit.
// API /api/auth/login yang sama dipakai → salah PIN 5× terkunci otomatis.
// Berhasil → sesi berpindah ke Admin tersebut (selectUserAndAuthorize).
// ============================================================
function RestrictedGate({ onSwitchUser }: { onSwitchUser: (u: SafeUser) => void }) {
  const { toast } = useToast();
  const [admins, setAdmins] = useState<{ id: number; name: string; username: string }[]>([]);
  const [selected, setSelected] = useState("");
  const [pin, setPin] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    apiJson<{ id: number; name: string; username: string }[]>("/api/users/admins")
      .then((list) => {
        setAdmins(list);
        if (list.length === 1) setSelected(list[0].username);
      })
      .catch(() => setAdmins([]));
  }, []);

  async function buka() {
    if (!selected) return;
    try {
      setBusy(true);
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: selected, pin }),
      });
      const data = (await res.json().catch(() => ({}))) as {
        status?: string;
        user?: SafeUser;
        message?: string;
        lockSeconds?: number;
      };
      if (data.status === "SUCCESS" && data.user) {
        toast({
          title: "Akses Admin Diberikan!",
          description: `Masuk sebagai ${data.user.name} — halaman Setting terbuka.`,
        });
        onSwitchUser(data.user);
        return;
      }
      if (data.status === "LOCKED") {
        toast({
          title: "Akun terkunci sementara",
          description: `Sisa waktu: ${data.lockSeconds ?? 0} detik. Coba lagi nanti.`,
          variant: "destructive",
        });
      } else if (data.status === "MUST_CHANGE_PIN") {
        toast({
          title: "PIN wajib diganti dulu",
          description: "Keluar lalu login lewat halaman login untuk mengganti PIN.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "PIN Admin Salah!",
          description: data.message ?? "Periksa PIN 4-digit Admin yang dipilih.",
          variant: "destructive",
        });
        setPin("");
      }
    } catch {
      toast({ title: "Terjadi kesalahan", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-[60vh] items-center justify-center px-4">
      <div className="w-full max-w-[450px] rounded-2xl border bg-card p-6 shadow-sm">
        <div className="flex flex-col items-center gap-4 text-center">
          <div className="flex size-14 items-center justify-center rounded-2xl bg-destructive/10">
            <Lock className="size-8 text-destructive" aria-hidden />
          </div>
          <div className="space-y-1">
            <p className="text-lg font-bold">Akses Terbatas (Butuh Hak Akses)</p>
            <p className="text-[13px] leading-relaxed text-muted-foreground">
              Halaman pengaturan ini hanya dapat diakses oleh pengguna yang memiliki Hak Akses
              Pengaturan. Silakan masuk atau pilih akun yang berwenang untuk membuka kunci.
            </p>
          </div>

          {admins.length === 0 ? (
            <p className="text-xs font-medium text-destructive">
              Tidak ada user Admin terdaftar. Mohon hubungi developer.
            </p>
          ) : (
            <div className="w-full space-y-3">
              <Select value={selected} onValueChange={setSelected}>
                <SelectTrigger className="w-full rounded-xl">
                  <SelectValue placeholder="Pilih Admin" />
                </SelectTrigger>
                <SelectContent>
                  {admins.map((a) => (
                    <SelectItem key={a.id} value={a.username}>
                      {a.name} ({a.username})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className="relative">
                <Input
                  id="gate-pin"
                  value={pin}
                  onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
                  type={showPin ? "text" : "password"}
                  inputMode="numeric"
                  autoComplete="off"
                  className="rounded-xl pr-10 font-mono tracking-[0.4em]"
                  placeholder="PIN 4-Digit"
                  aria-label="Masukkan PIN 4-Digit Admin"
                />
                <button
                  type="button"
                  onClick={() => setShowPin((v) => !v)}
                  aria-label={showPin ? "Sembunyikan PIN" : "Tampilkan PIN"}
                  className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-muted-foreground hover:bg-muted"
                >
                  {showPin ? <EyeOff className="size-4" aria-hidden /> : <Eye className="size-4" aria-hidden />}
                </button>
              </div>

              <Button
                onClick={() => void buka()}
                disabled={busy || !selected || pin.length < 4}
                className="w-full rounded-xl"
              >
                {busy ? "Memeriksa…" : "Buka Pengaturan"}
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Sub-tab 1 — Profil Toko (7.1): nama + telepon dipakai top bar, login,
// footer struk & pesan WhatsApp ({toko}/{telepon_toko}).
// ============================================================
function ProfilTokoTab({
  user,
  onShopUpdated,
}: {
  user: SafeUser;
  onShopUpdated: (shopName: string) => void;
}) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [shopName, setShopName] = useState("");
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [receiptFooter, setReceiptFooter] = useState("");

  useEffect(() => {
    let alive = true;
    apiJson<{ shopName: string; address: string; phone: string; receiptFooter: string }>(
      "/api/settings"
    )
      .then((s) => {
        if (!alive) return;
        setShopName(s.shopName);
        setAddress(s.address);
        setPhone(s.phone);
        setReceiptFooter(s.receiptFooter);
      })
      .catch(() => {
        if (alive) toast({ title: "Gagal memuat profil toko", variant: "destructive" });
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [toast]);

  const phoneInvalid = phone.trim() !== "" && !isValidPhone(phone);

  async function simpan() {
    try {
      setSaving(true);
      const updated = await apiJson<{ shopName: string }>("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          shopName: shopName.trim(),
          address,
          phone: phone.trim(),
          receiptFooter,
          requesterUsername: user.username, // D34/D39: identitas diverifikasi server
        }),
      });
      onShopUpdated(updated.shopName);
      toast({
        title: "Profil toko tersimpan",
        description: "Nama di top bar, struk, dan pesan WhatsApp otomatis mengikuti.",
      });
    } catch (e) {
      toast({
        title: "Gagal menyimpan profil",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <div className="rounded-2xl border bg-card p-5 lg:col-span-2">
        <div className="mb-4 flex items-center gap-2">
          <Store className="size-4 text-primary" aria-hidden />
          <h2 className="text-sm font-bold uppercase tracking-wide">Profil Toko</h2>
        </div>
        {loading ? (
          <p className="py-8 text-center text-sm text-muted-foreground">Memuat…</p>
        ) : (
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="toko-nama">Nama Toko *</Label>
              <Input
                id="toko-nama"
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                placeholder="Contoh: Servis HP Jaya"
                className="rounded-xl"
              />
              <p className="text-xs text-muted-foreground">
                Tampil di top bar, halaman login, dan struk.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="toko-alamat">Alamat</Label>
              <Input
                id="toko-alamat"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Contoh: Jl. Merdeka No. 10, Bandung"
                className="rounded-xl"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="toko-telepon">Telepon</Label>
              <Input
                id="toko-telepon"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="08123456789"
                inputMode="tel"
                className="rounded-xl"
              />
              <p className="text-xs text-muted-foreground">
                {phoneInvalid
                  ? `Nomor tidak valid — ${PHONE_HINT}`
                  : "Dipakai pada pesan WhatsApp (placeholder {telepon_toko}). " + PHONE_HINT}
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="toko-footer">Footer Struk</Label>
              <Input
                id="toko-footer"
                value={receiptFooter}
                onChange={(e) => setReceiptFooter(e.target.value)}
                placeholder="Terima kasih telah berbelanja!"
                className="rounded-xl"
              />
              <p className="text-xs text-muted-foreground">
                Teks penutup di bagian bawah struk kasir 58mm.
              </p>
            </div>
            <div className="flex justify-end pt-2">
              <Button
                onClick={() => void simpan()}
                disabled={saving || shopName.trim() === "" || phoneInvalid}
                className="rounded-xl"
              >
                {saving ? "Menyimpan…" : "Simpan Profil"}
              </Button>
            </div>
          </div>
        )}
      </div>

      <div className="space-y-3 rounded-2xl border bg-accent/40 p-5">
        <div className="flex items-center gap-2">
          <Info className="size-4 text-primary" aria-hidden />
          <h2 className="text-sm font-bold uppercase tracking-wide">Di Mana Dipakai?</h2>
        </div>
        <ul className="space-y-2.5 text-[13px] leading-relaxed">
          <li className="flex gap-2">
            <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-primary" aria-hidden />
            <span><b>Nama toko</b> — top bar, sidebar, halaman login &amp; struk kasir.</span>
          </li>
          <li className="flex gap-2">
            <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-primary" aria-hidden />
            <span><b>Telepon</b> — placeholder <code className="rounded bg-muted px-1 font-mono text-[11px]">{"{telepon_toko}"}</code> pada template WhatsApp; <code className="rounded bg-muted px-1 font-mono text-[11px]">{"{toko}"}</code> untuk nama.</span>
          </li>
          <li className="flex gap-2">
            <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-primary" aria-hidden />
            <span><b>Footer struk</b> — dicetak di struk 58mm setelah blok pembayaran.</span>
          </li>
          <li className="flex gap-2">
            <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-primary" aria-hidden />
            <span>Perubahan tersimpan di server — berlaku untuk semua perangkat kasir.</span>
          </li>
        </ul>
        <Separator />
        <p className="text-xs text-muted-foreground">
          Template pesan WhatsApp per status tetap diedit dari modul Servis (tombol WhatsApp
          pada tiket); profil ini menyediakan nama &amp; telepon tokonya.
        </p>
      </div>
    </div>
  );
}

// ============================================================
// Sub-tab 2 — Tampilan (D39): parity ThemeSettings.kt referensi.
//   · Dark Mode — preferensi per perangkat (localStorage + class .dark di <html>,
//     script anti-flash ada di layout.tsx; referensi menyimpannya di perangkat juga).
//   · Edit Tanggal Transaksi — pengaturan operasional GLOBAL di server
//     (ShopSettings.editTransactionDate): bila aktif, kasir boleh mengubah
//     tanggal & waktu saat pembayaran; bila mati, klien tidak dapat memaksa.
// ============================================================
function TampilanTab({ user }: { user: SafeUser }) {
  const { toast } = useToast();
  const [dark, setDark] = useState(false);
  const [editDate, setEditDate] = useState(false);
  const [loading, setLoading] = useState(true);
  const [savingDate, setSavingDate] = useState(false);

  useEffect(() => {
    try {
      setDark(document.documentElement.classList.contains("dark"));
    } catch {
      setDark(false);
    }
    apiJson<{ editTransactionDate?: boolean }>("/api/settings")
      .then((s) => setEditDate(Boolean(s.editTransactionDate)))
      .catch(() => undefined)
      .finally(() => setLoading(false));
  }, []);

  function toggleDark(v: boolean) {
    setDark(v);
    try {
      document.documentElement.classList.toggle("dark", v);
      localStorage.setItem("sphp_theme", v ? "dark" : "light");
    } catch {
      // penyimpanan penuh — tema hanya berlaku sesi ini
    }
  }

  async function toggleEditDate(v: boolean) {
    try {
      setSavingDate(true);
      const updated = await apiJson<{ editTransactionDate: boolean }>("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requesterUsername: user.username, editTransactionDate: v }),
      });
      setEditDate(Boolean(updated.editTransactionDate));
      toast({
        title: v ? "Edit Tanggal Transaksi DIAKTIFKAN" : "Edit Tanggal Transaksi DIMATIKAN",
        description: v
          ? "Kasir kini bisa mengubah tanggal & waktu saat pembayaran."
          : "Tanggal & waktu transaksi mengikuti waktu server otomatis.",
      });
    } catch (e) {
      toast({
        title: "Gagal menyimpan pengaturan",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setSavingDate(false);
    }
  }

  return (
    <div className="space-y-4">
      {/* Tema — parity kartu "Pengaturan Tema Aplikasi" */}
      <div className="rounded-2xl border bg-card p-5">
        <div className="mb-1 flex items-center gap-2">
          <Palette className="size-4 text-primary" aria-hidden />
          <h2 className="text-sm font-bold uppercase tracking-wide">Pengaturan Tema Aplikasi</h2>
        </div>
        <p className="mb-4 text-xs text-muted-foreground">
          Pilih mode tampilan layar aplikasi yang paling nyaman untuk mata Anda.
        </p>
        <div className="flex items-center justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              {dark ? <Moon className="size-4" aria-hidden /> : <Sun className="size-4" aria-hidden />}
              <p className="text-sm font-semibold">Tema Gelap (Dark Mode)</p>
            </div>
            <p className="mt-0.5 text-xs text-muted-foreground">
              {dark
                ? "Aktif (Menghemat baterai & nyaman di malam hari)"
                : "Nonaktif (Menggunakan mode terang)"}
            </p>
          </div>
          <Switch checked={dark} onCheckedChange={toggleDark} aria-label="Toggle dark mode" />
        </div>
      </div>

      {/* Operasional — parity kartu "Pengaturan Operasional" */}
      <div className="rounded-2xl border bg-card p-5">
        <div className="mb-1 flex items-center gap-2">
          <Settings className="size-4 text-primary" aria-hidden />
          <h2 className="text-sm font-bold uppercase tracking-wide">Pengaturan Operasional</h2>
        </div>
        <p className="mb-4 text-xs text-muted-foreground">
          Konfigurasi fungsionalitas operasional kasir dan pencatatan transaksi.
        </p>
        {loading ? (
          <p className="py-4 text-center text-sm text-muted-foreground">Memuat…</p>
        ) : (
          <div className="flex items-center justify-between gap-4">
            <div className="min-w-0">
              <p className="text-sm font-semibold">Edit Tanggal Transaksi</p>
              <p className="mt-0.5 text-xs text-muted-foreground">
                {editDate
                  ? "Aktif (Bisa mengubah tanggal & waktu saat bayar kasir)"
                  : "Nonaktif (Menggunakan tanggal & waktu saat ini otomatis)"}
              </p>
            </div>
            <Switch
              checked={editDate}
              disabled={savingDate}
              onCheckedChange={(v) => void toggleEditDate(v)}
              aria-label="Toggle edit tanggal transaksi"
            />
          </div>
        )}
        <p className="mt-3 rounded-xl bg-muted/60 px-3 py-2 text-[11.5px] leading-relaxed text-muted-foreground">
          Berlaku global untuk semua perangkat kasir; perubahan dicatat di Log Aktivitas.
          Server menolak tanggal dari klien bila pengaturan ini mati.
        </p>
      </div>
    </div>
  );
}

// ============================================================
// Sub-tab 3 — Data & Backup (D40): parity DatabaseSettings.kt referensi.
// 1) Statistik  2) Cadangan JSON granular + file .db  3) Pulihkan JSON/CSV +
//    file .db penuh (D43)
// 4) Ekspor & Impor CSV  5) Reset per tabel  6) Google Sheets (tidak
// diimplementasikan — butuh kredensial cloud eksternal; alternatif CSV/JSON).
// Semua endpoint Admin-only (D34): requesterUsername diverifikasi server.
// ============================================================
type BackupEntityKey =
  | "customers"
  | "technicians"
  | "spare_parts"
  | "service_products"
  | "repair_records"
  | "transactions"
  | "users";

const ENTITIES: { key: BackupEntityKey; label: string }[] = [
  { key: "customers", label: "Data Pelanggan" },
  { key: "technicians", label: "Data Teknisi" },
  { key: "spare_parts", label: "Data Sparepart" },
  { key: "service_products", label: "Data Produk Jasa" },
  { key: "repair_records", label: "Data Tiket Servis" },
  { key: "transactions", label: "Data Transaksi Kasir" },
  { key: "users", label: "Data Pengguna (Akun & PIN)" },
];

// 4 tabel CSV persis referensi (+ Teknisi & Produk Jasa sebagai bonus)
const CSV_TABLES: { key: BackupEntityKey; label: string }[] = [
  { key: "customers", label: "Pelanggan" },
  { key: "spare_parts", label: "Sparepart / Inventaris" },
  { key: "repair_records", label: "Tiket Servis" },
  { key: "transactions", label: "Transaksi Kasir" },
  { key: "technicians", label: "Teknisi" },
  { key: "service_products", label: "Produk Jasa" },
];

type Stats = Record<string, number>;

function unduhBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

function DataBackupTab({ user }: { user: SafeUser }) {
  const { toast } = useToast();
  const [stats, setStats] = useState<Stats | null>(null);

  // cadangan
  const [backupSel, setBackupSel] = useState<Set<BackupEntityKey>>(
    () => new Set(ENTITIES.map((e) => e.key))
  );
  const [backupJson, setBackupJson] = useState("");
  const [backupBusy, setBackupBusy] = useState(false);

  // pulihkan
  const [restoreSel, setRestoreSel] = useState<Set<BackupEntityKey>>(
    () => new Set(ENTITIES.filter((e) => e.key !== "users").map((e) => e.key)) // Pengguna mati — persis referensi
  );
  const [restoreText, setRestoreText] = useState("");
  const [restoreConfirmOpen, setRestoreConfirmOpen] = useState(false);
  const [restoreBusy, setRestoreBusy] = useState(false);
  const [restoreResult, setRestoreResult] = useState<{ summary: string } | null>(null);
  const restoreFileRef = useRef<HTMLInputElement>(null);

  // CSV
  const [csvImportTable, setCsvImportTable] = useState<BackupEntityKey | null>(null);
  const [csvImportText, setCsvImportText] = useState("");
  const [csvConfirmOpen, setCsvConfirmOpen] = useState(false);
  const [csvBusy, setCsvBusy] = useState(false);
  const csvFileRef = useRef<HTMLInputElement>(null);

  // reset
  const [resetSel, setResetSel] = useState<Set<BackupEntityKey>>(new Set());
  const [resetConfirmOpen, setResetConfirmOpen] = useState(false);
  const [resetBusy, setResetBusy] = useState(false);

  // factory reset (D66) — hapus SEMUA data & semua akun, kembali ke kondisi pabrik
  const [factoryOpen, setFactoryOpen] = useState(false);
  const [factoryStep, setFactoryStep] = useState<1 | 2>(1);
  const [factoryAck, setFactoryAck] = useState(false);
  const [factoryPin, setFactoryPin] = useState("");
  const [factoryShow, setFactoryShow] = useState(false);
  const [factoryBusy, setFactoryBusy] = useState(false);

  // pulihkan file .db (D43) — ganti seluruh database dari file ekspor
  const [dbFile, setDbFile] = useState<File | null>(null);
  const [dbRestoreConfirmOpen, setDbRestoreConfirmOpen] = useState(false);
  const [dbRestoreBusy, setDbRestoreBusy] = useState(false);
  const dbRestoreFileRef = useRef<HTMLInputElement>(null);

  const loadStats = useCallback(async () => {
    try {
      const s = await apiJson<Stats>(
        `/api/database/stats?requesterUsername=${encodeURIComponent(user.username)}`
      );
      setStats(s);
    } catch (e) {
      toast({
        title: "Gagal memuat statistik",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    }
  }, [toast, user.username]);

  useEffect(() => {
    void loadStats();
  }, [loadStats]);

  const statsRows: { key: string; label: string }[] = [
    { key: "repair_records", label: "Tiket Servis" },
    { key: "customers", label: "Pelanggan" },
    { key: "spare_parts", label: "Sparepart" },
    { key: "technicians", label: "Teknisi" },
    { key: "service_products", label: "Produk Jasa" },
    { key: "transactions", label: "Transaksi Kasir" },
    { key: "users", label: "Pengguna Sistem" },
    { key: "audit_logs", label: "Log Audit" },
  ];

  function toggleSel(setter: typeof setBackupSel, key: BackupEntityKey) {
    setter((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }

  // ===== Cadangan =====
  async function unduhJson() {
    if (!backupSel.size) return;
    try {
      setBackupBusy(true);
      const res = await fetch(
        `/api/database/backup?entities=${[...backupSel].join(",")}&download=1&requesterUsername=${encodeURIComponent(user.username)}`
      );
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error ?? "Gagal backup");
      unduhBlob(await res.blob(), `cadangan-fixplus-${new Date().toISOString().slice(0, 10)}.json`);
      toast({ title: "Cadangan JSON tersimpan", description: "File .json berhasil diunduh." });
    } catch (e) {
      toast({
        title: "Gagal membuat cadangan",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setBackupBusy(false);
    }
  }

  async function salinJson() {
    if (!backupSel.size) return;
    try {
      setBackupBusy(true);
      const payload = await apiJson<Record<string, unknown>>(
        `/api/database/backup?entities=${[...backupSel].join(",")}&requesterUsername=${encodeURIComponent(user.username)}`
      );
      const text = JSON.stringify(payload, null, 2);
      setBackupJson(text);
      try {
        await navigator.clipboard.writeText(text);
        toast({ title: "Kode JSON disalin ke clipboard", description: `${text.length.toLocaleString("id-ID")} karakter.` });
      } catch {
        toast({ title: "Kode JSON siap", description: "Clipboard diblokir — salin manual dari kotak di bawah." });
      }
    } catch (e) {
      toast({
        title: "Gagal membuat cadangan",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setBackupBusy(false);
    }
  }

  async function unduhDb() {
    try {
      setBackupBusy(true);
      const res = await fetch(
        `/api/database/backup-db?requesterUsername=${encodeURIComponent(user.username)}`
      );
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error ?? "Gagal backup");
      unduhBlob(await res.blob(), `database-fixplus-${new Date().toISOString().slice(0, 10)}.db`);
      toast({ title: "File database (.db) tersimpan", description: "Simpan dengan aman — berisi seluruh data." });
    } catch (e) {
      toast({
        title: "Gagal mengekspor file .db",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setBackupBusy(false);
    }
  }

  // ===== Pulihkan (JSON) =====
  function bacaFileRestore(file: File) {
    const reader = new FileReader();
    reader.onload = () => setRestoreText(String(reader.result ?? ""));
    reader.readAsText(file);
  }

  async function imporJson() {
    if (!restoreText.trim() || !restoreSel.size) return;
    let data: Record<string, unknown>;
    try {
      data = JSON.parse(restoreText) as Record<string, unknown>;
    } catch {
      toast({ title: "JSON tidak valid", description: "Periksa kembali kode cadangan.", variant: "destructive" });
      return;
    }
    try {
      setRestoreBusy(true);
      const res = await apiJson<{ summary: string }>("/api/database/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requesterUsername: user.username,
          entities: [...restoreSel],
          data,
        }),
      });
      setRestoreResult({ summary: res.summary });
      toast({ title: "Impor selesai", description: res.summary });
      await loadStats();
    } catch (e) {
      toast({
        title: "Gagal memulihkan data",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setRestoreBusy(false);
      setRestoreConfirmOpen(false);
    }
  }

  // ===== CSV =====
  async function eksporCsv(table: BackupEntityKey, label: string) {
    try {
      const res = await fetch(
        `/api/database/csv?table=${table}&requesterUsername=${encodeURIComponent(user.username)}`
      );
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error ?? "Gagal ekspor");
      unduhBlob(await res.blob(), `fixplus_${table}.csv`);
      toast({ title: `CSV ${label} tersimpan`, description: "Bisa dibuka di Excel / Google Sheets." });
    } catch (e) {
      toast({
        title: "Gagal mengekspor CSV",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    }
  }

  function bacaFileCsv(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      setCsvImportText(String(reader.result ?? ""));
      setCsvConfirmOpen(true);
    };
    reader.readAsText(file);
  }

  async function imporCsv() {
    if (!csvImportTable || !csvImportText.trim()) return;
    try {
      setCsvBusy(true);
      const res = await apiJson<{ summary: string }>("/api/database/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requesterUsername: user.username,
          csv: { table: csvImportTable, text: csvImportText },
        }),
      });
      setRestoreResult({ summary: res.summary });
      toast({ title: "Impor CSV selesai", description: res.summary });
      await loadStats();
    } catch (e) {
      toast({
        title: "Gagal mengimpor CSV",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setCsvBusy(false);
      setCsvConfirmOpen(false);
      setCsvImportText("");
      setCsvImportTable(null);
    }
  }

  // ===== Reset =====
  async function resetDatabase() {
    if (!resetSel.size) return;
    try {
      setResetBusy(true);
      const res = await apiJson<{ summary: string }>("/api/database/reset", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requesterUsername: user.username, tables: [...resetSel] }),
      });
      toast({ title: "Reset selesai", description: res.summary });
      setResetSel(new Set());
      await loadStats();
    } catch (e) {
      toast({
        title: "Gagal mereset database",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setResetBusy(false);
      setResetConfirmOpen(false);
    }
  }

  // ===== Factory reset (D66) — hapus SEMUA data & semua akun =====
  function bukaFactoryReset() {
    setFactoryStep(1);
    setFactoryAck(false);
    setFactoryPin("");
    setFactoryShow(false);
    setFactoryOpen(true);
  }

  async function factoryReset() {
    if (factoryPin.length !== 4) return;
    try {
      setFactoryBusy(true);
      const res = await apiJson<{ summary: string; factoryAdminUsername: string }>(
        "/api/database/factory-reset",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ requesterUsername: user.username, pin: factoryPin }),
        }
      );
      toast({
        title: "Factory reset selesai",
        description: `${res.summary} Sesi berakhir — halaman login dimuat ulang…`,
      });
      setFactoryOpen(false);
      // Akun yang mengeksekusi ikut terhapus → buang sesi agar kembali ke
      // halaman login (kondisi pabrik: admin/1234 wajib ganti PIN).
      setTimeout(() => {
        try {
          sessionStorage.removeItem("sphp_user");
        } catch {
          // abaikan
        }
        window.location.reload();
      }, 2400);
    } catch (e) {
      toast({
        title: "Factory reset gagal",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
      setFactoryBusy(false);
    }
  }

  // ===== Pulihkan file .db (D43) — ganti seluruh database =====
  async function pulihkanDb() {
    if (!dbFile) return;
    try {
      setDbRestoreBusy(true);
      const fd = new FormData();
      fd.append("requesterUsername", user.username);
      fd.append("file", dbFile);
      const res = await fetch("/api/database/restore-db", { method: "POST", body: fd });
      const j = (await res.json().catch(() => ({}))) as {
        error?: string;
        summary?: string;
        sessionInvalid?: boolean;
        safetyCopy?: string;
      };
      if (!res.ok) throw new Error(j.error ?? "Gagal memulihkan database");
      setRestoreResult({ summary: j.summary ?? "Database diganti." });
      toast({
        title: j.sessionInvalid
          ? "Database dipulihkan — sesi berakhir"
          : "Database berhasil dipulihkan",
        description: `${j.summary ?? ""}${j.safetyCopy ? ` Salinan keamanan: ${j.safetyCopy.split("/").pop()}` : ""} Halaman dimuat ulang…`,
      });
      setDbFile(null);
      setTimeout(() => window.location.reload(), 2000);
    } catch (e) {
      toast({
        title: "Gagal memulihkan file .db",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setDbRestoreBusy(false);
      setDbRestoreConfirmOpen(false);
    }
  }

  return (
    <div className="space-y-4">
      {/* 1. Statistik — parity "Statistik Data Database" */}
      <div className="rounded-2xl border bg-card p-5">
        <div className="mb-3 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Database className="size-4 text-primary" aria-hidden />
            <h2 className="text-sm font-bold uppercase tracking-wide">Statistik Data Database</h2>
          </div>
          <Button variant="ghost" size="sm" className="h-8 gap-1.5 rounded-lg" onClick={() => void loadStats()}>
            <RefreshCw className={"size-3.5" + (stats === null ? " animate-spin" : "")} aria-hidden />
            Muat Ulang
          </Button>
        </div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {statsRows.map((r) => (
            <div key={r.key} className="rounded-xl border bg-accent/40 px-3 py-2.5">
              <p className="text-lg font-bold tabular-nums">
                {(stats?.[r.key] ?? 0).toLocaleString("id-ID")}
              </p>
              <p className="text-[11px] font-medium text-muted-foreground">{r.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* 2. Cadangan — parity "Ekspor File .db" + "Cadangkan / Impor Granular (JSON)" */}
      <div className="rounded-2xl border bg-card p-5">
        <div className="mb-1 flex items-center gap-2">
          <Download className="size-4 text-primary" aria-hidden />
          <h2 className="text-sm font-bold uppercase tracking-wide">Cadangkan (Backup)</h2>
        </div>
        <p className="mb-3 text-xs text-muted-foreground">
          Unduh seluruh file database, atau pilih tabel tertentu ke file teks JSON / salin ke clipboard.
        </p>
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => void unduhDb()} disabled={backupBusy} className="gap-1.5 rounded-xl">
            <FileDown className="size-4" aria-hidden />
            {backupBusy ? "Memproses…" : "Unduh File Database (.db)"}
          </Button>
          <Button variant="outline" onClick={() => void unduhJson()} disabled={backupBusy || !backupSel.size} className="gap-1.5 rounded-xl">
            <Download className="size-4" aria-hidden />
            Simpan JSON Terpilih
          </Button>
          <Button variant="outline" onClick={() => void salinJson()} disabled={backupBusy || !backupSel.size} className="gap-1.5 rounded-xl">
            <Copy className="size-4" aria-hidden />
            Salin Kode
          </Button>
        </div>
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {ENTITIES.map((e) => (
            <label
              key={e.key}
              className="flex cursor-pointer items-center gap-2.5 rounded-xl border px-3 py-2 text-[13px] font-medium hover:bg-muted/50"
            >
              <Checkbox
                checked={backupSel.has(e.key)}
                onCheckedChange={() => toggleSel(setBackupSel, e.key)}
                aria-label={`Cadangkan ${e.label}`}
              />
              {e.label}
            </label>
          ))}
        </div>
        {backupJson && (
          <div className="mt-3 space-y-1.5">
            <Label htmlFor="backup-json">Kode JSON Backup ({backupJson.length.toLocaleString("id-ID")} karakter)</Label>
            <textarea
              id="backup-json"
              readOnly
              value={backupJson}
              className="h-32 w-full rounded-xl border bg-muted/40 p-3 font-mono text-[11px] leading-snug"
            />
          </div>
        )}
      </div>

      {/* 3. Pulihkan — parity "Pilih File Cadangan (.json)" + "Impor Data Terpilih" */}
      <div className="rounded-2xl border bg-card p-5">
        <div className="mb-1 flex items-center gap-2">
          <Upload className="size-4 text-primary" aria-hidden />
          <h2 className="text-sm font-bold uppercase tracking-wide">Pulihkan / Impor Data</h2>
        </div>
        <p className="mb-3 text-xs text-muted-foreground">
          Impor selektif dari file cadangan JSON. Data yang sudah ada <b>tidak ditimpa</b> — hanya
          baris baru yang ditambahkan (dipadankan dari nomor telepon / nama / SKU / nomor invoice).
        </p>
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <input
              ref={restoreFileRef}
              type="file"
              accept=".json,application/json"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) bacaFileRestore(f);
                e.target.value = "";
              }}
            />
            <Button variant="outline" onClick={() => restoreFileRef.current?.click()} className="gap-1.5 rounded-xl">
              <FileUp className="size-4" aria-hidden />
              Pilih File Cadangan (.json)
            </Button>
            <span className="text-xs text-muted-foreground">atau tempel kode secara manual:</span>
          </div>
          <textarea
            value={restoreText}
            onChange={(e) => setRestoreText(e.target.value)}
            placeholder="Paste JSON Backup di sini…"
            className="h-28 w-full rounded-xl border p-3 font-mono text-[11px] leading-snug"
            aria-label="Tempel JSON cadangan"
          />
          <div>
            <p className="mb-1.5 text-xs font-semibold">Pilih Data Yang Akan Dipulihkan (Restore):</p>
            <div className="grid gap-2 sm:grid-cols-2">
              {ENTITIES.map((e) => (
                <label
                  key={e.key}
                  className="flex cursor-pointer items-center gap-2.5 rounded-xl border px-3 py-2 text-[13px] font-medium hover:bg-muted/50"
                >
                  <Checkbox
                    checked={restoreSel.has(e.key)}
                    onCheckedChange={() => toggleSel(setRestoreSel, e.key)}
                    aria-label={`Pulihkan ${e.label}`}
                  />
                  {e.label}
                </label>
              ))}
            </div>
            <p className="mt-1.5 text-[11px] text-muted-foreground">
              “Data Pengguna” mati secara bawaan agar akun login tidak tertimpa tak sengaja (persis referensi).
            </p>
          </div>
          <Button
            onClick={() => setRestoreConfirmOpen(true)}
            disabled={!restoreText.trim() || !restoreSel.size}
            className="rounded-xl"
          >
            Impor Data Terpilih
          </Button>
          {restoreResult && (
            <p className="rounded-xl bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-800">
              Hasil impor terakhir: {restoreResult.summary}
            </p>
          )}
        </div>
      </div>

      {/* 3b. Pulihkan file .db — D43: ganti seluruh database dari file
          "Unduh File Database (.db)"; semantik REPLACE, bukan merge */}
      <div className="rounded-2xl border bg-card p-5">
        <div className="mb-1 flex items-center gap-2">
          <Database className="size-4 text-primary" aria-hidden />
          <h2 className="text-sm font-bold uppercase tracking-wide">Pulihkan File Database (.db)</h2>
        </div>
        <p className="mb-3 text-xs text-muted-foreground">
          Ganti <b>seluruh</b> isi database dengan file .db hasil “Unduh File Database (.db)”
          — berbeda dengan impor JSON/CSV di atas yang hanya menambah baris baru. Cocok untuk
          pindah server atau membatalkan kesalahan besar. Database saat ini otomatis disalin
          dulu sebagai berkas keamanan di server sebelum diganti.
        </p>
        <div className="flex flex-wrap items-center gap-2">
          <input
            ref={dbRestoreFileRef}
            type="file"
            accept=".db,application/octet-stream"
            className="hidden"
            onChange={(e) => {
              setDbFile(e.target.files?.[0] ?? null);
              e.target.value = "";
            }}
          />
          <Button
            variant="outline"
            onClick={() => dbRestoreFileRef.current?.click()}
            disabled={dbRestoreBusy}
            className="gap-1.5 rounded-xl"
          >
            <FileUp className="size-4" aria-hidden />
            Pilih File Database (.db)
          </Button>
          {dbFile && (
            <span className="rounded-lg bg-muted px-2.5 py-1 text-xs font-semibold">
              {dbFile.name} ({Math.ceil(dbFile.size / 1024)} KB)
            </span>
          )}
          <Button
            onClick={() => setDbRestoreConfirmOpen(true)}
            disabled={!dbFile || dbRestoreBusy}
            className="rounded-xl"
          >
            Pulihkan Database
          </Button>
        </div>
        <p className="mt-2 text-[11px] font-semibold text-amber-700">
          Perhatian: data yang tidak ada di dalam file tersebut akan hilang. Jika akun Anda
          tidak terdapat di dalam file, sesi berakhir dan Anda harus login ulang dengan akun
          dari file tersebut.
        </p>
      </div>

      {/* 4. CSV — parity "4. Ekspor & Impor CSV" */}
      <div className="rounded-2xl border bg-card p-5">
        <div className="mb-1 flex items-center gap-2">
          <FileSpreadsheet className="size-4 text-primary" aria-hidden />
          <h2 className="text-sm font-bold uppercase tracking-wide">Ekspor &amp; Impor CSV</h2>
        </div>
        <p className="mb-3 text-xs text-muted-foreground">
          Kelola data secara modular dengan format standar CSV (kompatibel Excel). File hasil
          ekspor pasti dapat diimpor kembali.
        </p>
        <div className="grid gap-2 sm:grid-cols-2">
          {CSV_TABLES.map((t) => (
            <div key={t.key} className="flex items-center justify-between gap-2 rounded-xl border px-3 py-2">
              <span className="truncate text-[13px] font-semibold">{t.label}</span>
              <span className="flex shrink-0 gap-1.5">
                <Button variant="outline" size="sm" className="h-8 rounded-lg px-2.5 text-[11px]" onClick={() => void eksporCsv(t.key, t.label)}>
                  <Download className="size-3.5" aria-hidden /> Ekspor
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 rounded-lg px-2.5 text-[11px]"
                  onClick={() => {
                    setCsvImportTable(t.key);
                    csvFileRef.current?.click();
                  }}
                >
                  <Upload className="size-3.5" aria-hidden /> Impor
                </Button>
              </span>
            </div>
          ))}
        </div>
        <input
          ref={csvFileRef}
          type="file"
          accept=".csv,text/csv,text/plain"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f && csvImportTable) bacaFileCsv(f);
            e.target.value = "";
          }}
        />
      </div>

      {/* 5. Reset — parity "3. Reset Database" */}
      <div className="rounded-2xl border bg-destructive/5 p-5">
        <div className="mb-1 flex items-center gap-2">
          <AlertTriangle className="size-4 text-destructive" aria-hidden />
          <h2 className="text-sm font-bold uppercase tracking-wide text-destructive">Reset Database</h2>
        </div>
        <p className="mb-3 rounded-xl bg-destructive/10 px-3 py-2 text-xs font-semibold leading-relaxed text-destructive">
          PERINGATAN: Tindakan ini akan menghapus data terpilih secara permanen. Lakukan backup
          terlebih dahulu!
        </p>
        <div className="grid gap-2 sm:grid-cols-2">
          {ENTITIES.map((e) => (
            <label
              key={e.key}
              className="flex cursor-pointer items-center gap-2.5 rounded-xl border px-3 py-2 text-[13px] font-medium hover:bg-muted/50"
            >
              <Checkbox
                checked={resetSel.has(e.key)}
                onCheckedChange={() => toggleSel(setResetSel, e.key)}
                aria-label={`Reset ${e.label}`}
              />
              {e.key === "users" ? "Reset Semua Pengguna (Kecuali Anda)" : e.label}
            </label>
          ))}
        </div>
        <Button
          variant="destructive"
          onClick={() => setResetConfirmOpen(true)}
          disabled={!resetSel.size}
          className="mt-3 rounded-xl"
        >
          Reset Tabel Terpilih ({resetSel.size})
        </Button>
      </div>

      {/* 5b. Factory Reset — D66: hapus SEMUA data, kembali ke kondisi pabrik */}
      <div className="rounded-2xl border border-destructive/40 bg-destructive/5 p-5">
        <div className="mb-1 flex items-center gap-2">
          <Factory className="size-4 text-destructive" aria-hidden />
          <h2 className="text-sm font-bold uppercase tracking-wide text-destructive">Factory Reset — Hapus Semua Data</h2>
        </div>
        <p className="mb-3 rounded-xl bg-destructive/10 px-3 py-2 text-xs font-semibold leading-relaxed text-destructive">
          PERINGATAN: Mengembalikan aplikasi ke kondisi pabrik. SELURUH data dihapus permanen —
          transaksi kasir, tiket servis, inventaris, produk jasa, pelanggan, teknisi, pre-order,
          barang pesanan, log aktivitas, dan SEMUA akun pengguna (termasuk akun Anda). Profil toko
          kembali ke bawaan. Tindakan ini tidak dapat dibatalkan — lakukan backup terlebih dahulu!
        </p>
        <p className="mb-3 text-xs leading-relaxed text-muted-foreground">
          Berbeda dengan “Reset Database” di atas yang menyisakan akun Anda, factory reset
          menghapus semuanya. Setelah selesai, tersisa satu akun bawaan pabrik:{" "}
          <b>admin</b> dengan PIN <b>1234</b> (wajib diganti saat login pertama).
        </p>
        <Button variant="destructive" onClick={bukaFactoryReset} className="rounded-xl">
          <Factory className="size-4" aria-hidden /> Factory Reset Sekarang
        </Button>
      </div>

      {/* 6a. GitHub — D68: backup/pulihkan ke repo GitHub privat (gratis,
          tanpa Google Cloud) dengan auto-backup harian */}
      <GithubCard user={user} />

      {/* 6. Google Drive — D67: backup/pulihkan langsung ke Drive (OAuth +
          Service Account) dengan auto-backup harian, pengganti catatan D40 */}
      <GdriveCard user={user} />

      {/* ===== Dialog konfirmasi: Factory Reset (D66) — 2 langkah ===== */}
      <AlertDialog
        open={factoryOpen}
        onOpenChange={(v) => {
          if (!factoryBusy) setFactoryOpen(v);
          if (!v) setFactoryStep(1);
        }}
      >
        <AlertDialogContent className="rounded-2xl">
          {factoryStep === 1 ? (
            <>
              <AlertDialogHeader>
                <AlertDialogTitle>Factory Reset — Hapus SEMUA Data?</AlertDialogTitle>
                <AlertDialogDescription>
                  Aplikasi akan dikembalikan ke kondisi pabrik (seolah baru diinstal). Seluruh
                  data berikut dihapus permanen dan tidak dapat dikembalikan:
                </AlertDialogDescription>
              </AlertDialogHeader>
              <ul className="grid grid-cols-1 gap-1 rounded-xl border border-destructive/30 bg-destructive/5 px-3 py-2.5 text-xs font-medium text-foreground sm:grid-cols-2">
                <li>• Transaksi kasir &amp; dokumen refund</li>
                <li>• Tiket servis &amp; riwayatnya</li>
                <li>• Inventaris sparepart</li>
                <li>• Produk jasa</li>
                <li>• Pelanggan &amp; poin loyalitas</li>
                <li>• Teknisi</li>
                <li>• Pre-order &amp; barang pesanan</li>
                <li>• Log aktivitas (audit)</li>
                <li className="font-semibold text-destructive sm:col-span-2">• SEMUA akun pengguna — termasuk akun Anda</li>
              </ul>
              <p className="text-xs leading-relaxed text-muted-foreground">
                Profil toko diatur ulang ke bawaan. Tersisa satu akun pabrik: <b>admin / 1234</b>
                {" "}(wajib ganti PIN saat login pertama). Sesi Anda berakhir otomatis setelah
                proses selesai. Nomor urut data (ID) juga di-nol-kan kembali seperti database baru.
              </p>
              <label className="flex cursor-pointer items-start gap-2.5 rounded-xl border px-3 py-2.5 text-[13px] font-medium hover:bg-muted/50">
                <Checkbox
                  checked={factoryAck}
                  onCheckedChange={(v) => setFactoryAck(v === true)}
                  aria-label="Pernyataan pemahaman factory reset"
                  className="mt-0.5"
                />
                Saya paham semua data akan dihapus permanen dan tidak dapat dikembalikan.
              </label>
              <AlertDialogFooter>
                <AlertDialogCancel>Batal</AlertDialogCancel>
                <AlertDialogAction
                  disabled={!factoryAck}
                  onClick={(ev) => { ev.preventDefault(); setFactoryStep(2); }}
                >
                  Lanjut — Verifikasi PIN
                </AlertDialogAction>
              </AlertDialogFooter>
            </>
          ) : (
            <>
              <AlertDialogHeader>
                <AlertDialogTitle>Verifikasi PIN Admin</AlertDialogTitle>
                <AlertDialogDescription>
                  Masukkan PIN akun <b>{user.username}</b> untuk mengonfirmasi factory reset.
                  Seluruh data dan semua akun — termasuk milik Anda — akan dihapus permanen.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <div className="relative">
                <Input
                  id="factory-reset-pin"
                  value={factoryPin}
                  onChange={(e) => setFactoryPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
                  type={factoryShow ? "text" : "password"}
                  inputMode="numeric"
                  autoComplete="off"
                  placeholder="PIN 4 digit"
                  className="pr-10"
                />
                <button
                  type="button"
                  onClick={() => setFactoryShow((v) => !v)}
                  aria-label={factoryShow ? "Sembunyikan PIN" : "Tampilkan PIN"}
                  className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1 text-muted-foreground hover:bg-muted"
                >
                  {factoryShow ? <EyeOff className="size-4" aria-hidden /> : <Eye className="size-4" aria-hidden />}
                </button>
              </div>
              <AlertDialogFooter>
                <Button variant="outline" onClick={() => setFactoryStep(1)} disabled={factoryBusy}>
                  Kembali
                </Button>
                <AlertDialogAction
                  className="bg-destructive text-white hover:bg-destructive/90"
                  disabled={factoryBusy || factoryPin.length !== 4}
                  onClick={(ev) => { ev.preventDefault(); void factoryReset(); }}
                >
                  {factoryBusy ? "Menghapus semua data…" : "Ya, Hapus Semua Data"}
                </AlertDialogAction>
              </AlertDialogFooter>
            </>
          )}
        </AlertDialogContent>
      </AlertDialog>

      {/* ===== Dialog konfirmasi: Impor JSON ===== */}
      <AlertDialog open={restoreConfirmOpen} onOpenChange={setRestoreConfirmOpen}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Impor Data Terpilih?</AlertDialogTitle>
            <AlertDialogDescription>
              Data baru dari file cadangan akan ditambahkan untuk:{" "}
              <b>{ENTITIES.filter((e) => restoreSel.has(e.key)).map((e) => e.label).join(", ")}</b>.
              Data yang sudah ada tidak ditimpa. Lanjutkan?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction disabled={restoreBusy} onClick={(ev) => { ev.preventDefault(); void imporJson(); }}>
              {restoreBusy ? "Mengimpor…" : "Impor"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ===== Dialog konfirmasi: Impor CSV ===== */}
      <AlertDialog open={csvConfirmOpen} onOpenChange={setCsvConfirmOpen}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>
              Impor CSV {csvImportTable ? CSV_TABLES.find((t) => t.key === csvImportTable)?.label : ""}?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Baris baru dari file CSV akan ditambahkan; baris yang sudah terdaftar (nomor
              telepon/SKU/invoice sama) akan dilewati. Lanjutkan?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setCsvImportText("")}>Batal</AlertDialogCancel>
            <AlertDialogAction disabled={csvBusy} onClick={(ev) => { ev.preventDefault(); void imporCsv(); }}>
              {csvBusy ? "Mengimpor…" : "Impor"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ===== Dialog konfirmasi: Reset (teks persis referensi) ===== */}
      <AlertDialog open={resetConfirmOpen} onOpenChange={setResetConfirmOpen}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Konfirmasi Reset Database</AlertDialogTitle>
            <AlertDialogDescription>
              Apakah Anda benar-benar yakin ingin menghapus seluruh data pada tabel yang Anda
              pilih ({ENTITIES.filter((e) => resetSel.has(e.key)).map((e) => e.label).join(", ")})?
              Tindakan ini permanen dan tidak dapat dibatalkan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={resetBusy}
              onClick={(ev) => { ev.preventDefault(); void resetDatabase(); }}
            >
              {resetBusy ? "Mereset…" : "Ya, Reset Sekarang"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ===== Dialog konfirmasi: Pulihkan file .db (D43) ===== */}
      <AlertDialog open={dbRestoreConfirmOpen} onOpenChange={setDbRestoreConfirmOpen}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Ganti Database dengan “{dbFile?.name}”?</AlertDialogTitle>
            <AlertDialogDescription>
              SELURUH data saat ini akan diganti dengan isi file tersebut — menimpa semua
              tabel (pengguna, pelanggan, tiket, transaksi). Database saat ini tetap disalin
              otomatis sebagai berkas keamanan. Jika akun yang sedang dipakai tidak ada di
              dalam file, Anda akan diminta login ulang. Lanjutkan?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={dbRestoreBusy}
              onClick={(ev) => { ev.preventDefault(); void pulihkanDb(); }}
            >
              {dbRestoreBusy ? "Memulihkan…" : "Ya, Ganti Database"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ============================================================
// Sub-tab 4 — Manajemen Pengguna (7.2): CRUD, role, reset PIN, 7 izin.
// Gate: permissionUsers (server juga memverifikasi via requesterUsername).
// ============================================================
function PenggunaTab({ user }: { user: SafeUser }) {
  const { toast } = useToast();
  const [users, setUsers] = useState<AppUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  // form tambah/edit
  const [formOpen, setFormOpen] = useState(false);
  const [editId, setEditId] = useState(0); // 0 = tambah
  const [inputName, setInputName] = useState("");
  const [inputUsername, setInputUsername] = useState("");
  const [inputRole, setInputRole] = useState<string>("Kasir");
  const [inputPin, setInputPin] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [inputMustChange, setInputMustChange] = useState(true);
  const [izin, setIzin] = useState<Record<PermissionField, boolean>>(() => rolePreset("Kasir"));
  const [saving, setSaving] = useState(false);

  // dialog lain
  const [resetTarget, setResetTarget] = useState<AppUser | null>(null);
  const [resetPin, setResetPin] = useState("");
  const [resetShow, setResetShow] = useState(false);
  const [resetSaving, setResetSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<AppUser | null>(null);
  const [deleteSaving, setDeleteSaving] = useState(false);

  // D58 — poin kinerja teknisi minggu berjalan (reset otomatis tiap hari Minggu).
  // Kunci = nama teknisi pada tiket; akun Pengguna dicocokkan lewat nama (aba besar-kecil).
  const [poinPerNama, setPoinPerNama] = useState<Record<string, { poin: number; selesai: number }>>({});

  const load = useCallback(async () => {
    try {
      setLoading(true);
      const data = await apiJson<AppUser[]>(
        `/api/users?requesterUsername=${encodeURIComponent(user.username)}`
      );
      setUsers(data);
    } catch (e) {
      toast({
        title: "Gagal memuat pengguna",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
    // D58 — poin mingguan dimuat terpisah: bila gagal, daftar pengguna tetap tampil
    try {
      const perf = await apiJson<{ perNama: Record<string, { poin: number; selesai: number }> }>(
        `/api/users/performance?requesterUsername=${encodeURIComponent(user.username)}`
      );
      setPoinPerNama(perf.perNama ?? {});
    } catch {
      setPoinPerNama({});
    }
  }, [toast, user.username]);

  useEffect(() => {
    void load();
  }, [load]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return users;
    return users.filter(
      (u) =>
        u.name.toLowerCase().includes(q) || u.username.toLowerCase().includes(q)
    );
  }, [users, search]);

  function grantedList(u: AppUser): PermissionField[] {
    return PERMISSION_ORDER.filter((f) => Boolean(u[f]));
  }

  // D58 — poin minggu berjalan milik akun: hanya role Teknisi, dicocokkan dari
  // nama teknisi pada tiket selesai (nama akun harus sama dengan nama teknisi).
  function poinUser(u: AppUser): { poin: number; selesai: number } {
    if (u.role !== "Teknisi") return { poin: 0, selesai: 0 };
    const key = Object.keys(poinPerNama).find(
      (k) => k.toLowerCase() === u.name.trim().toLowerCase()
    );
    return key ? poinPerNama[key] : { poin: 0, selesai: 0 };
  }

  function openAdd() {
    setEditId(0);
    setInputName("");
    setInputUsername("");
    setInputRole("Kasir");
    setInputPin("");
    setShowPin(false);
    setInputMustChange(true);
    setIzin(rolePreset("Kasir"));
    setFormOpen(true);
  }

  function openEdit(u: AppUser) {
    setEditId(u.id);
    setInputName(u.name);
    setInputUsername(u.username);
    setInputRole(u.role);
    setInputPin("");
    setShowPin(false);
    setInputMustChange(u.mustChangePin);
    setIzin(
      Object.fromEntries(PERMISSION_ORDER.map((f) => [f, Boolean(u[f])])) as Record<
        PermissionField,
        boolean
      >
    );
    setFormOpen(true);
  }

  function applyRole(role: string) {
    setInputRole(role);
    setIzin(rolePreset(role));
  }

  const usernameInvalid = inputUsername.trim() !== "" && !validUsername(inputUsername);
  const selfEditing = editId === user.id;
  const pinInvalid = editId === 0 && !validPinBaru(inputPin);

  // D54 — checklist hidup: alasan tombol Simpan masih nonaktif, ditampilkan di atas tombol.
  // Aturan tetap sama (PIN awal bukan 1234/1111 — keputusan 7.2); yang diperbaiki adalah
  // umpan baliknya agar tidak terkesan "tombol rusak".
  const pinDefaultTertolak =
    editId === 0 && inputPin.length === 4 && (inputPin === "1234" || inputPin === "1111");
  const alasanSimpan: string[] = [];
  if (inputName.trim() === "") alasanSimpan.push("Isi Nama pengguna");
  if (inputUsername.trim() === "") {
    alasanSimpan.push("Isi Username");
  } else if (usernameInvalid) {
    alasanSimpan.push("Username 3–20 karakter: huruf/angka/titik/garis, tanpa spasi");
  }
  if (editId === 0) {
    if (inputPin.length !== 4) {
      alasanSimpan.push(`PIN awal harus 4 angka (baru ${inputPin.length} angka)`);
    } else if (pinDefaultTertolak) {
      alasanSimpan.push("PIN 1234 & 1111 tidak diizinkan (keamanan) — pakai angka lain, contoh 5678");
    }
  }

  async function simpan() {
    try {
      setSaving(true);
      if (editId === 0) {
        await apiJson("/api/users", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            requesterUsername: user.username,
            name: inputName.trim(),
            username: inputUsername.trim(),
            role: inputRole,
            pin: inputPin,
            mustChangePin: inputMustChange,
            ...izin,
          }),
        });
        toast({ title: "Pengguna ditambahkan", description: `${inputName.trim()} (${inputRole})` });
      } else {
        await apiJson(`/api/users/${editId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            requesterUsername: user.username,
            name: inputName.trim(),
            username: inputUsername.trim(),
            ...(selfEditing ? {} : { role: inputRole, ...izin }),
          }),
        });
        toast({ title: "Perubahan pengguna tersimpan" });
      }
      setFormOpen(false);
      await load();
    } catch (e) {
      toast({
        title: "Gagal menyimpan pengguna",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  async function simpanResetPin() {
    if (!resetTarget) return;
    try {
      setResetSaving(true);
      await apiJson(`/api/users/${resetTarget.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requesterUsername: user.username,
          newPin: resetPin,
        }),
      });
      toast({
        title: `PIN ${resetTarget.username} direset`,
        description: "Pengguna wajib mengganti PIN saat login berikutnya.",
      });
      setResetTarget(null);
      setResetPin("");
      await load();
    } catch (e) {
      toast({
        title: "Gagal reset PIN",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setResetSaving(false);
    }
  }

  async function simpanHapus() {
    if (!deleteTarget) return;
    try {
      setDeleteSaving(true);
      await apiJson(
        `/api/users/${deleteTarget.id}?requesterUsername=${encodeURIComponent(user.username)}`,
        { method: "DELETE" }
      );
      toast({ title: "Pengguna dihapus", description: deleteTarget.username });
      setDeleteTarget(null);
      await load();
    } catch (e) {
      toast({
        title: "Gagal menghapus pengguna",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setDeleteSaving(false);
    }
  }

  if (!user.permissionUsers) {
    return (
      <EmptyState
        icon={<KeyRound className="size-7 text-muted-foreground/50" aria-hidden />}
        message="Anda tidak memiliki izin Pengguna"
        hint="Hanya akun dengan izin “Pengguna” yang boleh mengelola akun lain. Minta Admin untuk memberikan izin ini."
      />
    );
  }

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-[200px] flex-1 sm:max-w-xs">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <Input
            id="cari-pengguna"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari nama / username…"
            className="rounded-xl pl-9"
          />
        </div>
        <FinCountChip count={filtered.length} unit="pengguna" />
        <Button onClick={openAdd} className="ml-auto gap-1.5 rounded-xl">
          <Plus className="size-4" aria-hidden />
          Tambah Pengguna
        </Button>
      </div>

      {loading ? (
        <p className="py-10 text-center text-sm text-muted-foreground">Memuat pengguna…</p>
      ) : (
        <>
          {/* Desktop — tabel keuangan (D10) */}
          <div className="hidden overflow-x-auto rounded-2xl border bg-card md:block xl:overflow-x-visible">
            <Table>
              <TableHeader>
                <tr>
                  <FinTh corner="first">No</FinTh>
                  <FinTh>Nama</FinTh>
                  <FinTh>Username</FinTh>
                  <FinTh>Role</FinTh>
                  <FinTh>Izin</FinTh>
                  <FinTh align="right">
                    <span title="Poin kesulitan tiket selesai minggu berjalan — otomatis direset tiap hari Minggu">
                      Poin (minggu ini)
                    </span>
                  </FinTh>
                  <FinTh align="center">PIN</FinTh>
                  <FinTh align="right">Aksi</FinTh>
                </tr>
              </TableHeader>
              <TableBody>
                {filtered.map((u, i) => (
                  <FinRow key={u.id} zebra>
                    <FinIndexTd>{i + 1}</FinIndexTd>
                    <FinTd className="font-semibold">{u.name}</FinTd>
                    <FinTd className="font-mono text-[12px]">{u.username}</FinTd>
                    <FinTd>
                      <Badge
                        className={
                          u.role === "Admin"
                            ? "rounded-full bg-primary text-primary-foreground"
                            : "rounded-full bg-primary-container text-on-primary-container"
                        }
                      >
                        {u.role}
                      </Badge>
                    </FinTd>
                    <FinTd>
                      <span
                        className="font-mono text-[11px] tabular-nums text-muted-foreground"
                        title={grantedList(u).map((f) => PERMISSION_LABEL[f]).join(", ") || "Tidak ada izin"}
                      >
                        {grantedList(u).length}/7 {grantedList(u).length === 7 ? "(semua)" : ""}
                      </span>
                    </FinTd>
                    <FinTd align="right">
                      {(() => {
                        const perf = poinUser(u);
                        return (
                          <span
                            className={perf.poin > 0 ? "font-bold tabular-nums text-primary" : "tabular-nums text-muted-foreground"}
                            title={
                              u.role === "Teknisi"
                                ? `${perf.selesai} tiket selesai minggu ini — poin = poin kesulitan (Rendah 10 / Sedang 25 / Tinggi 50). Reset tiap hari Minggu.`
                                : "Hanya akun Teknisi yang mengumpulkan poin servis"
                            }
                          >
                            {perf.poin.toLocaleString("id-ID")}
                          </span>
                        );
                      })()}
                    </FinTd>
                    <FinTd align="center">
                      {u.mustChangePin ? (
                        <Badge className="rounded-full bg-amber-100 text-amber-800">Wajib ganti</Badge>
                      ) : (
                        <span className="text-[11px] text-muted-foreground">OK</span>
                      )}
                    </FinTd>
                    <FinTd align="right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="size-8 rounded-lg" aria-label={`Aksi untuk ${u.username}`}>
                            <MoreHorizontal className="size-4" aria-hidden />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-44">
                          <DropdownMenuItem onClick={() => openEdit(u)}>
                            <Pencil className="size-4" aria-hidden /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => { setResetTarget(u); setResetPin(""); }}>
                            <KeyRound className="size-4" aria-hidden /> Reset PIN
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            disabled={u.id === user.id}
                            onClick={() => setDeleteTarget(u)}
                            className="font-semibold text-destructive focus:text-destructive"
                          >
                            <Trash2 className="size-4" aria-hidden /> Hapus
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </FinTd>
                  </FinRow>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={8} className="py-10 text-center text-sm text-muted-foreground">
                      Tidak ada pengguna yang cocok dengan pencarian.
                    </td>
                  </tr>
                )}
              </TableBody>
            </Table>
          </div>

          {/* Mobile — kartu */}
          <div className="space-y-3 md:hidden">
            {filtered.map((u) => (
              <div key={u.id} className="rounded-2xl border bg-card p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold">{u.name}</p>
                    <p className="font-mono text-xs text-muted-foreground">@{u.username}</p>
                  </div>
                  <Badge
                    className={
                      u.role === "Admin"
                        ? "rounded-full bg-primary text-primary-foreground"
                        : "rounded-full bg-primary-container text-on-primary-container"
                    }
                  >
                    {u.role}
                  </Badge>
                </div>
                <div className="mt-2 flex flex-wrap gap-1">
                  {grantedList(u).map((f) => (
                    <span key={f} className="rounded-md bg-muted px-1.5 py-0.5 text-[10.5px] font-semibold text-muted-foreground">
                      {PERMISSION_LABEL[f]}
                    </span>
                  ))}
                  {grantedList(u).length === 0 && (
                    <span className="text-[11px] text-muted-foreground">Tidak ada izin</span>
                  )}
                </div>
                {u.mustChangePin && (
                  <Badge className="mt-2 rounded-full bg-amber-100 text-amber-800">Wajib ganti PIN</Badge>
                )}
                {u.role === "Teknisi" && (
                  <p className="mt-2 text-xs text-muted-foreground">
                    Poin minggu ini:{" "}
                    <b className={poinUser(u).poin > 0 ? "text-primary" : "text-muted-foreground"}>
                      {poinUser(u).poin.toLocaleString("id-ID")}
                    </b>{" "}
                    ({poinUser(u).selesai} tiket) — reset tiap Minggu
                  </p>
                )}
                <div className="mt-3 flex gap-2 border-t pt-3">
                  <Button variant="outline" size="sm" className="flex-1 rounded-xl" onClick={() => openEdit(u)}>
                    <Pencil className="size-3.5" aria-hidden /> Edit
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1 rounded-xl" onClick={() => { setResetTarget(u); setResetPin(""); }}>
                    <KeyRound className="size-3.5" aria-hidden /> Reset PIN
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="rounded-xl text-destructive hover:text-destructive"
                    disabled={u.id === user.id}
                    onClick={() => setDeleteTarget(u)}
                  >
                    <Trash2 className="size-3.5" aria-hidden />
                  </Button>
                </div>
              </div>
            ))}
            {filtered.length === 0 && (
              <EmptyState message="Tidak ada pengguna yang cocok" hint="Ubah kata kunci pencarian." />
            )}
          </div>

          {/* D58 — catatan kolom Poin */}
          <p className="text-xs text-muted-foreground">
            Poin = poin kesulitan tiket selesai (Rendah 10 / Sedang 25 / Tinggi 50) milik akun Teknisi
            pada minggu berjalan — <b>otomatis direset tiap hari Minggu</b>. Tiket tanpa teknisi dapat
            ditunjuk manual lewat Edit tiket (pilih Teknisi Penanggung Jawab). Riwayat poin per periode
            hanya di Laporan → 5A.5 Kinerja Teknisi.
          </p>
        </>
      )}

      {/* Dialog Tambah/Edit */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-h-[92vh] overflow-y-auto rounded-2xl sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editId === 0 ? "Tambah Pengguna" : `Edit Pengguna — ${inputUsername}`}</DialogTitle>
            <DialogDescription>
              {editId === 0
                ? "Buat akun baru dengan role & izin akses per menu."
                : "Ubah data akun. Reset PIN dilakukan lewat aksi “Reset PIN”."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="user-nama">Nama *</Label>
              <Input id="user-nama" value={inputName} onChange={(e) => setInputName(e.target.value)} className="rounded-xl" placeholder="Contoh: Budi Santoso" />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="user-username">Username *</Label>
                <Input
                  id="user-username"
                  value={inputUsername}
                  onChange={(e) => setInputUsername(e.target.value)}
                  aria-invalid={usernameInvalid || undefined}
                  className="rounded-xl font-mono"
                  placeholder="budi"
                />
                <p
                  className={
                    usernameInvalid
                      ? "text-xs font-semibold text-destructive"
                      : "text-xs text-muted-foreground"
                  }
                >
                  {usernameInvalid
                    ? "3–20 karakter: huruf/angka/titik/garis, tanpa spasi"
                    : inputUsername.trim() !== ""
                      ? "Format OK — unik, dipakai untuk login"
                      : "Unik, dipakai untuk login"}
                </p>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="user-role">Role *</Label>
                <Select value={inputRole} onValueChange={(v) => applyRole(v)} disabled={selfEditing}>
                  <SelectTrigger id="user-role" className="rounded-xl">
                    <SelectValue placeholder="Pilih role" />
                  </SelectTrigger>
                  <SelectContent>
                    {USER_ROLES.map((r) => (
                      <SelectItem key={r} value={r}>{r}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {/* D71 — sinkronisasi akun Teknisi dengan daftar Teknisi */}
                {inputRole === "Teknisi" && (
                  <p className="text-[11px] leading-relaxed text-muted-foreground">
                    Akun Teknisi otomatis muncul di daftar Teknisi (Pelanggan → Teknisi) untuk
                    penugasan tiket servis — nama akun = nama teknisi, dan perubahan nama akun
                    ikut tersinkron.
                  </p>
                )}
              </div>
            </div>
            {editId === 0 && (
              <div className="space-y-1.5">
                <Label htmlFor="user-pin">PIN Awal *</Label>
                <div className="relative">
                  <Input
                    id="user-pin"
                    value={inputPin}
                    onChange={(e) => setInputPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
                    type={showPin ? "text" : "password"}
                    inputMode="numeric"
                    autoComplete="new-password"
                    aria-invalid={inputPin.length > 0 && !validPinBaru(inputPin) ? true : undefined}
                    className="rounded-xl pr-10 font-mono tracking-[0.4em]"
                    placeholder="••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPin((v) => !v)}
                    aria-label={showPin ? "Sembunyikan PIN" : "Tampilkan PIN"}
                    className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-muted-foreground hover:bg-muted"
                  >
                    {showPin ? <EyeOff className="size-4" aria-hidden /> : <Eye className="size-4" aria-hidden />}
                  </button>
                </div>
                <p
                  className={
                    inputPin.length > 0 && !validPinBaru(inputPin)
                      ? "text-xs font-semibold text-destructive"
                      : "text-xs text-muted-foreground"
                  }
                >
                  {inputPin.length > 0 && !validPinBaru(inputPin)
                    ? inputPin === "1234" || inputPin === "1111"
                      ? "PIN 1234 & 1111 dilarang (keamanan) — pakai angka lain, contoh 5678"
                      : "PIN wajib tepat 4 angka"
                    : inputPin.length === 4
                      ? "PIN siap — bukan PIN default"
                      : "4 angka — bukan PIN default (1234/1111)"}
                </p>
                <div className="flex items-center justify-between gap-3 rounded-xl border p-3">
                  <div className="min-w-0">
                    <Label htmlFor="user-mustchange" className="cursor-pointer">Wajib ganti PIN saat login pertama</Label>
                    <p className="mt-0.5 text-xs text-muted-foreground">Rekomendasi keamanan (ala akun contoh).</p>
                  </div>
                  <Switch id="user-mustchange" checked={inputMustChange} onCheckedChange={setInputMustChange} />
                </div>
              </div>
            )}
            {selfEditing && (
              <p className="rounded-xl bg-amber-50 px-3 py-2 text-xs font-semibold text-amber-800">
                Anda sedang mengedit akun sendiri — role &amp; izin hanya bisa diubah oleh Admin lain.
              </p>
            )}
            <div className="space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <Label>Izin Akses ({PERMISSION_ORDER.filter((f) => izin[f]).length}/7)</Label>
                <div className="flex gap-1.5">
                  {USER_ROLES.map((r) => (
                    <Button
                      key={r}
                      type="button"
                      variant="outline"
                      size="sm"
                      className="h-7 rounded-lg px-2 text-[11px]"
                      disabled={selfEditing}
                      onClick={() => applyRole(r)}
                    >
                      Preset {r}
                    </Button>
                  ))}
                </div>
              </div>
              <div className="grid gap-2 sm:grid-cols-2">
                {PERMISSION_ORDER.map((f) => (
                  <div key={f} className="flex items-center justify-between gap-3 rounded-xl border px-3 py-2">
                    <Label htmlFor={`izin-${f}`} className="cursor-pointer text-[13px]">
                      {PERMISSION_LABEL[f]}
                    </Label>
                    <Switch
                      id={`izin-${f}`}
                      checked={izin[f]}
                      disabled={selfEditing}
                      onCheckedChange={(v) => setIzin((s) => ({ ...s, [f]: v }))}
                    />
                  </div>
                ))}
              </div>
              <p className="text-xs text-muted-foreground">
                Preset role mengikuti akun contoh: Kasir = Kasir ✓ Servis ✓ Pelanggan ✓; Teknisi = Servis ✓; Admin = semua.
              </p>
            </div>
          </div>
          {!saving && alasanSimpan.length > 0 && (
            <div
              role="status"
              className="rounded-xl border border-amber-300 bg-amber-50 px-3 py-2.5 dark:border-amber-500/40 dark:bg-amber-950/40"
            >
              <p className="text-xs font-bold text-amber-900 dark:text-amber-200">
                Tombol Simpan menyala hijau setelah:
              </p>
              <ul className="mt-1 list-disc space-y-0.5 pl-4 text-xs font-medium text-amber-900 dark:text-amber-200">
                {alasanSimpan.map((a) => (
                  <li key={a}>{a}</li>
                ))}
              </ul>
            </div>
          )}
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setFormOpen(false)}>Batal</Button>
            <Button
              onClick={() => void simpan()}
              disabled={
                saving ||
                inputName.trim() === "" ||
                inputUsername.trim() === "" ||
                usernameInvalid ||
                (editId === 0 && (pinInvalid || inputPin.length !== 4))
              }
            >
              {saving ? "Menyimpan…" : "Simpan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog Reset PIN */}
      <Dialog open={resetTarget !== null} onOpenChange={(v) => !v && setResetTarget(null)}>
        <DialogContent className="rounded-2xl sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Reset PIN — {resetTarget?.username}</DialogTitle>
            <DialogDescription>
              Tentukan PIN sementara. Pengguna akan diminta mengganti PIN ini saat login berikutnya.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-1.5">
            <Label htmlFor="reset-pin">PIN Baru *</Label>
            <div className="relative">
              <Input
                id="reset-pin"
                value={resetPin}
                onChange={(e) => setResetPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
                type={resetShow ? "text" : "password"}
                inputMode="numeric"
                autoComplete="new-password"
                className="rounded-xl pr-10 font-mono tracking-[0.4em]"
                placeholder="••••"
              />
              <button
                type="button"
                onClick={() => setResetShow((v) => !v)}
                aria-label={resetShow ? "Sembunyikan PIN" : "Tampilkan PIN"}
                className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-muted-foreground hover:bg-muted"
              >
                {resetShow ? <EyeOff className="size-4" aria-hidden /> : <Eye className="size-4" aria-hidden />}
              </button>
            </div>
            <p className="text-xs text-muted-foreground">
              {resetPin.length > 0 && !validPinBaru(resetPin)
                ? "PIN wajib 4 angka & bukan 1234/1111"
                : "4 angka — bukan PIN default (1234/1111)"}
            </p>
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setResetTarget(null)}>Batal</Button>
            <Button onClick={() => void simpanResetPin()} disabled={resetSaving || !validPinBaru(resetPin)}>
              {resetSaving ? "Menyimpan…" : "Reset PIN"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Konfirmasi hapus — teks persis pola referensi */}
      <AlertDialog open={deleteTarget !== null} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Pengguna</AlertDialogTitle>
            <AlertDialogDescription>
              Apakah Anda yakin ingin menghapus pengguna &quot;{deleteTarget?.username}&quot; ({deleteTarget?.name})?
              Tindakan ini tidak dapat dibatalkan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={deleteSaving}
              onClick={() => void simpanHapus()}
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ============================================================
// Sub-tab 3 — Log Aktivitas (7.4): audit_logs baca-saja, terbaru dulu.
// ============================================================
function LogAktivitasTab() {
  const { toast } = useToast();
  const [logs, setLogs] = useState<AuditEntry[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");

  const load = useCallback(
    async (keyword?: string) => {
      try {
        setLoading(true);
        const key = (keyword ?? q).trim();
        const data = await apiJson<{ items: AuditEntry[]; total: number }>(
          `/api/audit-logs?take=200${key ? `&q=${encodeURIComponent(key)}` : ""}`
        );
        setLogs(data.items);
        setTotal(data.total);
      } catch (e) {
        toast({
          title: "Gagal memuat log aktivitas",
          description: String(e instanceof Error ? e.message : e),
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    },
    [q, toast]
  );

  useEffect(() => {
    void load("");
  }, []);

  function waktu(ts: string): string {
    const d = new Date(ts);
    return new Intl.DateTimeFormat("id-ID", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    }).format(d);
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-[200px] flex-1 sm:max-w-sm">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <Input
            id="cari-log"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && void load()}
            placeholder="Cari aksi / detail / pelaku…"
            className="rounded-xl pl-9"
          />
        </div>
        <Button variant="outline" onClick={() => void load()} className="gap-1.5 rounded-xl">
          <RefreshCw className={"size-4" + (loading ? " animate-spin" : "")} aria-hidden />
          Muat Ulang
        </Button>
        <FinCountChip count={logs.length} unit="entri" />
      </div>

      <div className="overflow-x-auto rounded-2xl border bg-card xl:overflow-x-visible">
        <Table>
          <TableHeader>
            <tr>
              <FinTh corner="first">No</FinTh>
              <FinTh>Waktu</FinTh>
              <FinTh>Aksi</FinTh>
              <FinTh>Detail</FinTh>
              <FinTh>Oleh</FinTh>
            </tr>
          </TableHeader>
          <TableBody>
            {logs.map((log, i) => (
              <FinRow key={log.id} zebra>
                <FinIndexTd>{i + 1}</FinIndexTd>
                <FinTd className="whitespace-nowrap font-mono text-[11.5px] tabular-nums text-muted-foreground">
                  {waktu(log.timestamp)}
                </FinTd>
                <FinTd>
                  <Badge variant="outline" className="rounded-md font-mono text-[10.5px] font-bold">
                    {log.action}
                  </Badge>
                </FinTd>
                <FinTd className="max-w-[420px] truncate" title={log.details}>
                  {log.details}
                </FinTd>
                <FinTd className="text-[12px]">{log.performedBy}</FinTd>
              </FinRow>
            ))}
            {logs.length === 0 && !loading && (
              <tr>
                <td colSpan={5} className="py-10 text-center text-sm text-muted-foreground">
                  Tidak ada log yang cocok.
                </td>
              </tr>
            )}
          </TableBody>
        </Table>
      </div>
      <p className="text-xs text-muted-foreground">
        Menampilkan {logs.length} entri terbaru dari total {total.toLocaleString("id-ID")} log (maks 200 per muatan).
      </p>

      {/* EmptyState dipakai bila pencarian kosong di mobile juga */}
      {logs.length === 0 && !loading && (
        <EmptyState
          icon={<Inbox className="size-7 text-muted-foreground/50" aria-hidden />}
          message="Belum ada log aktivitas"
          hint="Setiap operasi penting (tambah/edit/hapus, login, ganti PIN) otomatis tercatat di sini."
        />
      )}
    </div>
  );
}

function EmptyState({
  message,
  hint,
  icon,
}: {
  message: string;
  hint?: string;
  icon?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed bg-card/60 px-6 py-14 text-center">
      <div className="mb-3 flex size-14 items-center justify-center rounded-2xl bg-muted">
        {icon ?? <Inbox className="size-7 text-muted-foreground/50" aria-hidden />}
      </div>
      <p className="text-sm font-semibold">{message}</p>
      {hint && <p className="mt-1 max-w-sm text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}
