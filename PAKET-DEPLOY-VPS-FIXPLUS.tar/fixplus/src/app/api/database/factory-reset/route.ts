import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { generateSalt, hashPin } from "@/lib/pin-hash";
import { db } from "@/lib/db";
import { suppressAutoRestore, loadCreds, saveCreds } from "@/lib/github-backup";

// Factory Reset — D66: kembalikan aplikasi ke KONDISI PABRIK (fresh install).
//
// Berbeda dengan POST /api/database/reset (D40) yang mereset tabel terpilih dan
// SELALU menyisakan akun yang sedang login, factory reset menghapus SEMUA data:
//   · Transaksi kasir (termasuk dokumen refund & rantai refundOfId)
//   · Pre-order & barang pesanan (D61 — tidak tercakup reset per tabel)
//   · Tiket servis, sparepart, produk jasa, pelanggan, teknisi
//   · Log aktivitas (audit) — lalu ditulis ulang entri FACTORY_RESET sebagai jejak
//   · SEMUA akun pengguna (termasuk akun yang mengeksekusi — sesi berakhir)
// Lalu mengembalikan kondisi pabrik:
//   · Profil toko (ShopSettings) ke nilai bawaan
//   · Counter AUTOINCREMENT di-nol-kan (DELETE FROM sqlite_sequence) — persis
//     database baru: ID berikutnya mulai dari 1 lagi
//   · Satu akun bawaan: admin / 1234 (Administrator, wajib ganti PIN) — identik
//     seed pabrik D45/D55 di db-migrate.ts, sehingga toko tidak pernah terkunci
//
// Keamanan: hanya Admin (D34) + WAJIB PIN akun yang mengeksekusi — aksi paling
// destruktif di aplikasi (menghapus juga semua akun lain), lebih berat dari
// reset per tabel. PIN diverifikasi SERVER-side terhadap hash akun tersebut.
let busy = false;

export async function POST(req: NextRequest) {
  if (busy) return errAction("Sedang ada proses factory reset berjalan. Coba lagi sesaat.", 409);
  let body: { requesterUsername?: string; pin?: string };
  try {
    body = await req.json();
  } catch {
    return errAction("Body JSON tidak valid", 400);
  }
  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const pin = String(body.pin ?? "").trim();
  if (!pin) return errAction("PIN konfirmasi wajib diisi", 400);
  if (hashPin(pin, actor.salt) !== actor.pin) {
    return errAction("PIN salah — factory reset dibatalkan", 403);
  }

  busy = true;
  try {
    // D70 — SEBELUM data dihapus: blokir auto-pulihkan GitHub untuk sisa hidup
    // proses ini. Database sengaja dikosongkan; tanpa ini, penjadwal akan
    // melihat database "kosong" dan memulihkan cadangan lama (membatalkan reset).
    suppressAutoRestore();

    // 1. Hapus SEMUA data — urutan aman FK (anak → induk; rantai refund
    //    Transaction↔Transaction diputus dulu lewat updateMany refundOfId=null).
    const deleted: Record<string, number> = {};
    deleted.pre_orders = (await db.preOrder.deleteMany()).count;
    deleted.requested_items = (await db.requestedItem.deleteMany()).count;
    await db.transaction.updateMany({ data: { refundOfId: null } });
    deleted.transactions = (await db.transaction.deleteMany()).count;
    deleted.repair_records = (await db.repairRecord.deleteMany()).count;
    deleted.spare_parts = (await db.sparePart.deleteMany()).count;
    deleted.service_products = (await db.serviceProduct.deleteMany()).count;
    deleted.customers = (await db.customer.deleteMany()).count;
    deleted.technicians = (await db.technician.deleteMany()).count;
    deleted.audit_logs = (await db.auditLog.deleteMany()).count;
    deleted.users = (await db.user.deleteMany()).count; // SEMUA akun — sesi berakhir

    // 2. Counter ID kembali ke kondisi pabrik (database baru → ID mulai dari 1).
    //    sqlite_sequence belum ada bila belum pernah ada INSERT AUTOINCREMENT.
    try {
      await db.$executeRawUnsafe(
        `DELETE FROM sqlite_sequence WHERE name IN ('Customer','Technician','SparePart','RepairRecord','Transaction','User','ServiceProduct','PreOrder','RequestedItem','AuditLog')`
      );
    } catch {
      // abaikan — tabel internal belum ada
    }

    // 3. Profil toko kembali ke bawaan pabrik (identik seed db-migrate.ts).
    await db.shopSettings.upsert({
      where: { id: 1 },
      update: {
        shopName: "Servis HP & POS",
        address: "",
        phone: "",
        receiptFooter: "Terima kasih telah berbelanja!",
        waTemplates: "{}",
        editTransactionDate: false,
      },
      create: {
        id: 1,
        shopName: "Servis HP & POS",
        address: "",
        phone: "",
        receiptFooter: "Terima kasih telah berbelanja!",
        waTemplates: "{}",
        editTransactionDate: false,
      },
    });

    // 4. Akun pabrik satu-satunya: admin / 1234, wajib ganti PIN (D45/D55).
    const salt = generateSalt();
    await db.user.create({
      data: {
        name: "Administrator",
        username: "admin",
        role: "Admin",
        pin: hashPin("1234", salt),
        salt,
        mustChangePin: true,
        permissionDashboard: true,
        permissionCashier: true,
        permissionServices: true,
        permissionInventory: true,
        permissionCustomers: true,
        permissionUsers: true,
        permissionSettings: true,
      },
    });

    // 5. D70 — matikan pengaturan auto-pulihkan secara permanen (kalau aktif):
    //    bila tidak, setelah restart berikutnya database yang sengaja dikosongkan
    //    akan langsung diisi ulang cadangan lama secara otomatis.
    let autoRestoreNote = "";
    try {
      const c = await loadCreds();
      if (c.autoRestore === true) {
        await saveCreds({ autoRestore: false });
        autoRestoreNote = " Auto-pulihkan GitHub dimatikan otomatis agar data lama tidak kembali sendiri.";
      }
    } catch {
      // tanpa koneksi GitHub / file kredensial gagal — lewati saja
    }

    // 6. Jejak audit pertama di database yang baru dibersihkan.
    const summary =
      `Factory reset — aplikasi kembali ke kondisi pabrik. Dihapus: ` +
      `${deleted.transactions} transaksi, ${deleted.pre_orders} pre-order, ` +
      `${deleted.requested_items} barang pesanan, ${deleted.repair_records} tiket servis, ` +
      `${deleted.spare_parts} sparepart, ${deleted.service_products} produk jasa, ` +
      `${deleted.customers} pelanggan, ${deleted.technicians} teknisi, ` +
      `${deleted.audit_logs} log, ${deleted.users} akun. ` +
      `Tersisa akun pabrik admin/1234 (wajib ganti PIN).${autoRestoreNote}`;
    await db.auditLog.create({
      data: {
        action: "FACTORY_RESET",
        details: summary,
        performedBy: actor.name,
      },
    });

    return NextResponse.json({
      ok: true,
      deleted,
      summary,
      factoryAdminUsername: "admin",
      sessionInvalid: true, // akun executor ikut terhapus → UI memuat halaman login
    });
  } catch (e) {
    console.error("factory reset error", e);
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Gagal menjalankan factory reset" },
      { status: 500 }
    );
  } finally {
    busy = false;
  }
}
