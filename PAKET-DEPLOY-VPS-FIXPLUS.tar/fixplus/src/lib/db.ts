import { PrismaClient } from '@prisma/client'
import { markDataChange } from '@/lib/data-dirty'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

const basePrisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ['query'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = basePrisma

// D69 — catat setiap TULISAN data (create/update/delete/upsert) untuk
// auto-backup GitHub mode "per-perubahan". AuditLog dikecualikan: ia cerminan
// aksi (login, backup, dsb.), bukan data bisnis yang berubah — kalau ikut
// memicu, backup akan berjalan pada setiap aksi apa pun.
// D81 — AppNotification juga dikecualikan dengan alasan yang sama: notifikasi
// sering DITULIS OLEH PROSES BACKUP SENDIRI (sukses/gagal/konflik) — bila ikut
// menandai perubahan, backup baru akan terpicu oleh notifikasinya sendiri
// (lingkaran backup→notifikasi→backup).
const WRITE_ACTIONS = new Set([
  'create',
  'createMany',
  'createManyAndReturn',
  'update',
  'updateMany',
  'updateManyAndReturn',
  'delete',
  'deleteMany',
  'upsert',
])

export const db = basePrisma.$extends({
  query: {
    $allModels: {
      $allOperations({ model, operation, args, query }) {
        if (WRITE_ACTIONS.has(operation) && model !== 'AuditLog' && model !== 'AppNotification') {
          markDataChange()
          // D74 — setiap tulisan data bisnis menaikkan nomor urut versi (seq)
          // SETELAH tulisan berhasil — dipakai manifest.json GitHub untuk
          // mendeteksi data lokal yang lebih tua / lebih baru saat aplikasi
          // dibuka. Diantrekan agar tidak memperlambat respons.
          return query(args).then((r) => {
            bumpDataVersion()
            return r
          })
        }
        return query(args)
      },
    },
  },
})

// ===== D74 — nomor urut versi data (seq) di tabel AppMeta =====
//
// Paritas rancangan sinkronisasi pemilik: setiap perubahan data → seq +1.
// Disimpan di TABEL AppMeta (bukan file samping) supaya seq "berjalan bersama"
// datanya: ikut masuk snapshot .db saat backup dan kembali saat dipulihkan —
// sehingga perbandingan seq lokal vs manifest.json GitHub selalu menggambarkan
// versi data yang benar-benar ada di file database.
//
// Antrean (chain) menjamin dua tulisan beruntun menaikkan seq dua kali tanpa
// saling menimpa; hasil COUNT-nya deterministik. Semua akses lewat SQL mentah
// basePrisma — TIDAK lewat ekstensi di atas, agar bump tidak memicu bump.
const gSeq = globalThis as unknown as { __fixplusSeqChain?: Promise<unknown> }

function queueSeqWork(fn: () => Promise<unknown>): void {
  gSeq.__fixplusSeqChain = (gSeq.__fixplusSeqChain ?? Promise.resolve())
    .then(fn)
    .catch((e) => console.error('[data-version] gagal:', e))
}

// Naikkan seq +1 (naik sendiri bila barisnya belum ada). Fire-and-forget:
// kegagalan dicatat tapi tidak menggagalkan tulisan bisnis yang memicunya.
export function bumpDataVersion(): void {
  queueSeqWork(() =>
    basePrisma.$executeRawUnsafe(
      `INSERT INTO "AppMeta" ("key", "value") VALUES ('dataVersion', '1')
       ON CONFLICT ("key") DO UPDATE SET "value" = CAST("AppMeta"."value" AS INTEGER) + 1`
    )
  )
}

// Baca seq terkini (0 bila baris belum ada / tabel baru dibuat). Menunggu
// antrean bump supaya nilai yang dibaca mencakup semua tulisan yang selesai.
export async function getDataVersion(): Promise<number> {
  if (gSeq.__fixplusSeqChain) {
    try {
      await gSeq.__fixplusSeqChain
    } catch {
      // kegagalan antrean sudah dicatat — baca apa adanya
    }
  }
  const rows = await basePrisma.$queryRawUnsafe<{ v: number | bigint | null }[]>(
    `SELECT CAST("value" AS INTEGER) AS v FROM "AppMeta" WHERE "key" = 'dataVersion'`
  )
  return rows?.length ? Number(rows[0].v ?? 0) : 0
}

// Paksa seq ke nilai tertentu — dipakai SETELAH database dipulihkan dari
// GitHub: "Set seq lokal sama dengan GitHub" (langkah 4 alur restore), agar
// file cadangan lama (tanpa AppMeta) tidak terdeteksi "lebih tua" terus-menerus.
export async function setDataVersion(v: number): Promise<void> {
  const safe = Math.max(0, Math.trunc(v))
  await basePrisma.$executeRawUnsafe(
    `INSERT INTO "AppMeta" ("key", "value") VALUES ('dataVersion', ?)
     ON CONFLICT ("key") DO UPDATE SET "value" = ?`,
    String(safe),
    String(safe)
  )
}
