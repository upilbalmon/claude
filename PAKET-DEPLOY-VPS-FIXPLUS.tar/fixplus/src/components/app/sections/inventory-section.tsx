"use client";

// InventorySection.kt + InventoryViewModel.kt → versi web (Tahap 1)
// Sub-tab 1: Manajemen Sparepart (setia referensi: cari nama/SKU, urut Nama/Harga/Stok
// ▲▼, kartu ikon stok menipis, form markup otomatis 80%, dialog detail, konfirmasi hapus)
// Sub-tab 2: Produk Jasa (ServiceProduct — rencana item 1.3)
// D22: SKU kosong → diisi otomatis mengikuti pola data yang sudah ada (saranSku),
// saran mengikuti nama & bisa ditimpa manual; server juga mengisi bila kosong.
// D23 (D18/D19): field "Nama di Struk / Nota (Alias)" — saranAlias hanya PREFILL,
// manual-first (bebas diubah); struk/nota mencetak alias ?? nama.
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  CheckCircle2,
  CircleAlert,
  Inbox,
  Package,
  Plus,
  Search,
  TriangleAlert,
  Wrench,
  X,
  Zap,
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableHeader } from "@/components/ui/table";
import {
  FinCountChip,
  FinFootTd,
  FinIndexTd,
  FinRow,
  FinSortTh,
  FinTd,
  FinTh,
  FinTfoot,
} from "@/components/app/fin-table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/format";
import { saranSku, skuUnik } from "@/lib/sku-utils";
import { saranAlias } from "@/lib/alias-utils";
import { SPARE_CATEGORIES, SPARE_CATEGORY_LABEL, spareCategoryOf } from "@/lib/spare-category"; // D48/5C-1.1
import type { SafeUser } from "@/lib/app-types";

// Saran nama bila katalog masih kosong (persis InventorySection.kt)
const COMMON_PART_NAMES = [
  "LCD Fullset",
  "Baterai Original",
  "Konektor Charger",
  "Kamera Belakang",
  "Kamera Depan",
  "Flexible On Off",
  "Speaker Earphone",
  "Buzzer Speaker",
  "Tempered Glass",
  "Backdoor Casing",
  "Flexible Charger",
  "IC Power",
];

type SparePart = {
  id: number;
  name: string;
  alias?: string | null; // D23 (D18/D19): "Nama di Struk / Nota"
  sku: string;
  category?: string; // D48/5C-1.1: kategori barang (laporan 4 jalur pendapatan)
  stock: number;
  minStock: number;
  costPrice: number;
  sellPrice: number;
  location: string;
};

type ServiceProduct = {
  id: number;
  name: string;
  basePrice: number;
  points: number;
};

type SortKey = "NAMA" | "HARGA" | "STOK";
type JasaSortKey = "NAMA" | "HARGA";

const SORT_OPTIONS: { key: SortKey; label: string }[] = [
  { key: "NAMA", label: "Nama" },
  { key: "HARGA", label: "Harga" },
  { key: "STOK", label: "Stok" },
];

const digitsOnly = (s: string) => s.replace(/\D/g, "");

async function apiJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string }).error ?? "Terjadi kesalahan server");
  return data as T;
}

export function InventorySection({ user }: { user: SafeUser }) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="flex size-10 items-center justify-center rounded-xl bg-primary/10">
          <Package className="size-5 text-primary" aria-hidden />
        </div>
        <div>
          <h1 className="text-xl font-bold">Inventaris</h1>
          <p className="text-sm text-muted-foreground">
            Kelola stok sparepart &amp; katalog produk jasa
          </p>
        </div>
      </div>

      <Tabs defaultValue="SPAREPART">
        <TabsList className="w-full sm:w-auto">
          <TabsTrigger value="SPAREPART" className="flex-1 gap-1.5 sm:flex-none">
            <Package className="size-4" aria-hidden />
            Sparepart
          </TabsTrigger>
          <TabsTrigger value="JASA" className="flex-1 gap-1.5 sm:flex-none">
            <Wrench className="size-4" aria-hidden />
            Produk Jasa
          </TabsTrigger>
        </TabsList>
        <TabsContent value="SPAREPART" className="mt-4">
          <SparepartTab user={user} />
        </TabsContent>
        <TabsContent value="JASA" className="mt-4">
          <ServiceProductTab user={user} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ================= SPAREPART (InventorySection.kt) =================

function SparepartTab({ user }: { user: SafeUser }) {
  const { toast } = useToast();
  const [parts, setParts] = useState<SparePart[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortKey, setSortKey] = useState<SortKey>("NAMA");
  const [sortAscending, setSortAscending] = useState(true);

  // Dialog form
  const [formOpen, setFormOpen] = useState(false);
  const [editPartId, setEditPartId] = useState(0);
  const [inputName, setInputName] = useState("");
  const [inputSku, setInputSku] = useState("");
  const [inputAlias, setInputAlias] = useState(""); // D23 (D18/D19): Nama di Struk / Nota
  const [inputStock, setInputStock] = useState("");
  const [inputMinStock, setInputMinStock] = useState("");
  const [inputCostPrice, setInputCostPrice] = useState("");
  const [inputSellPrice, setInputSellPrice] = useState("");
  const [partPriceMode, setPartPriceMode] = useState<"Otomatis" | "Manual">("Otomatis");
  const [partMarkupPercent, setPartMarkupPercent] = useState("80");
  const [inputLocation, setInputLocation] = useState("");
  const [inputCategory, setInputCategory] = useState("SPAREPART"); // D48/5C-1.1
  const [isSaving, setIsSaving] = useState(false);

  // D22: SKU kosong → saran otomatis mengikuti pola data yang sudah ada
  // (PREFIX-SINGKATAN, cth. LCD-A14) + anti-tabrakan; saran mengikuti nama
  // sampai user mengedit SKU manual (prinsip aman dari kesalahan — bisa ditimpa).
  const skuDiubahManual = useRef(false);
  useEffect(() => {
    if (skuDiubahManual.current) return;
    const nama = inputName.trim();
    if (nama === "") {
      setInputSku("");
      return;
    }
    const taken = parts.filter((p) => p.id !== editPartId).map((p) => p.sku);
    setInputSku(skuUnik(saranSku(nama), taken));
  }, [inputName, parts, editPartId]);

  // D23 (D18/D19): alias hanya SARAN yang mengikuti nama (gaya user: "lcd xxxxx" → LCD)
  // sampai user mengedit manual — manual-first, tidak pernah memaksa.
  const aliasDiubahManual = useRef(false);
  useEffect(() => {
    if (aliasDiubahManual.current) return;
    const nama = inputName.trim();
    setInputAlias(nama === "" ? "" : saranAlias(nama));
  }, [inputName]);

  const [detailPart, setDetailPart] = useState<SparePart | null>(null);
  const [deletePart, setDeletePart] = useState<SparePart | null>(null);

  const refresh = useCallback(async () => {
    try {
      const data = await apiJson<SparePart[]>("/api/spare-parts");
      setParts(data);
    } catch (e) {
      toast({
        title: e instanceof Error ? e.message : "Gagal memuat sparepart",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  // LaunchedEffect referensi: harga jual otomatis = harga beli × (1 + markup/100)
  useEffect(() => {
    if (partPriceMode === "Otomatis") {
      const cost = Number(inputCostPrice) || 0;
      const markup = Number(partMarkupPercent) || 80;
      const calculated = cost * (1 + markup / 100.0);
      setInputSellPrice(String(Math.trunc(calculated)));
    }
  }, [partPriceMode, inputCostPrice, partMarkupPercent]);

  // filteredParts referensi: cari nama/SKU (ignoreCase) + urutan SortKey ▲▼
  const filteredParts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = parts.filter(
      (p) => p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q)
    );
    const sorted = [...list].sort((a, b) => {
      if (sortKey === "NAMA") return a.name.toLowerCase().localeCompare(b.name.toLowerCase());
      if (sortKey === "HARGA") return a.sellPrice - b.sellPrice;
      return a.stock - b.stock;
    });
    return sortAscending ? sorted : sorted.reverse();
  }, [parts, searchQuery, sortKey, sortAscending]);

  const lowStockParts = parts.filter((p) => p.stock <= p.minStock);

  // Footer total (D10): dihitung dari daftar yang tampil (ikut filter pencarian)
  const totalStockUnits = filteredParts.reduce((s, p) => s + p.stock, 0);
  // T7: nilai stok = harga SATUAN × jumlah stok (dulu menjumlah harga satuan saja — salah rumus)
  const totalCostValue = filteredParts.reduce((s, p) => s + p.costPrice * p.stock, 0);
  const totalSellValue = filteredParts.reduce((s, p) => s + p.sellPrice * p.stock, 0);

  // Klik header kolom gaya aplikasi keuangan: klik ulang = balik arah ▲▼
  function sortBy(k: SortKey) {
    if (k === sortKey) setSortAscending((v) => !v);
    else {
      setSortKey(k);
      setSortAscending(true);
    }
  }

  // Saran nama: katalog ada → pakai nama unik; kosong → daftar umum (persis referensi)
  const nameSuggestions = useMemo(() => {
    const suggestions = Array.from(new Set(parts.map((p) => p.name).filter((n) => n.trim() !== "")));
    const finalSuggestions = suggestions.length > 0 ? suggestions : COMMON_PART_NAMES;
    if (inputName.trim() !== "") {
      return finalSuggestions
        .filter(
          (n) => n.toLowerCase().includes(inputName.toLowerCase()) && n.toLowerCase() !== inputName.toLowerCase()
        )
        .slice(0, 5);
    }
    return finalSuggestions.slice(0, 4);
  }, [parts, inputName]);

  function openAddDialog() {
    // Nilai awal persis FAB referensi
    setEditPartId(0);
    setInputName("");
    setInputSku("");
    skuDiubahManual.current = false; // D22: saran SKU aktif lagi untuk tiket baru
    setInputAlias("");
    aliasDiubahManual.current = false; // D23: saran alias aktif lagi
    setInputStock("10");
    setInputMinStock("3");
    setInputCostPrice("100000");
    setInputSellPrice("180000");
    setPartPriceMode("Otomatis");
    setPartMarkupPercent("80");
    setInputLocation("Rak A-1");
    setInputCategory("SPAREPART"); // D48/5C-1.1
    setFormOpen(true);
  }

  function openEditDialog(part: SparePart) {
    setEditPartId(part.id);
    setInputName(part.name);
    setInputSku(part.sku);
    // D22: SKU sudah ada → jangan ditimpa saran; kosong → biarkan saran terisi
    skuDiubahManual.current = part.sku.trim() !== "";
    // D23: alias sudah diisi → anggap manual (tidak ditimpa saran); kosong → saran mengikuti nama
    setInputAlias(part.alias ?? "");
    aliasDiubahManual.current = (part.alias ?? "").trim() !== "";
    setInputStock(String(part.stock));
    setInputMinStock(String(part.minStock));
    setInputCostPrice(String(Math.trunc(part.costPrice)));
    setInputSellPrice(String(Math.trunc(part.sellPrice)));
    setPartPriceMode("Manual"); // persis referensi saat edit
    setPartMarkupPercent("80");
    setInputLocation(part.location);
    setInputCategory(spareCategoryOf(part.category)); // D48/5C-1.1
    setFormOpen(true);
  }

  async function savePart() {
    if (!inputName.trim()) {
      toast({ title: "Nama sparepart wajib diisi!", variant: "destructive" });
      return;
    }
    // T4 (revisi Tahap 2): SKU wajib unik antar-part — cek instan sebelum ke server
    // (banding aba besar-kecil; SKU kosong tidak dianggap duplikat).
    const skuTrim = inputSku.trim();
    if (skuTrim !== "") {
      const dup = parts.find(
        (p) => p.id !== editPartId && p.sku.trim().toLowerCase() === skuTrim.toLowerCase()
      );
      if (dup) {
        toast({
          title: `SKU "${skuTrim}" sudah dipakai oleh sparepart "${dup.name}"`,
          description: "Gunakan SKU lain agar stok antar-part tidak tertukar.",
          variant: "destructive",
        });
        return;
      }
    }
    setIsSaving(true);
    try {
      // T2 (revisi Tahap 2): 0 tersimpan 0 (= tanpa peringatan menipis);
      // hanya kosong/tidak valid yang kembali ke default 5 (Entities.kt).
      const parsedMinStock = Number.parseInt(inputMinStock, 10);
      const body = {
        name: inputName.trim(),
        sku: skuTrim,
        alias: inputAlias.trim(), // D23 (D18/D19): Nama di Struk / Nota (kosong → null di server)
        stock: Number(inputStock) || 0,
        minStock: Number.isFinite(parsedMinStock) && parsedMinStock >= 0 ? parsedMinStock : 5,
        costPrice: Number(inputCostPrice) || 0,
        sellPrice: Number(inputSellPrice) || 0,
        location: inputLocation,
        category: inputCategory, // D48/5C-1.1
        performedBy: user.name,
      };
      if (editPartId === 0) {
        await apiJson("/api/spare-parts", { method: "POST", body: JSON.stringify(body) });
        toast({ title: `Sparepart "${body.name}" tersimpan` });
      } else {
        await apiJson(`/api/spare-parts/${editPartId}`, {
          method: "PUT",
          body: JSON.stringify(body),
        });
        toast({ title: `Sparepart "${body.name}" diperbarui` });
      }
      setFormOpen(false);
      await refresh();
    } catch (e) {
      toast({
        title: e instanceof Error ? e.message : "Gagal menyimpan sparepart",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  }

  async function confirmDeletePart() {
    if (!deletePart) return;
    try {
      await apiJson(`/api/spare-parts/${deletePart.id}?requesterUsername=${encodeURIComponent(user.username)}`, {
        method: "DELETE",
      });
      toast({ title: `Sparepart "${deletePart.name}" dihapus` });
      setDetailPart(null);
      await refresh();
    } catch (e) {
      toast({
        title: e instanceof Error ? e.message : "Gagal menghapus sparepart",
        variant: "destructive",
      });
    } finally {
      setDeletePart(null);
    }
  }

  return (
    <div className="space-y-4">
      {/* Toolbar: judul + jumlah data + cari + urutkan (persis baris atas referensi) */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="me-auto flex items-center gap-2">
          <h2 className="text-base font-extrabold text-primary">Manajemen Sparepart</h2>
          <FinCountChip count={filteredParts.length} unit="item" />
        </div>
        <div className="relative w-full sm:w-64">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari Sparepart atau SKU..."
            className="h-9 rounded-xl pl-8 pr-8"
            aria-label="Cari Sparepart atau SKU"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery("")}
              aria-label="Bersihkan pencarian"
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-muted-foreground hover:text-foreground"
            >
              <X className="size-4" aria-hidden />
            </button>
          )}
        </div>
        <div className="flex gap-2 md:hidden">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="h-9 rounded-xl">
                Urut: {SORT_OPTIONS.find((o) => o.key === sortKey)?.label}
                <span aria-hidden>{sortAscending ? " ▲" : " ▼"}</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              {SORT_OPTIONS.map((o) => (
                <DropdownMenuItem key={o.key} onClick={() => sortBy(o.key)}>
                  {o.label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <Button
            variant="outline"
            size="icon"
            className="size-9 rounded-xl"
            onClick={() => setSortAscending((v) => !v)}
            aria-label={sortAscending ? "Urutan menaik" : "Urutan menurun"}
            title={sortAscending ? "Menaik" : "Menurun"}
          >
            {sortAscending ? <ArrowUp className="size-4" aria-hidden /> : <ArrowDown className="size-4" aria-hidden />}
          </Button>
        </div>
        <Button size="sm" className="h-9 rounded-xl" onClick={openAddDialog}>
          <Plus className="size-4" aria-hidden />
          Tambah Sparepart
        </Button>
      </div>

      {/* Peringatan stok menipis (item 1.2) */}
      {lowStockParts.length > 0 && (
        <div className="flex items-start gap-2.5 rounded-2xl border border-warning/40 bg-warning/10 p-3.5">
          <TriangleAlert className="mt-0.5 size-4 shrink-0 text-warning" aria-hidden />
          <p className="text-sm">
            <span className="font-bold text-warning">{lowStockParts.length} sparepart stok menipis:</span>{" "}
            <span className="text-muted-foreground">
              {lowStockParts.map((p) => `${p.name} (${p.stock}/${p.minStock})`).join(", ")}
            </span>
          </p>
        </div>
      )}

      {loading ? (
        <p className="py-10 text-center text-sm text-muted-foreground">Memuat sparepart…</p>
      ) : filteredParts.length === 0 ? (
        <EmptyState message="Stok sparepart kosong atau tidak ditemukan." hint="Tekan “Tambah Sparepart” untuk mengisi stok." />
      ) : (
        <>
          {/* Desktop: tabel standar industri keuangan (D10) — zebra, No. urut, angka rata
              kanan tabular-nums, header sticky bisa diurutkan, baris total di footer */}
          <div className="hidden overflow-x-auto rounded-2xl border bg-card shadow-sm md:block xl:overflow-x-visible">
            <Table>
              <TableHeader className="[&_tr]:border-b-0">
                <tr>
                  <FinTh corner="first" align="center" className="w-10">#</FinTh>
                  <FinSortTh label="Nama" k="NAMA" sortKey={sortKey} asc={sortAscending} onSort={sortBy} />
                  <FinTh>SKU</FinTh>
                  <FinTh>Lokasi</FinTh>
                  <FinSortTh label="Stok" k="STOK" sortKey={sortKey} asc={sortAscending} onSort={sortBy} align="right" />
                  <FinTh align="right">Min. Stok</FinTh>
                  <FinTh align="right">Harga Beli (HPP)</FinTh>
                  <FinSortTh label="Harga Jual" k="HARGA" sortKey={sortKey} asc={sortAscending} onSort={sortBy} align="right" />
                  <FinTh align="center" corner="last">Status</FinTh>
                </tr>
              </TableHeader>
              <TableBody>
                {filteredParts.map((part, i) => {
                  const isLow = part.stock <= part.minStock;
                  return (
                    <FinRow key={part.id} zebra={i % 2 === 1} onClick={() => setDetailPart(part)}>
                      <FinIndexTd>{i + 1}</FinIndexTd>
                      <FinTd>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setDetailPart(part);
                          }}
                          className="text-left font-bold hover:text-primary hover:underline"
                        >
                          {part.name}
                        </button>
                        {/* D23 (D18/D19): tampilkan Nama di Struk bila diisi */}
                        {(part.alias ?? "").trim() !== "" && (
                          <p className="text-[11px] font-normal text-muted-foreground">Struk: {part.alias}</p>
                        )}
                      </FinTd>
                      <FinTd className="font-mono text-[12px] text-muted-foreground">{part.sku || "—"}</FinTd>
                      <FinTd className="text-muted-foreground">{part.location || "—"}</FinTd>
                      <FinTd className={"text-right font-bold tabular-nums" + (isLow ? " text-destructive" : "")}>
                        {part.stock}
                      </FinTd>
                      <FinTd className="text-right tabular-nums text-muted-foreground">{part.minStock}</FinTd>
                      <FinTd className="text-right tabular-nums text-muted-foreground">{formatCurrency(part.costPrice)}</FinTd>
                      <FinTd className="text-right font-bold tabular-nums text-primary">{formatCurrency(part.sellPrice)}</FinTd>
                      <FinTd className="text-center">
                        {isLow ? (
                          <Badge variant="destructive" className="gap-1 rounded-lg">
                            <TriangleAlert className="size-3" aria-hidden />
                            Menipis
                          </Badge>
                        ) : (
                          <Badge className="gap-1 rounded-lg bg-success/15 text-success hover:bg-success/20">
                            <CheckCircle2 className="size-3" aria-hidden />
                            Aman
                          </Badge>
                        )}
                      </FinTd>
                    </FinRow>
                  );
                })}
              </TableBody>
              <FinTfoot>
                <tr>
                  <FinFootTd colSpan={4}>Total {filteredParts.length} item</FinFootTd>
                  <FinFootTd className="text-right text-[12px] normal-case tracking-normal tabular-nums">
                    {totalStockUnits} unit
                  </FinFootTd>
                  <FinFootTd aria-hidden />
                  <FinFootTd className="text-right text-[12px] normal-case tracking-normal tabular-nums">
                    {formatCurrency(totalCostValue)}
                  </FinFootTd>
                  <FinFootTd className="text-right text-[12px] normal-case tracking-normal tabular-nums text-primary">
                    {formatCurrency(totalSellValue)}
                  </FinFootTd>
                  <FinFootTd aria-hidden />
                </tr>
              </FinTfoot>
            </Table>
          </div>

          {/* Mobile: kartu */}
          <div className="grid gap-3 sm:grid-cols-2 md:hidden">
          {filteredParts.map((part) => {
            const isLow = part.stock <= part.minStock;
            return (
              <button
                key={part.id}
                type="button"
                onClick={() => setDetailPart(part)}
                className="rounded-2xl border bg-card p-4 text-left shadow-sm transition-shadow hover:shadow-md"
              >
                <p className="font-bold">{part.name}</p>
                {/* D23 (D18/D19): tampilkan Nama di Struk bila diisi */}
                {(part.alias ?? "").trim() !== "" && (
                  <p className="mt-0.5 text-xs font-medium text-primary/80">Struk: {part.alias}</p>
                )}
                {(part.sku || part.location) && (
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {[part.sku && `SKU ${part.sku}`, part.location].filter(Boolean).join(" · ")}
                  </p>
                )}
                <div className="mt-2.5 flex items-center gap-2">
                  <span className="text-[13px] text-muted-foreground">Stok: {part.stock}</span>
                  <span className="text-[13px] font-bold text-primary">{formatCurrency(part.sellPrice)}</span>
                  {isLow ? (
                    <Badge variant="destructive" className="ms-auto gap-1 rounded-lg">
                      <TriangleAlert className="size-3" aria-hidden />
                      Menipis
                    </Badge>
                  ) : (
                    <CheckCircle2 className="ms-auto size-5 text-success" aria-hidden />
                  )}
                </div>
              </button>
            );
          })}
          </div>
        </>
      )}

      {/* Dialog tambah/edit */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-h-[85dvh] overflow-y-auto rounded-2xl sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editPartId === 0 ? "Tambah Sparepart Baru" : "Edit Sparepart"}</DialogTitle>
            <DialogDescription>
              {editPartId === 0
                ? "Isi data sparepart, harga jual dihitung otomatis dari markup."
                : "Perbarui data sparepart sesuai kebutuhan."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3.5">
            <div className="space-y-1.5">
              <Label htmlFor="part-name">Nama Sparepart</Label>
              <Input
                id="part-name"
                value={inputName}
                onChange={(e) => setInputName(e.target.value)}
                placeholder="cth. LCD Fullset"
              />
              <div className="flex flex-wrap gap-1.5 pt-1">
                {nameSuggestions.map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => setInputName(n)}
                    className="rounded-lg border border-primary/25 bg-primary/8 px-2.5 py-1 text-[11px] font-medium text-primary transition-colors hover:bg-primary/15"
                  >
                    {n}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="part-sku">SKU / Kode Barang</Label>
              <Input
                id="part-sku"
                value={inputSku}
                onChange={(e) => {
                  skuDiubahManual.current = true; // D22: berhenti menimpa saran
                  setInputSku(e.target.value);
                }}
                placeholder="cth. LCD-IP11-FS"
              />
              {/* T4 + D22: aturan unik & auto-isi pola existing */}
              <p className="text-[11px] text-muted-foreground">
                Diisi otomatis mengikuti pola data yang ada (cth. LCD-A14), boleh ditimpa; SKU harus unik antar-part.
              </p>
            </div>
            {/* D23 (D18/D19): Nama di Struk / Nota (Alias) — saran hanya prefill, manual-first */}
            <div className="space-y-1.5">
              <Label htmlFor="part-alias">Nama di Struk / Nota (Alias)</Label>
              <Input
                id="part-alias"
                value={inputAlias}
                onChange={(e) => {
                  aliasDiubahManual.current = true; // berhenti menimpa saran setelah user mengedit
                  setInputAlias(e.target.value);
                }}
                placeholder="cth. LCD"
              />
              <p className="text-[11px] text-muted-foreground">
                Nama pendek yang dicetak di struk/nota (cth. &quot;LCD Fullset Samsung A14&quot; → &quot;LCD&quot;).
                Diisi saran otomatis &amp; boleh diubah; kosong = pakai nama lengkap.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="part-stock">Jumlah Stok</Label>
                <Input
                  id="part-stock"
                  inputMode="numeric"
                  value={inputStock}
                  onChange={(e) => setInputStock(digitsOnly(e.target.value))}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="part-minstock">Minimum Stok Peringatan</Label>
                <Input
                  id="part-minstock"
                  inputMode="numeric"
                  value={inputMinStock}
                  onChange={(e) => setInputMinStock(digitsOnly(e.target.value))}
                />
                {/* T2: jelaskan arti 0 agar tidak heran saat banner tidak muncul */}
                <p className="text-[11px] text-muted-foreground">0 = part ini tidak pernah masuk peringatan menipis.</p>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="part-cost">Harga Beli Toko (HPP) (Rp)</Label>
              <Input
                id="part-cost"
                inputMode="numeric"
                value={inputCostPrice}
                onChange={(e) => setInputCostPrice(digitsOnly(e.target.value))}
              />
            </div>
            <div className="space-y-2">
              <p className="text-xs font-bold text-muted-foreground">Metode Penentuan Harga Jual Retail</p>
              <div className="grid grid-cols-2 gap-2">
                {(["Otomatis", "Manual"] as const).map((mode) => (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => setPartPriceMode(mode)}
                    className={
                      "rounded-lg px-3 py-2.5 text-xs font-bold transition-colors " +
                      (partPriceMode === mode
                        ? "bg-primary text-primary-foreground"
                        : "bg-primary/10 text-primary hover:bg-primary/20")
                    }
                  >
                    {mode === "Otomatis" ? "Otomatis (Markup %)" : "Ketik Manual"}
                  </button>
                ))}
              </div>
              {partPriceMode === "Otomatis" && (
                <div className="space-y-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="part-markup">Persentase Markup (%)</Label>
                    <Input
                      id="part-markup"
                      inputMode="numeric"
                      placeholder="Default: 80"
                      value={partMarkupPercent}
                      onChange={(e) => setPartMarkupPercent(digitsOnly(e.target.value))}
                    />
                  </div>
                  <div className="flex gap-1.5">
                    {[50, 80, 100, 120, 150].map((pct) => {
                      const active = partMarkupPercent === String(pct);
                      return (
                        <button
                          key={pct}
                          type="button"
                          onClick={() => setPartMarkupPercent(String(pct))}
                          className={
                            "flex-1 rounded-md border py-1.5 text-[11px] font-bold transition-colors " +
                            (active
                              ? "border-primary bg-primary/15 text-primary"
                              : "border-border bg-muted text-secondary-foreground")
                          }
                        >
                          {pct}%
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
              <div className="space-y-1.5">
                <Label htmlFor="part-sell">
                  {partPriceMode === "Otomatis" ? "Harga Jual Terhitung (Rp)" : "Harga Jual Retail (Rp)"}
                </Label>
                <Input
                  id="part-sell"
                  inputMode="numeric"
                  disabled={partPriceMode === "Otomatis"}
                  value={inputSellPrice}
                  onChange={(e) => {
                    if (partPriceMode === "Manual") setInputSellPrice(digitsOnly(e.target.value));
                  }}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="part-location">Lokasi Penyimpanan (Rak/Laci)</Label>
              <Input
                id="part-location"
                value={inputLocation}
                onChange={(e) => setInputLocation(e.target.value)}
                placeholder="cth. Rak A-1"
              />
            </div>
            {/* D48/5C-1.1 — kategori barang untuk laporan 4 jalur pendapatan */}
            <div className="space-y-1.5">
              <Label htmlFor="part-category">Kategori (untuk Laporan)</Label>
              <select
                id="part-category"
                value={inputCategory}
                onChange={(e) => setInputCategory(e.target.value)}
                className="h-10 w-full rounded-xl border bg-background px-3 text-sm"
              >
                {SPARE_CATEGORIES.map((c) => (
                  <option key={c} value={c}>{SPARE_CATEGORY_LABEL[c]}</option>
                ))}
              </select>
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="ghost" onClick={() => setFormOpen(false)} disabled={isSaving}>
              Batal
            </Button>
            <Button onClick={savePart} disabled={isSaving || !inputName.trim()}>
              {isSaving ? "Menyimpan…" : "Simpan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog detail (SparePartDetailDialog.kt) */}
      <Dialog open={detailPart !== null} onOpenChange={(v) => !v && setDetailPart(null)}>
        <DialogContent className="rounded-2xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Detail Sparepart</DialogTitle>
          </DialogHeader>
          {detailPart && (
            <div className="space-y-3">
              <div>
                <p className="text-[11px] text-muted-foreground">Nama Sparepart</p>
                <p className="text-base font-bold">{detailPart.name}</p>
                {/* D23 (D18/D19): Nama di Struk / Nota */}
                <p className="mt-0.5 text-[12px] text-muted-foreground">
                  Nama di Struk/Nota: <b className="text-foreground">{detailPart.alias?.trim() || "—"}</b>
                </p>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-[11px] text-muted-foreground">SKU / Kode</p>
                  <p className="text-sm font-medium">{detailPart.sku || "-"}</p>
                </div>
                <div>
                  <p className="text-[11px] text-muted-foreground">Lokasi Penyimpanan</p>
                  <p className="text-sm font-medium">{detailPart.location || "-"}</p>
                </div>
              </div>
              <Separator />
              {/* D48/5C-1.1 — kategori tampil di detail */}
              <div>
                <p className="text-[11px] text-muted-foreground">Kategori (untuk Laporan)</p>
                <p className="text-sm font-medium">{SPARE_CATEGORY_LABEL[spareCategoryOf(detailPart.category)] ?? detailPart.category ?? "Sparepart"}</p>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-[11px] text-muted-foreground">Harga Beli (HPP)</p>
                  <p className="text-sm font-semibold">{formatCurrency(detailPart.costPrice)}</p>
                </div>
                <div>
                  <p className="text-[11px] text-muted-foreground">Harga Jual Retail</p>
                  <p className="text-sm font-bold text-primary">{formatCurrency(detailPart.sellPrice)}</p>
                </div>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-[11px] text-muted-foreground">Stok Saat Ini</p>
                  <p
                    className={
                      "text-sm font-bold " +
                      (detailPart.stock <= detailPart.minStock ? "text-destructive" : "text-success")
                    }
                  >
                    {detailPart.stock} unit
                  </p>
                </div>
                <div>
                  <p className="text-[11px] text-muted-foreground">Minimum Stok</p>
                  <p className="text-sm font-medium">{detailPart.minStock} unit</p>
                </div>
              </div>
            </div>
          )}
          <DialogFooter className="gap-2 sm:gap-2">
            <Button
              variant="outline"
              className="border-destructive text-destructive hover:bg-destructive/10 hover:text-destructive"
              onClick={() => {
                setDeletePart(detailPart);
                setDetailPart(null);
              }}
            >
              Hapus
            </Button>
            <Button
              onClick={() => {
                if (detailPart) openEditDialog(detailPart);
                setDetailPart(null);
              }}
            >
              Edit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Konfirmasi hapus (AlertDialog referensi) */}
      <AlertDialog open={deletePart !== null} onOpenChange={(v) => !v && setDeletePart(null)}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Sparepart</AlertDialogTitle>
            <AlertDialogDescription>
              Apakah Anda yakin ingin menghapus sparepart &quot;{deletePart?.name}&quot;? Tindakan ini
              tidak dapat dibatalkan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDeletePart}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ================= PRODUK JASA (ServiceProduct) =================

function ServiceProductTab({ user }: { user: SafeUser }) {
  const { toast } = useToast();
  const [products, setProducts] = useState<ServiceProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [jSortKey, setJSortKey] = useState<JasaSortKey>("NAMA");
  const [jSortAscending, setJSortAscending] = useState(true);

  const [formOpen, setFormOpen] = useState(false);
  const [editId, setEditId] = useState(0);
  const [inputName, setInputName] = useState("");
  const [inputBasePrice, setInputBasePrice] = useState("");
  const [inputPoints, setInputPoints] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [deleteProduct, setDeleteProduct] = useState<ServiceProduct | null>(null);

  const refresh = useCallback(async () => {
    try {
      const data = await apiJson<ServiceProduct[]>("/api/service-products");
      setProducts(data);
    } catch (e) {
      toast({
        title: e instanceof Error ? e.message : "Gagal memuat produk jasa",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = products.filter((p) => p.name.toLowerCase().includes(q));
    const sorted = [...list].sort((a, b) => {
      if (jSortKey === "HARGA") return a.basePrice - b.basePrice;
      return a.name.toLowerCase().localeCompare(b.name.toLowerCase());
    });
    return jSortAscending ? sorted : sorted.reverse();
  }, [products, searchQuery, jSortKey, jSortAscending]);

  // Header kolom bisa diklik untuk urutkan (D10): klik ulang = balik arah ▲▼
  function sortJasaBy(k: JasaSortKey) {
    if (k === jSortKey) setJSortAscending((v) => !v);
    else {
      setJSortKey(k);
      setJSortAscending(true);
    }
  }

  function openAddDialog() {
    setEditId(0);
    setInputName("");
    setInputBasePrice("");
    setInputPoints("0");
    setFormOpen(true);
  }

  function openEditDialog(p: ServiceProduct) {
    setEditId(p.id);
    setInputName(p.name);
    setInputBasePrice(String(Math.trunc(p.basePrice)));
    setInputPoints(String(p.points));
    setFormOpen(true);
  }

  async function saveProduct() {
    if (!inputName.trim()) {
      toast({ title: "Nama produk jasa wajib diisi!", variant: "destructive" });
      return;
    }
    setIsSaving(true);
    try {
      const body = {
        name: inputName.trim(),
        basePrice: Number(inputBasePrice) || 0,
        points: Number(inputPoints) || 0,
        performedBy: user.name,
      };
      if (editId === 0) {
        await apiJson("/api/service-products", { method: "POST", body: JSON.stringify(body) });
        toast({ title: `Produk jasa "${body.name}" tersimpan` });
      } else {
        await apiJson(`/api/service-products/${editId}`, {
          method: "PUT",
          body: JSON.stringify(body),
        });
        toast({ title: `Produk jasa "${body.name}" diperbarui` });
      }
      setFormOpen(false);
      await refresh();
    } catch (e) {
      toast({
        title: e instanceof Error ? e.message : "Gagal menyimpan produk jasa",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  }

  async function confirmDeleteProduct() {
    if (!deleteProduct) return;
    try {
      await apiJson(
        `/api/service-products/${deleteProduct.id}?requesterUsername=${encodeURIComponent(user.username)}`,
        { method: "DELETE" }
      );
      toast({ title: `Produk jasa "${deleteProduct.name}" dihapus` });
      await refresh();
    } catch (e) {
      toast({
        title: e instanceof Error ? e.message : "Gagal menghapus produk jasa",
        variant: "destructive",
      });
    } finally {
      setDeleteProduct(null);
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="me-auto flex items-center gap-2">
          <h2 className="text-base font-extrabold text-primary">Katalog Produk Jasa</h2>
          <FinCountChip count={filteredProducts.length} unit="jasa" />
        </div>
        <div className="relative w-full sm:w-64">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari produk jasa..."
            className="h-9 rounded-xl pl-8 pr-8"
            aria-label="Cari produk jasa"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery("")}
              aria-label="Bersihkan pencarian"
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-muted-foreground hover:text-foreground"
            >
              <X className="size-4" aria-hidden />
            </button>
          )}
        </div>
        <Button size="sm" className="h-9 rounded-xl" onClick={openAddDialog}>
          <Plus className="size-4" aria-hidden />
          Tambah Jasa
        </Button>
      </div>

      {loading ? (
        <p className="py-10 text-center text-sm text-muted-foreground">Memuat produk jasa…</p>
      ) : filteredProducts.length === 0 ? (
        <EmptyState
          icon={<Wrench className="size-8 text-muted-foreground/50" aria-hidden />}
          message="Belum ada produk jasa."
          hint="Tekan “Tambah Jasa” untuk membuat layanan servis (nama, harga dasar, poin teknisi)."
        />
      ) : (
        <>
          {/* Desktop: tabel standar industri keuangan (D10) */}
          <div className="hidden overflow-x-auto rounded-2xl border bg-card shadow-sm md:block xl:overflow-x-visible">
            <Table>
              <TableHeader className="[&_tr]:border-b-0">
                <tr>
                  <FinTh corner="first" align="center" className="w-10">#</FinTh>
                  <FinSortTh label="Nama Produk Jasa" k="NAMA" sortKey={jSortKey} asc={jSortAscending} onSort={sortJasaBy} />
                  <FinSortTh label="Harga Dasar" k="HARGA" sortKey={jSortKey} asc={jSortAscending} onSort={sortJasaBy} align="right" />
                  <FinTh align="right">Poin Teknisi</FinTh>
                  <FinTh align="center" corner="last">Aksi</FinTh>
                </tr>
              </TableHeader>
              <TableBody>
                {filteredProducts.map((p, i) => (
                  <FinRow key={p.id} zebra={i % 2 === 1}>
                    <FinIndexTd>{i + 1}</FinIndexTd>
                    <FinTd className="font-bold">{p.name}</FinTd>
                    <FinTd className="text-right font-bold tabular-nums text-primary">
                      {formatCurrency(p.basePrice)}
                    </FinTd>
                    <FinTd className="text-right tabular-nums text-muted-foreground">{p.points}</FinTd>
                    <FinTd className="text-center">
                      <div className="flex justify-center gap-1">
                        <Button variant="outline" size="icon" className="size-8 rounded-lg" onClick={() => openEditDialog(p)} aria-label={`Edit ${p.name}`}>
                          <svg className="size-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
                        </Button>
                        <Button variant="outline" size="icon" className="size-8 rounded-lg text-destructive hover:text-destructive" onClick={() => setDeleteProduct(p)} aria-label={`Hapus ${p.name}`}>
                          <svg className="size-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
                        </Button>
                      </div>
                    </FinTd>
                  </FinRow>
                ))}
              </TableBody>
              <FinTfoot>
                <tr>
                  <FinFootTd colSpan={2}>Total {filteredProducts.length} jasa</FinFootTd>
                  <FinFootTd aria-hidden />
                  <FinFootTd aria-hidden />
                  <FinFootTd aria-hidden />
                </tr>
              </FinTfoot>
            </Table>
          </div>

          {/* Mobile: kartu */}
          <div className="grid gap-3 sm:grid-cols-2 md:hidden">
          {filteredProducts.map((p) => (
            <div
              key={p.id}
              className="flex items-center gap-3 rounded-2xl border bg-card p-4 shadow-sm"
            >
              <div className="min-w-0 flex-1">
                <p className="font-bold">{p.name}</p>
                <p className="mt-0.5 text-[13px] font-bold text-primary">{formatCurrency(p.basePrice)}</p>
              </div>
              <Badge className="gap-1 rounded-lg bg-primary-container text-on-primary-container">
                <Zap className="size-3" aria-hidden />
                {p.points} poin
              </Badge>
              <div className="flex shrink-0 gap-1">
                <Button variant="outline" size="icon" className="size-8 rounded-lg" onClick={() => openEditDialog(p)} aria-label={`Edit ${p.name}`}>
                  <svg className="size-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
                </Button>
                <Button variant="outline" size="icon" className="size-8 rounded-lg text-destructive hover:text-destructive" onClick={() => setDeleteProduct(p)} aria-label={`Hapus ${p.name}`}>
                  <svg className="size-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
                </Button>
              </div>
            </div>
          ))}
          </div>
        </>
      )}

      {/* Dialog tambah/edit produk jasa */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="rounded-2xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editId === 0 ? "Tambah Produk Jasa" : "Edit Produk Jasa"}</DialogTitle>
            <DialogDescription>
              Jasa ini bisa dipilih di Kasir &amp; tiket servis; poin jadi reward teknisi.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3.5">
            <div className="space-y-1.5">
              <Label htmlFor="svc-name">Nama Produk Jasa</Label>
              <Input
                id="svc-name"
                value={inputName}
                onChange={(e) => setInputName(e.target.value)}
                placeholder="cth. Ganti LCD Touchscreen"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="svc-price">Harga Dasar (Rp)</Label>
              <Input
                id="svc-price"
                inputMode="numeric"
                value={inputBasePrice}
                onChange={(e) => setInputBasePrice(digitsOnly(e.target.value))}
                placeholder="cth. 150000"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="svc-points">Poin Teknisi</Label>
              <Input
                id="svc-points"
                inputMode="numeric"
                value={inputPoints}
                onChange={(e) => setInputPoints(digitsOnly(e.target.value))}
              />
              <p className="text-xs text-muted-foreground">
                Acuan kesulitan: Rendah 10 · Sedang 25 · Tinggi 50
              </p>
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="ghost" onClick={() => setFormOpen(false)} disabled={isSaving}>
              Batal
            </Button>
            <Button onClick={saveProduct} disabled={isSaving || !inputName.trim()}>
              {isSaving ? "Menyimpan…" : "Simpan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Konfirmasi hapus produk jasa */}
      <AlertDialog open={deleteProduct !== null} onOpenChange={(v) => !v && setDeleteProduct(null)}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Produk Jasa</AlertDialogTitle>
            <AlertDialogDescription>
              Apakah Anda yakin ingin menghapus produk jasa &quot;{deleteProduct?.name}&quot;? Tindakan
              ini tidak dapat dibatalkan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDeleteProduct}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ================= EmptyState (ui/components/EmptyState.kt) =================

function EmptyState({ message, hint, icon }: { message: string; hint?: string; icon?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed bg-card/60 px-6 py-14 text-center">
      <div className="mb-3 flex size-14 items-center justify-center rounded-2xl bg-muted">
        {icon ?? <Inbox className="size-7 text-muted-foreground/50" aria-hidden />}
      </div>
      <p className="text-sm font-semibold">{message}</p>
      {hint && <p className="mt-1 max-w-sm text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}
