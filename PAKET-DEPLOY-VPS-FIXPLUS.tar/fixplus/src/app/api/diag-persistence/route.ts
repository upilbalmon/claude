import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { resolveActor, errAction } from "@/lib/action-guard";

// D65 — GET /api/diag-persistence?requesterUsername=... (admin-only)
//
// Diagnostik persistensi filesystem pada instance live. Latar terkonfirmasi:
// platform deploy menghapus SELURUH folder /app tiap deploy sehingga database
// runtime (/app/db/custom.db — data live) hilang setiap deploy ulang.
// Sebelum memindahkan DATABASE_URL ke jalur persisten, endpoint ini memberi
// PENANDA (.persist-probe.json berisi waktu pembuatan) pada jalur kandidat di
// luar /app. Cara pakai (dua deploy):
//   1. Deploy build ini → buka endpoint ini sekali (penanda dibuat = waktu
//      deploy #1) → catat hasilnya.
//   2. Deploy ulang → buka endpoint lagi. Penanda yang createdAt-nya LEBIH
//      LAMA dari penanda kontrol /app/db berarti jalur itu BERTAHAN lintas
//      deploy → DATABASE_URL bisa dipindah ke sana (data live kebal deploy).
// Read-mostly: tidak menyentuh data bisnis, hanya menulis file penanda di
// jalur kandidat; kegagalan izin dilaporkan apa adanya (bukan error HTTP).

export const dynamic = "force-dynamic";

const CANDIDATES = [
  "/app/db", // KONTROL: harus selalu baru (di-reset platform tiap deploy)
  "/data",
  "/persist",
  "/storage",
  "/srv/data",
  "/var/data",
  "/var/lib/appdata",
  "/mnt/data",
  "/mnt",
  "/opt/appdata",
  "/home",
  "/home/z",
  "/root",
  "/tmp",
  "/app-prev",
  "/releases",
];
const MARKER = ".persist-probe.json";

type ProbeResult = {
  path: string;
  writeOk: boolean;
  markerExisted?: boolean;
  markerCreatedAt?: string | null;
  error?: string;
};

type RootEntry = {
  name: string;
  type: "dir" | "file" | "other";
  mtime: string | null;
  writeOk: boolean;
};

function probePath(dir: string, nowIso: string): ProbeResult {
  const res: ProbeResult = { path: dir, writeOk: false };
  try {
    fs.mkdirSync(dir, { recursive: true });
    const marker = path.join(dir, MARKER);
    if (fs.existsSync(marker)) {
      res.markerExisted = true;
      try {
        const j = JSON.parse(fs.readFileSync(marker, "utf8")) as { createdAt?: string };
        res.markerCreatedAt = j.createdAt ?? null;
      } catch {
        // penanda korup → tulis ulang
        res.markerCreatedAt = null;
        fs.writeFileSync(marker, JSON.stringify({ createdAt: nowIso }));
      }
    } else {
      fs.writeFileSync(marker, JSON.stringify({ createdAt: nowIso }));
      res.markerExisted = false;
      res.markerCreatedAt = nowIso;
    }
    res.writeOk = true;
  } catch (e) {
    res.error = e instanceof Error ? e.message : String(e);
  }
  return res;
}

function listRoot(): RootEntry[] {
  try {
    return fs
      .readdirSync("/", { withFileTypes: true })
      .map((d): RootEntry => {
        const row: RootEntry = {
          name: d.name,
          type: d.isDirectory() ? "dir" : d.isFile() ? "file" : "other",
          mtime: null,
          writeOk: false,
        };
        try {
          const st = fs.statSync(`/${d.name}`);
          row.mtime = st.mtime.toISOString();
        } catch {
          /* stat gagal — biarkan mtime null */
        }
        try {
          fs.accessSync(`/${d.name}`, fs.constants.W_OK);
          row.writeOk = true;
        } catch {
          row.writeOk = false;
        }
        return row;
      });
  } catch {
    return [];
  }
}

function readMounts(): string[] {
  try {
    return fs
      .readFileSync("/proc/mounts", "utf8")
      .split("\n")
      .filter((l) => l.trim().length > 0)
      .map((l) => {
        const [dev, mp, type] = l.split(" ");
        return `${mp} (${type}) ${dev}`;
      });
  } catch {
    return [];
  }
}

export async function GET(req: NextRequest) {
  const actor = await resolveActor(req.nextUrl.searchParams.get("requesterUsername"));
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const nowIso = new Date().toISOString();

  const dbUrl = process.env.DATABASE_URL ?? null;
  const dbPath = (dbUrl ?? "").replace(/^file:/, "");
  const dbFile: { path: string; exists: boolean; sizeBytes?: number; mtime?: string } = {
    path: dbPath,
    exists: false,
  };
  try {
    const st = fs.statSync(dbPath);
    dbFile.exists = true;
    dbFile.sizeBytes = st.size;
    dbFile.mtime = st.mtime.toISOString();
  } catch {
    /* file belum ada */
  }

  return NextResponse.json({
    now: nowIso,
    databaseUrl: dbUrl,
    dbFile,
    probe: CANDIDATES.map((p) => probePath(p, nowIso)),
    root: listRoot(),
    mounts: readMounts(),
    note:
      "Penanda (.persist-probe.json) berisi waktu pembuatan. Setelah deploy ulang, " +
      "penanda yang createdAt-nya LEBIH LAMA dari kontrol /app/db berarti jalur " +
      "itu BERTAHAN lintas deploy — DATABASE_URL layak dipindah ke sana.",
  });
}
