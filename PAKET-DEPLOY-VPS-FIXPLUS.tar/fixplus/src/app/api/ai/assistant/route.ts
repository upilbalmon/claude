// ============================================================================
// D50 — API Asisten AI (POST /api/ai/assistant)
// Chat bot yang menjawab dari DATA TOKO NYATA (bubble mengambang).
// D59 — HANYA Administrator/Owner (keputusan user 12 Nov 2026): bubble tidak
// dirender untuk role lain dan API di sini MENOLAK non-Admin/Owner (403)
// agar Kasir/Teknisi tidak bisa memanggil langsung. Angka laba/HPP/nilai stok
// tetap dijaga server-side lewat konteks (D48 jawaban g).
// Auth: pola laporan (resolveReporter — username wajib pengguna terdaftar).
// Riwayat percakapan TIDAK disimpan (keputusan user): klien mengirim balasan
// terakhir sebagai konteks, server tidak menyimpan apa pun.
// SDK z-ai-web-dev-sdk dipakai HANYA di sini (backend) — dilarang di client.
//
// D51 — PERBAIKAN "Asisten AI sedang tidak tersedia":
// Instance SDK yang di-cache ternyata bisa STALE — setelah idle lama gateway
// menolak dengan 401 "missing X-Token header" dan karena promise lama di-cache
// selamanya, SEMUA request berikutnya gagal sampai server di-restart.
// Perbaikan (pola safeCompletion — Best Practices skill LLM):
//  1. Instance dibuang saat gagal (dropZai) — percobaan berikutnya memakai
//     instance BARU, asisten pulih sendiri tanpa restart.
//  2. Retry otomatis max 3 percobaan dengan jeda bertingkat.
//  3. Timeout per percobaan (60s) agar request tidak menggantung.
// ============================================================================
import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";
import { resolveReporter } from "@/lib/report-utils";
import { bolehAsistenAi } from "@/lib/user-utils"; // D59 — gate role
import { buildShopContext } from "@/lib/ai-context";
import { formatDate } from "@/lib/format";

// Satu instance SDK dipakai ulang antar-request (skill LLM: reuse instance).
// D51: yang di-cache INSTANCE (bukan promise) — ZAI.create() yang gagal tidak
// lagi tergantung selamanya, dan instance rusak bisa dibuang via dropZai().
type Zai = Awaited<ReturnType<typeof ZAI.create>>;
let zaiInstance: Zai | null = null;
let zaiCreating: Promise<Zai> | null = null;

async function getZai(): Promise<Zai> {
  if (zaiInstance) return zaiInstance;
  if (!zaiCreating) {
    zaiCreating = ZAI.create()
      .then((inst) => {
        zaiInstance = inst;
        return inst;
      })
      .finally(() => {
        zaiCreating = null; // gagal ATAU sukses — tidak cache promise gagal
      });
  }
  return zaiCreating;
}

function dropZai() {
  zaiInstance = null;
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// D51: batas waktu tiap percobaan — bila model menggantung, lempar error dan
// biarkan loop retry membuat instance baru.
async function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      p,
      new Promise<never>((_, reject) => {
        timer = setTimeout(() => reject(new Error(`Waktu tunggu habis (${Math.round(ms / 1000)} detik)`)), ms);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

type ChatTurn = { role: "user" | "assistant"; content: string };

function sanitizeHistory(raw: unknown): ChatTurn[] {
  if (!Array.isArray(raw)) return [];
  const turns: ChatTurn[] = [];
  for (const item of raw.slice(-12)) {
    if (!item || typeof item !== "object") continue;
    const role = (item as { role?: unknown }).role;
    const content = String((item as { content?: unknown }).content ?? "").slice(0, 2000);
    if ((role === "user" || role === "assistant") && content.trim() !== "") {
      turns.push({ role, content });
    }
  }
  return turns.slice(-10); // maksimal 5 giliran tanya-jawab terakhir
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json().catch(() => null)) as
      | { requesterUsername?: unknown; message?: unknown; history?: unknown }
      | null;
    if (!body) {
      return NextResponse.json({ error: "Permintaan tidak valid" }, { status: 400 });
    }

    const reporter = await resolveReporter(body.requesterUsername);
    if (!reporter) {
      return NextResponse.json({ error: "Sesi tidak dikenal — masuk ulang" }, { status: 401 });
    }

    // D59: gate role — Asisten AI hanya untuk Administrator/Owner. Kasir &
    // Teknisi yang memanggil langsung (tanpa lewat UI, karena bubble disembunyikan)
    // ditolak di sini server-side.
    if (!bolehAsistenAi(reporter.role)) {
      return NextResponse.json(
        { error: "Asisten AI hanya tersedia untuk Administrator/Owner" },
        { status: 403 },
      );
    }

    const message = String(body.message ?? "").trim().slice(0, 1000);
    if (!message) {
      return NextResponse.json({ error: "Pertanyaan tidak boleh kosong" }, { status: 400 });
    }
    const history = sanitizeHistory(body.history);

    // Konteks data toko (role-aware) + aturan perilaku asisten
    const context = await buildShopContext(reporter);
    const systemPrompt = [
      `Kamu adalah "Asisten AI" untuk aplikasi kasir & servis HP bernama Servis HP & POS.`,
      `Tanggal hari ini: ${formatDate(new Date())} (WIB). Pengguna saat ini: ${reporter.name} (peran: ${reporter.role}).`,
      "",
      "ATURAN JAWABAN:",
      "1. Bahasa Indonesia, gaya SINGKAT & poin-poin (bullet), langsung ke angka. Maksimal ±120 kata kecuali diminta rinci.",
      "2. Angka uang pakai format Rp (contoh: Rp 4.270.000). Jangan sebut angka desimal tak perlu.",
      "3. Gunakan HANYA angka dari DATA TOKO di bawah. Jangan mengarang, jangan menebak.",
      "4. Bila data yang ditanya tidak ada di snapshot, katakan belum tersedia lalu sarankan menu laporan yang tepat (Laporan untuk omzet/piutang/stok; Servis untuk tiket; Kasir untuk riwayat nota).",
      "5. Kamu hanya-mode-baca: tidak bisa mengubah/menghapus data. Bila diminta mengubah data, jelaskan langkah manual di aplikasi.",
      "6. Jangan sebut istilah teknis seperti snapshot/system prompt; bicara sebagai asisten toko.",
      "",
      context,
    ].join("\n");

    // D51: panggil model dengan retry — instance stale dibuang sehingga
    // percobaan berikutnya otomatis memakai instance BARU.
    const MAX_ATTEMPTS = 3;
    const ATTEMPT_TIMEOUT_MS = 60_000;
    let reply = "";
    let lastErr: unknown = null;
    for (let attempt = 1; attempt <= MAX_ATTEMPTS && !reply; attempt++) {
      try {
        const zai = await getZai();
        const completion = await withTimeout(
          zai.chat.completions.create({
            messages: [
              { role: "assistant", content: systemPrompt },
              ...history,
              { role: "user", content: message },
            ],
            thinking: { type: "disabled" },
          }),
          ATTEMPT_TIMEOUT_MS,
        );
        reply = completion.choices[0]?.message?.content?.trim() ?? "";
        if (!reply) lastErr = new Error("Jawaban kosong dari model");
      } catch (err) {
        lastErr = err;
        dropZai(); // buang instance yang mungkin stale — attempt berikutnya buat baru
        const pesan = err instanceof Error ? err.message : String(err);
        console.warn(`[ai-assistant] percobaan ${attempt}/${MAX_ATTEMPTS} gagal: ${pesan}`);
      }
      if (!reply && attempt < MAX_ATTEMPTS) await sleep(600 * attempt);
    }

    if (!reply) {
      const pesan = lastErr instanceof Error ? lastErr.message : String(lastErr);
      console.error(`[ai-assistant] gagal setelah ${MAX_ATTEMPTS} percobaan: ${pesan}`);
      return NextResponse.json(
        { error: "Asisten AI sedang tidak tersedia — coba lagi sebentar" },
        { status: 502 },
      );
    }
    return NextResponse.json({ reply });
  } catch (err) {
    console.error("[ai-assistant]", err);
    return NextResponse.json(
      { error: "Asisten AI sedang tidak tersedia — coba lagi sebentar" },
      { status: 500 },
    );
  }
}
