// formatCurrency() AppViewModel.kt — Rp 450.000 (locale id-ID)
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatDate(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(d);
}

export function formatDateTime(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(d);
}

// ===== D36 — jendela void & rentang tanggal laporan (zona Asia/Jakarta, UTC+7) =====
// Toko tidak mengenal shift; batas void = hari kalender yang sama (aturan 8 dokumen
// "Pembatalan transaksi"). Server & UI memakai fungsi yang sama agar selalu konsisten.
const WIB_OFFSET_MS = 7 * 60 * 60 * 1000;

/** "YYYY-MM-DD" hari kalender WIB dari sebuah instant */
export function dayKeyWIB(d: Date | string): string {
  const dt = typeof d === "string" ? new Date(d) : d;
  return new Date(dt.getTime() + WIB_OFFSET_MS).toISOString().slice(0, 10);
}

/** D36 — void hanya boleh pada hari yang sama (WIB) */
export function voidWindowOpen(timestamp: Date | string, now: Date = new Date()): boolean {
  return dayKeyWIB(timestamp) === dayKeyWIB(now);
}

/** Rentang UTC [dari, sampai) untuk satu hari kalender WIB — dipakai API laporan */
export function wibDayRange(day: string): { start: Date; end: Date } {
  const [y, m, d] = day.split("-").map(Number);
  const start = new Date(Date.UTC(y, (m ?? 1) - 1, d ?? 1) - WIB_OFFSET_MS);
  return { start, end: new Date(start.getTime() + 24 * 60 * 60 * 1000) };
}
