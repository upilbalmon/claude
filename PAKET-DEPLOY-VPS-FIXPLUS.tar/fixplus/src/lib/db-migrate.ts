import { db } from "@/lib/db";
import { generateSalt, hashPin } from "@/lib/pin-hash";

// D55 — Penyembuhan skema otomatis (self-healing) untuk SQLite.
//
// Latar belakang masalah nyata: database yang dipulihkan dari file versi
// aplikasi LAMA (atau dibuat oleh instance lain yang belum diperbarui)
// tidak memiliki kolom/tabel baru — contoh kasus 12 Nov 2026: file tanpa
// `SparePart.category`. Semua query Prisma yang memilih kolom itu gagal
// `no such column` → halaman "Gagal memuat data", termasuk manajemen
// pengguna (tabel User tanpa kolom izin → TIDAK BISA membuat pengguna
// baru baik kasir maupun role lain).
//
// Solusi: dibanding menolak/menggantungkan pada file yang benar, aplikasi
// kini MEMPERBAIKI skema database yang sedang berjalan sendiri saat server
// mulai (src/instrumentation.ts) dan — sebagai jaring pengaman — saat API
// pengguna/login menemukan error skema (withHeal di users-guard.ts).
// Semua operasi ADDITIF saja (CREATE TABLE IF NOT EXISTS + ALTER TABLE ADD
// COLUMN) — tidak ada kolom/tabel/data yang dihapus atau diubah isinya,
// sehingga aman dijalankan kapan pun dan idempoten.
//
// Pemakaian: `await ensureSchema()` (memoized; `ensureSchema({force:true})`
// untuk dipaksa jalan ulang, mis. setelah file database diganti restore).

export interface HealReport {
  ok: boolean;
  tablesCreated: string[];
  columnsAdded: string[];
  fixUps: string[];
  skipped: string[]; // kolom yang tak bisa ditambah via ALTER (NOT NULL tanpa default)
}

// DDL tabel lengkap — SINKRON dengan prisma/schema.prisma (gaya identik
// hasil `prisma db push`: BOOLEAN dengan literal false/true, DATETIME
// DEFAULT CURRENT_TIMESTAMP). CREATE TABLE IF NOT EXISTS sehingga database
// kosong/0-byte pun bisa di-bootstrap penuh.
const CREATE_DDL: Record<string, string> = {
  Customer: `CREATE TABLE IF NOT EXISTS "Customer" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "phone" TEXT NOT NULL,
    "email" TEXT NOT NULL DEFAULT '',
    "address" TEXT NOT NULL DEFAULT '',
    "loyaltyPoints" INTEGER NOT NULL DEFAULT 0,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`,
  Technician: `CREATE TABLE IF NOT EXISTS "Technician" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "phone" TEXT NOT NULL DEFAULT '',
    "isAvailable" BOOLEAN NOT NULL DEFAULT true,
    "userId" INTEGER
  )`,
  SparePart: `CREATE TABLE IF NOT EXISTS "SparePart" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "alias" TEXT,
    "sku" TEXT NOT NULL DEFAULT '',
    "category" TEXT NOT NULL DEFAULT 'SPAREPART',
    "stock" INTEGER NOT NULL DEFAULT 0,
    "minStock" INTEGER NOT NULL DEFAULT 5,
    "costPrice" REAL NOT NULL DEFAULT 0,
    "sellPrice" REAL NOT NULL DEFAULT 0,
    "location" TEXT NOT NULL DEFAULT '',
    "isShoppingSelected" BOOLEAN NOT NULL DEFAULT false,
    "shoppingIgnoredUntil" DATETIME
  )`,
  RepairRecord: `CREATE TABLE IF NOT EXISTS "RepairRecord" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "customerId" INTEGER,
    "customerName" TEXT NOT NULL,
    "customerPhone" TEXT NOT NULL,
    "deviceModel" TEXT NOT NULL,
    "serialOrImei" TEXT NOT NULL DEFAULT '',
    "damageDescription" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'ANTRI',
    "technicianId" INTEGER,
    "technicianName" TEXT,
    "serviceFee" REAL NOT NULL DEFAULT 0,
    "usedPartsJson" TEXT NOT NULL DEFAULT '[]',
    "requestedPartsJson" TEXT NOT NULL DEFAULT '[]',
    "totalPrice" REAL NOT NULL DEFAULT 0,
    "difficulty" TEXT NOT NULL DEFAULT 'Sedang',
    "notes" TEXT NOT NULL DEFAULT '',
    "estimatedCost" REAL,
    "downPayment" REAL,
    "estimatedCompletionTime" TEXT NOT NULL DEFAULT '',
    "createdByUser" TEXT NOT NULL DEFAULT '',
    "pointsReward" INTEGER,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completedAt" DATETIME,
    "warrantyDays" INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY ("customerId") REFERENCES "Customer" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY ("technicianId") REFERENCES "Technician" ("id") ON DELETE SET NULL ON UPDATE CASCADE
  )`,
  Transaction: `CREATE TABLE IF NOT EXISTS "Transaction" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "invoiceNumber" TEXT NOT NULL,
    "repairRecordId" INTEGER,
    "customerId" INTEGER,
    "customerName" TEXT NOT NULL,
    "subtotal" REAL NOT NULL DEFAULT 0,
    "discount" REAL NOT NULL DEFAULT 0,
    "grandTotal" REAL NOT NULL DEFAULT 0,
    "paymentMethod" TEXT NOT NULL DEFAULT 'Tunai',
    "paidAmount" REAL NOT NULL DEFAULT 0,
    "changeAmount" REAL NOT NULL DEFAULT 0,
    "itemsJson" TEXT NOT NULL DEFAULT '[]',
    "timestamp" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "paymentStatus" TEXT NOT NULL DEFAULT 'LUNAS',
    "isVoided" BOOLEAN NOT NULL DEFAULT false,
    "voidedBy" TEXT,
    "voidedAt" DATETIME,
    "voidReason" TEXT,
    "createdBy" TEXT NOT NULL DEFAULT 'Admin',
    "docType" TEXT NOT NULL DEFAULT 'PENJUALAN',
    "refundOfId" INTEGER,
    "referenceNumber" TEXT NOT NULL DEFAULT '',
    FOREIGN KEY ("repairRecordId") REFERENCES "RepairRecord" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY ("customerId") REFERENCES "Customer" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY ("refundOfId") REFERENCES "Transaction" ("id") ON DELETE SET NULL ON UPDATE CASCADE
  )`,
  User: `CREATE TABLE IF NOT EXISTS "User" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "username" TEXT NOT NULL,
    "role" TEXT NOT NULL,
    "pin" TEXT NOT NULL,
    "salt" TEXT NOT NULL DEFAULT '',
    "mustChangePin" BOOLEAN NOT NULL DEFAULT false,
    "permissionDashboard" BOOLEAN NOT NULL DEFAULT true,
    "permissionCashier" BOOLEAN NOT NULL DEFAULT true,
    "permissionServices" BOOLEAN NOT NULL DEFAULT true,
    "permissionInventory" BOOLEAN NOT NULL DEFAULT true,
    "permissionCustomers" BOOLEAN NOT NULL DEFAULT true,
    "permissionUsers" BOOLEAN NOT NULL DEFAULT true,
    "permissionSettings" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`,
  ServiceProduct: `CREATE TABLE IF NOT EXISTS "ServiceProduct" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "basePrice" REAL NOT NULL DEFAULT 0,
    "points" INTEGER NOT NULL DEFAULT 0,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`,
  PreOrder: `CREATE TABLE IF NOT EXISTS "PreOrder" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "customerId" INTEGER,
    "repairRecordId" INTEGER,
    "transactionId" INTEGER,
    "customerName" TEXT NOT NULL,
    "customerPhone" TEXT NOT NULL,
    "dp" REAL NOT NULL DEFAULT 0,
    "itemName" TEXT NOT NULL,
    "category" TEXT NOT NULL DEFAULT 'LAINNYA',
    "qty" INTEGER NOT NULL DEFAULT 1,
    "estPrice" REAL NOT NULL DEFAULT 0,
    "status" TEXT NOT NULL DEFAULT 'Pending',
    "cancelReason" TEXT,
    "notes" TEXT NOT NULL DEFAULT '',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("customerId") REFERENCES "Customer" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY ("repairRecordId") REFERENCES "RepairRecord" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY ("transactionId") REFERENCES "Transaction" ("id") ON DELETE SET NULL ON UPDATE CASCADE
  )`,
  RequestedItem: `CREATE TABLE IF NOT EXISTS "RequestedItem" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "customerId" INTEGER,
    "repairRecordId" INTEGER,
    "partId" INTEGER,
    "itemName" TEXT NOT NULL,
    "brandOrSpec" TEXT NOT NULL DEFAULT '',
    "qty" INTEGER NOT NULL DEFAULT 1,
    "estPrice" REAL NOT NULL DEFAULT 0,
    "customerName" TEXT NOT NULL DEFAULT '',
    "customerPhone" TEXT NOT NULL DEFAULT '',
    "status" TEXT NOT NULL DEFAULT 'Baru',
    "cancelReason" TEXT,
    "notes" TEXT NOT NULL DEFAULT '',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("customerId") REFERENCES "Customer" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY ("repairRecordId") REFERENCES "RepairRecord" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY ("partId") REFERENCES "SparePart" ("id") ON DELETE SET NULL ON UPDATE CASCADE
  )`,
  AuditLog: `CREATE TABLE IF NOT EXISTS "AuditLog" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "action" TEXT NOT NULL,
    "details" TEXT NOT NULL,
    "performedBy" TEXT NOT NULL,
    "timestamp" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`,
  ShopSettings: `CREATE TABLE IF NOT EXISTS "ShopSettings" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT DEFAULT 1,
    "shopName" TEXT NOT NULL DEFAULT 'Servis HP & POS',
    "address" TEXT NOT NULL DEFAULT '',
    "phone" TEXT NOT NULL DEFAULT '',
    "receiptFooter" TEXT NOT NULL DEFAULT 'Terima kasih telah berbelanja!',
    "waTemplates" TEXT NOT NULL DEFAULT '{}',
    "editTransactionDate" BOOLEAN NOT NULL DEFAULT false
  )`,
  // D74 — AppMeta: penyimpanan nomor urut versi data (seq) untuk sinkronisasi
  // backup/restore GitHub (manifest.json). Tabel TEKNIK — bukan data bisnis —
  // ikut tersimpan di file .db sehingga seq "berjalan bersama" datanya: masuk
  // snapshot saat backup, kembali saat dipulihkan. Tidak dimodelkan di
  // prisma/schema.prisma (diakses SQL mentah saja) agar klien Prisma tak perlu
  // diregenerasi.
  AppMeta: `CREATE TABLE IF NOT EXISTS "AppMeta" (
    "key" TEXT NOT NULL PRIMARY KEY,
    "value" TEXT NOT NULL
  )`,
  // D73 — Absensi Karyawan: satu baris per pengguna per hari kalender WIB.
  // userId nullable + ON DELETE SET NULL: riwayat tetap ada setelah akun
  // dihapus (nama dipertahankan via kolom snapshot userName).
  Attendance: `CREATE TABLE IF NOT EXISTS "Attendance" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "userId" INTEGER,
    "userName" TEXT NOT NULL,
    "date" TEXT NOT NULL,
    "checkIn" DATETIME,
    "checkOut" DATETIME,
    "status" TEXT NOT NULL DEFAULT 'HADIR',
    "notes" TEXT NOT NULL DEFAULT '',
    "recordedBy" TEXT NOT NULL DEFAULT '',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE SET NULL ON UPDATE CASCADE
  )`,
  // D81 — Pusat Notifikasi aplikasi (panel lonceng di header): riwayat
  // kejadian penting — sukses/gagal backup GitHub, konflik sinkronisasi,
  // pemulihan otomatis — yang harus tetap terbaca walau toast di layar sudah
  // hilang. Tabel TEKNIS (bukan data bisnis): dikecualikan di db.ts seperti
  // AuditLog sehingga tulisannya tidak memicu auto-backup per-perubahan.
  AppNotification: `CREATE TABLE IF NOT EXISTS "AppNotification" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "type" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "message" TEXT NOT NULL DEFAULT '',
    "metaJson" TEXT NOT NULL DEFAULT '{}',
    "readAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`,
  // D92 — Sesi Kas Laci: satu baris per pengguna per hari kalender WIB.
  // Buka = login pertama hari itu + wajib isi kas awal di laci; tutup =
  // tombol "Tutup Laci" (isi kas fisik) yang sekaligus menutup absen dan
  // mengakhiri sesi. userId nullable + ON DELETE SET NULL — pola sama dengan
  // Attendance agar riwayat tetap terbaca setelah akun dihapus.
  DrawerSession: `CREATE TABLE IF NOT EXISTS "DrawerSession" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "userId" INTEGER,
    "userName" TEXT NOT NULL,
    "date" TEXT NOT NULL,
    "openingCash" REAL NOT NULL DEFAULT 0,
    "closingCash" REAL,
    "cashIn" REAL,
    "expectedCash" REAL,
    "selisih" REAL,
    "openingAt" DATETIME,
    "closingAt" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE SET NULL ON UPDATE CASCADE
  )`,
};

// Kolom untuk ALTER TABLE ADD COLUMN — hanya kolom yang BOLEH ditambah ke
// tabel lama (nullable atau punya DEFAULT konstanta). Urutan = urutan versi
// aplikasi sehingga DB paling tua pun pulih langkah demi langkah.
// CATATAN: unik (username/invoiceNumber) TIDAK bisa dijamin via ADD COLUMN —
// kolom itu kolom asli tabel dan realistis tak pernah hilang.
const ADD_COLUMNS: Record<string, string[]> = {
  Customer: [
    `"email" TEXT NOT NULL DEFAULT ''`,
    `"address" TEXT NOT NULL DEFAULT ''`,
    `"loyaltyPoints" INTEGER NOT NULL DEFAULT 0`,
  ],
  Technician: [`"phone" TEXT NOT NULL DEFAULT ''`, `"isAvailable" BOOLEAN NOT NULL DEFAULT true`, `"userId" INTEGER`],
  SparePart: [
    `"alias" TEXT`,
    `"sku" TEXT NOT NULL DEFAULT ''`,
    `"category" TEXT NOT NULL DEFAULT 'SPAREPART'`,
    `"stock" INTEGER NOT NULL DEFAULT 0`,
    `"minStock" INTEGER NOT NULL DEFAULT 5`,
    `"costPrice" REAL NOT NULL DEFAULT 0`,
    `"sellPrice" REAL NOT NULL DEFAULT 0`,
    `"location" TEXT NOT NULL DEFAULT ''`,
    // D61 — Tahap 6.3 daftar belanja
    `"isShoppingSelected" BOOLEAN NOT NULL DEFAULT false`,
    `"shoppingIgnoredUntil" DATETIME`,
  ],
  RepairRecord: [
    `"serialOrImei" TEXT NOT NULL DEFAULT ''`,
    `"status" TEXT NOT NULL DEFAULT 'ANTRI'`,
    `"technicianName" TEXT`,
    `"serviceFee" REAL NOT NULL DEFAULT 0`,
    `"usedPartsJson" TEXT NOT NULL DEFAULT '[]'`,
    `"requestedPartsJson" TEXT NOT NULL DEFAULT '[]'`,
    `"totalPrice" REAL NOT NULL DEFAULT 0`,
    `"difficulty" TEXT NOT NULL DEFAULT 'Sedang'`,
    `"notes" TEXT NOT NULL DEFAULT ''`,
    `"estimatedCompletionTime" TEXT NOT NULL DEFAULT ''`,
    `"createdByUser" TEXT NOT NULL DEFAULT ''`,
    `"pointsReward" INTEGER`,
    `"completedAt" DATETIME`,
    `"warrantyDays" INTEGER NOT NULL DEFAULT 0`,
  ],
  Transaction: [
    `"subtotal" REAL NOT NULL DEFAULT 0`,
    `"discount" REAL NOT NULL DEFAULT 0`,
    `"grandTotal" REAL NOT NULL DEFAULT 0`,
    `"paymentMethod" TEXT NOT NULL DEFAULT 'Tunai'`,
    `"paidAmount" REAL NOT NULL DEFAULT 0`,
    `"changeAmount" REAL NOT NULL DEFAULT 0`,
    `"itemsJson" TEXT NOT NULL DEFAULT '[]'`,
    `"paymentStatus" TEXT NOT NULL DEFAULT 'LUNAS'`,
    `"isVoided" BOOLEAN NOT NULL DEFAULT false`,
    `"voidedBy" TEXT`,
    `"voidedAt" DATETIME`,
    `"voidReason" TEXT`,
    `"createdBy" TEXT NOT NULL DEFAULT 'Admin'`,
    `"docType" TEXT NOT NULL DEFAULT 'PENJUALAN'`,
    `"refundOfId" INTEGER`,
    `"referenceNumber" TEXT NOT NULL DEFAULT ''`,
  ],
  User: [
    `"salt" TEXT NOT NULL DEFAULT ''`,
    `"mustChangePin" BOOLEAN NOT NULL DEFAULT false`,
    `"permissionDashboard" BOOLEAN NOT NULL DEFAULT true`,
    `"permissionCashier" BOOLEAN NOT NULL DEFAULT true`,
    `"permissionServices" BOOLEAN NOT NULL DEFAULT true`,
    `"permissionInventory" BOOLEAN NOT NULL DEFAULT true`,
    `"permissionCustomers" BOOLEAN NOT NULL DEFAULT true`,
    `"permissionUsers" BOOLEAN NOT NULL DEFAULT true`,
    `"permissionSettings" BOOLEAN NOT NULL DEFAULT true`,
    `"createdAt" DATETIME`,
  ],
  ServiceProduct: [
    `"basePrice" REAL NOT NULL DEFAULT 0`,
    `"points" INTEGER NOT NULL DEFAULT 0`,
    `"createdAt" DATETIME`,
  ],
  PreOrder: [
    `"customerId" INTEGER`,
    `"repairRecordId" INTEGER`,
    `"dp" REAL NOT NULL DEFAULT 0`,
    `"qty" INTEGER NOT NULL DEFAULT 1`,
    `"status" TEXT NOT NULL DEFAULT 'Pending'`,
    `"notes" TEXT NOT NULL DEFAULT ''`,
    `"createdAt" DATETIME`,
    // D61 — Tahap 6.1 pre-order + DP
    `"estPrice" REAL NOT NULL DEFAULT 0`,
    `"category" TEXT NOT NULL DEFAULT 'LAINNYA'`,
    `"transactionId" INTEGER`,
    `"cancelReason" TEXT`,
  ],
  RequestedItem: [
    `"customerId" INTEGER`,
    `"repairRecordId" INTEGER`,
    `"brandOrSpec" TEXT NOT NULL DEFAULT ''`,
    `"qty" INTEGER NOT NULL DEFAULT 1`,
    `"customerName" TEXT NOT NULL DEFAULT ''`,
    `"customerPhone" TEXT NOT NULL DEFAULT ''`,
    `"status" TEXT NOT NULL DEFAULT 'Baru'`,
    `"notes" TEXT NOT NULL DEFAULT ''`,
    `"createdAt" DATETIME`,
    // D61 — Tahap 6.2 barang pesanan
    `"estPrice" REAL NOT NULL DEFAULT 0`,
    `"partId" INTEGER`,
    `"cancelReason" TEXT`,
  ],
  AuditLog: [`"timestamp" DATETIME`],
  ShopSettings: [
    `"shopName" TEXT NOT NULL DEFAULT 'Servis HP & POS'`,
    `"address" TEXT NOT NULL DEFAULT ''`,
    `"phone" TEXT NOT NULL DEFAULT ''`,
    `"receiptFooter" TEXT NOT NULL DEFAULT 'Terima kasih telah berbelanja!'`,
    `"waTemplates" TEXT NOT NULL DEFAULT '{}'`,
    `"editTransactionDate" BOOLEAN NOT NULL DEFAULT false`,
  ],
};

async function existingTables(): Promise<Set<string>> {
  const rows =
    (await db.$queryRawUnsafe<{ name: string }[]>(
      "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    )) ?? [];
  return new Set(rows.map((r) => String(r.name)));
}

async function existingColumns(table: string): Promise<Set<string>> {
  const rows =
    (await db.$queryRawUnsafe<{ name: string }[]>(
      `PRAGMA table_info(${JSON.stringify(table)})`
    )) ?? [];
  return new Set(rows.map((r) => String(r.name)));
}

// D71 — indeks unik yang wajib ada (tidak bisa dibuat via ADD COLUMN):
// Technician.userId unik — satu akun Pengguna paling punya satu profil teknisi.
// D73 — Attendance(userId, date) unik — satu catatan absensi per orang per hari
// (baris yatim userId NULL dikecualikan sendiri oleh SQLite — NULL ≠ NULL).
const ENSURE_INDEXES: { name: string; sql: string }[] = [
  {
    name: "Technician_userId_key",
    sql: `CREATE UNIQUE INDEX IF NOT EXISTS "Technician_userId_key" ON "Technician"("userId")`,
  },
  {
    name: "Attendance_userId_date_key",
    sql: `CREATE UNIQUE INDEX IF NOT EXISTS "Attendance_userId_date_key" ON "Attendance"("userId", "date")`,
  },
  {
    name: "DrawerSession_userId_date_key",
    sql: `CREATE UNIQUE INDEX IF NOT EXISTS "DrawerSession_userId_date_key" ON "DrawerSession"("userId", "date")`,
  },
];

// Perbaikan data-level setelah struktur pulih:
//  1. ShopSettings id=1 wajib ada (profil toko & template WA).
//  2. Tabel User kosong total → seed akun admin awal (admin / 1234,
//     wajib ganti PIN) — identik fallback seed deployment (D45), sehingga
//     toko TIDAK PERNAH terkunci keluar dari aplikasinya sendiri.
//  3. Tidak ada satu pun akun berizin "Pengguna" → akun Admin pertama
//     (atau akun pertama bila tak ada Admin) diberi semua izin — jaminan
//     manajemen pengguna selalu bisa diakses dari suatu akun.
// Semua bersifat minimal & aditif; PIN/salt akun lama TIDAK pernah disentuh.
async function runFixUps(fixUps: string[]): Promise<void> {
  // 1. ShopSettings id=1
  try {
    const settings = await db.$queryRawUnsafe<{ c: number }[]>(
      "SELECT COUNT(*) AS c FROM ShopSettings WHERE id = 1"
    );
    if (!settings?.length || Number(settings[0].c) === 0) {
      await db.$executeRawUnsafe(
        `INSERT OR IGNORE INTO ShopSettings (id, shopName, address, phone, receiptFooter, waTemplates, editTransactionDate)
         VALUES (1, 'Servis HP & POS', '', '', 'Terima kasih telah berbelanja!', '{}', false)`
      );
      fixUps.push("baris ShopSettings id=1 dibuat");
    }
  } catch (e) {
    console.warn("[heal-db] fix-up ShopSettings gagal:", e);
  }

  // 2 & 3. Jaminan akses manajemen pengguna.
  try {
    const count = await db.user.count();
    if (count === 0) {
      const salt = generateSalt();
      await db.$executeRawUnsafe(
        `INSERT INTO "User" (name, username, role, pin, salt, mustChangePin,
           permissionDashboard, permissionCashier, permissionServices,
           permissionInventory, permissionCustomers, permissionUsers, permissionSettings)
         VALUES ('Administrator', 'admin', 'Admin', ?, ?, true, true, true, true, true, true, true, true)`,
        hashPin("1234", salt),
        salt
      );
      fixUps.push("tabel User kosong → akun admin awal dibuat (admin / 1234, wajib ganti PIN)");
    } else {
      const berizin = await db.user.count({ where: { permissionUsers: true } });
      if (berizin === 0) {
        // Admin pertama; bila tak ada role Admin, akun pertama dinaikkan jadi Admin.
        const target =
          (await db.user.findFirst({ where: { role: "Admin" }, orderBy: { id: "asc" } })) ??
          (await db.user.findFirst({ orderBy: { id: "asc" } }));
        if (target) {
          await db.user.update({
            where: { id: target.id },
            data: {
              role: "Admin",
              permissionDashboard: true,
              permissionCashier: true,
              permissionServices: true,
              permissionInventory: true,
              permissionCustomers: true,
              permissionUsers: true,
              permissionSettings: true,
            },
          });
          fixUps.push(
            `tidak ada akun berizin Pengguna → akun "${target.username}" diberi semua izin (role Admin)`
          );
        }
      }
    }
  } catch (e) {
    console.warn("[heal-db] fix-up akun admin gagal:", e);
  }

  // 4. D71 — tautkan profil teknisi yatim (userId NULL) ke akun Pengguna role
  //    Teknisi dengan nama sama (abaikan besar-kecil) yang belum tertaut.
  //    Menyatukan dua daftar lama: teknisi manual + akun Teknisi yang sama orang.
  try {
    const orphans = await db.$queryRawUnsafe<{ id: number; name: string }[]>(
      `SELECT id, name FROM Technician WHERE "userId" IS NULL`
    );
    const teknisis = orphans ?? [];
    if (teknisis.length) {
      const candidates = await db.user.findMany({
        where: { role: "Teknisi" },
        select: { id: true, name: true },
      });
      for (const t of teknisis) {
        const sameName = candidates.find(
          (u) => u.name.trim().toLowerCase() === String(t.name).trim().toLowerCase()
        );
        if (!sameName) continue;
        const taken = await db.technician.findFirst({ where: { userId: sameName.id } });
        if (taken) continue; // akun ini sudah tertaut profil lain — biarkan
        await db.$executeRawUnsafe(`UPDATE Technician SET "userId" = ? WHERE id = ?`, sameName.id, t.id);
        fixUps.push(`teknisi "${t.name}" tertaut ke akun "${sameName.name}"`);
      }
    }
  } catch (e) {
    console.warn("[heal-db] fix-up tautan teknisi gagal:", e);
  }

  // 5. D74 — baris seq awal ('dataVersion' = 0) bila belum ada; bump di db.ts
  //    menaikkan nilainya sendiri via upsert, jadi ini hanya jaminan awal.
  try {
    const created = await db.$executeRawUnsafe(
      `INSERT OR IGNORE INTO AppMeta (key, value) VALUES ('dataVersion', '0')`
    );
    if (created) fixUps.push("baris AppMeta dataVersion (seq) dibuat");
  } catch (e) {
    console.warn("[heal-db] fix-up AppMeta gagal:", e);
  }
}

async function runHeal(): Promise<HealReport> {
  const report: HealReport = {
    ok: false,
    tablesCreated: [],
    columnsAdded: [],
    fixUps: [],
    skipped: [],
  };
  try {
    const tables = await existingTables();

    // 1. Tabel hilang → dibuat utuh (data tetap ada bila tabelnya sudah ada).
    for (const [table, ddl] of Object.entries(CREATE_DDL)) {
      if (!tables.has(table)) {
        await db.$executeRawUnsafe(ddl);
        report.tablesCreated.push(table);
      }
    }

    // 2. Kolom hilang → ALTER TABLE ADD COLUMN (baris lama terisi DEFAULT).
    for (const [table, cols] of Object.entries(ADD_COLUMNS)) {
      const have = await existingColumns(table);
      if (have.size === 0) continue; // tabel baru saja dibuat — DDL-nya sudah lengkap
      for (const colDef of cols) {
        const colName = colDef.slice(0, colDef.indexOf(" ")).replace(/"/g, "");
        if (have.has(colName)) continue;
        try {
          await db.$executeRawUnsafe(`ALTER TABLE ${JSON.stringify(table)} ADD COLUMN ${colDef}`);
          report.columnsAdded.push(`${table}.${colName}`);
        } catch (e) {
          const msg = e instanceof Error ? e.message : String(e);
          if (/duplicate column/i.test(msg)) continue; // balapan antar proses — abaikan
          if (/cannot add a (NOT NULL|non-DEFAULT)/i.test(msg)) {
            report.skipped.push(`${table}.${colName}`);
            continue;
          }
          throw e;
        }
      }
    }

    // 2b. D71 — indeks unik Technician.userId
    for (const idx of ENSURE_INDEXES) {
      try {
        await db.$executeRawUnsafe(idx.sql);
      } catch (e) {
        console.warn(`[heal-db] indeks ${idx.name} gagal dibuat:`, e);
      }
    }

    // 3. Fix-up data (profil toko & jaminan akun admin berizin).
    await runFixUps(report.fixUps);

    // 4. Catat ke audit HANYA bila benar-benar ada perbaikan (hindari spam).
    if (
      report.tablesCreated.length ||
      report.columnsAdded.length ||
      report.fixUps.length
    ) {
      const parts: string[] = [];
      if (report.tablesCreated.length) parts.push(`tabel dibuat: ${report.tablesCreated.join(", ")}`);
      if (report.columnsAdded.length) parts.push(`kolom ditambah: ${report.columnsAdded.join(", ")}`);
      if (report.fixUps.length) parts.push(`perbaikan data: ${report.fixUps.join("; ")}`);
      if (report.skipped.length) parts.push(`tak dapat ditambah: ${report.skipped.join(", ")}`);
      try {
        await db.auditLog.create({
          data: {
            action: "HEAL_DATABASE",
            details: `Skema database disesuaikan otomatis (D55) — ${parts.join(" | ")}`,
            performedBy: "Sistem",
          },
        });
      } catch (e) {
        // Audit gagal tidak boleh menggagalkan penyembuhan.
        console.warn("[heal-db] pencatatan audit gagal:", e);
      }
      console.log("[heal-db]", parts.join(" | "));
    }

    report.ok = true;
    return report;
  } catch (e) {
    console.error("[heal-db] penyembuhan skema gagal:", e);
    return report;
  }
}

let inflight: Promise<HealReport> | null = null;
let ranOnce = false;
let lastOk = false;

const EMPTY_REPORT: HealReport = {
  ok: true,
  tablesCreated: [],
  columnsAdded: [],
  fixUps: [],
  skipped: [],
};

export async function ensureSchema(opts?: { force?: boolean }): Promise<HealReport> {
  // Dedup: heal yang sedang berjalan dipakai bersama antar-request.
  if (inflight) return inflight;
  // Tanpa force: bila heal proses ini sudah selesai & sukses, tidak perlu
  // jalan ulang (pemanggil biasa hanya butuh sekali — instrumentation).
  if (!opts?.force && ranOnce && lastOk) return EMPTY_REPORT;
  inflight = runHeal().finally(() => {
    inflight = null;
  });
  const result = await inflight;
  ranOnce = true;
  lastOk = result.ok;
  return result;
}
