"use client";

// D92 — Kas Laci (alur absensi otomatis).
//
// Empat komponen di file ini:
//  1. useDrawerStatus() — hook status laci hari ini dari GET /api/drawer.
//  2. KasAwalDialog — dialog WAJIB setelah login pertama dalam 1 hari:
//     pemakai mengisi jumlah kas di laci (tidak bisa ditutup/diabaikan).
//  3. TutupLaciButton + dialog — tombol "Tutup Laci" (topbar & halaman
//     Absensi): input kas fisik → server mencatat kas, MENUTUP ABSEN, lalu
//     UI otomatis logout (onAfterClose).
//  4. KasLaciPanel — kartu status laci di halaman Absensi.
import { useCallback, useEffect, useState } from "react";
import { Banknote, LogOut, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/format";
import type { SafeUser } from "@/lib/app-types";

export type DrawerSessionInfo = {
  id: number;
  userName: string;
  date: string;
  openingCash: number;
  closingCash: number | null;
  cashIn: number | null;
  expectedCash: number | null;
  selisih: number | null;
  openingAt: string;
  closingAt: string | null;
  isOpen: boolean;
  jamBuka: string;
  jamTutup: string | null;
};

export type DrawerStatus = {
  today: DrawerSessionInfo | null;
  isOpen: boolean;
  cashIn: number;
  expected: number;
  attendance: { checkIn: string | null; checkOut: string | null; status: string } | null;
};

async function apiJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string }).error || "Terjadi kesalahan");
  return data as T;
}

// D92 — event sinkron antar komponen: dialog Kas Awal (AppRoot) & tombol
// Tutup Laci (topbar) & panel Absensi adalah TIGA komponen terpisah dengan
// status laci masing-masing — setiap perubahan laci menembakkan event ini
// agar semua penampung mengambil ulang status (tanpa reload halaman).
const LACI_EVENT = "fixplus:laci-changed";
function notifyLaciChanged() {
  if (typeof window !== "undefined") window.dispatchEvent(new Event(LACI_EVENT));
}

/** Hook status kas laci hari ini (semua role). */
export function useDrawerStatus(username: string) {
  const [status, setStatus] = useState<DrawerStatus | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const d = await apiJson<DrawerStatus>(
        `/api/drawer?requesterUsername=${encodeURIComponent(username)}`
      );
      setStatus(d);
    } catch {
      // biarkan status lama — jangan blokir aplikasi bila API sedang tidak bisa
    } finally {
      setLoading(false);
    }
  }, [username]);

  useEffect(() => {
    setLoading(true);
    setStatus(null);
    void refresh();
  }, [refresh]);

  // D92 — refresh otomatis saat laci berubah di komponen lain.
  useEffect(() => {
    const on = () => void refresh();
    window.addEventListener(LACI_EVENT, on);
    return () => window.removeEventListener(LACI_EVENT, on);
  }, [refresh]);

  return { status, loading, refresh };
}

/** Input rupiah: hanya angka. */
function digitsOnly(v: string): string {
  return v.replace(/\D/g, "").slice(0, 11);
}

/** Selisih kas → warna + label ("kas lebih" hijau / "kas kurang" merah / cocok). */
function selisihTone(sel: number): { cls: string; label: string } {
  if (sel > 0) return { cls: "text-green-700", label: `+${formatCurrency(sel)} (kas lebih)` };
  if (sel < 0) return { cls: "text-red-700", label: `−${formatCurrency(-sel)} (kas kurang)` };
  return { cls: "text-muted-foreground", label: "Cocok" };
}

// ===== 2. Dialog Kas Awal (wajib, tidak bisa ditutup) =====
export function KasAwalDialog({
  user,
  jamMasuk,
  onDone,
}: {
  user: SafeUser;
  jamMasuk?: string | null;
  onDone: () => void;
}) {
  const { toast } = useToast();
  const [kas, setKas] = useState("");
  const [busy, setBusy] = useState(false);

  const kasNum = Number(kas || "0");
  const valid = kas !== "" && kasNum >= 0 && kasNum <= 100_000_000;

  async function simpan() {
    if (!valid || busy) return;
    setBusy(true);
    try {
      await apiJson("/api/drawer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requesterUsername: user.username, openingCash: kasNum }),
      });
      notifyLaciChanged(); // topbar/panel langsung tahu laci kini terbuka
      toast({ title: "Kas awal tercatat — laci terbuka, selamat bekerja!" });
      onDone();
    } catch (e) {
      toast({
        title: e instanceof Error ? e.message : "Gagal menyimpan kas awal",
        variant: "destructive",
      });
      setBusy(false);
    }
  }

  return (
    <Dialog open>
      <DialogContent
        showCloseButton={false}
        className="rounded-2xl sm:max-w-md"
        onEscapeKeyDown={(e) => e.preventDefault()}
        onInteractOutside={(e) => e.preventDefault()}
        onPointerDownOutside={(e) => e.preventDefault()}
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wallet className="size-5 text-primary" aria-hidden />
            Isi Kas Awal di Laci
          </DialogTitle>
          <DialogDescription>
            Selamat bekerja, {user.name}!{jamMasuk ? ` Absen masuk otomatis tercatat pukul ${jamMasuk} WIB.` : ""}{" "}
            Sebelum mulai, hitung dan masukkan jumlah kas yang ada di laci saat ini.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-3">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="kas-awal">Jumlah Kas di Laci (Rp)</Label>
            <Input
              id="kas-awal"
              inputMode="numeric"
              autoFocus
              placeholder="Misal: 500000"
              value={kas}
              onChange={(e) => setKas(digitsOnly(e.target.value))}
              onKeyDown={(e) => {
                if (e.key === "Enter") void simpan();
              }}
              className="h-11 rounded-xl font-mono text-base tabular-nums"
            />
            {kas !== "" && (
              <p className="text-xs font-semibold text-primary tabular-nums">{formatCurrency(kasNum)}</p>
            )}
          </div>
          <p className="rounded-xl bg-muted p-3 text-xs text-muted-foreground">
            Kas awal wajib diisi sekali per hari. Di akhir shift, gunakan tombol{" "}
            <span className="font-bold text-foreground">&quot;Tutup Laci&quot;</span> untuk mencatat kas fisik,
            menutup absen, dan keluar dari aplikasi.
          </p>
        </div>
        <DialogFooter>
          <Button onClick={() => void simpan()} disabled={!valid || busy} className="h-11 flex-1 rounded-xl font-bold">
            {busy ? "Menyimpan..." : "Simpan & Buka Laci"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ===== 3. Tombol Tutup Laci (+ dialog) =====
export function TutupLaciButton({
  user,
  onAfterClose,
  size = "sm",
}: {
  user: SafeUser;
  onAfterClose: () => void;
  size?: "sm" | "lg";
}) {
  const { toast } = useToast();
  const { status, refresh } = useDrawerStatus(user.username);
  const [open, setOpen] = useState(false);
  const [kas, setKas] = useState("");
  const [busy, setBusy] = useState(false);

  const sesi = status?.today ?? null;
  const terbuka = status?.isOpen ?? false;

  async function bukaDialog() {
    setKas("");
    setOpen(true);
    await refresh(); // ambil angka tunai terbaru saat dialog dibuka
  }

  const kasNum = Number(kas || "0");
  const valid = kas !== "" && kasNum >= 0 && kasNum <= 100_000_000;
  const expected = status?.expected ?? 0;
  const previewSel = kas === "" ? null : kasNum - expected;
  const tone = previewSel !== null ? selisihTone(previewSel) : null;

  async function tutup() {
    if (!valid || busy) return;
    setBusy(true);
    try {
      await apiJson("/api/drawer", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requesterUsername: user.username, closingCash: kasNum }),
      });
      toast({
        title: "Laci ditutup — absen keluar tercatat. Terima kasih!",
        description: "Anda akan keluar dari aplikasi...",
      });
      setOpen(false);
      notifyLaciChanged(); // panel Absensi (bila terbuka) ikut memuat status baru
      // Tunda sesaat agar toast sempat terbaca sebelum layar kembali ke login.
      setTimeout(onAfterClose, 900);
    } catch (e) {
      toast({
        title: e instanceof Error ? e.message : "Gagal menutup laci",
        variant: "destructive",
      });
      setBusy(false);
    }
  }

  if (!terbuka) return null; // laci belum dibuka / sudah ditutup — tanpa tombol

  return (
    <>
      <Button
        variant="outline"
        onClick={() => void bukaDialog()}
        size={size === "lg" ? "default" : "sm"}
        className={"rounded-xl font-bold " + (size === "lg" ? "h-11" : "h-9")}
        title="Catat kas fisik di laci, tutup absen, dan keluar dari aplikasi"
      >
        <Wallet className="size-4" aria-hidden />
        Tutup Laci
      </Button>

      <Dialog open={open} onOpenChange={(o) => !busy && setOpen(o)}>
        <DialogContent className="rounded-2xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <LogOut className="size-5 text-destructive" aria-hidden />
              Tutup Laci — Catat Kas &amp; Keluar
            </DialogTitle>
            <DialogDescription>
              Hitung kas fisik yang ada di laci sekarang. Menutup laci sekaligus MENCATAT ABSEN KELUAR dan
              mengeluarkan Anda dari aplikasi.
            </DialogDescription>
          </DialogHeader>

          <div className="flex flex-col gap-3">
            <div className="rounded-xl border bg-muted/40 p-3 text-sm">
              <div className="flex justify-between py-0.5">
                <span className="text-muted-foreground">Kas awal ({sesi?.jamBuka ?? "—"} WIB)</span>
                <span className="font-semibold tabular-nums">{formatCurrency(sesi?.openingCash ?? 0)}</span>
              </div>
              <div className="flex justify-between py-0.5">
                <span className="text-muted-foreground">Penjualan tunai selama shift</span>
                <span className="font-semibold tabular-nums text-green-700">
                  +{formatCurrency(status?.cashIn ?? 0)}
                </span>
              </div>
              <div className="mt-1 flex justify-between border-t pt-1.5">
                <span className="font-bold">Kas seharusnya di laci</span>
                <span className="font-black tabular-nums">{formatCurrency(expected)}</span>
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <Label htmlFor="kas-tutup">Jumlah kas fisik di laci (Rp)</Label>
              <Input
                id="kas-tutup"
                inputMode="numeric"
                autoFocus
                placeholder="Misal: 750000"
                value={kas}
                onChange={(e) => setKas(digitsOnly(e.target.value))}
                onKeyDown={(e) => {
                  if (e.key === "Enter") void tutup();
                }}
                className="h-11 rounded-xl font-mono text-base tabular-nums"
              />
              {tone && (
                <p className={"text-xs font-bold tabular-nums " + tone.cls}>Selisih: {tone.label}</p>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} disabled={busy} className="rounded-xl">
              Batal
            </Button>
            <Button
              variant="destructive"
              onClick={() => void tutup()}
              disabled={!valid || busy}
              className="h-11 rounded-xl font-bold"
            >
              {busy ? "Menutup..." : "Tutup Laci, Absen Keluar & Keluar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

// ===== 4. Panel status laci (halaman Absensi) =====
export function KasLaciPanel({ user, onAfterClose }: { user: SafeUser; onAfterClose: () => void }) {
  const { status, loading } = useDrawerStatus(user.username);
  const sesi = status?.today ?? null;
  const terbuka = status?.isOpen ?? false;
  const selisih = sesi?.selisih ?? null;
  const tone = selisih !== null ? selisihTone(selisih) : null;

  return (
    <Card className="rounded-2xl">
      <CardContent className="flex flex-col gap-3 p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Banknote className="size-5 text-primary" aria-hidden />
            <div>
              <p className="text-sm font-bold">Kas Laci Hari Ini</p>
              <p className="text-xs text-muted-foreground">
                Kas awal diisi saat login pertama · dicatat per orang per hari
              </p>
            </div>
          </div>
          <span
            className={
              "inline-flex items-center gap-1.5 rounded-xl px-2.5 py-1 text-[11px] font-black " +
              (terbuka
                ? "bg-green-100 text-green-800"
                : sesi
                  ? "bg-slate-100 text-slate-600"
                  : "bg-amber-100 text-amber-800")
            }
          >
            <span
              className={
                "size-1.5 rounded-full " +
                (terbuka ? "bg-green-600 animate-pulse" : sesi ? "bg-slate-400" : "bg-amber-500")
              }
              aria-hidden
            />
            {terbuka ? "LACI TERBUKA" : sesi ? "SUDAH DITUTUP" : "BELUM DIBUKA"}
          </span>
        </div>

        {loading ? (
          <p className="py-2 text-sm text-muted-foreground">Memuat status laci...</p>
        ) : !sesi ? (
          <p className="rounded-xl bg-amber-50 p-3 text-xs text-amber-800">
            Laci belum dibuka hari ini. Kas awal diisi lewat dialog{" "}
            <span className="font-bold">&quot;Isi Kas Awal&quot;</span> yang muncul saat login pertama hari itu.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <div className="rounded-xl border bg-muted/40 p-3">
              <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">Kas Awal</p>
              <p className="font-mono text-lg font-black tabular-nums">{formatCurrency(sesi.openingCash)}</p>
              <p className="text-[10px] text-muted-foreground">dibuka {sesi.jamBuka} WIB</p>
            </div>
            <div className="rounded-xl border bg-muted/40 p-3">
              <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
                Penjualan Tunai
              </p>
              <p className="font-mono text-lg font-black tabular-nums text-green-700">
                +{formatCurrency(status?.cashIn ?? sesi.cashIn ?? 0)}
              </p>
              <p className="text-[10px] text-muted-foreground">
                {terbuka ? "berjalan (live)" : `snapshot saat tutup`}
              </p>
            </div>
            <div className="rounded-xl border bg-muted/40 p-3">
              <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
                Kas Fisik Saat Tutup
              </p>
              <p className="font-mono text-lg font-black tabular-nums">
                {sesi.closingCash !== null ? formatCurrency(sesi.closingCash) : "—"}
              </p>
              <p className="text-[10px] text-muted-foreground">
                {sesi.jamTutup ? `ditutup ${sesi.jamTutup} WIB` : "laci masih terbuka"}
              </p>
            </div>
            {selisih !== null && (
              <div className="col-span-2 rounded-xl border bg-muted/40 p-3 sm:col-span-3">
                <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
                  Selisih Kas (fisik − tercatat {formatCurrency(sesi.expectedCash ?? 0)})
                </p>
                <p className={"font-mono text-lg font-black tabular-nums " + tone?.cls}>{tone?.label}</p>
              </div>
            )}
          </div>
        )}

        {terbuka && (
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-[11px] text-muted-foreground">
              Menutup laci = catat kas fisik + tutup absen + keluar aplikasi
            </p>
            <TutupLaciButton user={user} onAfterClose={onAfterClose} size="lg" />
          </div>
        )}
      </CardContent>
    </Card>
  );
}
