"use client";

// MainLayout.kt → versi web: topbar + sidebar desktop + bottom-nav mobile (SERVIS,
// KASIR, INVENTARIS) + drawer menu (LAPORAN, BELANJA, PELANGGAN, SETTING)
import { useState, useCallback } from "react";
import {
  BarChart3,
  CalendarClock,
  CircleUser,
  ClipboardList,
  KeyRound,
  Menu,
  Package,
  PanelLeftClose,
  PanelLeftOpen,
  ShoppingCart,
  Settings,
  Users,
  Wrench,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import { isTabAllowed, TAB_LABEL, type SafeUser, type ShopTab } from "@/lib/app-types";
import { bolehAsistenAi } from "@/lib/user-utils"; // D59 — gate Asisten AI
import { SectionBody } from "@/components/app/sections/placeholder-sections";
import { GantiPinDialog } from "@/components/app/ganti-pin-dialog"; // Tahap 7.3
import { AiAssistant } from "@/components/app/ai-assistant"; // D50 — asisten AI (bubble melayang)
import { RecoveryBanner } from "@/components/app/recovery-banner"; // D75 — panduan pemulihan darurat
import { BackupStatus } from "@/components/app/backup-status"; // D80 — indikator backup + tombol cepat
import { NotificationBell } from "@/components/app/notification-bell"; // D81 — pusat notifikasi aplikasi
import { TutupLaciButton } from "@/components/app/kas-laci"; // D92 — tutup laci = catat kas + tutup absen + logout
import type { Repair } from "@/components/app/sections/servis-receipt";

const AccountCircle = CircleUser;

const TAB_ICON: Record<ShopTab, React.ComponentType<{ className?: string }>> = {
  LAPORAN: BarChart3,
  SERVIS: Wrench,
  KASIR: ShoppingCart,
  INVENTARIS: Package,
  BELANJA: ClipboardList,
  PELANGGAN: Users,
  ABSENSI: CalendarClock, // D73
  SETTING: Settings,
};

// Urutan default auto-redirect = urutan ShopTab.values() di MainLayout.kt
const TAB_ORDER: ShopTab[] = ["LAPORAN", "SERVIS", "KASIR", "INVENTARIS", "BELANJA", "PELANGGAN", "ABSENSI", "SETTING"];
// Bottom nav mobile = listOf(SERVIS, KASIR, INVENTARIS)
const BOTTOM_TABS: ShopTab[] = ["SERVIS", "KASIR", "INVENTARIS"];
// Sidebar/drawer = listOf(LAPORAN, BELANJA, PELANGGAN, ABSENSI, SETTING)
const DRAWER_TABS: ShopTab[] = ["LAPORAN", "BELANJA", "PELANGGAN", "ABSENSI", "SETTING"];
// Sidebar minimize (desktop): pilihan disimpan agar bertahan setelah reload
const SIDEBAR_MIN_KEY = "pos-sidebar-min";

function NavItem({
  tab,
  onSelect,
  active,
  collapsed,
}: {
  tab: ShopTab;
  onSelect: () => void;
  active: boolean;
  collapsed: boolean;
}) {
  const Icon = TAB_ICON[tab];
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-current={active ? "page" : undefined}
      title={collapsed ? TAB_LABEL[tab] : undefined}
      className={
        "flex w-full items-center rounded-xl text-sm transition-colors " +
        (collapsed ? "justify-center px-0 py-2.5 " : "gap-3 px-3 py-2.5 ") +
        (active
          ? "bg-accent font-bold text-accent-foreground"
          : "text-muted-foreground hover:bg-muted hover:text-foreground")
      }
    >
      <Icon className={"size-5 shrink-0 " + (active ? "text-primary" : "")} />
      {!collapsed && <span className="truncate">{TAB_LABEL[tab]}</span>}
    </button>
  );
}

function SidebarContent({
  shopName,
  user,
  selectedTab,
  onSelect,
  collapsed = false,
}: {
  shopName: string;
  user: SafeUser;
  selectedTab: ShopTab;
  onSelect: (tab: ShopTab) => void;
  collapsed?: boolean;
}) {
  const allowedDrawer = DRAWER_TABS.filter((t) => isTabAllowed(t, user));
  const allowedBottom = BOTTOM_TABS.filter((t) => isTabAllowed(t, user));
  return (
    <div className={"flex h-full flex-col gap-2 " + (collapsed ? "p-2 pt-3" : "p-4")}>
      {collapsed ? (
        <div className="flex items-center justify-center py-4" title={shopName}>
          <div className="flex size-9 items-center justify-center rounded-xl bg-primary/10">
            <Wrench className="size-5 text-primary" aria-hidden />
          </div>
        </div>
      ) : (
        <div className="flex items-center gap-3 px-3 py-4">
          <div className="flex size-9 items-center justify-center rounded-xl bg-primary/10">
            <Wrench className="size-5 text-primary" aria-hidden />
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-bold">{shopName}</p>
            <p className="text-xs text-muted-foreground">Sistem POS &amp; Servis</p>
          </div>
        </div>
      )}
      <Separator />
      {collapsed ? (
        <>
          {allowedDrawer.map((tab) => (
            <NavItem
              key={tab}
              tab={tab}
              active={selectedTab === tab}
              onSelect={() => onSelect(tab)}
              collapsed
            />
          ))}
          <Separator className="mx-2 my-1" />
          {allowedBottom.map((tab) => (
            <NavItem
              key={tab}
              tab={tab}
              active={selectedTab === tab}
              onSelect={() => onSelect(tab)}
              collapsed
            />
          ))}
        </>
      ) : (
        <>
          <p className="px-3 pb-1 pt-4 text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
            Menu Utama
          </p>
          {allowedDrawer.map((tab) => (
            <NavItem
              key={tab}
              tab={tab}
              active={selectedTab === tab}
              onSelect={() => onSelect(tab)}
              collapsed={false}
            />
          ))}
          <p className="px-3 pb-1 pt-4 text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
            Operasional
          </p>
          {allowedBottom.map((tab) => (
            <NavItem
              key={tab}
              tab={tab}
              active={selectedTab === tab}
              onSelect={() => onSelect(tab)}
              collapsed={false}
            />
          ))}
        </>
      )}
      <div className="mt-auto">
        {collapsed ? (
          <div
            className="flex justify-center py-1"
            title={`${user.name} · ${user.role}`}
          >
            <AccountCircle className="size-8 text-primary" aria-hidden />
          </div>
        ) : (
          <div className="flex items-center gap-2.5 rounded-xl bg-muted p-3">
            <AccountCircle className="size-8 shrink-0 text-primary" aria-hidden />
            <div className="min-w-0">
              <p className="truncate text-[13px] font-bold">{user.name}</p>
              <p className="text-[11px] text-muted-foreground">{user.role}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export function AppShell({
  user,
  shopName,
  onLogout,
  onShopNameChange,
  onSwitchUser,
}: {
  user: SafeUser;
  shopName: string;
  onLogout: () => void;
  // Tahap 7.1: profil toko tersimpan → nama di top bar/login diperbarui langsung
  onShopNameChange: (shopName: string) => void;
  // D41: gerbang "Akses Terbatas" Setting — pilih Admin + PIN → sesi berpindah
  onSwitchUser: (u: SafeUser) => void;
}) {
  // Default tab: KASIR (MainLayout.kt); bila tidak diizinkan, pakai tab pertama yang diizinkan
  const [selectedTab, setSelectedTab] = useState<ShopTab>(() =>
    isTabAllowed("KASIR", user)
      ? "KASIR"
      : (TAB_ORDER.find((t) => isTabAllowed(t, user)) ?? "KASIR")
  );
  const [drawerOpen, setDrawerOpen] = useState(false);
  // Sidebar minimize (desktop): konten lebih luas; pilihan disimpan di localStorage.
  // Aman hydration: AppShell hanya dirender di client setelah login (gate `ready` di AppRoot).
  const [sidebarMin, setSidebarMin] = useState<boolean>(() => {
    try {
      return typeof window !== "undefined" && window.localStorage.getItem(SIDEBAR_MIN_KEY) === "1";
    } catch {
      return false;
    }
  });
  const toggleSidebarMin = useCallback(() => {
    setSidebarMin((v) => {
      const nv = !v;
      try {
        window.localStorage.setItem(SIDEBAR_MIN_KEY, nv ? "1" : "0");
      } catch {
        /* abaikan */
      }
      return nv;
    });
  }, []);
  // Tahap 4.6: tiket servis yang dibawa ke Kasir (ala selectedRepairForCheckout
  // MainLayout.kt — tab otomatis pindah ke KASIR saat tiket dibawa)
  const [pendingRepair, setPendingRepair] = useState<Repair | null>(null);
  const checkoutRepair = useCallback((r: Repair) => {
    setPendingRepair(r);
    setSelectedTab("KASIR");
  }, []);
  // D72: arah sebaliknya — "Tambah Transaksi → Terima Servis" dari halaman Kasir:
  // tab berpindah ke SERVIS dan form tiket langsung terbuka (ala FAB referensi).
  // Pemicu sekali-pakai: dikonsumsi ServisSection lalu direset agar remount tab
  // berikutnya tidak membuka form lagi.
  const [serviceFormRequest, setServiceFormRequest] = useState(false);
  const openServiceForm = useCallback(() => {
    setServiceFormRequest(true);
    setSelectedTab("SERVIS");
  }, []);
  const serviceFormConsumed = useCallback(() => setServiceFormRequest(false), []);
  // Tahap 7.3: ganti PIN sendiri dari dropdown akun (semua role)
  const [gantiPinOpen, setGantiPinOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar permanen (desktop) — bisa diminimalkan jadi rail ikon */}
      <aside
        className={
          "sticky top-0 hidden h-screen shrink-0 border-r bg-card transition-[width] duration-200 md:block " +
          (sidebarMin ? "w-16" : "w-64")
        }
      >
        <SidebarContent
          shopName={shopName}
          user={user}
          selectedTab={selectedTab}
          onSelect={setSelectedTab}
          collapsed={sidebarMin}
        />
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Top bar */}
        <header className="sticky top-0 z-20 flex h-14 items-center gap-2 border-b bg-card px-4">
          {/* Hamburger + drawer (mobile) — menu sama seperti drawer Android */}
          <Sheet open={drawerOpen} onOpenChange={setDrawerOpen}>
            <SheetTrigger asChild>
              <button
                type="button"
                aria-label="Menu Samping"
                className="rounded-lg p-2 hover:bg-muted md:hidden"
              >
                <Menu className="size-5" aria-hidden />
              </button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[300px] rounded-r-2xl p-0">
              <SheetHeader className="sr-only">
                <SheetTitle>Menu Samping</SheetTitle>
              </SheetHeader>
              <SidebarContent
                shopName={shopName}
                user={user}
                selectedTab={selectedTab}
                onSelect={(t) => {
                  setSelectedTab(t);
                  setDrawerOpen(false);
                }}
              />
            </SheetContent>
          </Sheet>

          {/* Tombol minimize/expand sidebar (desktop) — agar tampilan konten lebih luas */}
          <button
            type="button"
            onClick={toggleSidebarMin}
            aria-label={sidebarMin ? "Perluas Sidebar" : "Minimalkan Sidebar"}
            aria-pressed={sidebarMin}
            title={sidebarMin ? "Perluas Sidebar" : "Minimalkan Sidebar"}
            className="hidden rounded-lg p-2 hover:bg-muted md:block"
          >
            {sidebarMin ? (
              <PanelLeftOpen className="size-5" aria-hidden />
            ) : (
              <PanelLeftClose className="size-5" aria-hidden />
            )}
          </button>

          <div className="flex min-w-0 items-center gap-2">
            <Wrench className="size-5 shrink-0 text-primary" aria-hidden />
            <span className="truncate font-bold">{shopName}</span>
          </div>

          {/* D80/D81/D92 — area kanan atas terlihat dari HALAMAN MANAPUN: lonceng
              notifikasi (panel riwayat kejadian — backup, konflik, pulihkan),
              indikator backup + tombol backup cepat, tombol TUTUP LACI (semua
              role — catat kas, tutup absen, keluar), lalu tombol akun.
              Lonceng/backup hanya Admin (API-nya juga menolak non-Admin server-side). */}
          <div className="ml-auto flex items-center gap-2">
            <TutupLaciButton user={user} onAfterClose={onLogout} />
            {user.role === "Admin" && (
              <>
                <NotificationBell requesterUsername={user.username} />
                <BackupStatus
                  requesterUsername={user.username}
                  onOpenSettings={() => setSelectedTab("SETTING")}
                />
              </>
            )}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  type="button"
                  className="flex items-center gap-1.5 rounded-2xl bg-accent px-3 py-1.5 text-xs font-bold text-accent-foreground transition-colors hover:bg-muted"
                >
                  <AccountCircle className="size-4 text-primary" aria-hidden />
                  <span className="max-w-[120px] truncate">{user.name}</span>
                  <span className="font-semibold text-primary">({user.role})</span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <p className="text-sm font-bold">{user.name}</p>
                  <p className="text-xs font-normal text-muted-foreground">
                    @{user.username} · {user.role}
                  </p>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => setGantiPinOpen(true)}
                  className="font-semibold"
                >
                  <KeyRound className="size-4" aria-hidden />
                  Ganti PIN
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={onLogout}
                  className="font-semibold text-destructive focus:text-destructive"
                >
                  Keluar &amp; Ganti Akun
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* D75 — panduan pemulihan darurat: DB kosong + GitHub belum terhubung
            / autoRestore mati → arahkan Admin menghubungkan ulang GitHub agar
            cadangan terakhir otomatis dipulihkan (token masuk sekali). */}
        <RecoveryBanner user={user} onOpenSettings={() => setSelectedTab("SETTING")} />

        {/* Konten tab aktif */}
        <main className="min-h-[calc(100vh-3.5rem)] flex-1 p-4 pb-24 md:pb-8">
          <div className={"mx-auto w-full transition-[max-width] duration-200 " + (sidebarMin ? "max-w-7xl" : "max-w-6xl")}>
            <SectionBody
              tab={selectedTab}
              user={user}
              pendingRepair={pendingRepair}
              onCheckoutRepair={checkoutRepair}
              onClearPendingRepair={() => setPendingRepair(null)}
              onShopUpdated={onShopNameChange}
              onSwitchUser={onSwitchUser}
              onOpenServiceForm={openServiceForm}
              serviceFormRequest={serviceFormRequest}
              onServiceFormRequestConsumed={serviceFormConsumed}
              onLogout={onLogout}
            />
          </div>
        </main>
      </div>

      {/* Bottom nav (mobile) — SERVIS, KASIR, INVENTARIS */}
      <nav
        aria-label="Navigasi utama"
        className="fixed inset-x-0 bottom-0 z-20 flex border-t bg-card md:hidden"
      >
        {BOTTOM_TABS.filter((t) => isTabAllowed(t, user)).map((tab) => {
          const Icon = TAB_ICON[tab];
          const active = selectedTab === tab;
          return (
            <button
              key={tab}
              type="button"
              onClick={() => setSelectedTab(tab)}
              aria-current={active ? "page" : undefined}
              className="flex flex-1 flex-col items-center gap-0.5 py-2.5"
            >
              <Icon className={"size-5 " + (active ? "text-primary" : "text-muted-foreground")} />
              <span
                className={
                  "text-[11px] " + (active ? "font-bold text-primary" : "text-muted-foreground")
                }
              >
                {TAB_LABEL[tab]}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Tahap 7.3 — dialog Ganti PIN sendiri (semua role) */}
      <GantiPinDialog user={user} open={gantiPinOpen} onOpenChange={setGantiPinOpen} />

      {/* D50 — Asisten AI: bubble melayang di semua halaman.
          D59 — hanya Administrator/Owner (Kasir & Teknisi tidak melihatnya;
          API-nya juga menolak non-Admin server-side). */}
      {bolehAsistenAi(user.role) && <AiAssistant user={user} />}
    </div>
  );
}
