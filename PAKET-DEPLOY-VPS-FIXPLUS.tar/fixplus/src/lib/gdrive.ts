// D67 — Integrasi Google Drive (backend murni, tanpa dependensi baru):
// semua panggilan API Drive v3 memakai fetch bawaan + penandatanganan JWT
// service account memakai crypto Node/Bun.
//
// Dua jalur koneksi (keduanya bisa aktif bersamaan; backup memilih salah satu):
//   A. OAuth 2.0 "Hubungkan Google" — kredensial OAuth Client milik toko,
//      scope least-privilege drive.file (+ userinfo.email hanya untuk nama akun).
//      File cadangan masuk folder "Fixplus Backup" di Drive pengguna.
//   B. Service Account — kunci JSON server-ke-server, tanpa popup. Wajib
//      Folder ID yang sudah dibagikan (Editor) ke email service account.
//
// Penyimpanan kredensial: berkas JSON di samping database
// (<dir db>/gdrive-credentials.json) — tidak ikut ter-backup di file .db
// (token akses/refresh tidak boleh bercampur data bisnis).
//
// Auto-backup harian: penjadwal dipasang dari instrumentation.ts
// (startDriveAutoBackup) — cek tiap 10 menit; bila jam Jakarta >= jam target
// dan hari ini belum dibackup → upload + pangkas cadangan lama (keepLast).
import { readFile, writeFile } from "fs/promises";
import { dirname, join } from "path";
import { createSign, randomBytes } from "crypto";
import { db } from "@/lib/db";
import { dbPathFromEnv } from "@/lib/db-restore";

const JAKARTA_OFFSET_MS = 7 * 3600 * 1000;

export const GDRIVE_FOLDER_NAME = "Fixplus Backup";
export const BACKUP_FILE_PREFIX = "database-fixplus-";
const TOKEN_URL = "https://oauth2.googleapis.com/token";
const AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth";
// OAuth: least-privilege — hanya file yang dibuat aplikasi ini (+ email akun
// untuk ditampilkan). Service account memakai scope drive penuh (kunci server
// yang dikontrol pemilik; folder dibagikan manual ke email SA).
export const OAUTH_SCOPES = [
  "https://www.googleapis.com/auth/drive.file",
  "https://www.googleapis.com/auth/userinfo.email",
];
const SA_SCOPE = "https://www.googleapis.com/auth/drive";

// ===== Tipe & penyimpanan kredensial =====
export type OAuthCreds = {
  clientId: string;
  clientSecret: string;
  refreshToken?: string;
  accessToken?: string;
  accessTokenExpiry?: string; // ISO
  email?: string;
  folderId?: string;
};
export type SaCreds = {
  clientEmail: string;
  privateKey: string; // PEM dengan newline asli
  folderId: string;
};
export type AutoSettings = {
  enabled: boolean;
  hour: number; // 0-23 waktu Jakarta
  method: "auto" | "oauth" | "sa";
  keepLast: number;
};
export type GdriveCreds = {
  oauth?: OAuthCreds;
  sa?: SaCreds;
  auto?: AutoSettings;
  lastBackupAt?: string | null;
  lastAutoBackupDate?: string | null; // YYYY-MM-DD Jakarta
  lastBackupFile?: string | null;
  pendingOauth?: { state: string; redirectUri: string; expiry: string };
};

const DEFAULT_AUTO: AutoSettings = { enabled: false, hour: 21, method: "auto", keepLast: 7 };

function credPath(): string {
  const dbPath = dbPathFromEnv();
  return dbPath ? join(dirname(dbPath), "gdrive-credentials.json") : "";
}

export async function loadCreds(): Promise<GdriveCreds> {
  const p = credPath();
  if (!p) return {};
  try {
    const raw = await readFile(p, "utf8");
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? (parsed as GdriveCreds) : {};
  } catch {
    return {}; // belum ada / rusak — mulai kosong
  }
}

export async function saveCreds(patch: Partial<GdriveCreds>): Promise<GdriveCreds> {
  const merged = { ...(await loadCreds()), ...patch };
  const p = credPath();
  if (!p) throw new Error("Lokasi penyimpanan kredensial tidak diketahui (DATABASE_URL kosong)");
  await writeFile(p, JSON.stringify(merged, null, 2), "utf8");
  return merged;
}

export async function updateCreds(
  fn: (c: GdriveCreds) => GdriveCreds
): Promise<GdriveCreds> {
  return saveCreds(fn(await loadCreds()));
}

export function credsSummary(c: GdriveCreds) {
  return {
    oauth: {
      configured: Boolean(c.oauth?.clientId && c.oauth?.clientSecret),
      connected: Boolean(c.oauth?.refreshToken),
      email: c.oauth?.email ?? null,
      folderId: c.oauth?.folderId ?? null,
    },
    sa: {
      configured: Boolean(c.sa?.clientEmail && c.sa?.privateKey && c.sa?.folderId),
      clientEmail: c.sa?.clientEmail ?? null,
      folderId: c.sa?.folderId ?? null,
    },
    auto: c.auto ?? DEFAULT_AUTO,
    lastBackupAt: c.lastBackupAt ?? null,
    lastAutoBackupDate: c.lastAutoBackupDate ?? null,
    lastBackupFile: c.lastBackupFile ?? null,
  };
}

// ===== Waktu Jakarta =====
function jakartaNow() {
  const d = new Date(Date.now() + JAKARTA_OFFSET_MS);
  const iso = d.toISOString();
  return {
    dateStr: iso.slice(0, 10),
    hour: d.getUTCHours(),
    // database-fixplus-2026-11-14-0930.db
    stamp: `${iso.slice(0, 10)}-${iso.slice(11, 13)}${iso.slice(14, 16)}`,
  };
}

// ===== Akses token =====
const saTokenCache = new Map<string, { token: string; expiry: number }>();

async function fetchAccessToken(body: URLSearchParams): Promise<{
  access_token: string;
  expires_in: number;
  refresh_token?: string;
}> {
  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
  });
  const json = (await res.json().catch(() => ({}))) as Record<string, unknown>;
  if (!res.ok) {
    const desc = String(json.error_description ?? json.error ?? res.statusText);
    throw new Error(`Google menolak permintaan token: ${desc}`);
  }
  return json as { access_token: string; expires_in: number; refresh_token?: string };
}

async function oauthAccessToken(c: OAuthCreds): Promise<string> {
  const expiry = c.accessTokenExpiry ? new Date(c.accessTokenExpiry).getTime() : 0;
  if (c.accessToken && expiry - 60_000 > Date.now()) return c.accessToken;
  if (!c.refreshToken) throw new Error("OAuth belum terhubung — tidak ada refresh token");
  const tok = await fetchAccessToken(
    new URLSearchParams({
      client_id: c.clientId,
      client_secret: c.clientSecret,
      refresh_token: c.refreshToken,
      grant_type: "refresh_token",
    })
  );
  await updateCreds((cr) => ({
    ...cr,
    oauth: {
      ...c,
      accessToken: tok.access_token,
      accessTokenExpiry: new Date(Date.now() + tok.expires_in * 1000).toISOString(),
    },
  }));
  return tok.access_token;
}

function b64u(buf: Buffer): string {
  return buf.toString("base64url");
}

function saJwtAssertion(c: SaCreds): string {
  const iat = Math.floor(Date.now() / 1000);
  const header = b64u(Buffer.from(JSON.stringify({ alg: "RS256", typ: "JWT" })));
  const claim = b64u(
    Buffer.from(
      JSON.stringify({ iss: c.clientEmail, scope: SA_SCOPE, aud: TOKEN_URL, iat, exp: iat + 3000 })
    )
  );
  const input = `${header}.${claim}`;
  const sig = createSign("RSA-SHA256").update(input).sign(c.privateKey);
  return `${input}.${b64u(sig)}`;
}

export async function saAccessToken(c: SaCreds): Promise<string> {
  const cached = saTokenCache.get(c.clientEmail);
  if (cached && cached.expiry - 60_000 > Date.now()) return cached.token;
  const tok = await fetchAccessToken(
    new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: saJwtAssertion(c),
    })
  );
  saTokenCache.set(c.clientEmail, {
    token: tok.access_token,
    expiry: Date.now() + tok.expires_in * 1000,
  });
  return tok.access_token;
}

// Pilih jalur backup: "auto" = OAuth diprioritaskan, fallback SA.
export type BackupMethodKind = "oauth" | "sa";
export async function resolveMethod(
  c: GdriveCreds,
  method: "auto" | "oauth" | "sa"
): Promise<BackupMethodKind> {
  const want = method === "auto" ? (c.oauth?.refreshToken ? "oauth" : c.sa ? "sa" : "oauth") : method;
  if (want === "oauth") {
    if (!c.oauth?.clientId || !c.oauth?.clientSecret || !c.oauth?.refreshToken) {
      throw new Error("Jalur OAuth belum terhubung — hubungkan Google atau pakai Service Account");
    }
    return "oauth";
  }
  if (!c.sa?.clientEmail || !c.sa?.privateKey || !c.sa?.folderId) {
    throw new Error("Service Account belum dikonfigurasi — simpan kunci JSON + Folder ID dulu");
  }
  return "sa";
}

// Derive origin publik dari header proxy (x-forwarded-host/proto) — dipakai
// membangun redirect URI OAuth. Browser menghitung URI yang sama dari
// window.location.origin, jadi keduanya konsisten di LAN maupun preview proxy.
export function requestOrigin(url: string, headers: Headers): string {
  const xfHost = headers.get("x-forwarded-host");
  const host = (xfHost?.split(",")[0] ?? headers.get("host") ?? "").trim();
  const proto =
    (headers.get("x-forwarded-proto")?.split(",")[0] ?? "").trim() ||
    (host && /^localhost|^127\.0\.0\.1/.test(host) ? "http" : "https");
  return host ? `${proto}://${host}` : url;
}

// ===== Panggilan Drive API v3 =====
async function driveJson(
  token: string,
  url: string,
  init?: RequestInit
): Promise<Record<string, unknown>> {
  const res = await fetch(url, {
    ...init,
    headers: { ...(init?.headers ?? {}), Authorization: `Bearer ${token}` },
  });
  const json = (await res.json().catch(() => ({}))) as Record<string, unknown>;
  if (!res.ok) {
    const err = json.error as { message?: string } | undefined;
    throw new Error(err?.message ?? `Google Drive menolak: HTTP ${res.status}`);
  }
  return json;
}

export type DriveFileInfo = {
  id: string;
  name: string;
  size: string | null;
  createdTime: string;
  modifiedTime: string;
};

// Cari folder (atau buat) untuk jalur OAuth. parentId null = root Drive pengguna.
export async function findOrCreateFolder(
  token: string,
  name: string,
  parentId: string | null
): Promise<string> {
  const parentQ = parentId ? `'${parentId}' in parents` : `'me' in parents`;
  const q = `mimeType = 'application/vnd.google-apps.folder' and name = '${name.replace(/'/g, "\\'")}' and trashed = false and ${parentQ}`;
  const res = await driveJson(
    token,
    `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id,name)&pageSize=10`
  );
  const files = (res.files as { id: string }[] | undefined) ?? [];
  if (files.length) return files[0].id;
  const created = await driveJson(token, "https://www.googleapis.com/drive/v3/files", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name,
      mimeType: "application/vnd.google-apps.folder",
      ...(parentId ? { parents: [parentId] } : {}),
    }),
  });
  return String(created.id);
}

export async function uploadFile(
  token: string,
  name: string,
  buf: Buffer,
  parentId: string | null
): Promise<{ id: string; name: string; size: number }> {
  const boundary = `fixplus${randomBytes(12).toString("hex")}`;
  const meta = JSON.stringify({
    name,
    ...(parentId ? { parents: [parentId] } : {}),
  });
  const body = Buffer.concat([
    Buffer.from(
      `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${meta}\r\n--${boundary}\r\nContent-Type: application/octet-stream\r\n\r\n`
    ),
    buf,
    Buffer.from(`\r\n--${boundary}--`),
  ]);
  const res = await fetch(
    "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,size",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": `multipart/related; boundary=${boundary}`,
      },
      body: new Uint8Array(body),
    }
  );
  const json = (await res.json().catch(() => ({}))) as Record<string, unknown>;
  if (!res.ok) {
    const err = json.error as { message?: string } | undefined;
    throw new Error(err?.message ?? `Unggah ke Drive gagal: HTTP ${res.status}`);
  }
  return {
    id: String(json.id),
    name: String(json.name ?? name),
    size: Number(json.size ?? buf.length),
  };
}

export async function listBackupFiles(
  token: string,
  folderId: string
): Promise<DriveFileInfo[]> {
  const q = `'${folderId}' in parents and trashed = false and name contains '${BACKUP_FILE_PREFIX}'`;
  const res = await driveJson(
    token,
    `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&orderBy=createdTime desc&pageSize=100&fields=files(id,name,size,createdTime,modifiedTime)`
  );
  const files = (res.files as Record<string, unknown>[] | undefined) ?? [];
  return files.map((f) => ({
    id: String(f.id),
    name: String(f.name),
    size: f.size === undefined || f.size === null ? null : String(f.size),
    createdTime: String(f.createdTime ?? ""),
    modifiedTime: String(f.modifiedTime ?? ""),
  }));
}

export async function downloadDriveFile(token: string, id: string): Promise<Buffer> {
  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${id}?alt=media`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(
      text
        ? `Gagal mengunduh dari Drive: HTTP ${res.status} — ${text.slice(0, 300)}`
        : `Gagal mengunduh dari Drive: HTTP ${res.status}`
    );
  }
  return Buffer.from(await res.arrayBuffer());
}

export async function deleteDriveFile(token: string, id: string): Promise<void> {
  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${id}`, {
    method: "DELETE",
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok && res.status !== 204 && res.status !== 404) {
    const text = await res.text().catch(() => "");
    throw new Error(text ? `Gagal hapus di Drive: ${text.slice(0, 300)}` : `Gagal hapus di Drive: HTTP ${res.status}`);
  }
}

export async function getDriveFileInfo(token: string, id: string): Promise<DriveFileInfo> {
  const json = await driveJson(
    token,
    `https://www.googleapis.com/drive/v3/files/${id}?fields=id,name,size,createdTime,modifiedTime,mimeType`
  );
  if (String(json.mimeType ?? "").includes("application/vnd.google-apps.folder")) {
    throw new Error("Item yang dipilih adalah folder, bukan file cadangan");
  }
  return {
    id: String(json.id),
    name: String(json.name),
    size: json.size === undefined ? null : String(json.size),
    createdTime: String(json.createdTime ?? ""),
    modifiedTime: String(json.modifiedTime ?? ""),
  };
}

// ===== Backup penuh (.db) → Drive =====
export async function makeDbBackupBuffer(): Promise<{ buf: Buffer; fileName: string }> {
  // Pastikan WAL dituangkan ke file utama (parity backup-db route)
  await db.$queryRawUnsafe("PRAGMA wal_checkpoint(FULL)");
  const dbPath = dbPathFromEnv();
  if (!dbPath) throw new Error("Lokasi file database tidak diketahui");
  const buf = await readFile(dbPath);
  return { buf, fileName: `${BACKUP_FILE_PREFIX}${jakartaNow().stamp}.db` };
}

async function tokenAndFolder(method: BackupMethodKind, c: GdriveCreds) {
  if (method === "oauth") {
    const oauth = c.oauth!;
    const token = await oauthAccessToken(oauth);
    const folderId =
      oauth.folderId ?? (await findOrCreateFolder(token, GDRIVE_FOLDER_NAME, null));
    if (folderId !== oauth.folderId) {
      await updateCreds((cr) => ({ ...cr, oauth: { ...oauth, folderId } }));
    }
    return { token, folderId };
  }
  const sa = c.sa!;
  return { token: await saAccessToken(sa), folderId: sa.folderId };
}
export { tokenAndFolder };

export type BackupOutcome = {
  method: BackupMethodKind;
  fileName: string;
  fileId: string;
  size: number;
  pruned: number;
};

export async function performDriveBackup(
  actorName: string,
  method: "auto" | "oauth" | "sa"
): Promise<BackupOutcome> {
  const c = await loadCreds();
  const kind = await resolveMethod(c, method);
  const { token, folderId } = await tokenAndFolder(kind, c);
  const { buf, fileName } = await makeDbBackupBuffer();
  const up = await uploadFile(token, fileName, buf, folderId);

  // Pangkas cadangan lama di atas keepLast (default 7)
  const keepLast = Math.max(1, Math.min(90, c.auto?.keepLast ?? 7));
  let pruned = 0;
  try {
    const files = await listBackupFiles(token, folderId);
    const old = files
      .slice()
      .sort((a, b) => (a.createdTime < b.createdTime ? 1 : -1))
      .slice(keepLast);
    for (const f of old) {
      try {
        await deleteDriveFile(token, f.id);
        pruned++;
      } catch (e) {
        console.error("[gdrive] gagal menghapus cadangan lama:", f.name, e);
      }
    }
  } catch (e) {
    console.error("[gdrive] pemangkasan dilewati:", e);
  }

  await updateCreds((cr) => ({
    ...cr,
    lastBackupAt: new Date().toISOString(),
    lastBackupFile: fileName,
  }));
  await db.auditLog.create({
    data: {
      action: "BACKUP_GDRIVE",
      details: `Cadangan ${kind === "oauth" ? "OAuth" : "Service Account"} "${fileName}" (${Math.ceil(up.size / 1024)} KB) terunggah ke Google Drive${pruned ? `, ${pruned} cadangan lama dipangkas` : ""}`,
      performedBy: actorName,
    },
  });
  return { method: kind, fileName: up.name, fileId: up.id, size: up.size, pruned };
}

// ===== Auto-backup harian (dipanggil penjadwal di instrumentation) =====
let schedStarted = false;
let autoRunning = false;

export function startDriveAutoBackup() {
  if (schedStarted) return;
  schedStarted = true;
  const tick = async () => {
    try {
      await autoBackupTick();
    } catch (e) {
      console.error("[gdrive] auto-backup gagal:", e);
    }
  };
  setTimeout(tick, 20_000); // cek pertama 20 detik setelah server hidup
  setInterval(tick, 10 * 60_000); // lalu tiap 10 menit
}

async function autoBackupTick() {
  if (autoRunning) return;
  autoRunning = true;
  try {
    const c = await loadCreds();
    const auto = { ...DEFAULT_AUTO, ...(c.auto ?? {}) };
    if (!auto.enabled) return;
    const now = jakartaNow();
    if (auto.hour > now.hour) return; // belum jamnya hari ini
    if (c.lastAutoBackupDate === now.dateStr) return; // sudah dibackup hari ini
    const method = await resolveMethod(c, auto.method);
    const out = await performDriveBackup("Sistem (Auto-Backup)", method);
    await updateCreds((cr) => ({ ...cr, lastAutoBackupDate: now.dateStr }));
    console.log(`[gdrive] auto-backup selesai: ${out.fileName} (${out.method})`);
  } finally {
    autoRunning = false;
  }
}
