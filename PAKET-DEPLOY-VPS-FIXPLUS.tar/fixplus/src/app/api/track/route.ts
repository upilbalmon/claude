import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { serviceIdOf, pendingRequestedParts } from "@/lib/repair-utils";
import { REPAIR_STATUS_LABEL } from "@/lib/app-types";

// GET /api/track?id=SRV-1234567890 — pelacakan status servis PUBLIK (tanpa login).
// D26: dipakai halaman /track — tautannya tercetak (beserta QR) di struk terima
// barang. Data yang bocor sengaja dibatasi demi privasi: nama pelanggan dimask,
// TANPA no. HP lengkap, TANPA IMEI/serial, TANPA catatan internal teknisi.
//
// D27 (anti penyalahgunaan pihak tak berwenang):
// - SATU-SATUNYA format yang diterima: "SRV-<epoch>" — kode unik yang hanya
//   diketahui pemegang struk (tercetak di struk & QR-nya).
// - Jalur ID tiket berurutan ("#123"/"123") DIHAPUS — bisa dienumerasi orang
//   luar untuk mengintip servis pelanggan lain.
// - Rate limit per-IP sederhana (in-memory) menghambat brute-force kode epoch.
export async function GET(req: NextRequest) {
  try {
    const ip =
      req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
      req.headers.get("x-real-ip") ||
      "lokal";
    if (rateLimited(ip)) {
      return NextResponse.json(
        { error: "Terlalu banyak permintaan. Coba lagi sebentar." },
        { status: 429 }
      );
    }

    const raw = (req.nextUrl.searchParams.get("id") ?? "").trim();
    if (!raw) {
      return NextResponse.json(
        { error: "Buka tautan pelacakan lengkap dari struk terima barang (contoh: /track?id=SRV-1234567890)" },
        { status: 400 }
      );
    }

    // Hanya "SRV-<epoch detik>" (prefix boleh tanpa "SRV-") — kode struk pelanggan.
    const epochMatch = raw.match(/^(?:SRV-)?(\d{10})$/i);
    if (!epochMatch) {
      return NextResponse.json(
        { error: "Tautan tidak valid. Gunakan tautan/QR Lacak Servis pada struk terima barang Anda." },
        { status: 400 }
      );
    }

    const ms = Number(epochMatch[1]) * 1000;
    // D57: ikutkan poin loyalitas pelanggan (halaman /track menampilkannya).
    // Null bila tiket tanpa pelanggan terdaftar (walk-in) atau pelanggan dihapus.
    const repair = await db.repairRecord.findFirst({
      where: { createdAt: { gte: new Date(ms), lt: new Date(ms + 1000) } },
      include: { customer: { select: { loyaltyPoints: true } } },
    });

    if (!repair) {
      return NextResponse.json({ found: false }, { status: 404 });
    }

    const settings = await db.shopSettings.findUnique({ where: { id: 1 } });
    // Mask nama: kata pertama utuh, kata berikutnya hanya huruf awal (privasi)
    const maskedName = repair.customerName
      .split(" ")
      .filter(Boolean)
      .map((w, i) => (i === 0 ? w : `${w.charAt(0)}***`))
      .join(" ");

    return NextResponse.json({
      found: true,
      serviceId: serviceIdOf(repair.createdAt),
      customerName: maskedName,
      deviceModel: repair.deviceModel,
      damageDescription: repair.damageDescription,
      status: repair.status,
      statusLabel: REPAIR_STATUS_LABEL[repair.status] ?? repair.status,
      createdAt: repair.createdAt,
      updatedAt: repair.updatedAt,
      estimatedCompletionTime: repair.estimatedCompletionTime,
      technicianName: repair.technicianName,
      warrantyDays: repair.warrantyDays,
      // D57: poin loyalitas pelanggan pemegang tiket (null = bukan pelanggan terdaftar)
      loyaltyPoints: repair.customer?.loyaltyPoints ?? null,
      // D28: tiket Disetujui yang masih menunggu sparepart dipesan
      waitingParts:
        repair.status === "DISETUJUI" && pendingRequestedParts(repair.requestedPartsJson).length > 0,
      shop: { name: settings?.shopName ?? "", phone: settings?.phone ?? "" },
    });
  } catch (e) {
    console.error("track GET error", e);
    return NextResponse.json({ error: "Gagal memuat status servis" }, { status: 500 });
  }
}

// === D27: rate limit per-IP sederhana (penyimpanan in-memory, cukup untuk
// deployment POS single-instance). 30 permintaan/menit/IP. ===
const RATE_LIMIT = 30;
const RATE_WINDOW_MS = 60_000;
const rateMap = new Map<string, { count: number; resetAt: number }>();

function rateLimited(ip: string): boolean {
  const now = Date.now();
  const entry = rateMap.get(ip);
  if (!entry || entry.resetAt <= now) {
    rateMap.set(ip, { count: 1, resetAt: now + RATE_WINDOW_MS });
    if (rateMap.size > 1000) {
      for (const [k, v] of rateMap) if (v.resetAt <= now) rateMap.delete(k);
    }
    return false;
  }
  entry.count += 1;
  return entry.count > RATE_LIMIT;
}
