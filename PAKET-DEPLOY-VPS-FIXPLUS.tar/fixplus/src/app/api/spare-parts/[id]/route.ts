import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { resolveActor } from "@/lib/action-guard";
import { saranSku, skuUnik } from "@/lib/sku-utils";
import { spareCategoryOf } from "@/lib/spare-category";

type Params = { params: Promise<{ id: string }> };

// PUT /api/spare-parts/[id] — edit sparepart (ala saveSparePart id≠0;
// isShoppingSelected & shoppingIgnoredUntil dipertahankan persis InventoryViewModel.kt)
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return NextResponse.json({ error: "ID tidak valid" }, { status: 400 });
    }
    const existing = await db.sparePart.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Sparepart tidak ditemukan" }, { status: 404 });
    }

    const body = await req.json();
    const name = String(body.name ?? "").trim();
    if (!name) {
      return NextResponse.json({ error: "Nama sparepart wajib diisi" }, { status: 400 });
    }

    // T4 (revisi Tahap 2): SKU wajib unik — cek duplikat dengan mengecualikan
    // baris yang sedang diedit (banding aba besar-kecil).
    // D22: SKU dikosongkan saat edit → diisi ulang otomatis mengikuti pola data
    // yang sudah ada (PREFIX-SINGKATAN) + anti-tabrakan antar-part lain.
    const all = await db.sparePart.findMany({ select: { id: true, name: true, sku: true } });
    const skuInput = String(body.sku ?? "").trim();
    let sku = skuInput;
    if (sku) {
      const dup = all.find((p) => p.id !== id && p.sku.trim().toLowerCase() === sku.toLowerCase());
      if (dup) {
        return NextResponse.json(
          { error: `SKU "${sku}" sudah dipakai oleh sparepart "${dup.name}"` },
          { status: 409 }
        );
      }
    } else {
      sku = skuUnik(saranSku(name), all.filter((p) => p.id !== id).map((p) => p.sku));
    }

    // D23 (D18/D19): "Nama di Struk / Nota" — alias opsional; dikosongkan → hapus alias.
    const alias = String(body.alias ?? "").trim();

    const part = await db.sparePart.update({
      where: { id },
      data: {
        name,
        alias: alias === "" ? null : alias,
        sku,
        stock: clampNonNegInt(body.stock, existing.stock),
        minStock: clampNonNegInt(body.minStock, existing.minStock),
        costPrice: clampNonNegNum(body.costPrice, existing.costPrice),
        sellPrice: clampNonNegNum(body.sellPrice, existing.sellPrice),
        location: String(body.location ?? "").trim(),
        // D48/5C-1.1: kategori barang (whitelist server, bila tak dikirim → pertahankan)
        ...(body.category !== undefined ? { category: spareCategoryOf(body.category) } : {}),
      },
    });

    await db.auditLog.create({
      data: {
        action: "EDIT_SPAREPART",
        details: `${part.name} (stok ${part.stock})`,
        performedBy: String(body.performedBy ?? "Tidak diketahui"),
      },
    });

    return NextResponse.json(part);
  } catch (e) {
    console.error("spare-parts PUT error", e);
    return NextResponse.json({ error: "Gagal mengubah sparepart" }, { status: 500 });
  }
}

// DELETE /api/spare-parts/[id]?requesterUsername=… — hapus sparepart (ala deleteSparePart)
// D34: hapus data = hanya Admin (aturan 4), diverifikasi server.
export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return NextResponse.json({ error: "ID tidak valid" }, { status: 400 });
    }
    const actor = await resolveActor(req.nextUrl.searchParams.get("requesterUsername"));
    if (!actor) {
      return NextResponse.json({ error: "Hanya Admin yang dapat menghapus data" }, { status: 403 });
    }
    const existing = await db.sparePart.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Sparepart tidak ditemukan" }, { status: 404 });
    }

    await db.sparePart.delete({ where: { id } });
    await db.auditLog.create({
      data: {
        action: "HAPUS_SPAREPART",
        details: `${existing.name} (stok ${existing.stock})`,
        performedBy: actor.name,
      },
    });

    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("spare-parts DELETE error", e);
    return NextResponse.json({ error: "Gagal menghapus sparepart" }, { status: 500 });
  }
}

function clampNonNegInt(v: unknown, fallback: number): number {
  const n = Math.trunc(Number(v));
  return Number.isFinite(n) && n >= 0 ? n : fallback;
}

function clampNonNegNum(v: unknown, fallback: number): number {
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 ? n : fallback;
}
