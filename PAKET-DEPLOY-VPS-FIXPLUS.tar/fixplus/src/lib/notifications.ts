// D81 — Pusat notifikasi aplikasi: penyimpanan permanen kejadian penting di
// tabel AppNotification, ditampilkan lewat panel lonceng di header (bisa
// dibuka kapan saja) sebagai pelengkap toast yang hanya tampil sebentar.
//
// Dirancang ekstensibel: fitur lain di masa depan cukup memanggil
// pushNotification() dengan type baru (UI panel punya ikon bawaan untuk type
// yang tidak dikenal). Semua kegagalan penyimpanan DITELAN (hanya log) —
// notifikasi tidak boleh menggagalkan alur utama yang memanggilnya
// (mis. backup yang sudah sukses tetap sukses walau notifikasinya gagal
// tersimpan).
//
// PENTING (Lihat db.ts): tulisan AppNotification dikecualikan dari penanda
// perubahan data — notifikasi sering ditulis proses backup sendiri, jadi bila
// ikut menandai "dirty" akan terjadi lingkaran backup→notifikasi→backup.
import { db } from "@/lib/db";

export type NotificationType =
  | "BACKUP_SUCCESS"
  | "BACKUP_FAILED"
  | "SYNC_CONFLICT"
  | "SYNC_ERROR"
  | "RESTORE"
  | "SYSTEM";

// Riwayat dipangkas: panel cukup menampilkan yang baru, database tidak boleh
// menumpuk baris notifikasi tanpa batas (ikut ter-backup di file .db).
const KEEP_MAX = 100;

/**
 * Simpan satu notifikasi ke pusat notifikasi (fire-and-forget yang aman:
 * selalu resolve, kegagalan hanya dicatat di log server).
 *
 * @param dedupeMs jendela anti-spam (ms): bila notifikasi dengan type+title
 *   yang sama sudah dibuat dalam jendela ini, yang baru DILEWATKAN. 0 (bawaan)
 *   = selalu simpan. Dipakai untuk kejadian berulang otomatis (mis. backup
 *   otomatis gagal tiap siklus 10 menit → cukup 1 notifikasi per jam).
 */
export async function pushNotification(input: {
  type: NotificationType | string;
  title: string;
  message?: string;
  meta?: Record<string, unknown>;
  dedupeMs?: number;
}): Promise<void> {
  try {
    const dedupeMs = Math.max(0, Math.trunc(input.dedupeMs ?? 0));
    if (dedupeMs > 0) {
      const last = await db.appNotification.findFirst({
        where: { type: input.type, title: input.title },
        orderBy: [{ createdAt: "desc" }, { id: "desc" }],
        select: { createdAt: true },
      });
      if (last && Date.now() - new Date(last.createdAt).getTime() < dedupeMs) return;
    }
    await db.appNotification.create({
      data: {
        type: input.type,
        title: input.title,
        message: input.message ?? "",
        metaJson: JSON.stringify(input.meta ?? {}),
      },
    });
    // Pangkas di atas KEEP_MAX — simpan 100 baris terbaru (createdAt, lalu id
    // sebagai pemecah seri bila timestamp sama).
    const boundary = await db.appNotification.findMany({
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      skip: KEEP_MAX - 1,
      take: 1,
      select: { id: true, createdAt: true },
    });
    if (boundary.length === 1) {
      const b = boundary[0];
      await db.appNotification.deleteMany({
        where: {
          OR: [
            { createdAt: { lt: b.createdAt } },
            { createdAt: b.createdAt, id: { lt: b.id } },
          ],
        },
      });
    }
  } catch (e) {
    console.error("[notifikasi] gagal menyimpan notifikasi:", e);
  }
}
