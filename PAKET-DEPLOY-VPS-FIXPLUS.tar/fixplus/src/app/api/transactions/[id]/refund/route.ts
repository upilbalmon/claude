import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { errAction, resolveActor, verifySupervisorPin } from "@/lib/action-guard";

type Params = { params: Promise<{ id: string }> };

// POST /api/transactions/[id]/refund — D38: refund/retur SETELAH pembayaran selesai
// (aturan 2 dokumen "Pembatalan transaksi"): dibuat dokumen transaksi BARU bernilai
// negatif yang merujuk nota asli (refundOfId) sehingga stok & kas otomatis seimbang.
// Bedanya dengan void: nota asli TETAP sah (barang/uang sudah berpindah), koreksinya
// berupa dokumen retur tersendiri — jejak audit tetap utuh dua-duanya.
//
// Aturan yang dipegang:
//  - D34: hanya Admin (requesterUsername diverifikasi server);
//  - D35: wajib PIN otorisasi supervisor;
//  - wajib alasan (dicatat di audit);
//  - hanya PENJUALAN non-void dengan paidAmount > 0 (BON belum dibayar → pakai void);
//  - satu dokumen refund aktif per nota asli (refund lama yang di-void boleh diganti);
//  - stok item retail (partId) kembali masuk (retur barang), poin loyalitas ditarik;
//  - status tiket servis TIDAK diubah — unit sudah diambil pelanggan;
//  - tidak berlaku batas hari yang sama (D36 khusus void) — pelanggan bisa kembali
//    kapan pun; koreksi periode lama nanti diatur period lock (di luar scope D34–D38).

type ReceiptItem = { name?: string; alias?: string | null; qty?: number; price?: number; costPrice?: number; itemType?: string; partId?: number };

export async function POST(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return errAction("ID tidak valid", 400);
    }

    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;

    // D34 — aktor wajib Admin
    const actor = await resolveActor(body.requesterUsername);
    if (!actor) {
      return errAction("Hanya Admin yang dapat melakukan refund", 403);
    }

    // D35 — PIN otorisasi supervisor wajib
    const approver = await verifySupervisorPin(body.authorizePin);
    if (!approver) {
      return errAction("PIN otorisasi salah — refund wajib persetujuan supervisor (PIN Admin)", 403);
    }

    // Alasan wajib — jejak audit refund
    const reason = String(body.reason ?? "").trim();
    if (!reason) {
      return errAction("Alasan refund wajib diisi", 400);
    }

    const original = await db.transaction.findUnique({ where: { id } });
    if (!original) {
      return errAction("Transaksi tidak ditemukan", 404);
    }
    if (original.isVoided) {
      return errAction("Transaksi sudah dibatalkan (void) — tidak bisa direfund", 400);
    }
    if (original.docType !== "PENJUALAN") {
      return errAction("Hanya dokumen penjualan yang bisa direfund", 400);
    }

    // satu dokumen refund aktif per nota
    const liveRefund = await db.transaction.findFirst({
      where: { refundOfId: original.id, isVoided: false },
    });
    if (liveRefund) {
      return errAction(
        `Transaksi sudah direfund sebelumnya (${liveRefund.invoiceNumber})`,
        400
      );
    }

    // nilai uang yang benar-benar diterima → yang dikembalikan ke pelanggan
    const refundAmount = original.paidAmount;
    if (!(refundAmount > 0)) {
      return errAction(
        "Tidak ada uang yang tercatat diterima pada nota ini (bon/piutang belum dibayar) — gunakan Void untuk pembatalan",
        400
      );
    }

    // nomor dokumen refund: <INV asli>-R<n> (n = urutan refund termasuk yang sudah di-void)
    const priorRefunds = await db.transaction.count({ where: { refundOfId: original.id } });
    const invoiceNumber = `${original.invoiceNumber}-R${priorRefunds + 1}`;

    // item dibalik tandanya (retur barang); partId dipertahankan untuk efek stok
    let items: ReceiptItem[] = [];
    try {
      const parsed = JSON.parse(original.itemsJson) as ReceiptItem[];
      items = Array.isArray(parsed) ? parsed : [];
    } catch {
      items = [];
    }
    const returnedItems = items.map((it) => ({ ...it, qty: -Math.abs(Math.trunc(Number(it.qty) || 1)) }));
    const stockBack = returnedItems
      .filter((it) => Number.isInteger(it.partId) && it.partId! > 0)
      .map((it) => ({ partId: it.partId!, qty: Math.abs(Math.trunc(Number(it.qty))) }));

    const pointsToDeduct = Math.floor(refundAmount / 10000);

    const refundDoc = await db.$transaction(async (tx) => {
      // barang retur masuk gudang
      for (const s of stockBack) {
        await tx.sparePart.update({
          where: { id: s.partId },
          data: { stock: { increment: s.qty } },
        });
      }

      // poin loyalitas dari nilai yang direfund ditarik kembali (min 0)
      if (original.customerId && pointsToDeduct > 0) {
        const customer = await tx.customer.findUnique({ where: { id: original.customerId } });
        if (customer) {
          await tx.customer.update({
            where: { id: customer.id },
            data: { loyaltyPoints: Math.max(0, customer.loyaltyPoints - pointsToDeduct) },
          });
        }
      }

      const doc = await tx.transaction.create({
        data: {
          invoiceNumber,
          repairRecordId: null, // refund dokumen keuangan — tidak menaut tiket
          customerId: original.customerId,
          customerName: original.customerName,
          subtotal: -refundAmount,
          discount: 0,
          grandTotal: -refundAmount,
          paymentMethod: original.paymentMethod,
          paidAmount: -refundAmount, // kas keluar
          changeAmount: 0,
          itemsJson: JSON.stringify(returnedItems),
          paymentStatus: "LUNAS",
          docType: "REFUND",
          refundOfId: original.id,
          referenceNumber: original.invoiceNumber,
          createdBy: actor.name,
        },
      });

      await tx.auditLog.create({
        data: {
          action: "REFUND_TRANSAKSI",
          details:
            `Refund Invoice ${original.invoiceNumber} → dokumen ${invoiceNumber} ` +
            `(Rp -${Math.trunc(refundAmount).toLocaleString("id-ID")}, ${original.customerName}) — ` +
            `Alasan: ${reason} — Otorisasi PIN: ${approver.name}`,
          performedBy: actor.name,
        },
      });

      return doc;
    }, { timeout: 15000, maxWait: 5000 }); // D12: ruang menunggu kunci tulis SQLite

    return NextResponse.json(refundDoc, { status: 201 });
  } catch (e) {
    const message = e instanceof Error ? e.message : "Gagal memproses refund";
    console.error("transactions refund error", e);
    return errAction(message, (e as { code?: string }).code === "P2002" ? 400 : 500);
  }
}
