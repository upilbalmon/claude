import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { resolveReporter } from "@/lib/report-utils";

// D48/5A.6 — Daftar Piutang (BON + DP Sebagian).
// GET /api/reports/piutang?requesterUsername=…
// Sisa tagihan = grandTotal − paidAmount (transaksi tidak void, dokumen PENJUALAN).
// Umur hari dihitung dari timestamp nota (WIB). Pelunasan bertahap menyusul di
// 5B.2 (tabel payments) — angka di sini sudah benar dari paidAmount yang ada.

const DAY_MS = 24 * 60 * 60 * 1000;

export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const reporter = await resolveReporter(sp.get("requesterUsername"));
    if (!reporter) {
      return NextResponse.json({ error: "Sesi tidak dikenal — masuk ulang" }, { status: 401 });
    }
    const now = Date.now();

    const rows0 = await db.transaction.findMany({
      where: {
        isVoided: false,
        docType: "PENJUALAN",
        paymentStatus: { in: ["BON_PIUTANG", "DP_SEBAGIAN"] },
      },
      orderBy: { timestamp: "asc" },
      select: {
        id: true, invoiceNumber: true, customerName: true, timestamp: true,
        grandTotal: true, paidAmount: true, paymentStatus: true, createdBy: true,
      },
    });

    const rows = rows0.map((t) => ({
      id: t.id,
      invoiceNumber: t.invoiceNumber,
      customerName: t.customerName,
      timestamp: t.timestamp,
      createdBy: t.createdBy,
      status: t.paymentStatus, // BON_PIUTANG | DP_SEBAGIAN
      total: t.grandTotal,
      dibayar: t.paidAmount,
      sisa: Math.max(0, t.grandTotal - t.paidAmount),
      umurHari: Math.max(0, Math.floor((now - new Date(t.timestamp).getTime()) / DAY_MS)),
    }));

    return NextResponse.json({
      rows,
      totalSisa: rows.reduce((s, r) => s + r.sisa, 0),
      totalBon: rows.filter((r) => r.status === "BON_PIUTANG").reduce((s, r) => s + r.sisa, 0),
      totalDp: rows.filter((r) => r.status === "DP_SEBAGIAN").reduce((s, r) => s + r.sisa, 0),
      count: rows.length,
    });
  } catch (e) {
    console.error("reports piutang GET error", e);
    return NextResponse.json({ error: "Gagal memuat daftar piutang" }, { status: 500 });
  }
}
