import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { REQUESTED_STATUS_ORDER } from "@/lib/belanja-utils";

// D61 — Tahap 6.2: Barang Pesanan pelanggan/tiket servis (belum ada di katalog).
// GET /api/requested-items — daftar + statistik; POST — catat barang pesanan
// baru (status awal Baru). Kaitan pelanggan & tiket servis opsional (item 6.4);
// bila tiket servis dipilih tanpa pelanggan, pelanggan diambil dari tiket.

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = req.nextUrl;
    const status = String(searchParams.get("status") ?? "").trim();
    const q = String(searchParams.get("q") ?? "").trim();

    const where: Record<string, unknown> = {};
    if (status && (REQUESTED_STATUS_ORDER as readonly string[]).includes(status)) {
      where.status = status;
    }
    if (q) {
      where.OR = [
        { customerName: { contains: q } },
        { customerPhone: { contains: q } },
        { itemName: { contains: q } },
        { brandOrSpec: { contains: q } },
        { notes: { contains: q } },
      ];
    }

    const rows = await db.requestedItem.findMany({
      where,
      orderBy: { createdAt: "desc" },
      include: {
        customer: { select: { id: true, name: true, phone: true } },
        // D63: createdAt tiket ikut — kode SRV-<epoch> memakai tanggal tiket sebenarnya
        repairRecord: { select: { id: true, deviceModel: true, status: true, customerName: true, createdAt: true } },
        part: { select: { id: true, name: true, sku: true, stock: true } },
      },
    });

    const all = await db.requestedItem.findMany({ select: { status: true, qty: true, estPrice: true } });
    const aktif = all.filter((r) => ["Baru", "Dipesan"].includes(r.status));
    const stats = {
      total: all.length,
      perStatus: Object.fromEntries(
        REQUESTED_STATUS_ORDER.map((s) => [s, all.filter((r) => r.status === s).length])
      ) as Record<string, number>,
      aktif: aktif.length,
      nilaiAktif: aktif.reduce((n, r) => n + r.estPrice * r.qty, 0), // perkiraan biaya belanja aktif
    };

    return NextResponse.json({ rows, stats });
  } catch (e) {
    console.error("requested-items GET error", e);
    return NextResponse.json({ error: "Gagal memuat barang pesanan" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const itemName = String(body.itemName ?? "").trim();
    if (!itemName) {
      return NextResponse.json({ error: "Nama barang wajib diisi" }, { status: 400 });
    }

    const qty = clampInt(body.qty, 1, 1, 999);
    const estPrice = clampNum(body.estPrice, 0, 0);
    const brandOrSpec = String(body.brandOrSpec ?? "").trim();
    const notes = String(body.notes ?? "").trim();

    // Pelanggan terdaftar (opsional)
    let customerId: number | null = null;
    let customerName = String(body.customerName ?? "").trim();
    let customerPhone = String(body.customerPhone ?? "").trim();

    // Tiket servis (opsional): bila pelanggan belum dipilih, ambil dari tiket (6.4)
    let repairRecordId: number | null = null;
    if (body.repairRecordId !== undefined && body.repairRecordId !== null && String(body.repairRecordId).trim() !== "") {
      const rid = Number(body.repairRecordId);
      if (!Number.isInteger(rid)) {
        return NextResponse.json({ error: "ID tiket servis tidak valid" }, { status: 400 });
      }
      const repair = await db.repairRecord.findUnique({ where: { id: rid } });
      if (!repair) {
        return NextResponse.json({ error: "Tiket servis tidak ditemukan" }, { status: 404 });
      }
      repairRecordId = rid;
      if (!customerId && repair.customerId) {
        const cust = await db.customer.findUnique({ where: { id: repair.customerId } });
        if (cust) {
          customerId = cust.id;
          if (!customerName) customerName = cust.name;
          if (!customerPhone) customerPhone = cust.phone;
        }
      }
      if (!customerName && repair.customerName) customerName = repair.customerName;
      if (!customerPhone && repair.customerPhone) customerPhone = repair.customerPhone;
    }

    if (body.customerId !== undefined && body.customerId !== null && String(body.customerId).trim() !== "") {
      const cid = Number(body.customerId);
      if (!Number.isInteger(cid)) {
        return NextResponse.json({ error: "ID pelanggan tidak valid" }, { status: 400 });
      }
      const cust = await db.customer.findUnique({ where: { id: cid } });
      if (!cust) {
        return NextResponse.json({ error: "Pelanggan tidak ditemukan" }, { status: 404 });
      }
      customerId = cid;
      if (!customerName) customerName = cust.name;
      if (!customerPhone) customerPhone = cust.phone;
    }

    const row = await db.requestedItem.create({
      data: {
        customerId,
        repairRecordId,
        itemName,
        brandOrSpec,
        qty,
        estPrice,
        customerName,
        customerPhone,
        notes,
        status: "Baru",
      },
    });

    await db.auditLog.create({
      data: {
        action: "TAMBAH_BARANG_PESANAN",
        details: `${row.itemName}${row.brandOrSpec ? ` (${row.brandOrSpec})` : ""} ×${row.qty} — ${row.customerName || "Umum"}`,
        performedBy: String(body.performedBy ?? "Tidak diketahui"),
      },
    });

    return NextResponse.json(row, { status: 201 });
  } catch (e) {
    console.error("requested-items POST error", e);
    return NextResponse.json({ error: "Gagal menyimpan barang pesanan" }, { status: 500 });
  }
}

function clampInt(v: unknown, fallback: number, min: number, max: number): number {
  const n = Math.trunc(Number(v));
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
}

function clampNum(v: unknown, fallback: number, min: number): number {
  const n = Number(v);
  return Number.isFinite(n) && n >= min ? n : fallback;
}
