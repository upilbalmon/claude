import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { spareCategoryOf } from "@/lib/spare-category";

// GET /api/transactions — daftar semua transaksi (urut waktu desc, ala repository.allTransactions)
export async function GET() {
  try {
    const transactions = await db.transaction.findMany({
      orderBy: { timestamp: "desc" },
    });
    return NextResponse.json(transactions);
  } catch (e) {
    console.error("transactions GET error", e);
    return NextResponse.json({ error: "Gagal memuat transaksi" }, { status: 500 });
  }
}

type CheckoutItemInput = {
  itemType: "retail" | "service" | "other" | "external_sparepart";
  partId?: number; // retail: wajib — harga & stok diambil dari DB terkini
  name?: string; // service/other/external
  price?: number;
  costPrice?: number; // external_sparepart (HPP part toko lain, untuk laporan profit)
  qty?: number;
};

// POST /api/transactions — checkout (ala CheckoutUseCase.execute + Daos.executeCheckoutTransaction)
// Semua tulisan DB (potong stok, insert transaksi, poin loyalitas, audit) dalam 1 transaksi Prisma.
// Tahap 4: bila repairRecordId dikirim → checkout TIKET SERVIS:
// subtotal = jasa (diedit kasir) + part internal dari DB + part toko lain + retail + biaya lain,
// grandTotal = subtotal - diskon - DP tiket; tiket otomatis berstatus DIAMBIL + garansi disimpan.

// T5/D12: checkout paralel DISERIALISASI di level proses. SQLite hanya mengizinkan 1 penulis;
// tanpa antrean ini, 2 kasir/perangkat yang menekan bersamaan saling menunggu kunci tulis
// hingga timeout transaksi (terbukti 2 dari 3 checkout paralel gagal "Transaction already closed").
// Antrean menjanjikan pesanan FIFO; error dari satu request tidak memutus antrean.
let checkoutQueue: Promise<unknown> = Promise.resolve();

export function POST(req: NextRequest) {
  const run = checkoutQueue.then(() => handleCheckout(req));
  checkoutQueue = run.catch(() => undefined);
  return run;
}

async function handleCheckout(req: NextRequest) {
  try {
    const body = await req.json();
    const customerName = String(body.customerName ?? "Umum").trim() || "Umum";
    const customerId = Number.isInteger(body.customerId) && body.customerId > 0 ? Number(body.customerId) : null;
    const discount = Math.max(0, Number(body.discount) || 0);
    const paymentMethod = String(body.paymentMethod ?? "Tunai");
    // T6: status pembayaran tak dikenal kini DITOLAK dengan pesan jelas
    // (dulu diam-diam dianggap LUNAS sehingga pesan error menjadi "Kurang bayar" — membingungkan)
    if (
      body.paymentStatus !== undefined &&
      !["LUNAS", "DP_SEBAGIAN", "BON_PIUTANG"].includes(body.paymentStatus)
    ) {
      return NextResponse.json(
        { error: "Status pembayaran tidak valid (LUNAS / DP_SEBAGIAN / BON_PIUTANG)" },
        { status: 400 }
      );
    }
    const paymentStatus: string = body.paymentStatus ?? "LUNAS";
    // D39 (aturan ThemeSettings referensi): tanggal/waktu transaksi boleh diubah
    // kasir HANYA bila pengaturan "Edit Tanggal Transaksi" aktif di server.
    // Tanpa ini, timestamp klien akan diabaikan (waktu server dipakai).
    const shopSettings = await db.shopSettings.findUnique({ where: { id: 1 } });
    const editDateEnabled = shopSettings?.editTransactionDate ?? false;
    let transactionTime = new Date();
    if (body.timestamp !== undefined) {
      if (!editDateEnabled) {
        return NextResponse.json(
          { error: "Perubahan tanggal transaksi dinonaktifkan oleh Admin (Pengaturan → Tampilan)" },
          { status: 400 }
        );
      }
      const parsed = new Date(String(body.timestamp));
      if (Number.isNaN(parsed.getTime())) {
        return NextResponse.json({ error: "Tanggal transaksi tidak valid" }, { status: 400 });
      }
      // Tidak boleh terlalu jauh di masa depan (maks. 1 hari) — anti salah input
      if (parsed.getTime() - Date.now() > 24 * 60 * 60 * 1000) {
        return NextResponse.json(
          { error: "Tanggal transaksi tidak boleh lebih dari 1 hari ke depan" },
          { status: 400 }
        );
      }
      transactionTime = parsed;
    }

    const createdBy = String(body.createdBy ?? "Tidak diketahui");
    // D38 (aturan 3): nomor referensi transaksi pengganti setelah void — mis. INV-... yang
    // digantikan. Opsional, maks 60 karakter, hanya dicatat (tidak memengaruhi perhitungan).
    const referenceNumber = String(body.referenceNumber ?? "").trim().slice(0, 60);
    const items: CheckoutItemInput[] = Array.isArray(body.items) ? body.items : [];

    // ===== Tahap 4: tiket servis =====
    const repairRecordId =
      Number.isInteger(body.repairRecordId) && Number(body.repairRecordId) > 0
        ? Number(body.repairRecordId)
        : null;
    let repair: Awaited<ReturnType<typeof db.repairRecord.findUnique>> = null;
    if (repairRecordId) {
      repair = await db.repairRecord.findUnique({ where: { id: repairRecordId } });
      if (!repair) {
        return NextResponse.json({ error: "Tiket servis tidak ditemukan" }, { status: 400 });
      }
      // D25: checkout/pengambilan unit HANYA untuk tiket SELESAI (perbaikan
      // selesai, siap dibayar & diambil) atau TIDAK_BISA (void — unit diambil
      // kembali; biaya jasa/cek bila ada ikut diselesaikan).
      if (repair.status !== "SELESAI" && repair.status !== "TIDAK_BISA") {
        return NextResponse.json(
          {
            error:
              "Checkout/pengambilan hanya untuk tiket berstatus Selesai atau Tidak Bisa/void (saat ini: " +
              repair.status +
              ")",
          },
          { status: 400 }
        );
      }
    }
    const warrantyDays =
      repairRecordId !== null
        ? Math.max(0, Math.trunc(Number(body.warrantyDays) || 0))
        : 0;

    if (!items.length) {
      return NextResponse.json({ error: "Keranjang kosong — tidak ada yang dibayar" }, { status: 400 });
    }
    // D48/5C-1.2: QRIS masuk daftar metode bayar (jawaban d — disetujui user)
    const METHODS = ["Tunai", "Transfer", "QRIS", "E-Wallet", "Kartu"];
    if (!METHODS.includes(paymentMethod)) {
      return NextResponse.json({ error: "Metode pembayaran tidak valid" }, { status: 400 });
    }

    // ===== 1. Harga retail SELALU dari DB terkini, bukan snapshot UI (CheckoutUseCase langkah 1) =====
    const retailQty = new Map<number, number>(); // partId → total qty
    for (const item of items) {
      if (item.itemType === "retail") {
        if (!Number.isInteger(item.partId) || item.partId! <= 0) {
          return NextResponse.json({ error: "Item retail tanpa partId yang valid" }, { status: 400 });
        }
        const qty = Math.trunc(Number(item.qty) || 0);
        if (qty <= 0) {
          return NextResponse.json({ error: "Qty retail wajib lebih dari 0" }, { status: 400 });
        }
        retailQty.set(item.partId!, (retailQty.get(item.partId!) ?? 0) + qty);
      }
    }

    let retailTotal = 0;
    const retailResolved: { partId: number; name: string; alias: string | null; qty: number; price: number; costPrice: number; category: string }[] = [];
    for (const [partId, qty] of retailQty) {
      const part = await db.sparePart.findUnique({ where: { id: partId } });
      if (!part) {
        return NextResponse.json({ error: "Sparepart retail tidak ditemukan!" }, { status: 400 });
      }
      retailTotal += part.sellPrice * qty;
      // D23 (D18/D19): snapshot "Nama di Struk" saat checkout — struk mencetak alias ?? nama
      // D48/5C-1.3: snapshot kategori ikut itemsJson (laporan tak berubah bila katalog diedit)
      retailResolved.push({ partId, name: part.name, alias: part.alias ?? null, qty, price: part.sellPrice, costPrice: part.costPrice, category: spareCategoryOf(part.category) });
    }

    // ===== 2. Jasa & biaya lain dari body (divalidasi ringan) =====
    let serviceTotal = 0;
    let otherTotal = 0;
    const serviceResolved: { name: string; qty: number; price: number }[] = [];
    let otherResolved: { name: string; qty: number; price: number } | null = null;
    let externalResolved: { name: string; qty: number; price: number; costPrice: number }[] = [];
    for (const item of items) {
      const qty = Math.trunc(Number(item.qty) || 1);
      const price = Math.max(0, Number(item.price) || 0);
      if (item.itemType === "service") {
        const name = String(item.name ?? "").trim();
        if (!name || price < 0) continue;
        serviceTotal += price * qty;
        serviceResolved.push({ name, qty, price });
      } else if (item.itemType === "other") {
        if (price <= 0) continue;
        otherTotal += price * Math.max(1, qty);
        otherResolved = { name: "Biaya Lainnya", qty: 1, price: otherTotal }; // digabung 1 baris, persis referensi
      } else if (item.itemType === "external_sparepart") {
        // Tahap 4: sparepart dari toko lain — harga dari input kasir (tidak ada di DB)
        const name = String(item.name ?? "").trim();
        if (!name) continue;
        externalResolved.push({
          name,
          qty: Math.max(1, qty),
          price,
          costPrice: Math.max(0, Number(item.costPrice) || 0),
        });
      }
    }

    // T6: bila SEMUA item gugur validasi (jasa tanpa nama, biaya lain 0, dst.) → tidak ada item
    // efektif → tolak. Dulu ini lolos dan menerbitkan transaksi Rp 0 dengan itemsJson [].
    if (!retailResolved.length && !serviceResolved.length && !otherResolved && !externalResolved.length) {
      return NextResponse.json(
        { error: "Keranjang kosong — tidak ada item efektif untuk diproses" },
        { status: 400 }
      );
    }

    // ===== 2b. Tiket servis: part internal dari usedPartsJson tiket (DB terkini) + jasa final =====
    let repairPartsTotal = 0;
    let repairPartsToDeduct: { partId: number; qty: number }[] = [];
    let repairPartsResolved: { partId: number | null; name: string; alias: string | null; qty: number; price: number; costPrice: number; category: string }[] = [];
    let serviceFee = serviceTotal;
    if (repair && repairRecordId) {
      // usedPartsJson tersimpan di tiket: [{partId,name,qty,sellPrice,costPrice,isExternal?}]
      let storedParts: { partId?: number; name?: string; alias?: string | null; qty?: number; sellPrice?: number; costPrice?: number; isExternal?: boolean }[] = [];
      try {
        const parsed = JSON.parse(repair.usedPartsJson);
        if (Array.isArray(parsed)) storedParts = parsed;
      } catch {
        storedParts = [];
      }
      // D48/(a): partId & kategori ikut itemsJson — void transaksi tiket bisa
      // mengembalikan stok part internal (2 opsi) tanpa menebak dari nama.
      const partIds = [...new Set(storedParts.map((p) => Number(p.partId)).filter((n) => Number.isInteger(n) && n > 0))];
      const partMap = new Map<number, { category: string }>();
      for (const pid of partIds) {
        const p = await db.sparePart.findUnique({ where: { id: pid }, select: { category: true } });
        if (p) partMap.set(pid, { category: spareCategoryOf(p.category) });
      }
      repairPartsResolved = storedParts
        .filter((p) => p && typeof p.name === "string")
        .map((p) => {
          const pid = Number(p.partId);
          return {
            partId: Number.isInteger(pid) && pid > 0 ? pid : null,
            name: `Sparepart: ${p.name}`,
            // D23 (D18/D19): alias part internal ikut ke itemsJson — struk cetak alias ?? nama
            alias: typeof p.alias === "string" && p.alias.trim() !== "" ? p.alias.trim() : null,
            qty: Math.max(1, Math.trunc(Number(p.qty) || 1)),
            price: Math.max(0, Number(p.sellPrice) || 0),
            costPrice: Math.max(0, Number(p.costPrice) || 0),
            category: partMap.get(pid)?.category ?? "SPAREPART",
          };
        });
      repairPartsTotal = repairPartsResolved.reduce((s, p) => s + p.price * p.qty, 0);
      repairPartsToDeduct = storedParts
        .filter((p) => Number(p.partId) > 0 && !p.isExternal)
        .map((p) => ({ partId: Number(p.partId), qty: Math.max(1, Math.trunc(Number(p.qty) || 1)) }));

      // jasa final = yang diedit kasir (adjustedServiceFee); itemsJson jasa lama diabaikan agar tak dobel hitung
      serviceFee = Number.isFinite(Number(body.adjustedServiceFee))
        ? Math.max(0, Number(body.adjustedServiceFee))
        : repair.serviceFee;
    }

    const otherAndExternalTotal =
      otherTotal + externalResolved.reduce((s, p) => s + p.price * p.qty, 0);

    // subtotal = jasa + part servis tiket + part eksternal + item retail + biaya lain
    // (CheckoutUseCase langkah 2)
    const subtotal = serviceFee + repairPartsTotal + retailTotal + otherAndExternalTotal;
    // grandTotal = subtotal - diskon - DP tiket — minimum 0 (langkah 3)
    const downPayment = repair ? (repair.downPayment ?? 0) : 0;
    const grandTotal = Math.max(0, subtotal - discount - downPayment);

    // paidAmount default = grandTotal (uang pas) — ala amountPaidInput kosong di referensi.
    // T8: untuk BON/Piutang, bayar kosong berarti pelanggan BELUM membayar apa pun → catat 0
    // (dulu ikut default uang pas sehingga field Dibayar menyesatkan untuk rekap piutang).
    let paidAmount = Number(body.paidAmount);
    if (!Number.isFinite(paidAmount) || paidAmount < 0) {
      paidAmount = paymentStatus === "BON_PIUTANG" ? 0 : grandTotal;
    }
    paidAmount = Math.min(paidAmount, 9_999_999_999);

    // ===== 3. Validasi bayar (langkah 4) =====
    // LUNAS: wajib >= grandTotal → ditolak "Kurang bayar Rp X"
    // DP_SEBAGIAN (adaptasi web, checklist 3.3): boleh kurang dari total, wajib > 0
    // BON_PIUTANG: tanpa cek (utang dicatat, bayar boleh 0) — persis referensi
    if (paymentStatus === "LUNAS" && paidAmount < grandTotal) {
      const shortage = grandTotal - paidAmount;
      return NextResponse.json(
        { error: `Kurang bayar Rp ${Math.trunc(shortage).toLocaleString("id-ID")}` },
        { status: 400 }
      );
    }
    if (paymentStatus === "DP_SEBAGIAN" && (paidAmount <= 0 || paidAmount >= grandTotal)) {
      return NextResponse.json(
        { error: "DP Sebagian: jumlah bayar wajib di antara 0 dan total tagihan" },
        { status: 400 }
      );
    }

    const changeAmount = paidAmount >= grandTotal ? paidAmount - grandTotal : 0;

    // T5: nomor invoice kini hampir pasti unik — epoch detik + 2 digit acak
    // (dulu `INV-<epoch>` bisa bentrok bila 2 perangkat checkout di detik yang sama),
    // ditambah constraint @unique di DB + retry P2002 di dalam transaksi di bawah.
    const makeInvoiceNumber = () =>
      `INV-${Math.floor(Date.now() / 1000)}${Math.floor(Math.random() * 100)
        .toString()
        .padStart(2, "0")}`;
    let invoiceNumber = makeInvoiceNumber();

    // itemsJson persis format referensi {name, qty, price, costPrice, itemType} + partId (untuk restore stok saat void)
    // D48: partId & category kini JUGA untuk part internal tiket (sebelumnya tanpa partId —
    // void tidak bisa mengembalikan stoknya; jawaban a: 2 opsi dikembalikan/tidak) dan snapshot
    // kategori untuk laporan 4 jalur pendapatan (5C-1.3). Data lama tetap terbaca laporan
    // lewat penurunan kategori otomatis (deriveItemCategory).
    const itemsJson = JSON.stringify([
      ...(repairRecordId && serviceFee >= 0
        ? [{ name: serviceResolved[0]?.name || `Jasa Servis`, qty: 1, price: serviceFee, costPrice: 0, itemType: "service", category: "JASA_SERVIS" }]
        : serviceResolved.map((s) => ({ name: s.name, qty: s.qty, price: s.price, costPrice: 0, itemType: "service", category: "JASA_SERVIS" }))),
      ...repairPartsResolved.map((p) => ({
        name: p.name,
        ...(p.alias ? { alias: p.alias } : {}),
        qty: p.qty,
        price: p.price,
        costPrice: p.costPrice,
        itemType: "sparepart",
        ...(p.partId ? { partId: p.partId } : {}),
        category: p.category,
      })),
      ...externalResolved.map((p) => ({ name: p.name, qty: p.qty, price: p.price, costPrice: p.costPrice, itemType: "external_sparepart", category: "SPAREPART" })),
      ...retailResolved.map((r) => ({
        name: r.name,
        ...(r.alias ? { alias: r.alias } : {}), // D23 (D18/D19): snapshot nama struk
        qty: r.qty,
        price: r.price,
        costPrice: r.costPrice,
        itemType: "retail",
        partId: r.partId,
        category: r.category,
      })),
      ...(otherResolved ? [{ ...otherResolved, costPrice: 0, itemType: "other", category: "LAINNYA" }] : []),
    ]);

    // ===== 4. SATU transaksi DB: cek stok + potong stok + simpan + poin loyalitas + update tiket
    // (executeCheckoutTransaction); timeout & maxWait dilonggar (D12). =====
    const created = await db.$transaction(async (tx) => {
      // potong stok atomik: WHERE stock >= qty → 0 baris berarti stok kurang (ala reduceStock Room)
      const deductions: { partId: number; qty: number }[] = [...retailResolved.map((r) => ({ partId: r.partId, qty: r.qty })), ...repairPartsToDeduct];
      for (const d of deductions) {
        const res = await tx.sparePart.updateMany({
          where: { id: d.partId, stock: { gte: d.qty } },
          data: { stock: { decrement: d.qty } },
        });
        if (res.count === 0) {
          const part = await tx.sparePart.findUnique({ where: { id: d.partId } });
          const name = part?.name ?? `Sparepart ID ${d.partId}`;
          const stock = part?.stock ?? 0;
          throw new Error(`Stok tidak cukup untuk ${name}! Tersedia: ${stock}, diminta: ${d.qty}`);
        }
      }

      // T5: bila nomor invoice kebetulan sudah dipakai (P2002), coba nomor baru — maks. 5x
      let transaction: Awaited<ReturnType<typeof tx.transaction.create>>;
      for (let attempt = 0; ; attempt++) {
        try {
          transaction = await tx.transaction.create({
            data: {
              invoiceNumber,
              repairRecordId,
              customerId,
              customerName,
              subtotal,
              discount,
              grandTotal,
              paymentMethod,
              paidAmount,
              changeAmount,
              itemsJson,
              paymentStatus,
              createdBy,
              referenceNumber,
              ...(editDateEnabled && body.timestamp !== undefined ? { timestamp: transactionTime } : {}),
            },
          });
          break;
        } catch (err) {
          if ((err as { code?: string }).code === "P2002" && attempt < 4) {
            invoiceNumber = makeInvoiceNumber();
            continue;
          }
          throw err;
        }
      }

      // Tahap 4: tiket → DIAMBIL + simpan penyesuaian kasir (jasa/part final/garansi)
      // (Daos.executeCheckoutTransaction: insertRepairRecord dengan status DIAMBIL)
      if (repair && repairRecordId) {
        const finalUsedParts =
          typeof body.usedPartsJson === "string" && body.usedPartsJson.trim().startsWith("[")
            ? body.usedPartsJson
            : repair.usedPartsJson;
        await tx.repairRecord.update({
          where: { id: repairRecordId },
          data: {
            status: "DIAMBIL",
            serviceFee,
            usedPartsJson: finalUsedParts,
            totalPrice:
              Number.isFinite(Number(body.adjustedTotalPrice)) && Number(body.adjustedTotalPrice) >= 0
                ? Number(body.adjustedTotalPrice)
                : serviceFee + repairPartsTotal,
            warrantyDays,
            updatedAt: new Date(),
            completedAt: new Date(),
          },
        });
      }

      // poin loyalitas: floor(grandTotal / 10000), hanya untuk pelanggan terdaftar (Daos.kt baris 187–192)
      if (customerId) {
        const points = Math.floor(grandTotal / 10000);
        if (points > 0) {
          await tx.customer.update({
            where: { id: customerId },
            data: { loyaltyPoints: { increment: points } },
          });
        }
      }

      await tx.auditLog.create({
        data: {
          action: "TAMBAH_TRANSAKSI",
          details: `Invoice ${invoiceNumber} — ${customerName} — Rp ${Math.trunc(grandTotal).toLocaleString("id-ID")} (${paymentMethod})${repair ? ` — Tiket SRV-${Math.floor(new Date(repair.createdAt).getTime() / 1000)}` : ""}`,
          performedBy: createdBy,
        },
      });

      return transaction;
    }, { timeout: 15000, maxWait: 5000 });

    return NextResponse.json(created, { status: 201 });
  } catch (e) {
    const message = e instanceof Error ? e.message : "Terjadi kesalahan pembayaran";
    console.error("transactions POST error", e);
    // Pesan bisnis (stok kurang dll.) diteruskan apa adanya — sama seperti toast referensi
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
