import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { errAction, resolveActor, verifySupervisorPin } from "@/lib/action-guard";
import { voidWindowOpen } from "@/lib/format";

type Params = { params: Promise<{ id: string }> };

// POST /api/transactions/[id]/void — batalkan transaksi (ala AppViewModel.deleteTransaction +
// Daos.voidTransactionAtomic): tandai void (oleh siapa, kapan, alasan) + kembalikan stok
// item retail (partId di itemsJson) + kurangi poin loyalitas — SEMUA dalam 1 transaksi DB.
//
// Aturan dokumen "Pembatalan transaksi" yang dipegang API ini (D34–D38):
//  - D34: hanya Admin (requesterUsername diverifikasi server, bukan percaya UI);
//  - D35: wajib PIN otorisasi supervisor (cocok salah satu akun Admin);
//  - D36: hanya hari kalender yang sama (WIB) — transaksi lama tidak bisa di-void;
//  - D38: transaksi yang sudah direfund TIDAK boleh di-void (batalkan dulu dokumen
//         refund-nya); void atas dokumen REFUND membalik arah stok (barang keluar lagi)
//         dan mengembalikan poin yang tertarik saat refund.
export async function POST(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return errAction("ID tidak valid", 400);
    }

    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;

    // D34 — aktor wajib Admin (server-side)
    const actor = await resolveActor(body.requesterUsername);
    if (!actor) {
      return errAction("Hanya Admin yang dapat membatalkan transaksi", 403);
    }

    // D35 — PIN otorisasi supervisor wajib
    const approver = await verifySupervisorPin(body.authorizePin);
    if (!approver) {
      return errAction("PIN otorisasi salah — pembatalan wajib persetujuan supervisor (PIN Admin)", 403);
    }

    // Alasan wajib (aturan 1)
    const reason = String(body.reason ?? "").trim();
    if (!reason) {
      return errAction("Alasan pembatalan wajib diisi", 400);
    }

    // D48/(a) — jawaban user "2 opsi (dikembalikan atau tidak)": bila transaksi
    // tiket memakai part internal, void boleh memilih mengembalikan stok part
    // (default TRUE) atau tidak (part rusak/hilang/sudah dipakai). Retail tetap
    // selalu kembali — opsi ini hanya untuk part internal tiket servis.
    const returnInternalParts = body.returnInternalParts !== false;

    const existing = await db.transaction.findUnique({ where: { id } });
    if (!existing) {
      return errAction("Transaksi tidak ditemukan", 404);
    }
    if (existing.isVoided) {
      return errAction("Transaksi sudah dibatalkan sebelumnya", 400);
    }

    // D36 — jendela void: hari yang sama (WIB)
    if (!voidWindowOpen(existing.timestamp)) {
      return errAction(
        "Melewati batas waktu pembatalan — void hanya boleh pada hari yang sama (aturan D36). " +
          "Gunakan Refund untuk koreksi transaksi hari sebelumnya.",
        400
      );
    }

    // D38 — transaksi yang punya dokumen refund aktif tidak boleh di-void
    if (existing.docType === "PENJUALAN") {
      const liveRefund = await db.transaction.findFirst({
        where: { refundOfId: existing.id, isVoided: false },
      });
      if (liveRefund) {
        return errAction(
          `Transaksi sudah direfund (${liveRefund.invoiceNumber}) — batalkan dulu dokumen refund-nya bila perlu`,
          400
        );
      }
    }

    // Efek stok: PENJUALAN di-void → barang kembali (increment);
    // dokumen REFUND di-void → barang keluar lagi (decrement, wajib stok cukup).
    type ReceiptItem = { partId?: number; qty?: number; itemType?: string; name?: string; alias?: string | null };
    let stockItems: { partId: number; qty: number }[] = [];
    let internalItems: { partId: number | null; name: string; alias: string | null; qty: number }[] = [];
    try {
      const parsed = JSON.parse(existing.itemsJson) as ReceiptItem[];
      stockItems = parsed
        .filter((it) => Number.isInteger(it.partId) && it.partId! > 0 && Number(it.qty) !== 0 && it.itemType !== "sparepart")
        .map((it) => ({ partId: it.partId!, qty: Math.abs(Math.trunc(Number(it.qty))) }));
      if (existing.docType === "PENJUALAN") {
        // part internal tiket: itemType "sparepart" — stok dipotong saat checkout
        // (D48/(a): kini punya partId di itemsJson; data lama dicocokkan katalog)
        internalItems = parsed
          .filter((it) => it.itemType === "sparepart" && Number(it.qty) !== 0)
          .map((it) => ({
            partId: Number.isInteger(it.partId) && it.partId! > 0 ? it.partId! : null,
            name: String(it.name ?? "").replace(/^Sparepart:\s*/i, "").trim(),
            alias: typeof it.alias === "string" ? it.alias.trim() : null,
            qty: Math.abs(Math.trunc(Number(it.qty))),
          }));
      }
    } catch {
      stockItems = [];
      internalItems = [];
    }
    const stockSign = existing.docType === "REFUND" ? -1 : 1;

    // Poin loyalitas: nilai dokumen REFUND negatif → pakai nilai absolut
    const nilaiAbs = Math.abs(existing.grandTotal);
    const pointsToMove = Math.floor(nilaiAbs / 10000);
    const pointsSign = existing.docType === "REFUND" ? 1 : -1; // refund void → poin kembali

    const voided = await db.$transaction(async (tx) => {
      for (const r of stockItems) {
        if (stockSign > 0) {
          await tx.sparePart.update({
            where: { id: r.partId },
            data: { stock: { increment: r.qty } },
          });
        } else {
          // membatalkan refund = barang keluar lagi; tolak bila stok tidak cukup
          const res = await tx.sparePart.updateMany({
            where: { id: r.partId, stock: { gte: r.qty } },
            data: { stock: { decrement: r.qty } },
          });
          if (res.count === 0) {
            const part = await tx.sparePart.findUnique({ where: { id: r.partId } });
            throw new Error(
              `Stok tidak cukup untuk membatalkan refund ${part?.name ?? `ID ${r.partId}`}`
            );
          }
        }
      }

      // D48/(a) — part internal tiket: kembalikan stok sesuai pilihan user.
      // partId baru (snapshot checkout) langsung dipakai; data lama tanpa partId
      // dicocokkan lewat alias lalu nama katalog — hanya bila cocok TEPAT SATU
      // part (ambigu → dilewati & dilaporkan di respons, tidak menggagalkan void).
      const unresolvedParts: string[] = [];
      if (stockSign > 0 && returnInternalParts && internalItems.length > 0) {
        const catalog = await tx.sparePart.findMany();
        const byId = new Map(catalog.map((p) => [p.id, p]));
        const byAlias = new Map<string, typeof catalog>();
        const byName = new Map<string, typeof catalog>();
        for (const p of catalog) {
          const nk = p.name.trim().toLowerCase();
          byName.set(nk, [...(byName.get(nk) ?? []), p]);
          if (p.alias && p.alias.trim() !== "") {
            const ak = p.alias.trim().toLowerCase();
            byAlias.set(ak, [...(byAlias.get(ak) ?? []), p]);
          }
        }
        for (const it of internalItems) {
          let target: (typeof catalog)[number] | undefined;
          if (it.partId) {
            target = byId.get(it.partId);
            if (!target) unresolvedParts.push(`${it.name} (partId ${it.partId} tidak ada di katalog)`);
          } else {
            const keys = [it.alias, it.name].filter((k): k is string => !!k && k !== "").map((k) => k.trim().toLowerCase());
            const found = new Set<number>();
            let hit: (typeof catalog)[number] | undefined;
            for (const k of keys) {
              for (const p of byAlias.get(k) ?? []) {
                if (!found.has(p.id)) { found.add(p.id); hit = p; }
              }
              for (const p of byName.get(k) ?? []) {
                if (!found.has(p.id)) { found.add(p.id); hit = p; }
              }
            }
            if (found.size === 1) target = hit;
            else if (found.size === 0) unresolvedParts.push(`${it.name} (tidak ada di katalog)`);
            else unresolvedParts.push(`${it.name} (cocok ${found.size} part katalog — ambigu)`);
          }
          if (target) {
            await tx.sparePart.update({
              where: { id: target.id },
              data: { stock: { increment: it.qty } },
            });
          }
        }
      }
      const internalReturned = stockSign > 0 && returnInternalParts
        ? internalItems.length - unresolvedParts.length
        : 0;

      // poin loyalitas: void penjualan menarik poin; void dokumen refund mengembalikannya
      if (existing.customerId && pointsToMove > 0) {
        const customer = await tx.customer.findUnique({ where: { id: existing.customerId } });
        if (customer) {
          await tx.customer.update({
            where: { id: customer.id },
            data: {
              loyaltyPoints: Math.max(0, customer.loyaltyPoints + pointsSign * pointsToMove),
            },
          });
        }
      }

      const transaction = await tx.transaction.update({
        where: { id },
        data: {
          isVoided: true,
          voidedBy: actor.name, // D34: dari aktor terverifikasi server, bukan string klien
          voidedAt: new Date(),
          voidReason: reason,
        },
      });

      // Tahap 4: void PENJUALAN tiket servis → kembalikan status tiket SELESAI
      // (hanya bila saat ini DIAMBIL) agar tiket bisa di-checkout ulang.
      // Dokumen REFUND tidak menaut tiket — unit sudah diambil pelanggan.
      if (existing.docType === "PENJUALAN" && existing.repairRecordId) {
        const repair = await tx.repairRecord.findUnique({ where: { id: existing.repairRecordId } });
        if (repair && repair.status === "DIAMBIL") {
          await tx.repairRecord.update({
            where: { id: repair.id },
            data: { status: "SELESAI", updatedAt: new Date() },
          });
        }
      }

      await tx.auditLog.create({
        data: {
          action: "HAPUS_TRANSAKSI",
          details:
            `Membatalkan ${existing.docType === "REFUND" ? "dokumen refund" : "transaksi"}: ` +
            `Invoice ${existing.invoiceNumber} (${existing.customerName}) — Alasan: ${reason}` +
            (internalItems.length > 0 && stockSign > 0
              ? ` — Part internal tiket: ${returnInternalParts ? `${internalReturned} dikembalikan ke stok${unresolvedParts.length ? `, ${unresolvedParts.length} dilewati` : ""}` : "TIDAK dikembalikan (pilihan)"}`
              : "") +
            ` — Otorisasi PIN: ${approver.name}`,
          performedBy: actor.name,
        },
      });

      return { transaction, internalReturned, unresolvedParts };
    }, { timeout: 15000, maxWait: 5000 }); // D12: ruang menunggu kunci tulis SQLite saat checkout paralel

    return NextResponse.json({
      ...voided.transaction,
      // D48/(a): umpan balik pengembalian part internal untuk toast UI
      internalReturned: voided.internalReturned,
      unresolvedParts: voided.unresolvedParts,
    });
  } catch (e) {
    const message = e instanceof Error ? e.message : "Gagal membatalkan transaksi";
    console.error("transactions void error", e);
    // pesan bisnis (stok kurang, dll.) → 400; kesalahan infrastruktur → 500
    return errAction(message, message.startsWith("Stok tidak cukup") ? 400 : 500);
  }
}
