import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { resolveActor } from "@/lib/action-guard";

type Params = { params: Promise<{ id: string }> };

// PUT /api/service-products/[id] — edit produk jasa
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return NextResponse.json({ error: "ID tidak valid" }, { status: 400 });
    }
    const existing = await db.serviceProduct.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Produk jasa tidak ditemukan" }, { status: 404 });
    }

    const body = await req.json();
    const name = String(body.name ?? "").trim();
    if (!name) {
      return NextResponse.json({ error: "Nama produk jasa wajib diisi" }, { status: 400 });
    }

    const product = await db.serviceProduct.update({
      where: { id },
      data: {
        name,
        basePrice: toNum(body.basePrice, existing.basePrice),
        points: toInt(body.points, existing.points),
      },
    });

    await db.auditLog.create({
      data: {
        action: "EDIT_PRODUK_JASA",
        details: `${product.name} (Rp ${product.basePrice}, ${product.points} poin)`,
        performedBy: String(body.performedBy ?? "Tidak diketahui"),
      },
    });

    return NextResponse.json(product);
  } catch (e) {
    console.error("service-products PUT error", e);
    return NextResponse.json({ error: "Gagal mengubah produk jasa" }, { status: 500 });
  }
}

// DELETE /api/service-products/[id]?requesterUsername=… — hapus produk jasa
// D34: hapus data = hanya Admin (aturan 4), diverifikasi server.
export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return NextResponse.json({ error: "ID tidak valid" }, { status: 400 });
    }
    const actor = await resolveActor(req.nextUrl.searchParams.get("requesterUsername"));
    if (!actor) {
      return NextResponse.json({ error: "Hanya Admin yang dapat menghapus data" }, { status: 403 });
    }
    const existing = await db.serviceProduct.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Produk jasa tidak ditemukan" }, { status: 404 });
    }

    await db.serviceProduct.delete({ where: { id } });
    await db.auditLog.create({
      data: {
        action: "HAPUS_PRODUK_JASA",
        details: existing.name,
        performedBy: actor.name,
      },
    });

    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("service-products DELETE error", e);
    return NextResponse.json({ error: "Gagal menghapus produk jasa" }, { status: 500 });
  }
}

function toInt(v: unknown, fallback: number): number {
  const n = Math.trunc(Number(v));
  return Number.isFinite(n) && n >= 0 ? n : fallback;
}

function toNum(v: unknown, fallback: number): number {
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 ? n : fallback;
}
