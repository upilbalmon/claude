import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { db } from "@/lib/db";
import {
  loadCreds,
  saveCreds,
  testConnection,
  enableAutoBackupOnChangeAfterConnect, // D86 — aturan: terhubung → auto-backup per-perubahan aktif
  normalizeFolder,
  credsSummary,
  REPO_RE,
  BRANCH_RE,
  FOLDER_RE,
  DEFAULT_BRANCH,
  DEFAULT_FOLDER,
} from "@/lib/github-backup";

// D68 — POST /api/github/credentials — simpan / uji / putuskan koneksi GitHub.
// Body JSON:
//   { requesterUsername, token, repo, branch?, folder? } → uji koneksi lalu simpan
//   { requesterUsername, clearToken: true }              → putuskan (hapus token)
// Selalu diuji dulu ke api.github.com — kredensial salah tidak akan tersimpan.
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as {
    requesterUsername?: unknown;
    token?: unknown;
    repo?: unknown;
    branch?: unknown;
    folder?: unknown;
    clearToken?: unknown;
  };
  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  // --- Putuskan koneksi ---
  if (body.clearToken === true) {
    const current = await loadCreds();
    await saveCreds({ token: "" });
    await db.auditLog.create({
      data: {
        action: "GITHUB_DISCONNECT",
        details: `Koneksi GitHub diputus${current.repo ? ` (repo ${current.repo})` : ""} — token dihapus dari server`,
        performedBy: actor.name,
      },
    });
    return NextResponse.json({ ok: true, status: credsSummary(await loadCreds()) });
  }

  // --- Simpan & uji ---
  const token = String(body.token ?? "").trim();
  const repo = String(body.repo ?? "").trim();
  const branch = (String(body.branch ?? "").trim() || DEFAULT_BRANCH).replace(/^\/+|\/+$/g, "");
  const folder = normalizeFolder(String(body.folder ?? "").trim() || DEFAULT_FOLDER);
  if (!token) return errAction("Token GitHub wajib diisi", 400);
  if (!REPO_RE.test(repo)) {
    return errAction('Format repo salah — gunakan "owner/repo", mis. budi/fixplus-backup', 400);
  }
  if (!BRANCH_RE.test(branch)) return errAction("Nama branch mengandung karakter tidak valid", 400);
  if (folder && !FOLDER_RE.test(folder)) {
    return errAction("Nama folder mengandung karakter tidak valid", 400);
  }

  let info;
  try {
    info = await testConnection(token, repo, branch);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("github credentials test error", e);
    return errAction(msg, 400);
  }

  await saveCreds({ token, repo, branch, folder });

  // D86 — ATURAN PEMILIK: koneksi GitHub BERHASIL (uji koneksi lulus +
  // kredensial tersimpan) → auto-backup mode "per-perubahan data" LANGSUNG
  // AKTIF — sama seperti jalur bootstrap pra-login. Bila mode sudah onchange,
  // tidak ada yang diubah dan tidak ada audit duplikat.
  let autoBackupOnChange = false;
  try {
    autoBackupOnChange = await enableAutoBackupOnChangeAfterConnect(actor.name);
  } catch (e) {
    console.error("github aturan D86 gagal (koneksi tetap tersimpan):", e);
  }

  await db.auditLog.create({
    data: {
      action: "GITHUB_CONNECT",
      details: `GitHub tersambung — repo ${info.fullName}${info.isPrivate ? " (privat)" : " (PUBLIK — disarankan ganti ke privat)"}, branch ${branch}, folder ${folder || "(root)"}${info.emptyRepo ? ", repo kosong (backup pertama akan menginisialisasi branch)" : ""}, token ••••${token.slice(-4)}`,
      performedBy: actor.name,
    },
  });
  return NextResponse.json({ ok: true, repo: info, autoBackupOnChange, status: credsSummary(await loadCreds()) });
}
