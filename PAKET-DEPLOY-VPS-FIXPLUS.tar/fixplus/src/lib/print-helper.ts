// PrintHelper — netralisasi ancestor dialog untuk pencetakan (D15/D16).
// DialogContent Tailwind v4 memakai `position:fixed; top:50%; left:50%;
// translate:-50% -50%`; properti translate/transform menciptakan containing
// block sehingga node cetak position:fixed/static ikut bergeser ke posisi
// dialog di tengah halaman. Reset via CSS dikalahkan Lightning CSS (mengubah
// `transform:none` menjadi transform identitas & membuang `translate:none`),
// maka leluhur node dinetralkan lewat inline style (selalu menang atas class
// utility), dicetak, lalu dipulihkan.
export type PrintOverrideSaved = Array<[HTMLElement, string]>;

export function pasangPrintOverride(nodeId: string): PrintOverrideSaved {
  const node = document.getElementById(nodeId);
  const saved: PrintOverrideSaved = [];
  let el = node?.parentElement;
  while (el && el !== document.body) {
    saved.push([el, el.getAttribute("style") ?? ""]);
    const imp = "important";
    el.style.setProperty("position", "static", imp);
    el.style.setProperty("top", "auto", imp);
    el.style.setProperty("left", "auto", imp);
    el.style.setProperty("right", "auto", imp);
    el.style.setProperty("bottom", "auto", imp);
    el.style.setProperty("inset", "auto", imp);
    el.style.setProperty("translate", "none", imp);
    el.style.setProperty("rotate", "none", imp);
    el.style.setProperty("scale", "none", imp);
    el.style.setProperty("transform", "none", imp);
    el.style.setProperty("margin", "0", imp);
    el.style.setProperty("padding", "0", imp);
    el.style.setProperty("width", "auto", imp);
    el.style.setProperty("max-width", "none", imp);
    el.style.setProperty("min-height", "0", imp);
    el = el.parentElement;
  }
  return saved;
}

export function pulihkanPrintOverride(saved: PrintOverrideSaved) {
  for (const [el, style] of saved) {
    if (style === "") el.removeAttribute("style");
    else el.setAttribute("style", style);
  }
}

// Alur lengkap: pasang gate class di body + netralisasi leluhur → window.print()
// → pulihkan semua (gate class dilepas setelah print selesai, ala pola kasir).
export function cetakNode(nodeId: string, bodyGateClass: string) {
  document.body.classList.add(bodyGateClass);
  const saved = pasangPrintOverride(nodeId);
  window.print();
  window.setTimeout(() => {
    document.body.classList.remove(bodyGateClass);
    pulihkanPrintOverride(saved);
  }, 500);
}
