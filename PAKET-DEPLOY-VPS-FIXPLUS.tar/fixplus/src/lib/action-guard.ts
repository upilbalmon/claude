import { db } from "@/lib/db";
import { hashPin } from "@/lib/pin-hash";

// D34/D35 — guard server-side aksi sensitif (void, refund, edit & hapus data).
// Aturan 4 dokumen "Pembatalan transaksi": kasir hanya membuat transaksi;
// void/refund/hapus butuh otorisasi. Pola sama dengan users-guard (Tahap 7.2):
// klien mengirim requesterUsername, SERVER yang memeriksa role — UI bukan
// satu-satunya penjaga lagi.

export function errAction(message: string, status: number) {
  return Response.json({ error: message }, { status });
}

// D34 — resolve aktor dari requesterUsername (body POST/PUT ATAU query DELETE).
// requireAdmin=true (default): hanya Admin — "hapus data" & void/refund = owner.
export async function resolveActor(username: unknown, requireAdmin = true) {
  const uname = String(username ?? "").trim();
  if (!uname) return null;
  const actor = await db.user.findUnique({ where: { username: uname } });
  if (!actor) return null;
  if (requireAdmin && actor.role !== "Admin") return null;
  return actor;
}

// D35 — verifikasi PIN otorisasi supervisor: PIN harus cocok salah satu akun
// Admin (yang bertindak boleh memasukkan PIN Admin lain = persetujuan atas
// perintahnya; bila satu-satunya Admin, ia memasukkan PIN-nya sendiri).
// Return akun Admin yang menyetujui — dicatat di audit log.
export async function verifySupervisorPin(pin: unknown) {
  const p = String(pin ?? "");
  if (!p) return null;
  const admins = await db.user.findMany({ where: { role: "Admin" } });
  for (const a of admins) {
    if (hashPin(p, a.salt) === a.pin) return a;
  }
  return null;
}
