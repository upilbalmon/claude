// Utilitas manajemen pengguna (Tahap 7.2) — dipakai API & UI Setting.
// Role & izin mengikuti referensi: Admin = semua izin; Kasir = Cashier ✓
// Services ✓ Customers ✓ (LoginScreen.kt akun default); Teknisi = fokus Servis.

export const USER_ROLES = ["Admin", "Kasir", "Teknisi"] as const;
export type UserRole = (typeof USER_ROLES)[number];

export const PERMISSION_FIELDS = [
  "permissionDashboard",
  "permissionCashier",
  "permissionServices",
  "permissionInventory",
  "permissionCustomers",
  "permissionUsers",
  "permissionSettings",
] as const;

export type PermissionField = (typeof PERMISSION_FIELDS)[number];

export const PERMISSION_LABEL: Record<PermissionField, string> = {
  permissionDashboard: "Laporan",
  permissionCashier: "Kasir",
  permissionServices: "Servis",
  permissionInventory: "Inventaris",
  permissionCustomers: "Pelanggan",
  permissionUsers: "Pengguna",
  permissionSettings: "Setting",
};

// Urutan tampil di form/tab izin (mengikuti urutan menu aplikasi)
export const PERMISSION_ORDER: PermissionField[] = [
  "permissionDashboard",
  "permissionServices",
  "permissionCashier",
  "permissionInventory",
  "permissionCustomers",
  "permissionUsers",
  "permissionSettings",
];

// Preset izin default per role — persis akun contoh referensi (LoginScreen.kt):
// admin semua izin; kasir Cashier ✓ Services ✓ Customers ✓; teknisi fokus Servis.
export function rolePreset(role: string): Record<PermissionField, boolean> {
  const preset = Object.fromEntries(PERMISSION_FIELDS.map((f) => [f, false])) as Record<
    PermissionField,
    boolean
  >;
  switch (role) {
    case "Admin":
      for (const f of PERMISSION_FIELDS) preset[f] = true;
      break;
    case "Kasir":
      preset.permissionCashier = true;
      preset.permissionServices = true;
      preset.permissionCustomers = true;
      break;
    case "Teknisi":
      preset.permissionServices = true;
      break;
  }
  return preset;
}

// PIN wajib 4 angka & bukan PIN default (aturan persis LoginScreen.kt / change-pin API)
export function validPinBaru(pin: unknown): boolean {
  return typeof pin === "string" && /^\d{4}$/.test(pin) && pin !== "1234" && pin !== "1111";
}

// D59 — Gate Asisten AI (keputusan user 12 Nov 2026): bubble & API Asisten AI
// hanya untuk "administrator atau owner". Di aplikasi ini role kepala toko =
// "Admin" (akun Administrator); "Owner" ikut diizinkan bila suatu saat ada
// role itu. Kasir & Teknisi tidak melihat bubble dan API menolak 403.
export const AI_ASSISTANT_ROLES = ["Admin", "Owner"] as const;

export function bolehAsistenAi(role: string): boolean {
  return (AI_ASSISTANT_ROLES as readonly string[]).includes(role);
}

// Username: 3–20 karakter huruf/angka/._- (tanpa spasi) — dipakai form & API
export function validUsername(username: string): boolean {
  return /^[a-zA-Z0-9._-]{3,20}$/.test(username);
}
