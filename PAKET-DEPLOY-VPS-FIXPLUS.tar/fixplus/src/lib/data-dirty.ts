// D69 — Penanda "ada perubahan data" untuk auto-backup GitHub per-perubahan.
// Modul murni tanpa dependensi agar bisa dipakai db.ts (hook tulisan Prisma)
// dan github-backup.ts (penjadwal) tanpa siklus impor.
//
// Status disimpan di globalThis supaya SEMUA salinan instansi modul (bundle
// route berbeda di dev / chunk terpisah di build) berbagi satu keadaan —
// penjadwal dari satu salinan modul tetap melihat perubahan yang ditandai
// oleh salinan modul lain.

type DirtyState = {
  dirty: boolean;
  firstDirtyAt: number | null;
  lastChangeAt: number;
  suppressed: boolean;
};

const g = globalThis as unknown as { __fixplusDataDirty?: DirtyState };
const state: DirtyState = (g.__fixplusDataDirty ??= {
  dirty: false,
  firstDirtyAt: null,
  lastChangeAt: 0,
  suppressed: false,
});

// Dipanggil setiap ada tulisan data (create/update/delete/upsert) dari hook
// Prisma di db.ts. Perubahan beruntun hanya memajukan lastChangeAt — backup
// dinyalakan ketika data "tenang" DEBOUNCE detik, atau saat MAX_WAIT terlampaui.
export function markDataChange(): void {
  if (state.suppressed) return;
  const now = Date.now();
  if (!state.dirty) {
    state.dirty = true;
    state.firstDirtyAt = now;
  }
  state.lastChangeAt = now;
}

export function peekDirty(): {
  dirty: boolean;
  firstDirtyAt: number | null;
  lastChangeAt: number;
} {
  return { dirty: state.dirty, firstDirtyAt: state.firstDirtyAt, lastChangeAt: state.lastChangeAt };
}

export function clearDirty(): void {
  state.dirty = false;
  state.firstDirtyAt = null;
}

// Selama backup berjalan, tulisan yang dibuat proses backup itu sendiri
// (mis. jejak audit BACKUP_GITHUB) tidak dianggap perubahan data baru —
// mencegah lingkaran backup→audit→backup.
export function suppressDirty(v: boolean): void {
  state.suppressed = v;
  if (v) clearDirty();
}
