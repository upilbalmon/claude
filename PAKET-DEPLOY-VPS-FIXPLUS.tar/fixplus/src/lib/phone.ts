// Validasi ringan nomor telepon/WA — Revisi Tahap 2 (temuan T3 uji simulasi).
// Aturan: setelah semua karakter non-angka dibuang, panjang wajib 9–15 digit.
// Menerima 08… (lokal Indonesia), 62…, dan +62… (spasi/strip/dll. diabaikan).
// Tujuan utama: menolak salah ketik pendek ("0812") yang membuat Blast WA salah sasaran.
export function phoneDigits(raw: string): string {
  return raw.replace(/\D/g, "");
}

export function isValidPhone(raw: string): boolean {
  const digits = phoneDigits(raw);
  return digits.length >= 9 && digits.length <= 15;
}

// Teks bantu seragam untuk form & pesan error API.
export const PHONE_HINT = "9–15 digit angka, contoh: 08123456789";
