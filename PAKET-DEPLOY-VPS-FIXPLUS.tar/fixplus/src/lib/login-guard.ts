// LoginAttemptGuard.kt — 5 percobaan gagal → kunci 60 detik (in-memory)
// Disimpan di globalThis agar state tidak hilang saat modul di-reload dev server
type Entry = { attempts: number; lockUntil: number };

const GUARD_KEY = "__sphp_login_guard__";

type GuardStore = Map<string, Entry>;

function store(): GuardStore {
  const g = globalThis as unknown as { [GUARD_KEY]?: GuardStore };
  if (!g[GUARD_KEY]) {
    g[GUARD_KEY] = new Map();
  }
  return g[GUARD_KEY];
}

const MAX_ATTEMPTS = 5;
const LOCK_DURATION_MS = 60_000;

function norm(username: string): string {
  return username.trim().toLowerCase();
}

export function getAttempts(username: string): number {
  return store().get(norm(username))?.attempts ?? 0;
}

export function recordFailedAttempt(username: string): void {
  const key = norm(username);
  const s = store();
  const e = s.get(key) ?? { attempts: 0, lockUntil: 0 };
  e.attempts += 1;
  if (e.attempts >= MAX_ATTEMPTS) {
    e.lockUntil = Date.now() + LOCK_DURATION_MS;
  }
  s.set(key, e);
}

export function isLocked(username: string): boolean {
  const key = norm(username);
  const e = store().get(key);
  if (!e) return false;
  // Belum pernah dikunci (lockUntil=0) → jangan sentuh entry, hanya lapor tidak terkunci
  if (e.lockUntil <= 0) return false;
  if (Date.now() > e.lockUntil) {
    // Kedaluwarsa → reset, persis LoginAttemptGuard.kt
    store().delete(key);
    return false;
  }
  return true;
}

export function getRemainingLockSeconds(username: string): number {
  const e = store().get(norm(username));
  if (!e) return 0;
  return Math.max(0, Math.floor((e.lockUntil - Date.now()) / 1000));
}

export function resetAttempts(username: string): void {
  store().delete(norm(username));
}
