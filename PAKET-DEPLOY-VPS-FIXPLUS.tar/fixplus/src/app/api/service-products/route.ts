import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/service-products — katalog produk jasa (ala repository.allServiceProducts)
export async function GET() {
  try {
    const products = await db.serviceProduct.findMany({ orderBy: { name: "asc" } });
    return NextResponse.json(products);
  } catch (e) {
    console.error("service-products GET error", e);
    return NextResponse.json({ error: "Gagal memuat produk jasa" }, { status: 500 });
  }
}

// POST /api/service-products — tambah produk jasa (nama, harga dasar, poin teknisi)
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const name = String(body.name ?? "").trim();
    if (!name) {
      return NextResponse.json({ error: "Nama produk jasa wajib diisi" }, { status: 400 });
    }

    const product = await db.serviceProduct.create({
      data: {
        name,
        basePrice: toNum(body.basePrice, 0),
        points: toInt(body.points, 0),
      },
    });

    await db.auditLog.create({
      data: {
        action: "TAMBAH_PRODUK_JASA",
        details: `${product.name} (Rp ${product.basePrice}, ${product.points} poin)`,
        performedBy: String(body.performedBy ?? "Tidak diketahui"),
      },
    });

    return NextResponse.json(product, { status: 201 });
  } catch (e) {
    console.error("service-products POST error", e);
    return NextResponse.json({ error: "Gagal menyimpan produk jasa" }, { status: 500 });
  }
}

function toInt(v: unknown, fallback: number): number {
  const n = Math.trunc(Number(v));
  return Number.isFinite(n) && n >= 0 ? n : fallback;
}

function toNum(v: unknown, fallback: number): number {
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 ? n : fallback;
}
