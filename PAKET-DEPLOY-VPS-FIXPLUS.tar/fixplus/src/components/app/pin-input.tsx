"use client";

// PinInput Adaptif — Keputusan Desain D1 (usulan & disetujui user, 10 Nov 2026)
// - Desktop      : titik PIN + ketikan keyboard fisik, auto-submit saat 4 digit penuh (atau Enter)
// - Layar sentuh : keypad 3×4 tampil otomatis (matchMedia "(hover: none) and (pointer: coarse)")
// - Desktop      : tombol "Gunakan keypad" untuk membuka keypad manual bila dibutuhkan
// Konsisten dipakai di 3 titik: login (LoginScreen.kt), buka-kunci sesi (PinUnlockScreen.kt),
// dan ganti PIN pertama — sehingga di desktop semuanya "tinggal ketik".

import { useEffect, useRef, useState } from "react";
import { Delete } from "lucide-react";
import { cn } from "@/lib/utils";

const MAX_LEN = 4;

export type PinInputProps = {
  value: string;
  onChange: (pin: string) => void;
  /** Dipanggil saat PIN mencapai 4 digit — baik dari keyboard fisik maupun keypad */
  onComplete?: (pin: string) => void;
  /** Dipanggil saat menekan Enter (form yang butuh aksi eksplisit) */
  onSubmit?: () => void;
  /** Naikkan angkanya untuk memicu animasi goyang saat PIN salah */
  errorTick?: number;
  disabled?: boolean;
  autoFocus?: boolean;
  /** "bare" = titik besar tanpa kotak (layar kunci); "field" = kotak seperti input (form login/ganti PIN) */
  variant?: "bare" | "field";
  /** id untuk kolom tersembunyi — agar <Label htmlFor> tetap tersambung */
  id?: string;
  ariaLabel?: string;
  className?: string;
};

export function PinInput({
  value,
  onChange,
  onComplete,
  onSubmit,
  errorTick = 0,
  disabled = false,
  autoFocus = true,
  variant = "bare",
  id,
  ariaLabel = "PIN",
  className,
}: PinInputProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const shakeRef = useRef<HTMLDivElement>(null);
  const [isTouch, setIsTouch] = useState(false);
  const [keypadOpen, setKeypadOpen] = useState(false);

  // Deteksi perangkat layar sentuh — keypad grafis muncul otomatis di HP/tablet
  useEffect(() => {
    const mq = window.matchMedia("(hover: none) and (pointer: coarse)");
    const update = () => setIsTouch(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);

  // Fokus otomatis saat komponen muncul — tidak perlu klik dulu
  useEffect(() => {
    if (!autoFocus || disabled) return;
    const t = setTimeout(() => inputRef.current?.focus(), 60);
    return () => clearTimeout(t);
  }, [autoFocus, disabled]);

  // Animasi goyang ketika errorTick berubah (PIN salah) — lewat kelas DOM,
  // tanpa setState di dalam effect (kepatuhan lint react-hooks)
  useEffect(() => {
    if (errorTick <= 0) return;
    const el = shakeRef.current;
    if (!el) return;
    el.classList.remove("animate-pin-shake");
    void el.offsetWidth; // paksa reflow agar animasi bisa direstart
    el.classList.add("animate-pin-shake");
    const t = setTimeout(() => el.classList.remove("animate-pin-shake"), 600);
    return () => clearTimeout(t);
  }, [errorTick]);

  function pushDigit(d: string) {
    if (disabled || value.length >= MAX_LEN) return;
    const next = value + d;
    onChange(next);
    if (next.length === MAX_LEN) onComplete?.(next);
  }

  function popDigit() {
    if (disabled || value.length === 0) return;
    onChange(value.slice(0, -1));
  }

  // Kolom tersembunyi menangkap ketikan keyboard fisik (desktop) / keyboard angka OS (HP)
  function handleNativeChange(e: React.ChangeEvent<HTMLInputElement>) {
    const digits = e.target.value.replace(/\D/g, "").slice(0, MAX_LEN);
    if (digits === value) return;
    const grew = digits.length > value.length;
    onChange(digits);
    if (grew && digits.length === MAX_LEN) onComplete?.(digits);
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter") {
      e.preventDefault();
      onSubmit?.();
    }
  }

  const showKeypad = isTouch || keypadOpen;
  const isBare = variant === "bare";

  return (
    <div className={cn("flex w-full flex-col items-center gap-3", className)}>
      {/* Titik PIN + kolom ketikan tersembunyi di atasnya (klik area titik = fokus) */}
      <div ref={shakeRef} className="relative">
        <div
          className={cn(
            "flex cursor-text items-center justify-center",
            isBare ? "gap-4 py-1" : "h-11 w-64 gap-3 rounded-xl border border-input bg-transparent",
            disabled && "opacity-50"
          )}
        >
          {Array.from({ length: MAX_LEN }).map((_, i) => (
            <span
              key={i}
              aria-hidden
              className={cn(
                "rounded-full border-[1.5px] border-primary transition-all duration-150",
                isBare ? "size-[18px]" : "size-3.5",
                i < value.length ? "scale-110 bg-primary" : "bg-transparent"
              )}
            />
          ))}
        </div>
        <input
          ref={inputRef}
          id={id}
          type="password"
          inputMode="numeric"
          autoComplete="off"
          aria-label={ariaLabel}
          disabled={disabled}
          value={value}
          onChange={handleNativeChange}
          onKeyDown={handleKeyDown}
          onPaste={(e) => e.preventDefault()}
          className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
        />
      </div>

      {/* Petunjuk + saklar keypad manual (perangkat non-sentuh saja) */}
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        {!isTouch && !keypadOpen && isBare && <span>Ketik 4 angka PIN di keyboard</span>}
        {!isTouch && (
          <button
            type="button"
            onClick={() => setKeypadOpen((v) => !v)}
            className="underline-offset-4 hover:underline"
          >
            {keypadOpen ? "Sembunyikan keypad" : "Gunakan keypad"}
          </button>
        )}
      </div>

      {/* Keypad 3×4 — otomatis di layar sentuh, manual di desktop */}
      {showKeypad && (
        <div className="mt-1 w-full max-w-[280px]" role="group" aria-label="Keypad PIN">
          {[
            ["1", "2", "3"],
            ["4", "5", "6"],
            ["7", "8", "9"],
            ["", "0", "BACKSPACE"],
          ].map((row, ri) => (
            <div key={ri} className={cn("flex w-full gap-3", ri < 3 && "mb-3")}>
              {row.map((key, ki) =>
                key === "" ? (
                  <span key={ki} className="flex-1" />
                ) : key === "BACKSPACE" ? (
                  <button
                    key={ki}
                    type="button"
                    onClick={popDigit}
                    disabled={disabled}
                    aria-label="Hapus digit"
                    className="flex aspect-square min-h-11 flex-1 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted active:bg-accent"
                  >
                    <Delete className="size-5" aria-hidden />
                  </button>
                ) : (
                  <button
                    key={ki}
                    type="button"
                    onClick={() => pushDigit(key)}
                    disabled={disabled}
                    className="flex aspect-square min-h-11 flex-1 items-center justify-center rounded-full text-xl font-medium transition-colors hover:bg-muted active:bg-accent"
                  >
                    {key}
                  </button>
                )
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
