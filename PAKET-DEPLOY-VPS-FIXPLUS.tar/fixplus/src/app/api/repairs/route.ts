import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { REPAIR_STATUSES } from "@/lib/repair-utils";
import { partShortageWarnings } from "@/lib/part-warning";

// GET /api/repairs — daftar semua tiket servis (ala repository.allRepairs,
// urut terbaru dulu untuk tampilan daftar per grup tanggal)
export async function GET() {
  try {
    const repairs = await db.repairRecord.findMany({
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json(repairs);
  } catch (e) {
    console.error("repairs GET error", e);
    return NextResponse.json({ error: "Gagal memuat tiket servis" }, { status: 500 });
  }
}

// D64 — part EXTERNAL (toko lain) kini boleh langsung di tiket (Terima Servis,
// incl. Servis Kilat & dialog Diagnosa): petugas mengetik nama + harga beli &
// jual; partId 0 & isExternal true — tidak menyentuh stok, ikut total & HPP
// (satu pola dengan part toko lain di kartu tagihan Kasir).
type UsedPartInput = {
  partId: number;
  qty: number;
  name?: string;
  sellPrice?: number;
  costPrice?: number;
  isExternal?: boolean;
};

// POST /api/repairs — terima servis baru (ala saveRepairRecord AppViewModel.kt).
// Harga & nama sparepart di-resolve dari DB terkini (snapshot UI tidak dipercaya);
// stok TIDAK dipotong di sini — potong stok terjadi saat checkout tiket (Tahap 4.6).
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const deviceModel = String(body.deviceModel ?? "").trim();
    const damageDescription = String(body.damageDescription ?? "").trim();
    if (!deviceModel || !damageDescription) {
      return NextResponse.json(
        { error: "Model HP dan deskripsi kerusakan wajib diisi" },
        { status: 400 }
      );
    }
    const customerName = String(body.customerName ?? "").trim();
    if (!customerName) {
      return NextResponse.json({ error: "Nama pelanggan wajib diisi" }, { status: 400 });
    }
    const customerPhone = String(body.customerPhone ?? "").trim(); // D52: nomor WA opsional — boleh kosong (tanpa lagi default "081" palsu)

    const status = REPAIR_STATUSES.includes(body.status) ? body.status : "ANTRI";
    const difficulty = ["Rendah", "Sedang", "Tinggi"].includes(body.difficulty)
      ? body.difficulty
      : "Sedang";
    const serviceFee = Math.max(0, Number(body.serviceFee) || 0);
    const estimatedCost =
      body.estimatedCost === null || body.estimatedCost === undefined || body.estimatedCost === ""
        ? null
        : Math.max(0, Number(body.estimatedCost) || 0);
    const downPayment =
      body.downPayment === null || body.downPayment === undefined || body.downPayment === ""
        ? null
        : Math.max(0, Number(body.downPayment) || 0);
    const warrantyDays = Math.max(0, Math.trunc(Number(body.warrantyDays) || 0));
    const pointsReward =
      body.pointsReward === null || body.pointsReward === undefined || Number(body.pointsReward) <= 0
        ? null
        : Math.trunc(Number(body.pointsReward));
    const estimatedCompletionTime = String(body.estimatedCompletionTime ?? "").trim();
    const notes = String(body.notes ?? "").trim();
    const createdByUser = String(body.createdByUser ?? "Tidak diketahui");

    const customerId =
      Number.isInteger(body.customerId) && Number(body.customerId) > 0
        ? Number(body.customerId)
        : null;
    if (customerId) {
      const customer = await db.customer.findUnique({ where: { id: customerId } });
      if (!customer) {
        return NextResponse.json({ error: "Pelanggan tidak ditemukan" }, { status: 400 });
      }
    }

    // Sparepart terpakai — internal resolve dari DB; D64: entri isExternal dibawa
    // apa adanya (nama/harga dari input, partId 0) — tidak di-resolve katalog.
    const partsInput: UsedPartInput[] = Array.isArray(body.usedParts) ? body.usedParts : [];
    const resolvedParts: {
      partId: number;
      name: string;
      alias: string | null; // D23 (D18/D19): snapshot "Nama di Struk" saat tiket dibuat
      qty: number;
      sellPrice: number;
      costPrice: number;
      isExternal?: boolean;
    }[] = [];
    for (const p of partsInput) {
      const qty = Math.trunc(Number(p?.qty) || 0);
      if (p?.isExternal) {
        // D64: part external — wajib nama; harga jual ≥ 0 & beli ≥ 0 (beli boleh 0 bila gratis)
        const name = String(p?.name ?? "").trim();
        if (!name || qty <= 0) continue;
        resolvedParts.push({
          partId: 0,
          name,
          alias: null,
          qty,
          sellPrice: Math.max(0, Number(p?.sellPrice) || 0),
          costPrice: Math.max(0, Number(p?.costPrice) || 0),
          isExternal: true,
        });
        continue;
      }
      const partId = Number(p?.partId);
      if (!Number.isInteger(partId) || partId <= 0 || qty <= 0) continue;
      const part = await db.sparePart.findUnique({ where: { id: partId } });
      if (!part) {
        return NextResponse.json(
          { error: `Sparepart tidak ditemukan (ID ${partId})` },
          { status: 400 }
        );
      }
      resolvedParts.push({
        partId,
        name: part.name,
        alias: part.alias ?? null,
        qty,
        sellPrice: part.sellPrice,
        costPrice: part.costPrice,
      });
    }
    const partsSum = resolvedParts.reduce((s, p) => s + p.sellPrice * p.qty, 0);
    const totalPrice = serviceFee + partsSum;

    // D48/(b) — peringatan janji stok (tanpa reservasi): stok baru dipotong saat
    // checkout; bila part yang dijanjikan melebihi ketersediaan efektif, kirim
    // `warnings` — UI menampilkan peringatan, tiket tetap boleh dibuat.
    const warnings = await partShortageWarnings(
      resolvedParts
        .filter((p) => !p.isExternal) // D64: part external tidak berhubungan dengan stok
        .map((p) => ({ partId: p.partId, qty: p.qty }))
    );

    // Teknisi: nama disimpan persis referensi (technicianId + technicianName)
    let technicianId: number | null = null;
    let technicianName: string | null = null;
    if (Number.isInteger(body.technicianId) && Number(body.technicianId) > 0) {
      const tech = await db.technician.findUnique({ where: { id: Number(body.technicianId) } });
      if (!tech) {
        return NextResponse.json({ error: "Teknisi tidak ditemukan" }, { status: 400 });
      }
      technicianId = tech.id;
      technicianName = tech.name;
    }

    // D89 — paritas D39 (kasir): tanggal/waktu TERIMA SERVIS boleh diatur
    // petugas HANYA bila pengaturan "Edit Tanggal Transaksi" aktif di server.
    // Tanpa timestamp → waktu server dipakai (perilaku lama tetap).
    const shopSettings = await db.shopSettings.findUnique({ where: { id: 1 } });
    const editDateEnabled = shopSettings?.editTransactionDate ?? false;
    const rawTimestamp = body.timestamp;
    let terimaTime = new Date();
    let tanggalCustom = false;
    if (rawTimestamp !== undefined && rawTimestamp !== null && String(rawTimestamp).trim() !== "") {
      if (!editDateEnabled) {
        return NextResponse.json(
          { error: "Perubahan tanggal terima servis dinonaktifkan oleh Admin (Pengaturan → Tampilan)" },
          { status: 400 }
        );
      }
      const parsed = new Date(String(rawTimestamp));
      if (Number.isNaN(parsed.getTime())) {
        return NextResponse.json({ error: "Tanggal terima servis tidak valid" }, { status: 400 });
      }
      // Tidak boleh terlalu jauh di masa depan (maks. 1 hari) — anti salah input
      if (parsed.getTime() - Date.now() > 24 * 60 * 60 * 1000) {
        return NextResponse.json(
          { error: "Tanggal terima servis tidak boleh lebih dari 1 hari ke depan" },
          { status: 400 }
        );
      }
      terimaTime = parsed;
      tanggalCustom = true;
    }

    const created = await db.$transaction(async (tx) => {
      const repair = await tx.repairRecord.create({
        data: {
          createdAt: terimaTime,
          customerId,
          customerName,
          customerPhone,
          deviceModel,
          serialOrImei: String(body.serialOrImei ?? "").trim(),
          damageDescription,
          status,
          technicianId,
          technicianName,
          serviceFee,
          usedPartsJson: JSON.stringify(resolvedParts),
          totalPrice,
          difficulty,
          notes,
          estimatedCost,
          downPayment,
          estimatedCompletionTime,
          createdByUser,
          pointsReward,
          warrantyDays,
        },
      });

      await tx.auditLog.create({
        data: {
          action: "TAMBAH_REPAIR",
          details: `Terima servis baru: ${repair.deviceModel} — ${repair.customerName} (Rp ${Math.trunc(repair.totalPrice).toLocaleString("id-ID")})${tanggalCustom ? ` — tanggal terima diatur ke ${terimaTime.toLocaleString("id-ID", { timeZone: "Asia/Jakarta", dateStyle: "medium", timeStyle: "short" })}` : ""}`,
          performedBy: createdByUser,
        },
      });

      return repair;
    });

    return NextResponse.json({ ...created, warnings }, { status: 201 });
  } catch (e) {
    console.error("repairs POST error", e);
    return NextResponse.json({ error: "Gagal menyimpan tiket servis" }, { status: 500 });
  }
}
