import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { db } from "@/lib/db";
import { loadCreds, saveCreds, saAccessToken } from "@/lib/gdrive";

// D67 — Kredensial Service Account (jalur B, backup otomatis tanpa popup).
// POST: kunci JSON service account + Folder ID yang dibagikan ke SA
// (Editor). Divalidasi langsung: minta token (uji kunci) + baca metadata
// folder (uji akses) SEBELUM disimpan — kesalahan ketik langsung ketahuan.
// DELETE: hapus konfigurasi SA.
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as {
    requesterUsername?: unknown;
    keyJson?: unknown;
    folderId?: unknown;
  };
  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const rawKey = String(body.keyJson ?? "").trim();
  const folderId = String(body.folderId ?? "").trim();
  if (!rawKey || !folderId) {
    return errAction("Kunci JSON service account dan Folder ID wajib diisi", 400);
  }
  let parsed: { client_email?: unknown; private_key?: unknown };
  try {
    parsed = JSON.parse(rawKey) as { client_email?: unknown; private_key?: unknown };
  } catch {
    return errAction(
      "Kunci JSON tidak bisa dibaca — pastikan mengunggah seluruh isi file kunci (.json) dari Google Cloud Console (IAM & Admin → Service Accounts → Keys)",
      400
    );
  }
  const clientEmail = String(parsed.client_email ?? "").trim();
  let privateKey = String(parsed.private_key ?? "");
  if (!clientEmail || !privateKey) {
    return errAction(
      "Kunci tidak berisi client_email / private_key — ini bukan kunci service account yang benar",
      400
    );
  }
  // File kunci berisi \n literal — normalisasi ke newline asli
  privateKey = privateKey.replace(/\\n/g, "\n");

  try {
    // Uji 1: kunci valid → token terbit
    const token = await saAccessToken({ clientEmail, privateKey, folderId });
    // Uji 2: folder terlihat & benar-benar folder (terbagikan ke SA)
    const res = await fetch(
      `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(folderId)}?fields=id,name,mimeType`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    const meta = (await res.json().catch(() => ({}))) as Record<string, unknown>;
    if (!res.ok) {
      const err = meta.error as { message?: string } | undefined;
      throw new Error(
        `Folder tidak bisa diakses: ${err?.message ?? `HTTP ${res.status}`}. Pastikan folder di Drive Anda DIBAGIKAN (Editor) ke email service account ${clientEmail}`
      );
    }
    if (!String(meta.mimeType ?? "").includes("application/vnd.google-apps.folder")) {
      throw new Error("ID yang diberikan bukan folder — buat folder khusus cadangan lalu bagikan ke service account");
    }

    await saveCreds({ sa: { clientEmail, privateKey, folderId } });
    await db.auditLog.create({
      data: {
        action: "GDRIVE_SA_SAVE",
        details: `Service Account ${clientEmail} dikonfigurasi; folder target "${String(meta.name)}" (${folderId})`,
        performedBy: actor.name,
      },
    });
    return NextResponse.json({
      ok: true,
      clientEmail,
      folderName: String(meta.name ?? ""),
      folderId,
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("gdrive sa save error", e);
    return errAction(msg, 400);
  }
}

export async function DELETE(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as { requesterUsername?: unknown };
  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);
  const c = await loadCreds();
  if (!c.sa) return errAction("Service Account belum dikonfigurasi", 400);
  await saveCreds({ sa: undefined });
  return NextResponse.json({ ok: true });
}
