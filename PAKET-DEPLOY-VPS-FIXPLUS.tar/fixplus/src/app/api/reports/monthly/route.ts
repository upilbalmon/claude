import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { dayKeyWIB } from "@/lib/format";
import { isAdminRole, resolveReporter, wibMonthKey, wibMonthRange } from "@/lib/report-utils";

// D48/5A.9 — Rekap Omzet Bruto Bulanan (dasar pajak UMKM).
// GET /api/reports/monthly?year=YYYY&requesterUsername=…
// Per bulan kalender WIB: omzet kotor (Σ grandTotal PENJUALAN tidak void),
// refund (Σ |grandTotal| REFUND tidak void), omzet net, jumlah transaksi.
// HPP/laba hanya untuk Admin (jawaban g). 12 baris selalu dikembalikan.
// Ekspor CSV rekap ini = dasar pelaporan omzet bruto (SAK EMKM sederhana).

export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const reporter = await resolveReporter(sp.get("requesterUsername"));
    if (!reporter) {
      return NextResponse.json({ error: "Sesi tidak dikenal — masuk ulang" }, { status: 401 });
    }
    const admin = isAdminRole(reporter);

    const yearRaw = Number(sp.get("year"));
    const nowWib = dayKeyWIB(new Date());
    const year = Number.isInteger(yearRaw) && yearRaw >= 2000 && yearRaw <= 2100 ? yearRaw : Number(nowWib.slice(0, 4));

    const start = wibMonthRange(year, 0).start;
    const end = wibMonthRange(year + 1, 0).start;

    const txs = await db.transaction.findMany({
      where: { timestamp: { gte: start, lt: end } },
      select: { timestamp: true, grandTotal: true, docType: true, isVoided: true, itemsJson: true },
    });

    type Row = { bulan: number; omzetKotor: number; refund: number; omzetNet: number; count: number; hpp: number };
    const months: Row[] = Array.from({ length: 12 }, (_, i) => ({
      bulan: i + 1, omzetKotor: 0, refund: 0, omzetNet: 0, count: 0, hpp: 0,
    }));

    for (const t of txs) {
      if (t.isVoided) continue;
      const mk = wibMonthKey(t.timestamp);
      const mIdx = Number(mk.slice(5, 7)) - 1;
      if (mIdx < 0 || mIdx > 11) continue;
      const row = months[mIdx];
      if (t.docType === "REFUND") {
        row.refund += Math.abs(t.grandTotal);
      } else {
        row.omzetKotor += t.grandTotal;
        row.count += 1;
        if (admin) {
          try {
            const items = JSON.parse(t.itemsJson) as { qty?: number; costPrice?: number }[];
            if (Array.isArray(items)) {
              row.hpp += items.reduce(
                (s, it) => s + Math.max(0, Number(it?.costPrice) || 0) * Math.max(1, Math.trunc(Number(it?.qty) || 1)),
                0
              );
            }
          } catch {
            // itemsJson rusak → HPP dokumen ini 0
          }
        }
      }
    }

    const bulanLabel = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
    const rows = months.map((m) => ({
      bulan: m.bulan,
      label: bulanLabel[m.bulan - 1],
      omzetKotor: m.omzetKotor,
      refund: m.refund,
      omzetNet: m.omzetKotor - m.refund,
      count: m.count,
      hpp: admin ? m.hpp : null,
      labaKotor: admin ? m.omzetKotor - m.refund - m.hpp : null,
    }));

    return NextResponse.json({
      year,
      isAdmin: admin,
      rows,
      totalOmzetKotor: rows.reduce((s, r) => s + r.omzetKotor, 0),
      totalRefund: rows.reduce((s, r) => s + r.refund, 0),
      totalNet: rows.reduce((s, r) => s + r.omzetNet, 0),
      totalCount: rows.reduce((s, r) => s + r.count, 0),
    });
  } catch (e) {
    console.error("reports monthly GET error", e);
    return NextResponse.json({ error: "Gagal memuat rekap bulanan" }, { status: 500 });
  }
}
