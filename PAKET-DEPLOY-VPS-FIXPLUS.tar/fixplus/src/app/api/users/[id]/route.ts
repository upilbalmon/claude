import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { generateSalt, hashPin, sanitizeUser } from "@/lib/pin-hash";
import { err, resolveManager, withHeal } from "@/lib/users-guard";
import {
  PERMISSION_FIELDS,
  USER_ROLES,
  validPinBaru,
  validUsername,
} from "@/lib/user-utils";

type Params = { params: Promise<{ id: string }> };

// Tahap 7.2 — edit & hapus pengguna.
// Aturan pelindung (server-side):
//  - peminta wajib punya izin permissionUsers;
//  - TIDAK BOLEH mengubah role/izin akun sendiri (mencegah terkunci sendiri);
//  - TIDAK BOLEH menghapus akun sendiri;
//  - role Admin terakhir tidak boleh diturunkan/dihapus.

// PUT /api/users/[id] — edit profil/role/izin + reset PIN (bila dikirim)
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    // D55 — id & body dibaca SEKALI di luar withHeal (body request hanya
    // bisa dibaca sekali; retry cukup mengulang pekerjaan database).
    const id = Number((await params).id);
    if (!Number.isInteger(id)) return err("ID tidak valid", 400);
    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
    return await withHeal(async () => {
      const manager = await resolveManager(body.requesterUsername);
      if (!manager) return err("Anda tidak memiliki izin mengelola pengguna", 403);

      const existing = await db.user.findUnique({ where: { id } });
      if (!existing) return err("Pengguna tidak ditemukan", 404);

      const name = body.name === undefined ? existing.name : String(body.name).trim();
      if (!name) return err("Nama pengguna wajib diisi", 400);

      const username =
        body.username === undefined ? existing.username : String(body.username).trim();
      if (!validUsername(username)) {
        return err("Username 3–20 karakter, hanya huruf/angka/titik/garis (tanpa spasi)", 400);
      }
      if (username.toLowerCase() !== existing.username.toLowerCase()) {
        const all = await db.user.findMany({ select: { id: true, username: true } });
        const dup = all.find(
          (u) => u.id !== id && u.username.toLowerCase() === username.toLowerCase()
        );
        if (dup) return err(`Username "${username}" sudah dipakai`, 409);
      }

      const role = body.role === undefined ? existing.role : String(body.role).trim();
      if (!USER_ROLES.includes(role as (typeof USER_ROLES)[number])) {
        return err("Role harus salah satu dari: Admin, Kasir, Teknisi", 400);
      }

      // Pelindung 1: role/izin akun sendiri tidak boleh diubah oleh akun itu sendiri
      const mengubahRole = body.role !== undefined && role !== existing.role;
      const mengubahIzin = PERMISSION_FIELDS.some((f) => body[f] !== undefined);
      if (manager.id === id && (mengubahRole || mengubahIzin)) {
        return err(
          "Tidak dapat mengubah role/izin akun sendiri — minta Admin lain untuk melakukannya",
          403
        );
      }

      // Pelindung 2: Admin terakhir tidak boleh diturunkan rolenya
      if (existing.role === "Admin" && role !== "Admin") {
        const admins = await db.user.count({ where: { role: "Admin" } });
        if (admins <= 1) return err("Minimal harus ada satu Admin di aplikasi ini", 400);
      }

      // Izin: hanya field yang dikirim yang diubah
      const permissions: Record<string, boolean> = {};
      for (const f of PERMISSION_FIELDS) {
        if (body[f] !== undefined) permissions[f] = Boolean(body[f]);
      }

      const updated = await db.user.update({
        where: { id },
        data: { name, username, role, ...permissions },
      });

      await db.auditLog.create({
        data: {
          action: "EDIT_PENGGUNA",
          details: `${updated.username} (${updated.name}, role ${updated.role})`,
          performedBy: manager.name,
        },
      });

      // D71 — sinkronkan profil teknisi dengan akun:
      //  · role Teknisi + belum ada profil → buat otomatis (atau taut profil
      //    yatim bernama sama) supaya akun langsung bisa ditugaskan di tiket;
      //  · nama akun berubah → nama profil ikut (poin kinerja dicocokkan dari
      //    nama tiket ↔ nama akun, jadi harus selalu sinkron);
      //  · role berubah KELUAR dari Teknisi → profil penugasan dihapus
      //    (riwayat tiket tetap utuh: technicianId men-null, snapshot nama ada).
      if (updated.role === "Teknisi") {
        const profile = await db.technician.findUnique({ where: { userId: updated.id } });
        if (!profile) {
          const orphans = await db.technician.findMany({ where: { userId: null } });
          const orphan = orphans.find(
            (t) => t.name.trim().toLowerCase() === updated.name.trim().toLowerCase()
          );
          if (orphan) {
            await db.technician.update({
              where: { id: orphan.id },
              data: { userId: updated.id, name: updated.name },
            });
            await db.auditLog.create({
              data: {
                action: "EDIT_TEKNISI",
                details: `Profil teknisi "${orphan.name}" tertaut ke akun ${updated.username}`,
                performedBy: manager.name,
              },
            });
          } else {
            await db.technician.create({ data: { name: updated.name, userId: updated.id } });
            await db.auditLog.create({
              data: {
                action: "TAMBAH_TEKNISI",
                details: `Profil teknisi "${updated.name}" otomatis dibuat untuk akun ${updated.username}`,
                performedBy: manager.name,
              },
            });
          }
        } else if (profile.name !== updated.name) {
          const lama = profile.name;
          await db.technician.update({ where: { id: profile.id }, data: { name: updated.name } });
          await db.auditLog.create({
            data: {
              action: "EDIT_TEKNISI",
              details: `Nama profil teknisi disinkronkan dengan akun: ${lama} → ${updated.name}`,
              performedBy: manager.name,
            },
          });
        }
      } else if (existing.role === "Teknisi" && updated.role !== "Teknisi") {
        const profile = await db.technician.findUnique({ where: { userId: updated.id } });
        if (profile) {
          await db.technician.delete({ where: { id: profile.id } });
          await db.auditLog.create({
            data: {
              action: "HAPUS_TEKNISI",
              details: `Profil teknisi "${profile.name}" dihapus — akun ${updated.username} tidak lagi role Teknisi (riwayat tiket tetap tersimpan)`,
              performedBy: manager.name,
            },
          });
        }
      }

      // Reset PIN (7.2): PIN baru dikirim → ganti hash + wajib ganti PIN saat login
      const newPin = body.newPin === undefined ? null : String(body.newPin);
      if (newPin !== null) {
        if (!validPinBaru(newPin)) {
          return err("PIN baru wajib 4 angka dan bukan PIN default (1234/1111)", 400);
        }
        const salt = generateSalt();
        await db.user.update({
          where: { id },
          data: { pin: hashPin(newPin, salt), salt, mustChangePin: true },
        });
        await db.auditLog.create({
          data: {
            action: "RESET_PIN",
            details: `PIN ${updated.username} direset — wajib ganti PIN saat login berikutnya`,
            performedBy: manager.name,
          },
        });
      }

      const fresh = await db.user.findUnique({ where: { id } });
      return NextResponse.json(sanitizeUser(fresh!));
    });
  } catch (e) {
    console.error("users PUT error", e);
    return err("Gagal mengubah pengguna", 500);
  }
}

// DELETE /api/users/[id]?requesterUsername=… — hapus pengguna
export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    return await withHeal(async () => {
      const id = Number((await params).id);
      if (!Number.isInteger(id)) return err("ID tidak valid", 400);
      const manager = await resolveManager(req.nextUrl.searchParams.get("requesterUsername"));
      if (!manager) return err("Anda tidak memiliki izin mengelola pengguna", 403);
      // D34 (aturan 4): hak hapus data = hanya Admin/owner — izin permissionUsers saja
      // tidak lagi cukup (dulu Kasir berizin pun bisa menghapus akun).
      if (manager.role !== "Admin") return err("Hanya Admin yang dapat menghapus data", 403);

      const existing = await db.user.findUnique({ where: { id } });
      if (!existing) return err("Pengguna tidak ditemukan", 404);

      // Pelindung 3: tidak boleh menghapus akun sendiri
      if (manager.id === id) {
        return err("Tidak dapat menghapus akun sendiri", 400);
      }
      // Pelindung 2 (lagi): Admin terakhir tidak boleh dihapus
      if (existing.role === "Admin") {
        const admins = await db.user.count({ where: { role: "Admin" } });
        if (admins <= 1) return err("Minimal harus ada satu Admin di aplikasi ini", 400);
      }

      // D71 — profil teknisi tertaut ikut dihapus (penugasan tiket tak lagi
      // menampilkan orang yang akunnya sudah dihapus). Riwayat tiket tetap
      // utuh: technicianId men-null otomatis, snapshot technicianName tersimpan
      // untuk laporan & poin kinerja.
      const linkedProfile = await db.technician.findUnique({ where: { userId: id } });

      await db.user.delete({ where: { id } });
      if (linkedProfile) {
        await db.technician.delete({ where: { id: linkedProfile.id } });
      }
      await db.auditLog.create({
        data: {
          action: "HAPUS_PENGGUNA",
          details: `Menghapus pengguna: ${existing.username} (${existing.name}, role ${existing.role})${linkedProfile ? ` — profil teknisi "${linkedProfile.name}" ikut dihapus` : ""}`,
          performedBy: manager.name,
        },
      });

      return NextResponse.json({ ok: true });
    });
  } catch (e) {
    console.error("users DELETE error", e);
    return err("Gagal menghapus pengguna", 500);
  }
}
