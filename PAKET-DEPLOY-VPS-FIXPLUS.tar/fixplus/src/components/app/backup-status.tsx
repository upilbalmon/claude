"use client";

// ============================================================================
// D80 — INDIKATOR STATUS BACKUP GITHUB DI HEADER + TOMBOL BACKUP CEPAT
// Permintaan pemilik (16 Nov 2026): "untuk mengetahui secara pasti bahwa auto
// backup sudah berjalan, buatlah indikator yang mudah dilihat dari halaman
// manapun. dan ketika backup sukses dilakukan tampilkan notifikasinya. ...
// tombol quick backup yang mudah diakses dari halaman manapun ... misal di
// sebelah akun di pojok kanan atas."
//
// Tiga bagian dalam SATU komponen (state dibagi supaya konsisten):
//   1. CHIP STATUS (klik → Pengaturan): warna ikon menjelaskan kondisi —
//      hijau = backup otomatis AKTIF & sehat; kuning = perlu diperhatikan
//      (auto mati / harian belum jalan >26 jam); merah = konflik sinkronisasi;
//      abu = belum terhubung. Detail lengkap di tooltip (title).
//   2. PEMANTAU BACKUP LATAR BELAKANG: status /api/github/status dipoll tiap
//      45 detik + saat tab kembali terlihat/fokus. Bila lastBackupAt berubah
//      → toast "Backup GitHub berhasil" — jadi backup OTOMATIS server-side
//      (D69/D70) yang sukses pun muncul notifikasinya walau terjadi di latar.
//   3. TOMBOL CLOUD UPLOAD: backup manual SEKARANG (POST /api/github/backup)
//      dengan spinner + toast sukses/gagal, lalu status langsung disegarkan.
//
// HANYA dirender untuk Admin — API status/backup juga menolak non-Admin
// server-side (action-guard), UI bukan satu-satunya penjaga.
// Token GitHub tidak pernah dikirim ke browser (hanya tokenHint 4 akhir).
// ============================================================================
import { useCallback, useEffect, useRef, useState } from "react";
import {
  Cloud,
  CloudAlert,
  CloudCheck,
  CloudOff,
  CloudUpload,
  Loader2,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatDateTime } from "@/lib/format";

type StatusJson = {
  configured: boolean;
  repo: string | null;
  tokenHint: string | null;
  auto: { enabled: boolean; mode: "onchange" | "daily" | "off"; hour: number; keepLast: number };
  autoRestore: boolean;
  conflict: {
    detectedAt: string;
    detail: string;
    manifestDeviceId: string | null;
    localSeq: number;
    manifestSeq: number;
  } | null;
  lastBackupAt: string | null;
  lastBackupFile: string | null;
  dataVersion?: number | null;
  error?: string;
};

const POLL_MS = 45_000;
// "Harian" harusnya jalan tiap jam WIB tertentu (D70); lebih dari 26 jam tanpa
// cadangan berarti ada yang tidak beres (server mati, token kedaluwarsa, dsb).
const STALE_HARIAN_MS = 26 * 60 * 60 * 1000;

function formatBytes(n: number): string {
  if (!Number.isFinite(n) || n <= 0) return "0 B";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(2)} MB`;
}

const MODE_LABEL: Record<StatusJson["auto"]["mode"], string> = {
  onchange: "Per-perubahan (aktif)",
  daily: "Harian",
  off: "MATI — hanya backup manual",
};

export function BackupStatus({
  requesterUsername,
  onOpenSettings,
}: {
  requesterUsername: string;
  onOpenSettings: () => void;
}) {
  const { toast } = useToast();
  const [status, setStatus] = useState<StatusJson | null>(null);
  const [running, setRunning] = useState(false);

  // Baseline cadangan terakhir yang SUDAH dilaporkan (via toast atau tombol
  // sendiri) — perubahan setelah ini dianggap backup baru yang layak diberitahu.
  const reportedBackupRef = useRef<string | null>(null);
  const firstLoadRef = useRef(true);
  // Nama file hasil backup yang notifikasinya SUDAH ditampilkan oleh tombol
  // quick-backup sendiri — agar pemantau tidak menostoast dua kali.
  const ownFileRef = useRef<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch(
        `/api/github/status?requesterUsername=${encodeURIComponent(requesterUsername)}`,
        { cache: "no-store" }
      );
      if (!res.ok) return; // 403 non-Admin / gangguan — biarkan status terakhir
      const s = (await res.json()) as StatusJson;
      if (s && typeof s === "object" && "configured" in s) setStatus(s);

      // Notifikasi sukses backup latar belakang (otomatis D69/D70 maupun
      // manual dari layar Pengaturan): lastBackupAt berubah = backup baru.
      const now = s.lastBackupAt ?? null;
      const prev = reportedBackupRef.current;
      const file = s.lastBackupFile ?? null;
      if (!firstLoadRef.current && now && now !== prev) {
        if (file && file !== ownFileRef.current) {
          toast({
            title: "Backup GitHub berhasil",
            description: `Cadangan "${file}" tersimpan di repo ${s.repo ?? ""}.`,
          });
        }
      }
      if (file !== ownFileRef.current) ownFileRef.current = null;
      reportedBackupRef.current = now;
      firstLoadRef.current = false;
    } catch {
      /* offline / server restart — chip tetap menampilkan data terakhir */
    }
  }, [requesterUsername, toast]);

  useEffect(() => {
    let alive = true;
    const tick = () => {
      if (alive && typeof document !== "undefined" && document.visibilityState === "visible") {
        void refresh();
      }
    };
    void refresh(); // segera saat mount
    const id = setInterval(tick, POLL_MS);
    const onVisible = () => {
      if (document.visibilityState === "visible") void refresh();
    };
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("focus", onVisible);
    return () => {
      alive = false;
      clearInterval(id);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("focus", onVisible);
    };
  }, [refresh]);

  // ===== Backup cepat manual =====
  const quickBackup = useCallback(async () => {
    if (running) return;
    setRunning(true);
    try {
      const res = await fetch("/api/github/backup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requesterUsername }),
      });
      const j = (await res.json().catch(() => ({}))) as {
        ok?: boolean;
        fileName?: string;
        repo?: string;
        size?: number;
        error?: string;
      };
      if (!res.ok || !j.ok) {
        throw new Error(j.error || `HTTP ${res.status}`);
      }
      const nama = j.fileName ?? "(tanpa nama)";
      ownFileRef.current = nama; // pemantau tidak perlu menostoast ulang
      toast({
        title: "Backup ke GitHub berhasil",
        description: `${nama} (${formatBytes(j.size ?? 0)}) terkirim ke ${j.repo ?? "repo"}.`,
      });
      await refresh(); // chip langsung menunjukkan cadangan terbaru
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      toast({
        variant: "destructive",
        title: "Backup ke GitHub GAGAL",
        description: `${msg} — backup otomatis tetap berjalan sesuai jadwal.`,
      });
    } finally {
      setRunning(false);
    }
  }, [requesterUsername, refresh, running, toast]);

  // ===== Turunan tampilan =====
  const auto = status?.auto;
  const autoEnabled = auto?.enabled === true;
  const lastAt = status?.lastBackupAt ?? null;
  // D81 — label "log cadangan terakhir dibuat" di samping indikator: jelas
  // kapan aktivitas backup terakhir terjadi tanpa membuka tooltip/panel.
  const labelCadangan = lastAt
    ? `Cadangan terakhir: ${formatDateTime(lastAt)}`
    : "Belum ada cadangan";
  const harianMundur =
    auto?.mode === "daily" &&
    (!lastAt || Date.now() - new Date(lastAt).getTime() > STALE_HARIAN_MS);

  const konflik = status?.conflict ?? null;
  const configured = status?.configured === true;

  const wajah = !status
    ? {
        icon: Cloud,
        cls: "text-muted-foreground",
        label: "Backup…",
        dot: "bg-muted-foreground",
        title: "Memuat status backup GitHub…",
      }
    : konflik
      ? {
          icon: CloudAlert,
          cls: "text-red-600 dark:text-red-400",
          label: "Konflik",
          dot: "bg-red-600 dark:text-red-400",
          title:
            "KONFLIK SINKRONISASI — backup otomatis DIHENTIKAN agar data perangkat lain tidak tertimpa.\n" +
            `${konflik.detail}\n` +
            "Klik untuk memutuskan di Pengaturan → Backup GitHub.",
        }
      : !configured
        ? {
            icon: CloudOff,
            cls: "text-muted-foreground",
            label: "Belum Terhubung",
            dot: "bg-muted-foreground",
            title:
              "Backup GitHub belum terhubung di perangkat ini.\n" +
              "Klik untuk membuka Pengaturan → Backup GitHub.",
          }
        : harianMundur
          ? {
              icon: CloudAlert,
              cls: "text-amber-600 dark:text-amber-400",
              label: "Periksa Backup",
              dot: "bg-amber-500",
              title:
                "Backup otomatis harian AKTIF tetapi belum ada cadangan baru lebih dari 26 jam.\n" +
                `Terakhir: ${lastAt ? formatDateTime(lastAt) : "belum pernah"}\n` +
                "Periksa koneksi/token di Pengaturan → Backup GitHub (klik).",
            }
          : autoEnabled
            ? {
                icon: CloudCheck,
                cls: "text-emerald-600 dark:text-emerald-400",
                label: "Backup Aktif",
                dot: "bg-emerald-500",
                title:
                  "Backup otomatis AKTIF — data aman tersalin ke GitHub.\n" +
                  `Mode: ${MODE_LABEL[auto?.mode ?? "off"]}\n` +
                  `Repo: ${status.repo ?? "-"}\n` +
                  `Cadangan terakhir: ${lastAt ? formatDateTime(lastAt) : "belum ada"}${status.lastBackupFile ? ` (${status.lastBackupFile})` : ""}\n` +
                  "Klik untuk detail di Pengaturan → Backup GitHub.",
              }
            : {
                icon: Cloud,
                cls: "text-amber-600 dark:text-amber-400",
                label: "Backup Manual",
                dot: "bg-amber-500",
                title:
                  "Backup GitHub terhubung tetapi backup OTOMATIS MATI — data hanya aman bila backup manual dijalankan.\n" +
                  `Cadangan terakhir: ${lastAt ? formatDateTime(lastAt) : "belum ada"}\n` +
                  "Klik untuk menyalakan otomatis di Pengaturan → Backup GitHub.",
              };

  const Icon = wajah.icon;

  return (
    <div className="flex items-center gap-1">
      {/* Chip status — klik menuju Pengaturan */}
      <button
        type="button"
        onClick={onOpenSettings}
        title={wajah.title}
        aria-label={`Status backup GitHub: ${wajah.label}`}
        className={
          "flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold transition-colors hover:bg-muted " +
          wajah.cls
        }
      >
        <Icon className="size-4" aria-hidden />
        <span className={"hidden lg:inline " + wajah.cls}>{wajah.label}</span>
        <span className={"size-1.5 rounded-full " + wajah.dot} aria-hidden />
      </button>

      {/* D81 — log cadangan terakhir dibuat, di samping indikator: notifikasi
          toast hanya sebentar, teks ini SELALU terlihat dari halaman manapun
          (disembunyikan di layar sempit — tetap ada di tooltip chip & panel). */}
      {status && (
        <span
          className="hidden max-w-[220px] truncate text-[11px] leading-tight text-muted-foreground xl:inline"
          title={`${labelCadangan}${status.lastBackupFile ? ` — ${status.lastBackupFile}` : ""}`}
        >
          {labelCadangan}
        </span>
      )}

      {/* Tombol backup cepat */}
      <button
        type="button"
        onClick={quickBackup}
        disabled={running || !configured}
        title={
          configured
            ? "Backup ke GitHub sekarang"
            : "Backup GitHub belum terhubung — atur dulu di Pengaturan"
        }
        aria-label="Backup ke GitHub sekarang"
        className="flex items-center rounded-lg p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground disabled:pointer-events-none disabled:opacity-40"
      >
        {running ? (
          <Loader2 className="size-5 animate-spin" aria-hidden />
        ) : (
          <CloudUpload className="size-5" aria-hidden />
        )}
      </button>
    </div>
  );
}
