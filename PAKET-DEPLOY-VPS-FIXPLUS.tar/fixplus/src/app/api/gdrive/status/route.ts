import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { loadCreds, credsSummary } from "@/lib/gdrive";

// D67 — GET /api/gdrive/status?requesterUsername=...
// Status koneksi Google Drive (OAuth & Service Account) + pengaturan auto-backup.
// Hanya Admin — kredensial & cadangan berisi data sensitif.
export async function GET(req: NextRequest) {
  const actor = await resolveActor(req.nextUrl.searchParams.get("requesterUsername"));
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);
  try {
    const creds = await loadCreds();
    return NextResponse.json(credsSummary(creds));
  } catch (e) {
    console.error("gdrive status error", e);
    return NextResponse.json({ error: "Gagal membaca status Google Drive" }, { status: 500 });
  }
}
