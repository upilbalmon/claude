// D48/5A — util bersama API laporan:
// - resolveReporter: setiap endpoint laporan menerima requesterUsername dan
//   memverifikasinya server-side (jawaban g: angka laba/nilai stok dijaga di
//   SERVER, bukan cuma disembunyikan di UI).
// - parseRange: rentang tanggal kalender WIB inklusif (dipakai sales/services).
// - rentang bulan/tahun WIB untuk rekap bulanan.
import { db } from "@/lib/db";
import { wibDayRange } from "@/lib/format";

export type Reporter = { id: number; name: string; role: string };

export async function resolveReporter(username: unknown): Promise<Reporter | null> {
  const uname = String(username ?? "").trim();
  if (!uname) return null;
  const u = await db.user.findUnique({ where: { username: uname } });
  if (!u) return null;
  return { id: u.id, name: u.name, role: u.role };
}

export function isAdminRole(r: Reporter | null): boolean {
  return r?.role === "Admin";
}

/** "YYYY-MM-DD" valid? */
export function isDay(v: string | null): boolean {
  return !!v && /^\d{4}-\d{2}-\d{2}$/.test(v);
}

/** Rentang [start, end) UTC dari dua hari kalender WIB inklusif (dibalik bila terbalik). */
export function parseRange(fromRaw: string | null, toRaw: string | null, today: string) {
  const from = isDay(fromRaw) ? fromRaw! : today;
  const to = isDay(toRaw) ? toRaw! : today;
  const [a, b] = from <= to ? [from, to] : [to, from];
  return { from: a, to: b, start: wibDayRange(a).start, end: wibDayRange(b).end };
}

/** Rentang [start, end) untuk satu bulan kalender WIB. */
export function wibMonthRange(year: number, month0: number): { start: Date; end: Date } {
  const start = wibDayRange(`${year}-${String(month0 + 1).padStart(2, "0")}-01`).start;
  const ny = month0 === 11 ? year + 1 : year;
  const nm = month0 === 11 ? 0 : month0 + 1;
  const end = wibDayRange(`${ny}-${String(nm + 1).padStart(2, "0")}-01`).start;
  return { start, end };
}

/** Kunci bulan WIB "YYYY-MM" dari sebuah instant. */
export function wibMonthKey(d: Date): string {
  return new Date(d.getTime() + 7 * 60 * 60 * 1000).toISOString().slice(0, 7);
}
