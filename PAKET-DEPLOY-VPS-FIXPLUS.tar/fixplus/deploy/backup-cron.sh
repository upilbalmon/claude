#!/usr/bin/env bash
# Backup harian DB FixPlus (aman dijalankan saat aplikasi berjalan —
# memakai sqlite3 .backup, bukan salinan file mentah) + retensi 7 hari.
#
# Pasang di cron (sudo crontab -e):
#   0 2 * * * /opt/fixplus/deploy/backup-cron.sh >> /var/log/fixplus-backup.log 2>&1
set -euo pipefail

APP_DIR="/opt/fixplus"              # sesuaikan bila path berbeda
DB_PATH="$APP_DIR/db/custom.db"     # sesuaikan bila path berbeda
BACKUP_DIR="/var/backups/fixplus"   # sesuaikan bila path berbeda
RETENSI_HARI=7

mkdir -p "$BACKUP_DIR"
TS="$(date +%Y-%m-%d_%H%M%S)"
OUT="$BACKUP_DIR/custom-$TS.db"

sqlite3 "$DB_PATH" ".backup '$OUT'"

# Uji integritas hasil backup; buang bila korup
if ! sqlite3 "$OUT" "PRAGMA integrity_check;" | grep -q "^ok$"; then
    rm -f "$OUT"
    echo "$(date '+%F %T') BACKUP GAGAL (integrity_check tidak ok): $OUT"
    exit 1
fi

find "$BACKUP_DIR" -name 'custom-*.db' -type f -mtime +"$RETENSI_HARI" -delete
echo "$(date '+%F %T') backup OK: $OUT ($(du -h "$OUT" | cut -f1))"
