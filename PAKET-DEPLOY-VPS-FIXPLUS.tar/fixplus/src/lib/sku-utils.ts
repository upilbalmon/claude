// SKU otomatis (D22) — "jika kosong maka diisi sesuai pola pada data yang sudah ada".
// Pola SKU existing: PREFIX-SINGKATAN (LCD-IP11, BAT-S20, FLEX-RN10, TG-UNIV,
// LCD-IP11-FS, LCD-A14) — jenis part di depan, model/penanda ringkas di belakang.
// Deterministik & bisa ditimpa manual (prinsip aman dari kesalahan D19/D21).

// Kode jenis part — urutan penting (frasa lebih spesifik dulu, mis. "tempered glass")
const TYPE_CODES: Array<[RegExp, string]> = [
  [/tempered\s*glass|antigores|anti\s*gores/i, "TG"],
  [/\blcd\b|touchscreen|touch screen/i, "LCD"],
  [/batterai|battery|baterai/i, "BAT"],
  [/\bflex\b/i, "FLEX"],
  [/kamera|camera/i, "CAM"],
  [/speaker/i, "SPK"],
  [/buzzer/i, "BZ"],
  [/\bmic\b|mikrofon/i, "MIC"],
  [/\bic\b/i, "IC"],
  [/konektor|connector/i, "KON"],
  [/charger/i, "CHG"],
  [/housing|kesing/i, "HS"],
  [/\bframe\b|kerangka/i, "FR"],
  [/\bkaca\b/i, "KCA"],
  [/sim\s*tray|\bsim\b/i, "SIM"],
  [/antena|antenna/i, "ANT"],
];

// Kata umum yang tidak membantu membedakan → dilewati
const GENERIC_SKIP = new Set([
  "screen", "galaxy", "kabel", "cable", "charger", "original", "oem", "unit",
  "hp", "handphone", "baru", "new", "replacement", "sparepart", "part",
  "aksesoris", "ganti", "service", "servis", "samsung",
]);

// Singkatan merek/model yang umum di SKU (persis referensi: iPhone 11 → IP11,
// Redmi Note 10 → RN10; merek dengan nomor model self-identifying dilewati:
// Samsung S20 → S20, Samsung Galaxy A14 → A14)
const WORD_CODES: Record<string, string> = {
  iphone: "IP", ipad: "IPD", redmi: "R", note: "N", oppo: "O", vivo: "V",
  xiaomi: "XM", realme: "RM", infinix: "IX", tecno: "TC", itel: "IT",
  asus: "AS", lenovo: "LV", nokia: "NK", pixel: "GP", honor: "HN",
  huawei: "HW", advan: "AD", itouch: "ITC",
  pro: "P", max: "MX", ultra: "U", lite: "LT", mini: "M", plus: "P",
  pocket: "PK", turbo: "T",
};

export function saranSku(name: string): string {
  const clean = name.trim().replace(/\s+/g, " ");
  if (!clean) return "";

  // 1) Jenis part → prefix (kata kunci pertama yang cocok dihapus dari tail)
  let prefix = "";
  let tail = clean;
  for (const [re, code] of TYPE_CODES) {
    const m = clean.match(re);
    if (m) {
      prefix = code;
      tail = (clean.slice(0, m.index) + " " + clean.slice((m.index ?? 0) + m[0].length)).trim();
      break;
    }
  }
  if (!prefix) {
    const first = clean.split(" ")[0] ?? "";
    prefix = first.replace(/[^A-Za-z0-9]/g, "").toUpperCase().slice(0, 8);
    tail = clean.slice(first.length).trim();
  }

  // 2) Tail → singkatan: kata berangka utuh, kata umum dilewati, merek/model
  //    memakai kode, kata lain memakai 4 huruf depan; "fullset" ditempel di akhir
  //    (persis pola LCD Fullset iPhone 11 → LCD-IP11-FS).
  const parts: string[] = [];
  let trailing = "";
  const adaAngka = /\d/.test(tail);
  for (const raw of tail.split(" ")) {
    const w = raw.replace(/[^A-Za-z0-9]/g, "").toLowerCase();
    if (!w) continue;
    if (/\d/.test(w)) {
      parts.push(w.toUpperCase());
      continue;
    }
    if (GENERIC_SKIP.has(w)) continue;
    if (w === "fullset") {
      trailing = "FS";
      continue;
    }
    if (w === "universal") {
      parts.push("UNIV");
      continue;
    }
    const code = WORD_CODES[w];
    if (code) {
      parts.push(code);
      continue;
    }
    // Kata sisa: cukup 1 huruf bila sudah ada kata berangka/merek (Ic Power
    // MT6582 → IC-PMT6582); kalau satu-satunya penanda → 4 huruf depan (Universal → UNIV)
    parts.push(adaAngka || parts.length > 0 ? w.slice(0, 1).toUpperCase() : w.slice(0, 4).toUpperCase());
  }
  let suffix = parts.join("").slice(0, 10);
  if (trailing) suffix = suffix ? `${suffix}-${trailing}` : trailing;

  return suffix ? `${prefix}-${suffix}` : prefix;
}

// Pastikan unik antar-part (banding aba besar-kecil) — kalau tabrakan tambahkan
// -2, -3, … (LCD-A14, LCD-A14-2, dst). `taken` = daftar SKU existing mentah.
export function skuUnik(base: string, taken: string[]): string {
  const sku = base.trim().toUpperCase();
  if (!sku) return sku;
  const takenLower = taken.map((s) => s.trim().toLowerCase()).filter((s) => s !== "");
  if (!takenLower.includes(sku.toLowerCase())) return sku;
  for (let n = 2; ; n++) {
    const cand = `${sku}-${n}`;
    if (!takenLower.includes(cand.toLowerCase())) return cand;
  }
}
