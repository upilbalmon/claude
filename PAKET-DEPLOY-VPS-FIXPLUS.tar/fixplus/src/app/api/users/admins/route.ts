import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { sanitizeUser } from "@/lib/pin-hash";
import { withHeal } from "@/lib/users-guard";

// D41 — GET /api/users/admins — daftar akun Admin (nama & username saja,
// tanpa PIN/hash) untuk gerbang "Akses Terbatas" halaman Setting:
// perangkat kasir bersama bisa memilih Admin lalu memasukkan PIN-nya
// (persis piloxAdminUsers + selectUserAndAuthorize referensi).
// D55 — withHeal: bila database versi lama, gerbang Setting tetap berfungsi.
export async function GET() {
  try {
    return await withHeal(async () => {
      const admins = await db.user.findMany({
        where: { role: "Admin" },
        orderBy: { name: "asc" },
      });
      return NextResponse.json(
        admins.map((a) => ({ id: a.id, name: a.name, username: a.username }))
      );
    });
  } catch (e) {
    console.error("users admins error", e);
    return NextResponse.json({ error: "Gagal memuat daftar admin" }, { status: 500 });
  }
}
