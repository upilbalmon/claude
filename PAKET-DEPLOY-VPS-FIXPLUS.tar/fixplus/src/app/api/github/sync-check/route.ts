import { NextResponse } from "next/server";
import { triggerAutoSync } from "@/lib/github-backup";

// D74 — POST /api/github/sync-check — pemeriksaan sinkronisasi SAAT APLIKASI
// DIBUKA (parity "pengecekan di splash screen sebelum UI kasir tampil" pada
// rancangan sinkronisasi). Menjalankan tickAutoSync di luar siklus 10 menit:
//   · DB kosong / seq lokal < repo → pulihkan otomatis (bila Admin menyalakan)
//   · seq lokal > repo → unggah backup yang belum terkirim (bila auto-backup aktif)
//   · perangkat berbeda, dua-duanya punya data → catat konflik, tunggu pemilik
// Tidak butuh body & tidak mengembalikan data sensitif — semua aksi internal
// tunduk pada pengaturan Admin dan tidak pernah menimpa data yang lebih baru.
// Dibatasi maksimal sekali per 60 detik agar tab ganda / remount tidak spam.
const gCheck = globalThis as unknown as { __fixplusSyncCheckAt?: number };

export async function POST() {
  const now = Date.now();
  const last = gCheck.__fixplusSyncCheckAt ?? 0;
  gCheck.__fixplusSyncCheckAt = now;
  if (now - last < 60_000) {
    return NextResponse.json({ ok: true, skipped: true });
  }
  try {
    await triggerAutoSync();
  } catch (e) {
    console.error("[github] sync-check gagal:", e);
  }
  return NextResponse.json({ ok: true });
}
