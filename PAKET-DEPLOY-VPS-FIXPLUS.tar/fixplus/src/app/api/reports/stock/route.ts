import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { resolveReporter, isAdminRole } from "@/lib/report-utils";
import { SPARE_CATEGORY_LABEL, spareCategoryOf } from "@/lib/spare-category";

// D48/5A.7 — Nilai Stok & Stok Menipis (Admin saja — jawaban g).
// GET /api/reports/stock?requesterUsername=…
// Nilai stok = harga SATUAN × jumlah stok (rumus T7):
//   nilaiBeli = costPrice × stock, nilaiJual = sellPrice × stock.
// Menipis = stock ≤ minStock (minStock 0 = tanpa peringatan, mengikuti Inventaris).
// Dikelompokkan per kategori (5C-1.1).

export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const reporter = await resolveReporter(sp.get("requesterUsername"));
    // jawaban g: nilai stok = angka modal → Admin saja, dicek DI SERVER
    if (!reporter || !isAdminRole(reporter)) {
      return NextResponse.json(
        { error: "Laporan nilai stok hanya untuk Admin" },
        { status: 403 }
      );
    }

    const parts = await db.sparePart.findMany({ orderBy: { name: "asc" } });

    const rows = parts.map((p) => ({
      id: p.id,
      name: p.name,
      sku: p.sku,
      kategori: spareCategoryOf(p.category),
      kategoriLabel: SPARE_CATEGORY_LABEL[spareCategoryOf(p.category)] ?? p.category,
      stock: p.stock,
      minStock: p.minStock,
      costPrice: p.costPrice,
      sellPrice: p.sellPrice,
      nilaiBeli: p.costPrice * p.stock,
      nilaiJual: p.sellPrice * p.stock,
      menipis: p.minStock > 0 && p.stock <= p.minStock,
    }));

    const perKategori = new Map<string, { kategori: string; kategoriLabel: string; nilaiBeli: number; nilaiJual: number; item: number; unit: number }>();
    for (const r of rows) {
      const k = perKategori.get(r.kategori) ?? {
        kategori: r.kategori,
        kategoriLabel: r.kategoriLabel,
        nilaiBeli: 0, nilaiJual: 0, item: 0, unit: 0,
      };
      k.nilaiBeli += r.nilaiBeli;
      k.nilaiJual += r.nilaiJual;
      k.item += 1;
      k.unit += r.stock;
      perKategori.set(r.kategori, k);
    }

    return NextResponse.json({
      rows,
      perKategori: [...perKategori.values()].sort((a, b) => b.nilaiJual - a.nilaiJual),
      menipis: rows.filter((r) => r.menipis).sort((a, b) => a.stock - b.stock),
      totalNilaiBeli: rows.reduce((s, r) => s + r.nilaiBeli, 0),
      totalNilaiJual: rows.reduce((s, r) => s + r.nilaiJual, 0),
      count: rows.length,
    });
  } catch (e) {
    console.error("reports stock GET error", e);
    return NextResponse.json({ error: "Gagal memuat laporan stok" }, { status: 500 });
  }
}
