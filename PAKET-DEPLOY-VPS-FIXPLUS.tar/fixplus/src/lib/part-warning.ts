// D48/(b) — jawaban user "Peringatan cukup": stok TIDAK direservasi saat tiket
// dibuat (potong stok tetap terjadi saat checkout), tetapi API memberi PERINGATAN
// bila part yang dijanjikan melebihi ketersediaan efektif:
//   tersedia efektif = stok sekarang − janji di tiket lain yang masih terbuka.
// Tiket terbuka = status ANTRI/DIAGNOSA/KONFIRMASI/DISETUJUI/DIKERJAKAN
// (SELESAI/DIAMBIL sudah checkout → stok sudah benar-benar dipotong;
//  DIBATALKAN/TIDAK_BISA tidak akan checkout).
import { db } from "@/lib/db";

export const OPEN_REPAIR_STATUSES = ["ANTRI", "DIAGNOSA", "KONFIRMASI", "DISETUJUI", "DIKERJAKAN"];

type UsedPartStored = { partId?: number; qty?: number; isExternal?: boolean };

export async function promisedQtyByPart(excludeRepairId?: number): Promise<Map<number, number>> {
  const open = await db.repairRecord.findMany({
    where: { status: { in: OPEN_REPAIR_STATUSES } },
    select: { id: true, usedPartsJson: true },
  });
  const promised = new Map<number, number>();
  for (const r of open) {
    if (excludeRepairId && r.id === excludeRepairId) continue;
    try {
      const arr = JSON.parse(r.usedPartsJson) as UsedPartStored[];
      if (!Array.isArray(arr)) continue;
      for (const p of arr) {
        const pid = Number(p?.partId);
        if (!Number.isInteger(pid) || pid <= 0) continue; // part toko lain (external) tanpa stok
        if (p?.isExternal) continue;
        promised.set(pid, (promised.get(pid) ?? 0) + Math.max(1, Math.trunc(Number(p?.qty) || 1)));
      }
    } catch {
      // usedPartsJson rusak → lewati tiket ini
    }
  }
  return promised;
}

/** Kembalikan daftar pesan peringatan (kosong = aman) untuk part yang dijanjikan ke sebuah tiket. */
export async function partShortageWarnings(
  parts: { partId: number; qty: number }[],
  excludeRepairId?: number
): Promise<string[]> {
  if (parts.length === 0) return [];
  const promised = await promisedQtyByPart(excludeRepairId);
  const warnings: string[] = [];
  for (const p of parts) {
    const part = await db.sparePart.findUnique({ where: { id: p.partId } });
    if (!part) continue;
    const terjanji = promised.get(p.partId) ?? 0;
    const efektif = part.stock - terjanji;
    if (p.qty > efektif) {
      warnings.push(
        `Stok "${part.name}" mungkin tidak cukup: tersedia ${efektif} unit ` +
          `(stok ${part.stock}${terjanji > 0 ? `, terjanji ${terjanji} di tiket lain` : ""}), ` +
          `diminta ${p.qty}. Stok baru dipotong saat checkout.`
      );
    }
  }
  return warnings;
}
