import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { db } from "@/lib/db";
import { loadCreds, saveCreds, type GithubAuto, type GithubAutoMode } from "@/lib/github-backup";

// D68/D69/D70/D74 — POST /api/github/auto — pengaturan auto-backup + auto-pulihkan
// GitHub. Body JSON: { requesterUsername, auto?: { mode, hour?, keepLast? },
// autoRestore?: boolean }
//   mode "off"      → auto-backup mati
//   mode "daily"    → jadwal harian jam `hour` WIB
//   mode "onchange" → backup otomatis ±2 menit setelah perubahan data terakhir
//   autoRestore     → bila true: saat server menyala / aplikasi dibuka,
//                     database kosong ATAU lebih tua dari cadangan terbaru
//                     (nomor urut seq) otomatis dipulihkan — data kembali
//                     sendiri tanpa klik apa pun. Backup yang belum terkirim
//                     (lokal lebih baru) diunggah dulu, bukan di-restore.
// Kompatibilitas klien lama (D68): bila `mode` tidak dikirim, diturunkan dari
// `enabled` (aktif = harian, mati = off).
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as {
    requesterUsername?: unknown;
    auto?: Partial<GithubAuto>;
    autoRestore?: unknown;
  };
  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const a = body.auto ?? {};
  const cur = await loadCreds();
  const current = cur.auto;

  // D70 — bila klien hanya mengirim autoRestore (tanpa objek auto), pengaturan
  // auto-backup yang sudah ada TIDAK disentuh — cukup ubah auto-pulihkan saja.
  if (body.auto !== undefined) {
    const mode: GithubAutoMode =
      a.mode === "onchange" || a.mode === "daily" || a.mode === "off"
        ? a.mode
        : a.enabled === true
          ? "daily"
          : "off";
    const hour = Math.trunc(Number(a.hour ?? current?.hour ?? 21));
    if (!Number.isInteger(hour) || hour < 0 || hour > 23) {
      return errAction("Jam backup harus 0-23 (waktu Jakarta)", 400);
    }
    const keepLast = Math.trunc(Number(a.keepLast ?? current?.keepLast ?? 7));
    if (!Number.isInteger(keepLast) || keepLast < 1 || keepLast > 90) {
      return errAction("Jumlah cadangan disimpan harus 1-90", 400);
    }
    const auto: GithubAuto = { enabled: mode !== "off", mode, hour, keepLast };
    await saveCreds({ auto });

    const detilAuto =
      mode === "daily"
        ? `harian jam ${String(hour).padStart(2, "0")}:00 WIB`
        : mode === "onchange"
          ? "per-perubahan data (jeda ±2 menit setelah perubahan terakhir, maks tunggu 30 menit)"
          : "DIMATIKAN";
    await db.auditLog.create({
      data: {
        action: "GITHUB_AUTO_SETTINGS",
        details: `Auto-backup GitHub ${mode === "off" ? detilAuto : detilAuto + " DIAKTIFKAN"} — simpan ${keepLast} cadangan terakhir`,
        performedBy: actor.name,
      },
    });
  }

  // D70 — auto-pulihkan hanya diubah bila dikirim (boolean), jangan menimpa
  // pengaturan yang sudah ada saat klien lama hanya menyimpan mode backup.
  if (typeof body.autoRestore === "boolean") {
    const nowOn = (await loadCreds()).autoRestore === true;
    if (body.autoRestore !== nowOn) {
      await saveCreds({ autoRestore: body.autoRestore });
      await db.auditLog.create({
        data: {
          action: "GITHUB_AUTO_SETTINGS",
          details: `Auto-pulihkan & sinkron awal ${body.autoRestore ? "DIAKTIFKAN — database kosong/lebih tua (seq) otomatis dipulihkan dari cadangan terbaru; backup belum terkirim diunggah dulu" : "DIMATIKAN"}`,
          performedBy: actor.name,
        },
      });
    }
  }
  const saved = await loadCreds();
  return NextResponse.json({
    ok: true,
    auto:
      saved.auto ??
      current ?? { enabled: false, mode: "off" as GithubAutoMode, hour: 21, keepLast: 7 },
    autoRestore: saved.autoRestore === true,
  });
}
