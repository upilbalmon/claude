// FixPlus — buat akun admin awal untuk DATABASE BARU (bukan DB bawaan paket).
// Versi Node dari seed platform (.zscripts/seed-users.mjs, D45).
// Pemakaian: node --env-file=.env deploy/seed-admin.mjs
//   → username: admin, PIN: 1234 (segera ganti setelah login pertama).
// ShopSettings tidak dibuat di sini — aplikasi otomatis membuat baris default
// (id=1) saat pertama dibaca (parity GET /api/settings).
import { PrismaClient } from "@prisma/client";
import { createHash, randomUUID } from "crypto";

const prisma = new PrismaClient();
const salt = randomUUID().replace(/-/g, "").slice(0, 8);
const pin = createHash("sha256").update("1234" + salt, "utf8").digest("hex");

try {
  const user = await prisma.user.upsert({
    where: { username: "admin" },
    update: {},
    create: {
      name: "Administrator",
      username: "admin",
      role: "Admin",
      pin,
      salt,
      mustChangePin: false,
      permissionDashboard: true,
      permissionCashier: true,
      permissionServices: true,
      permissionInventory: true,
      permissionCustomers: true,
      permissionUsers: true,
      permissionSettings: true,
    },
  });
  console.log("Akun admin siap:", user.username, "(PIN awal: 1234)");
} finally {
  await prisma.$disconnect();
}
