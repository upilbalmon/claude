"use client";

// CashierSection.kt + CheckoutUseCase.kt + Daos.executeCheckoutTransaction → versi web (Tahap 3)
// Dua tampilan: Riwayat Transaksi (filter, cari, grup tanggal, detail, edit admin, void)
// dan Transaksi Baru (katalog POS + produk jasa → keranjang → diskon → bayar → struk 58mm).
// Logika uang & stok selalu divalidasi ulang server (CheckoutUseCase): harga retail dari DB
// terkini, "Kurang bayar Rp X", potong stok atomik, poin loyalitas floor(total/10000).
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Ban,
  ChevronLeft,
  ClipboardList,
  Download,
  Inbox,
  Minus,
  Pencil,
  Plus,
  Printer,
  Receipt,
  Repeat,
  Search,
  Share2,
  ShoppingCart,
  Trash2,
  Undo2,
  User,
  Wrench,
  X,
} from "lucide-react";
import { toJpeg } from "html-to-image";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Table, TableBody, TableHeader } from "@/components/ui/table";
import {
  FinCountChip,
  FinFootTd,
  FinIndexTd,
  FinRow,
  FinSortTh,
  FinTd,
  FinTh,
  FinTfoot,
} from "@/components/app/fin-table";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { PinInput } from "@/components/app/pin-input";
import { dayKeyWIB, formatCurrency, formatDateTime, voidWindowOpen } from "@/lib/format";
import { cetakNode } from "@/lib/print-helper";
import { parseUsedParts, serviceIdOf, usedPartsTotal } from "@/lib/repair-utils";
import type { Repair } from "@/components/app/sections/servis-receipt";
import type { SafeUser } from "@/lib/app-types";

type SparePart = {
  id: number; name: string; alias?: string | null; sku: string; stock: number; minStock: number;
  costPrice: number; sellPrice: number; location: string;
};
type ServiceProduct = { id: number; name: string; basePrice: number; points: number };
type CustomerLite = { id: number; name: string; phone: string; loyaltyPoints: number };
// D23 (D18/D19): alias = "Nama di Struk" (snapshot saat checkout) — struk mencetak alias ?? nama
type ReceiptItem = { name: string; alias?: string | null; qty: number; price: number; costPrice?: number; itemType?: string; partId?: number };
type Transaction = {
  id: number; invoiceNumber: string; customerId: number | null; customerName: string;
  subtotal: number; discount: number; grandTotal: number; paymentMethod: string;
  paidAmount: number; changeAmount: number; itemsJson: string; timestamp: string;
  paymentStatus: string; isVoided: boolean; voidedBy: string | null;
  voidedAt: string | null; voidReason: string | null; createdBy: string;
  // D38 — dokumen refund & referensi pengganti
  docType?: string; refundOfId?: number | null; referenceNumber?: string;
};
type ShopSettingsLite = { shopName: string; address: string; phone: string; receiptFooter: string; editTransactionDate?: boolean };

// D37 — laporan void & refund harian per kasir (aturan 8: pantau fraud)
type VoidReportRow = { name: string; count: number; total: number };
type VoidReportDetail = {
  id: number; invoiceNumber: string; customerName: string; grandTotal: number;
  createdBy: string; voidedBy: string | null; voidedAt: string | null; voidReason: string | null;
  docType: string; referenceNumber: string; refundOfId: number | null; timestamp: string;
};
type VoidReport = {
  from: string; to: string;
  voids: { rows: VoidReportRow[]; details: VoidReportDetail[] };
  refunds: { rows: VoidReportRow[]; details: VoidReportDetail[] };
};

type CartItem = {
  key: string;
  itemType: "retail" | "service";
  partId?: number;
  serviceId?: number;
  name: string;
  price: number;
  qty: number;
  maxQty?: number; // retail: stok tersedia
};

type POSSortKey = "NAMA" | "HARGA" | "STOK";
// D48/5C-1.2: QRIS masuk daftar metode bayar (jawaban d — disetujui user)
const PAYMENT_METHODS = ["Tunai", "Transfer", "QRIS", "E-Wallet", "Kartu"] as const;

async function apiJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string }).error ?? "Terjadi kesalahan");
  return data as T;
}

function parseReceiptItems(jsonStr: string): ReceiptItem[] {
  try {
    const arr = JSON.parse(jsonStr) as ReceiptItem[];
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

// Konversi data URL (base64) → File agar bisa dibagikan via navigator.share
function dataUrlToFile(dataUrl: string, filename: string): File | null {
  try {
    const [meta, b64] = dataUrl.split(",");
    const mime = meta?.match(/:(.*?);/)?.[1] ?? "image/jpeg";
    const bin = atob(b64 ?? "");
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new File([bytes], filename, { type: mime });
  } catch {
    return null;
  }
}

// label status persis referensi (detail: "Lunas"/"Piutang / Bon"/"DP Sebagian"; kartu: versi pendek)
function statusLabel(status: string): string {
  if (status === "BON_PIUTANG") return "Piutang / Bon";
  if (status === "DP_SEBAGIAN") return "DP Sebagian";
  return "Lunas";
}
function statusLabelShort(status: string): string {
  if (status === "BON_PIUTANG") return "PIUTANG";
  if (status === "DP_SEBAGIAN") return "DP";
  return "LUNAS";
}
// D15: istilah di struk (menghadap pelanggan) — standar nota Indonesia:
// LUNAS ↔ BELUM LUNAS (bukan "hutang"; piutang = istilah pembukuan internal)
function statusLabelStruk(status: string): string {
  if (status === "BON_PIUTANG") return "BELUM LUNAS";
  if (status === "DP_SEBAGIAN") return "DP";
  return "LUNAS";
}

function digitsOnly(v: string): string {
  // D46: buang nol di depan (bila diikuti digit) supaya mengetik pada kolom
  // yang berangkat dari "0" tidak menghasilkan "05000" — ketikan "5000"
  // tampil apa adanya "5000". Kolom "0" saja tetap "0", kosong tetap kosong.
  return v.replace(/\D/g, "").replace(/^0+(?=\d)/, "");
}

// Sparepart dari toko lain (ExternalPart MainLayout.kt) — diinput saat checkout tiket
type ExternalPart = { name: string; costPrice: number; sellPrice: number; qty: number };

export function CashierSection({
  user,
  pendingRepair,
  onClearPendingRepair,
  onOpenServiceForm,
}: {
  user: SafeUser;
  // Tahap 4.6: tiket servis Selesai yang dibayar lewat POS (ala pendingRepair referensi)
  pendingRepair?: Repair | null;
  onClearPendingRepair?: () => void;
  // D72: opsi "Terima Servis" pada menu Tambah Transaksi → AppShell pindah ke
  // tab Servis + form tiket langsung terbuka (ala FAB referensi CashierSection)
  onOpenServiceForm?: () => void;
}) {
  const { toast } = useToast();
  const isAdmin = user.role === "Admin";

  // ===== Data =====
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [parts, setParts] = useState<SparePart[]>([]);
  const [services, setServices] = useState<ServiceProduct[]>([]);
  const [customers, setCustomers] = useState<CustomerLite[]>([]);
  const [settings, setSettings] = useState<ShopSettingsLite>({
    shopName: "Servis HP & POS", address: "", phone: "", receiptFooter: "Terima kasih telah berbelanja!",
  });
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const [t, p, s, c] = await Promise.all([
        apiJson<Transaction[]>("/api/transactions"),
        apiJson<SparePart[]>("/api/spare-parts"),
        apiJson<ServiceProduct[]>("/api/service-products"),
        apiJson<CustomerLite[]>("/api/customers"),
      ]);
      setTransactions(t);
      setParts(p);
      setServices(s);
      setCustomers(c);
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Gagal memuat data", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    apiJson<ShopSettingsLite>("/api/settings").then(setSettings).catch(() => {});
    void load();
  }, [load]);

  // ===== Navigasi dua tampilan =====
  const [view, setView] = useState<"RIWAYAT" | "BARU">("RIWAYAT");

  // ===== Keranjang & pembayaran (ala CashierSection baris 108–157) =====
  const [cart, setCart] = useState<CartItem[]>([]);
  const [checkoutCustomerId, setCheckoutCustomerId] = useState<number | null>(null);
  const [checkoutCustomerName, setCheckoutCustomerName] = useState("Umum");
  const [discountInput, setDiscountInput] = useState("0");
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>("Tunai");
  const [selectedPaymentStatus, setSelectedPaymentStatus] = useState<"LUNAS" | "DP_SEBAGIAN" | "BON_PIUTANG">("LUNAS");
  const [amountPaidInput, setAmountPaidInput] = useState("");
  const [otherFeeInput, setOtherFeeInput] = useState("");

  // ===== Tiket servis (Tahap 4.6): tagihan servis di atas katalog =====
  const [externalParts, setExternalParts] = useState<ExternalPart[]>([]);
  const [serviceFeeInput, setServiceFeeInput] = useState("");
  const [selectedWarrantyDays, setSelectedWarrantyDays] = useState(0);
  const [showRepairBillDetail, setShowRepairBillDetail] = useState(false);
  const [extName, setExtName] = useState("");
  const [extCost, setExtCost] = useState("");
  const [extSell, setExtSell] = useState("");
  const [extQty, setExtQty] = useState("1");

  // Saat tiket dibawa dari Servis → isi pelanggan, jasa & garansi awal (ala LaunchedEffect pendingRepair)
  useEffect(() => {
    if (pendingRepair) {
      setCheckoutCustomerId(pendingRepair.customerId);
      setCheckoutCustomerName(pendingRepair.customerName);
      setServiceFeeInput(String(Math.trunc(pendingRepair.serviceFee)));
      setSelectedWarrantyDays(pendingRepair.warrantyDays);
      setExternalParts([]);
      setShowRepairBillDetail(false);
      setView("BARU");
    }
  }, [pendingRepair]);

  // ===== Katalog POS: cari + urut (ala filteredPOSParts) =====
  const [pSearchQuery, setPSearchQuery] = useState("");
  const [pSortKey, setPSortKey] = useState<POSSortKey>("NAMA");
  const [pSortAscending, setPSortAscending] = useState(true);
  const [sSortKey, setSSortKey] = useState<"NAMA" | "HARGA">("NAMA");
  const [sSortAscending, setSSortAscending] = useState(true);

  const filteredPOSParts = useMemo(() => {
    const q = pSearchQuery.trim().toLowerCase();
    const list = parts.filter(
      (p) => p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q)
    );
    const sorted = [...list].sort((a, b) => {
      if (pSortKey === "NAMA") return a.name.toLowerCase().localeCompare(b.name.toLowerCase());
      if (pSortKey === "HARGA") return a.sellPrice - b.sellPrice;
      return a.stock - b.stock;
    });
    return pSortAscending ? sorted : sorted.reverse();
  }, [parts, pSearchQuery, pSortKey, pSortAscending]);

  const filteredPOSServices = useMemo(() => {
    const q = pSearchQuery.trim().toLowerCase();
    const list = services.filter((s) => s.name.toLowerCase().includes(q));
    const sorted = [...list].sort((a, b) => {
      if (sSortKey === "HARGA") return a.basePrice - b.basePrice;
      return a.name.toLowerCase().localeCompare(b.name.toLowerCase());
    });
    return sSortAscending ? sorted : sorted.reverse();
  }, [services, pSearchQuery, sSortKey, sSortAscending]);

  function sortServiceBy(k: "NAMA" | "HARGA") {
    if (k === sSortKey) setSSortAscending((v) => !v);
    else {
      setSSortKey(k);
      setSSortAscending(true);
    }
  }

  function sortBy(k: POSSortKey) {
    if (k === pSortKey) setPSortAscending((v) => !v);
    else {
      setPSortKey(k);
      setPSortAscending(true);
    }
  }

  // ===== Kalkulasi (persis baris 321–337 + tiket servis Tahap 4) =====
  const partsSubtotal = cart.reduce((sum, it) => sum + it.price * it.qty, 0);
  const otherFee = Number(otherFeeInput) || 0;
  const repairFee = pendingRepair ? Number(serviceFeeInput) || 0 : 0;
  const repairInternalPartsTotal = pendingRepair
    ? usedPartsTotal(parseUsedParts(pendingRepair.usedPartsJson))
    : 0;
  const externalPartsTotal = externalParts.reduce((s, p) => s + p.sellPrice * p.qty, 0);
  const repairBillTotal = repairFee + repairInternalPartsTotal + externalPartsTotal;
  const repairDownPayment = pendingRepair ? (pendingRepair.downPayment ?? 0) : 0;
  const totalSubtotal = partsSubtotal + otherFee + repairBillTotal;
  const discount = Number(discountInput) || 0;
  const grandTotal = Math.max(0, totalSubtotal - discount - repairDownPayment);
  // T8: BON/Piutang dengan kolom bayar kosong = pelanggan belum membayar apa pun → 0
  // (dulu ikut default "uang pas" sehingga field Dibayar menyesatkan untuk rekap piutang)
  const amountPaid =
    amountPaidInput === ""
      ? selectedPaymentStatus === "BON_PIUTANG"
        ? 0
        : grandTotal
      : Number(amountPaidInput) || 0;
  const changeAmount = Math.max(0, amountPaid - grandTotal);
  const totalCartItems = cart.reduce((sum, it) => sum + it.qty, 0);

  // ===== Aksi keranjang =====
  function addPart(part: SparePart) {
    const cartQty = cart.find((it) => it.partId === part.id)?.qty ?? 0;
    const remaining = part.stock - cartQty;
    if (remaining <= 0) return; // habis / melebihi stok — kartu sudah nonaktif
    setCart((prev) => {
      const idx = prev.findIndex((it) => it.partId === part.id);
      if (idx !== -1) {
        const next = [...prev];
        next[idx] = { ...next[idx], qty: next[idx].qty + 1 };
        return next;
      }
      return [
        ...prev,
        {
          key: `retail-${part.id}`, itemType: "retail", partId: part.id,
          name: part.name, price: part.sellPrice, qty: 1, maxQty: part.stock,
        },
      ];
    });
  }

  function addService(svc: ServiceProduct) {
    setCart((prev) => {
      const idx = prev.findIndex((it) => it.serviceId === svc.id);
      if (idx !== -1) {
        const next = [...prev];
        next[idx] = { ...next[idx], qty: next[idx].qty + 1 };
        return next;
      }
      return [
        ...prev,
        {
          key: `service-${svc.id}`, itemType: "service", serviceId: svc.id,
          name: svc.name, price: svc.basePrice, qty: 1,
        },
      ];
    });
  }

  function changeQty(key: string, delta: number) {
    setCart((prev) =>
      prev
        .map((it) => {
          if (it.key !== key) return it;
          const max = it.maxQty ?? Infinity;
          return { ...it, qty: Math.min(max, Math.max(0, it.qty + delta)) };
        })
        .filter((it) => it.qty > 0)
    );
  }

  function resetTransactionForm() {
    setCart([]);
    setDiscountInput("0");
    setAmountPaidInput("");
    setOtherFeeInput("");
    setSelectedPaymentStatus("LUNAS");
    setSelectedPaymentMethod("Tunai");
    setCheckoutCustomerId(null);
    setCheckoutCustomerName("Umum");
    // Tahap 4: bersihkan tagihan tiket servis
    setExternalParts([]);
    setServiceFeeInput("");
    setSelectedWarrantyDays(0);
    setShowRepairBillDetail(false);
    setExtName("");
    setExtCost("");
    setExtSell("");
    setExtQty("1");
    onClearPendingRepair?.();
  }

  // ===== Checkout (ala tombol BAYAR baris 1270–1285 + dialog konfirmasi baris 1952–2223) =====
  const [cartDialogOpen, setCartDialogOpen] = useState(false);
  const [showPaymentDetail, setShowPaymentDetail] = useState(false);
  const [showConfirmCheckout, setShowConfirmCheckout] = useState(false);
  // D39: bila "Edit Tanggal Transaksi" aktif di Pengaturan → Tampilan, kasir boleh
  // mengubah tanggal & waktu transaksi saat konfirmasi pembayaran (datetime-local).
  const [checkoutDate, setCheckoutDate] = useState("");
  const [processing, setProcessing] = useState(false);
  const [receiptTransaction, setReceiptTransaction] = useState<Transaction | null>(null);
  const [sharingJpg, setSharingJpg] = useState(false);
  // D14: tombol Bagikan hanya tampil bila browser mendukung share FILE (umumnya HP);
  // deteksi sekali saat mount agar tidak terjadi hydration mismatch.
  const [canShareFiles, setCanShareFiles] = useState(false);
  useEffect(() => {
    try {
      const probe = new File([new Blob([""])], "probe.jpg", { type: "image/jpeg" });
      setCanShareFiles(typeof navigator.share === "function" && !!navigator.canShare?.({ files: [probe] }));
    } catch {
      setCanShareFiles(false);
    }
  }, []);

  function handleBayarClick() {
    // persis guard referensi — tiket servis boleh dibayar tanpa item retail
    if (!pendingRepair && cart.length === 0 && otherFee <= 0) return;
    // D25: tiket void (TIDAK_BISA) boleh diproses Rp 0 — transaksi berfungsi
    // sebagai bukti pengambilan unit (tanpa tagihan). Tiket SELESAI tetap wajib > 0.
    if (pendingRepair && repairBillTotal <= 0 && pendingRepair.status !== "TIDAK_BISA") {
      toast({ title: "Total biaya servis masih Rp 0 — isi biaya jasa terlebih dahulu", variant: "destructive" });
      return;
    }
    const kurang = grandTotal - amountPaid;
    if (selectedPaymentStatus === "LUNAS" && kurang > 0) {
      toast({ title: `Kurang bayar Rp ${Math.trunc(kurang).toLocaleString("id-ID")}`, variant: "destructive" });
      return;
    }
    if (selectedPaymentStatus === "DP_SEBAGIAN" && (amountPaid <= 0 || amountPaid >= grandTotal)) {
      toast({
        title: "DP Sebagian: jumlah bayar wajib di antara 0 dan total tagihan",
        variant: "destructive",
      });
      return;
    }
    setShowConfirmCheckout(true);
    // D39: default = waktu saat ini; dapat diubah bila setting mengizinkan
    setCheckoutDate(
      settings.editTransactionDate
        ? new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16)
        : ""
    );
  }

  async function processCheckout() {
    setProcessing(true);
    try {
      // Tiket servis (Tahap 4): item persis referensi — Jasa Servis (Model),
      // Sparepart: X (dari usedPartsJson, dihitung server dari DB),
      // Sparepart Toko Lain: X (external), Biaya Lainnya, item retail keranjang.
      const items = pendingRepair
        ? [
            {
              itemType: "service",
              name: `Jasa Servis (${pendingRepair.deviceModel})`,
              price: repairFee,
              qty: 1,
            },
            ...externalParts.map((p) => ({
              itemType: "external_sparepart",
              name: `Sparepart Toko Lain: ${p.name}`,
              price: p.sellPrice,
              costPrice: p.costPrice,
              qty: p.qty,
            })),
            ...cart.map((it) =>
              it.itemType === "retail"
                ? { itemType: "retail", partId: it.partId, qty: it.qty }
                : { itemType: "service", name: it.name, price: it.price, qty: it.qty }
            ),
            ...(otherFee > 0 ? [{ itemType: "other", name: "Biaya Lainnya", price: otherFee, qty: 1 }] : []),
          ]
        : [
            ...cart.map((it) =>
              it.itemType === "retail"
                ? { itemType: "retail", partId: it.partId, qty: it.qty }
                : { itemType: "service", name: it.name, price: it.price, qty: it.qty }
            ),
            ...(otherFee > 0 ? [{ itemType: "other", name: "Biaya Lainnya", price: otherFee, qty: 1 }] : []),
          ];
      // usedPartsJson final = part tiket + part toko lain (isExternal, partId 0) — persis referensi
      const finalUsedPartsJson = pendingRepair
        ? JSON.stringify([
            ...parseUsedParts(pendingRepair.usedPartsJson),
            ...externalParts.map((p) => ({
              partId: 0,
              name: `${p.name} (Toko Lain)`,
              qty: p.qty,
              sellPrice: p.sellPrice,
              costPrice: p.costPrice,
              isExternal: true,
            })),
          ])
        : undefined;
      const saved = await apiJson<Transaction>("/api/transactions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerId: pendingRepair ? pendingRepair.customerId : checkoutCustomerId,
          customerName: pendingRepair ? pendingRepair.customerName : checkoutCustomerName,
          discount,
          paymentMethod: selectedPaymentMethod,
          paidAmount: amountPaid,
          paymentStatus: selectedPaymentStatus,
          items,
          createdBy: user.name,
          // D38 (aturan 3): no. referensi transaksi pengganti setelah void
          ...(replacementRef ? { referenceNumber: replacementRef } : {}),
          // D39: tanggal/waktu kustom — hanya saat setting aktif (server validasi ulang)
          ...(settings.editTransactionDate && checkoutDate
            ? { timestamp: new Date(checkoutDate).toISOString() }
            : {}),
          // Tahap 4: checkout tiket → status DIAMBIL + garansi + penyesuaian biaya
          ...(pendingRepair
            ? {
                repairRecordId: pendingRepair.id,
                adjustedServiceFee: repairFee,
                adjustedTotalPrice: repairBillTotal,
                usedPartsJson: finalUsedPartsJson,
                warrantyDays: selectedWarrantyDays,
              }
            : {}),
        }),
      });
      setShowConfirmCheckout(false);
      resetTransactionForm();
      setReplacementRef(""); // referensi pengganti selesai dipakai (D38)
      // D72 (permintaan user): selesai bayar → kembali ke tampilan awal kasir
      // (Riwayat Transaksi). Struk tetap muncul di atasnya; begitu ditutup,
      // kasir sudah siap menerima pelanggan berikutnya.
      setView("RIWAYAT");
      toast({ title: "Pembayaran berhasil diproses" });
      setReceiptTransaction(saved);
      await load();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Terjadi kesalahan pembayaran", variant: "destructive" });
    } finally {
      setProcessing(false);
    }
  }

  // ===== Riwayat: filter + cari (ala appliedCheckboxes & appliedSearchQuery) =====
  const [showFilterDialog, setShowFilterDialog] = useState(false);
  const [appliedCheckboxes, setAppliedCheckboxes] = useState<Set<string>>(new Set());
  const [appliedCreatedBy, setAppliedCreatedBy] = useState("Semua");
  const [appliedSearchQuery, setAppliedSearchQuery] = useState("");
  const [tempCheckboxes, setTempCheckboxes] = useState<Set<string>>(new Set());
  const [tempCreatedBy, setTempCreatedBy] = useState("Semua");
  const [tempSearchQuery, setTempSearchQuery] = useState("");

  const FILTER_OPTIONS = ["Lunas", "Belum Lunas", "Tunai", "Non Tunai", "Ada Diskon", "Dibatalkan"];
  const creatorOptions = useMemo(
    () => Array.from(new Set(transactions.map((t) => t.createdBy))).sort(),
    [transactions]
  );

  const filteredTransactions = useMemo(() => {
    const q = appliedSearchQuery.trim().toLowerCase();
    return transactions.filter((t) => {
      const lunas = appliedCheckboxes.has("Lunas");
      const belum = appliedCheckboxes.has("Belum Lunas");
      if (lunas || belum) {
        if (!(lunas && t.paymentStatus === "LUNAS") && !(belum && t.paymentStatus !== "LUNAS")) return false;
      }
      const tunai = appliedCheckboxes.has("Tunai");
      const nonTunai = appliedCheckboxes.has("Non Tunai");
      if (tunai || nonTunai) {
        if (!(tunai && t.paymentMethod === "Tunai") && !(nonTunai && t.paymentMethod !== "Tunai")) return false;
      }
      if (appliedCheckboxes.has("Ada Diskon") && !(t.discount > 0)) return false;
      if (appliedCheckboxes.has("Dibatalkan") && !t.isVoided) return false;
      if (appliedCreatedBy !== "Semua" && t.createdBy !== appliedCreatedBy) return false;
      if (q) {
        const items = parseReceiptItems(t.itemsJson);
        const match =
          t.customerName.toLowerCase().includes(q) ||
          t.invoiceNumber.toLowerCase().includes(q) ||
          items.some((it) => it.name.toLowerCase().includes(q));
        if (!match) return false;
      }
      return true;
    });
  }, [transactions, appliedCheckboxes, appliedCreatedBy, appliedSearchQuery]);

  const groupedTransactions = useMemo(() => {
    const fmt = new Intl.DateTimeFormat("id-ID", {
      weekday: "long", day: "numeric", month: "long", year: "numeric",
    });
    const groups = new Map<string, Transaction[]>();
    for (const t of filteredTransactions) {
      const key = fmt.format(new Date(t.timestamp));
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key)!.push(t);
    }
    return Array.from(groups.entries());
  }, [filteredTransactions]);

  const activeFilterCount =
    appliedCheckboxes.size + (appliedCreatedBy !== "Semua" ? 1 : 0) + (appliedSearchQuery ? 1 : 0);

  // ===== Tabel riwayat desktop (D10): urutan Waktu/Total bisa diklik di header =====
  const [rSortKey, setRSortKey] = useState<"WAKTU" | "TOTAL">("WAKTU");
  const [rSortAscending, setRSortAscending] = useState(false); // default: terbaru & terbesar dulu
  function sortRiwayatBy(k: "WAKTU" | "TOTAL") {
    if (k === rSortKey) setRSortAscending((v) => !v);
    else {
      setRSortKey(k);
      setRSortAscending(false);
    }
  }
  const sortedRiwayat = useMemo(() => {
    const list = [...filteredTransactions];
    list.sort((a, b) => {
      if (rSortKey === "TOTAL") return a.grandTotal - b.grandTotal;
      return new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
    });
    return rSortAscending ? list : list.reverse();
  }, [filteredTransactions, rSortKey, rSortAscending]);
  // Footer total: transaksi void tidak dihitung ke nilai (tetap tampil di baris)
  const riwayatVoidCount = sortedRiwayat.filter((t) => t.isVoided).length;
  const riwayatTotalNilai = sortedRiwayat.reduce((s, t) => (t.isVoided ? s : s + t.grandTotal), 0);

  // ===== Detail transaksi + edit admin + void (ala dialog baris 2368–2843) =====
  const [detailTransaction, setDetailTransaction] = useState<Transaction | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editCustomerName, setEditCustomerName] = useState("");
  const [editPaymentMethod, setEditPaymentMethod] = useState("Tunai");
  const [editPaymentStatus, setEditPaymentStatus] = useState<"LUNAS" | "DP_SEBAGIAN" | "BON_PIUTANG">("LUNAS");
  const [editDiscount, setEditDiscount] = useState("0");
  const [editPaidAmount, setEditPaidAmount] = useState("0");
  const [savingEdit, setSavingEdit] = useState(false);
  const [voidTarget, setVoidTarget] = useState<Transaction | null>(null);
  const [voidReason, setVoidReason] = useState("");
  const [voiding, setVoiding] = useState(false);
  // D48/(a) — 2 opsi part internal tiket: dikembalikan ke stok (default) / tidak
  const [voidReturnInternal, setVoidReturnInternal] = useState(true);
  // D35 — PIN otorisasi supervisor untuk void (aturan 4)
  const [voidPin, setVoidPin] = useState("");
  const [voidErrorTick, setVoidErrorTick] = useState(0);
  // D38 — refund (aturan 2) & transaksi pengganti (aturan 3)
  const [refundTarget, setRefundTarget] = useState<Transaction | null>(null);
  const [refundReason, setRefundReason] = useState("");
  const [refundPin, setRefundPin] = useState("");
  const [refundErrorTick, setRefundErrorTick] = useState(0);
  const [refunding, setRefunding] = useState(false);
  const [replacementRef, setReplacementRef] = useState(""); // no. nota yang digantikan
  // D37 — laporan void & refund harian per kasir
  const [showVoidReport, setShowVoidReport] = useState(false);
  const [voidReportDay, setVoidReportDay] = useState(dayKeyWIB(new Date()));
  const [voidReport, setVoidReport] = useState<VoidReport | null>(null);
  const [voidReportLoading, setVoidReportLoading] = useState(false);

  // D37 — muat laporan saat kartu dibuka / tanggal diganti
  useEffect(() => {
    if (!showVoidReport) return;
    let aktif = true;
    setVoidReportLoading(true);
    apiJson<VoidReport>(`/api/reports/void?from=${voidReportDay}&to=${voidReportDay}`)
      .then((r) => {
        if (aktif) setVoidReport(r);
      })
      .catch(() => {
        if (aktif) setVoidReport(null);
      })
      .finally(() => {
        if (aktif) setVoidReportLoading(false);
      });
    return () => {
      aktif = false;
    };
  }, [showVoidReport, voidReportDay]);

  // D48/(a): opsi part internal kembali ke default ("dikembalikan") setiap
  // dialog void dibuka — pilihan lama tidak terbawa.
  useEffect(() => {
    if (voidTarget) setVoidReturnInternal(true);
  }, [voidTarget]);

  function openDetail(t: Transaction) {
    setDetailTransaction(t);
    setIsEditing(false);
    setEditCustomerName(t.customerName);
    setEditPaymentMethod(t.paymentMethod);
    setEditPaymentStatus(t.paymentStatus as typeof editPaymentStatus);
    setEditDiscount(String(Math.trunc(t.discount)));
    setEditPaidAmount(String(Math.trunc(t.paidAmount)));
  }

  async function saveEdit() {
    if (!detailTransaction) return;
    setSavingEdit(true);
    try {
      const updated = await apiJson<Transaction>(`/api/transactions/${detailTransaction.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: editCustomerName,
          paymentMethod: editPaymentMethod,
          paymentStatus: editPaymentStatus,
          discount: Number(editDiscount) || 0,
          paidAmount: Number(editPaidAmount) || 0,
          requesterUsername: user.username, // D34: diverifikasi server
        }),
      });
      toast({ title: "Transaksi berhasil diperbarui!" });
      setIsEditing(false);
      setDetailTransaction(null);
      await load();
      if (receiptTransaction?.id === updated.id) setReceiptTransaction(updated);
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Gagal mengubah transaksi", variant: "destructive" });
    } finally {
      setSavingEdit(false);
    }
  }

  async function processVoid() {
    if (!voidTarget) return;
    if (!voidReason.trim()) {
      toast({ title: "Alasan pembatalan wajib diisi!", variant: "destructive" });
      return;
    }
    // D36 — jaga-jaga UI: void hanya hari yang sama (server tetap memvalidasi ulang)
    if (!voidWindowOpen(voidTarget.timestamp)) {
      toast({ title: "Melewati batas waktu void — hanya hari yang sama (D36)", variant: "destructive" });
      return;
    }
    // D35 — PIN otorisasi supervisor wajib
    if (!voidPin.trim()) {
      toast({ title: "Masukkan PIN otorisasi supervisor!", variant: "destructive" });
      setVoidErrorTick((v) => v + 1);
      return;
    }
    setVoiding(true);
    try {
      const res = await apiJson<Transaction & { internalReturned?: number; unresolvedParts?: string[] }>(`/api/transactions/${voidTarget.id}/void`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reason: voidReason.trim(),
          requesterUsername: user.username, // D34: aktor diverifikasi server
          authorizePin: voidPin.trim(), // D35: PIN supervisor
          // D48/(a): pilihan pengembalian part internal tiket (default: dikembalikan)
          returnInternalParts: voidReturnInternal,
        }),
      });
      toast({ title: `Transaksi ${voidTarget.invoiceNumber} dibatalkan` });
      // umpan balik part internal (D48/(a))
      if ((res.internalReturned ?? 0) > 0) {
        toast({ title: `${res.internalReturned} part internal dikembalikan ke stok` });
      }
      if ((res.unresolvedParts?.length ?? 0) > 0) {
        toast({
          title: "Sebagian part tidak ditemukan di katalog — stok tidak dikembalikan",
          description: res.unresolvedParts!.join("; "),
          variant: "destructive",
        });
      }
      setVoidTarget(null);
      setVoidReason("");
      setVoidPin("");
      setVoidReturnInternal(true);
      setDetailTransaction(null);
      await load();
    } catch (e) {
      setVoidErrorTick((v) => v + 1);
      toast({ title: e instanceof Error ? e.message : "Gagal membatalkan transaksi", variant: "destructive" });
    } finally {
      setVoiding(false);
    }
  }

  // D38 — proses refund: dokumen negatif otomatis merujuk nota asli (aturan 2)
  async function processRefund() {
    if (!refundTarget) return;
    if (!refundReason.trim()) {
      toast({ title: "Alasan refund wajib diisi!", variant: "destructive" });
      return;
    }
    if (!refundPin.trim()) {
      toast({ title: "Masukkan PIN otorisasi supervisor!", variant: "destructive" });
      setRefundErrorTick((v) => v + 1);
      return;
    }
    setRefunding(true);
    try {
      const doc = await apiJson<Transaction>(`/api/transactions/${refundTarget.id}/refund`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reason: refundReason.trim(),
          requesterUsername: user.username, // D34: aktor diverifikasi server
          authorizePin: refundPin.trim(), // D35: PIN supervisor
        }),
      });
      toast({ title: `Refund diproses — dokumen ${doc.invoiceNumber} dibuat` });
      setRefundTarget(null);
      setRefundReason("");
      setRefundPin("");
      setDetailTransaction(null);
      await load();
    } catch (e) {
      setRefundErrorTick((v) => v + 1);
      toast({ title: e instanceof Error ? e.message : "Gagal memproses refund", variant: "destructive" });
    } finally {
      setRefunding(false);
    }
  }

  // ===== Struk 58mm (ala dialog Struk Pembayaran) =====
  // Keputusan D12: struk adalah nota untuk PELANGGAN → harga SELALU angka nyata
  // (tidak ikut penyamaran non-admin yang tetap dipakai di riwayat & detail).
  //
  // D16: netralisasi leluhur dialog saat cetak dipusatkan di lib/print-helper.ts
  // (DialogContent Tailwind v4 `translate:-50% -50%` menciptakan containing block
  // yang menggeser struk; reset CSS dikalahkan Lightning CSS).
  function handlePrintReceipt() {
    cetakNode("struk-print", "print-struk");
  }

  // ===== Struk sebagai JPG (D13; direvisi D14: Unduh & Bagikan dipisah) =====
  // Umpan balik user: lembar bagikan bawaan (Web Share) di beberapa browser hanya
  // menawarkan "Copy" tanpa opsi unduh → aksi Unduh JPG kini tombol tersendiri yang
  // SELALU tersedia; tombol Bagikan hanya muncul bila browser mendukung share file
  // (biasanya HP: WhatsApp, dsb.).
  async function renderReceiptJpg(): Promise<string> {
    const node = document.getElementById("struk-print");
    if (!node) throw new Error("Struk tidak ditemukan");
    return toJpeg(node, {
      quality: 0.95,
      backgroundColor: "#ffffff",
      pixelRatio: 3,
      // margin putih kiri-kanan 12px: width = node + 2×12 agar isi tidak terpotong
      // (SVG di-render selebar options.width, padding diterapkan ke klon border-box)
      width: node.clientWidth + 24,
      style: { padding: "0 12px" },
    });
  }

  function unduhDataUrl(dataUrl: string, namaFile: string) {
    const link = document.createElement("a");
    link.href = dataUrl;
    link.download = namaFile;
    link.click();
  }

  async function handleUnduhReceiptJpg() {
    if (!receiptTransaction || sharingJpg) return;
    setSharingJpg(true);
    const namaFile = `struk-${receiptTransaction.invoiceNumber}.jpg`;
    try {
      unduhDataUrl(await renderReceiptJpg(), namaFile);
      toast({
        title: "Struk JPG diunduh",
        description: "Bagikan file dari folder Unduhan/Galeri ke pelanggan (WhatsApp, dsb.).",
      });
    } catch (e) {
      console.error("gagal render struk jpg:", e);
      toast({ title: e instanceof Error ? e.message : "Gagal membuat JPG struk", variant: "destructive" });
    } finally {
      setSharingJpg(false);
    }
  }

  async function handleBagikanReceiptJpg() {
    if (!receiptTransaction || sharingJpg) return;
    setSharingJpg(true);
    const namaFile = `struk-${receiptTransaction.invoiceNumber}.jpg`;
    try {
      const dataUrl = await renderReceiptJpg();
      const file = dataUrlToFile(dataUrl, namaFile);
      if (file && typeof navigator.share === "function" && navigator.canShare?.({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: `Struk ${receiptTransaction.invoiceNumber}`,
          text: `Struk pembayaran ${receiptTransaction.customerName} - ${settings.shopName}`,
        });
        toast({ title: "Struk dibagikan" });
      } else {
        // Tidak mendukung share file → jatuh ke unduh supaya aksi tetap berhasil
        unduhDataUrl(dataUrl, namaFile);
        toast({
          title: "Bagikan tidak tersedia — JPG diunduh",
          description: "Bagikan file dari folder Unduhan/Galeri ke pelanggan (WhatsApp, dsb.).",
        });
      }
    } catch (e) {
      // User menutup lembar bagikan bawaan → bukan error
      if (e instanceof DOMException && e.name === "AbortError") return;
      console.error("gagal membagikan struk jpg:", e);
      toast({ title: "Gagal membagikan struk", variant: "destructive" });
    } finally {
      setSharingJpg(false);
    }
  }

  // Non-admin: harga disamarkan "Rp **.***" — persis formatCurrencyWithRole referensi.
  // Lingkup: riwayat, detail & footer. Struk TIDAK ikut disamarkan (lihat D12).
  const fmt = useCallback(
    (value: number) => (isAdmin ? formatCurrency(value) : "Rp **.***"),
    [isAdmin]
  );

  // D38 — tautan antar dokumen: refund aktif atas nota, dan nota asli suatu refund
  const liveRefundFor = useCallback(
    (t: Transaction) => transactions.find((x) => x.refundOfId === t.id && !x.isVoided) ?? null,
    [transactions]
  );
  const originalOf = useCallback(
    (t: Transaction) => (t.refundOfId ? transactions.find((x) => x.id === t.refundOfId) ?? null : null),
    [transactions]
  );

  const cartBadge = totalCartItems > 0 ? totalCartItems : null;

  return (
    <div className="space-y-4">
      {/* D46: RiwayatView/TransaksiBaruView adalah fungsi render yang didefinisikan
          DI DALAM body CashierSection. Bila dirender sebagai <Komponen/>, tiap render
          CashierSection menghasilkan tipe komponen baru → React menganggap komponen
          berbeda → seluruh panel (termasuk kolom Diskon/Biaya Lainnya/Bayar) di-
          unmount/remount SETIAP keystroke → fokus hilang tiap 1 karakter (dulu harus
          klik ulang kolom untuk setiap digit). Dipanggil langsung sebagai fungsi,
          elemen yang dikembalikan bertipe stabil (div/Card/Input biasa) sehingga
          DOM input dipertahankan, fokus & posisi kursor aman. Semua view ini bebas
          hooks, jadi pemanggilan langsung aman (tidak mengubah urutan hook induk). */}
      {view === "RIWAYAT" ? RiwayatView() : TransaksiBaruView()}

      {/* ===== Dialog keranjang ===== */}
      <Dialog open={cartDialogOpen} onOpenChange={setCartDialogOpen}>
        <DialogContent className="rounded-2xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Keranjang Belanja</DialogTitle>
            <DialogDescription>Atur jumlah item retail &amp; jasa sebelum membayar.</DialogDescription>
          </DialogHeader>
          {cart.length === 0 ? (
            <p className="rounded-xl bg-muted p-4 text-center text-sm text-muted-foreground">
              Keranjang masih kosong — pilih sparepart atau jasa dari katalog.
            </p>
          ) : (
            <div className="max-h-64 space-y-2 overflow-y-auto pr-1">
              {cart.map((it) => (
                <div key={it.key} className="flex items-center gap-2 rounded-xl border p-2.5">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-bold">{it.name}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {formatCurrency(it.price)}{it.maxQty !== undefined ? ` · stok ${it.maxQty}` : ""}
                    </p>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button variant="outline" size="icon" className="size-7" onClick={() => changeQty(it.key, -1)} aria-label={`Kurangi ${it.name}`}>
                      <Minus className="size-3.5" aria-hidden />
                    </Button>
                    <span className="w-6 text-center text-sm font-bold tabular-nums">{it.qty}</span>
                    <Button
                      variant="outline" size="icon" className="size-7"
                      onClick={() => changeQty(it.key, 1)}
                      disabled={it.maxQty !== undefined && it.qty >= it.maxQty}
                      aria-label={`Tambah ${it.name}`}
                    >
                      <Plus className="size-3.5" aria-hidden />
                    </Button>
                  </div>
                  <span className="w-20 text-right text-[13px] font-bold tabular-nums">
                    {formatCurrency(it.price * it.qty)}
                  </span>
                  <Button
                    variant="ghost" size="icon" className="size-7 text-destructive hover:text-destructive"
                    onClick={() => setCart((prev) => prev.filter((x) => x.key !== it.key))}
                    aria-label={`Hapus ${it.name}`}
                  >
                    <Trash2 className="size-3.5" aria-hidden />
                  </Button>
                </div>
              ))}
            </div>
          )}
          <div className="space-y-1.5">
            <Label htmlFor="biaya-lain">Biaya Lainnya (Rp)</Label>
            <Input
              id="biaya-lain"
              inputMode="numeric"
              value={otherFeeInput}
              onChange={(e) => setOtherFeeInput(digitsOnly(e.target.value))}
              placeholder="0"
            />
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <div className="flex w-full items-center justify-between text-sm font-bold">
              <span>Subtotal Keranjang</span>
              <span className="text-primary tabular-nums">{formatCurrency(totalSubtotal)}</span>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== Dialog Detail Pembayaran (ala showDetailPembayaranSheet) ===== */}
      <Dialog open={showPaymentDetail} onOpenChange={setShowPaymentDetail}>
        <DialogContent className="rounded-2xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Detail Pembayaran</DialogTitle>
            <DialogDescription>Metode, status, dan jumlah uang yang dibayarkan.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <p className="text-xs font-bold text-muted-foreground">Metode Pembayaran</p>
              <div className="flex flex-wrap gap-2">
                {PAYMENT_METHODS.map((m) => (
                  <button
                    key={m} type="button" onClick={() => setSelectedPaymentMethod(m)}
                    className={
                      "rounded-lg px-3 py-2 text-xs font-bold transition-colors " +
                      (selectedPaymentMethod === m
                        ? "bg-primary text-primary-foreground"
                        : "bg-primary/10 text-primary hover:bg-primary/20")
                    }
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-1.5">
              <p className="text-xs font-bold text-muted-foreground">Status Pembayaran</p>
              <div className="flex flex-wrap gap-2">
                {(["LUNAS", "BON_PIUTANG", "DP_SEBAGIAN"] as const).map((s) => (
                  <button
                    key={s} type="button" onClick={() => setSelectedPaymentStatus(s)}
                    className={
                      "rounded-lg px-3 py-2 text-xs font-bold transition-colors " +
                      (selectedPaymentStatus === s
                        ? "bg-primary text-primary-foreground"
                        : "bg-primary/10 text-primary hover:bg-primary/20")
                    }
                  >
                    {statusLabel(s)}
                  </button>
                ))}
              </div>
              {selectedPaymentStatus !== "LUNAS" && (
                <p className="text-[11px] text-muted-foreground">
                  {selectedPaymentStatus === "BON_PIUTANG"
                    ? "Piutang/Bon: dicatat sebagai utang — kosongkan Jumlah Bayar bila pelanggan belum membayar apa pun (T8)."
                    : "DP Sebagian: bayar sebagian dulu (lebih dari 0, kurang dari total)."}
                </p>
              )}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="jumlah-bayar">
                {selectedPaymentStatus === "BON_PIUTANG"
                  ? "Jumlah Bayar Tunai (Rp) - Kosongkan = belum membayar"
                  : "Jumlah Bayar Tunai (Rp) - Kosongkan jika pas"}
              </Label>
              <Input
                id="jumlah-bayar"
                inputMode="numeric"
                value={amountPaidInput}
                onChange={(e) => setAmountPaidInput(digitsOnly(e.target.value))}
                placeholder={selectedPaymentStatus === "BON_PIUTANG" ? "0" : String(Math.trunc(grandTotal))}
              />
            </div>
            {amountPaid > grandTotal && (
              <div className="flex items-center justify-between text-sm font-bold">
                <span>Uang Kembali</span>
                <span className="tabular-nums text-destructive">{formatCurrency(changeAmount)}</span>
              </div>
            )}
            {/* Tahap 4: garansi servis — chips persis referensi (Set Garansi Manual) */}
            {pendingRepair && (
              <div className="space-y-1.5 border-t pt-3">
                <p className="text-xs font-bold text-primary">Set Garansi Servis (Hari):</p>
                <div className="flex flex-wrap gap-1.5">
                  {[0, 3, 7, 14, 30].map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setSelectedWarrantyDays(d)}
                      className={
                        "rounded-lg px-2.5 py-1.5 text-[11px] font-bold transition-colors " +
                        (selectedWarrantyDays === d
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground hover:bg-background")
                      }
                    >
                      {d === 0 ? "Tanpa" : `${d} Hari`}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button onClick={() => setShowPaymentDetail(false)} className="w-full rounded-xl">
              Terapkan &amp; Tutup
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== Dialog Konfirmasi Pembayaran (persis referensi) ===== */}
      <Dialog open={showConfirmCheckout} onOpenChange={setShowConfirmCheckout}>
        <DialogContent className="rounded-2xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Konfirmasi Pembayaran</DialogTitle>
            <DialogDescription>Apakah Anda yakin ingin memproses transaksi ini?</DialogDescription>
          </DialogHeader>
          <Card className="rounded-xl bg-primary-container text-on-primary-container">
            <CardContent className="flex flex-col items-center gap-1 p-4">
              <p className="text-[11px] font-bold opacity-80">TOTAL BELANJA</p>
              <p className="text-3xl font-black text-primary tabular-nums">{formatCurrency(grandTotal)}</p>
            </CardContent>
          </Card>
          <div className="space-y-1.5 text-sm">
            <div className="flex justify-between"><span>Metode Pembayaran:</span><span className="font-bold">{selectedPaymentMethod}</span></div>
            <div className="flex justify-between"><span>Status:</span><span className="font-bold">{statusLabel(selectedPaymentStatus)}</span></div>
            <div className="flex justify-between"><span>Jumlah Bayar:</span><span className="font-bold tabular-nums">{formatCurrency(amountPaid)}</span></div>
            {amountPaid > grandTotal && (
              <div className="flex justify-between"><span className="text-destructive">Kembalian:</span><span className="font-bold tabular-nums text-destructive">{formatCurrency(changeAmount)}</span></div>
            )}
          </div>
          {settings.editTransactionDate && (
            <div className="space-y-1 rounded-xl border bg-muted/40 p-3">
              <Label htmlFor="checkout-tanggal">Tanggal &amp; Waktu Transaksi</Label>
              <Input
                id="checkout-tanggal"
                type="datetime-local"
                value={checkoutDate}
                onChange={(e) => setCheckoutDate(e.target.value)}
                className="rounded-xl"
              />
              <p className="text-[11px] text-muted-foreground">
                "Edit Tanggal Transaksi" aktif — ubah bila mencatat transaksi mundur (mis. pembayaran kemarin).
              </p>
            </div>
          )}
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setShowConfirmCheckout(false)} disabled={processing}>
              Batal
            </Button>
            <Button onClick={() => void processCheckout()} disabled={processing}>
              {processing ? "Memproses..." : "Ya, Proses"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== Dialog Struk (print CSS 58mm) ===== */}
      <Dialog open={receiptTransaction !== null} onOpenChange={(open) => !open && setReceiptTransaction(null)}>
        <DialogContent className="rounded-2xl sm:max-w-sm">
          <DialogHeader className="sr-only">
            <DialogTitle>Struk Pembayaran</DialogTitle>
            <DialogDescription>Struk siap dicetak ke printer thermal 58mm.</DialogDescription>
          </DialogHeader>
          {receiptTransaction && (
            <StrukBody trans={receiptTransaction} settings={settings} cashierName={user.name} fmt={formatCurrency} />
          )}
          <div className="space-y-2">
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => void handleUnduhReceiptJpg()}
                disabled={sharingJpg}
                className="h-11 flex-1 rounded-xl"
              >
                <Download className="size-4" aria-hidden /> {sharingJpg ? "Menyiapkan..." : "Unduh JPG"}
              </Button>
              {canShareFiles && (
                <Button
                  variant="outline"
                  onClick={() => void handleBagikanReceiptJpg()}
                  disabled={sharingJpg}
                  className="h-11 flex-1 rounded-xl"
                >
                  <Share2 className="size-4" aria-hidden /> Bagikan
                </Button>
              )}
            </div>
            <div className="flex gap-2">
              <Button onClick={handlePrintReceipt} disabled={sharingJpg} className="h-11 flex-1 rounded-xl">
                <Printer className="size-4" aria-hidden /> Cetak Struk
              </Button>
              <Button
                variant="outline"
                onClick={() => setReceiptTransaction(null)}
                disabled={sharingJpg}
                className="h-11 flex-1 rounded-xl"
              >
                Selesai &amp; Tutup
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== Dialog Detail Transaksi (+edit admin) ===== */}
      <Dialog open={detailTransaction !== null} onOpenChange={(open) => !open && setDetailTransaction(null)}>
        <DialogContent className="max-h-[85vh] overflow-y-auto rounded-2xl sm:max-w-md">
          {detailTransaction && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center justify-between gap-2">
                  <span>Detail Transaksi</span>
                  <span className="flex items-center gap-1.5">
                    {detailTransaction.docType === "REFUND" && (
                      <Badge className="bg-orange-100 font-black text-orange-800">REFUND</Badge>
                    )}
                    {detailTransaction.isVoided && (
                      <Badge className="bg-red-100 font-black text-red-800">BATAL / VOID</Badge>
                    )}
                  </span>
                </DialogTitle>
                <DialogDescription>
                  Invoice <span className="font-bold text-primary">{detailTransaction.invoiceNumber}</span> ·{" "}
                  {formatDateTime(detailTransaction.timestamp)}
                </DialogDescription>
              </DialogHeader>

              {/* D38 — tautan antar dokumen (aturan 2 & 3) */}
              {!isEditing && detailTransaction.docType === "REFUND" && (
                <p className="rounded-xl bg-orange-50 px-3 py-2 text-[11px] font-semibold text-orange-900">
                  Dokumen REFUND — uang dikembalikan ke pelanggan, merujuk nota asli{" "}
                  <b className="font-mono">
                    {detailTransaction.referenceNumber || originalOf(detailTransaction)?.invoiceNumber || "?"}
                  </b>
                  . Nota asli tetap tersimpan.
                </p>
              )}
              {!isEditing && detailTransaction.docType !== "REFUND" && liveRefundFor(detailTransaction) && (
                <p className="rounded-xl bg-orange-50 px-3 py-2 text-[11px] font-semibold text-orange-900">
                  Sudah direfund: dokumen <b className="font-mono">{liveRefundFor(detailTransaction)!.invoiceNumber}</b>
                  {" "}(nilai {fmt(liveRefundFor(detailTransaction)!.grandTotal)}).
                </p>
              )}
              {!isEditing && detailTransaction.docType !== "REFUND" && detailTransaction.referenceNumber && (
                <p className="rounded-xl bg-muted px-3 py-2 text-[11px] text-muted-foreground">
                  Transaksi pengganti untuk nota <b className="font-mono">{detailTransaction.referenceNumber}</b>
                  {" "}(aturan koreksi D38).
                </p>
              )}

              {isEditing ? (
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="edit-nama">Nama Pelanggan</Label>
                    <Input id="edit-nama" value={editCustomerName} onChange={(e) => setEditCustomerName(e.target.value)} />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="edit-metode">Metode Pembayaran</Label>
                    <select
                      id="edit-metode"
                      value={editPaymentMethod}
                      onChange={(e) => setEditPaymentMethod(e.target.value)}
                      className="h-10 w-full rounded-xl border border-input bg-background px-3 text-sm"
                    >
                      {PAYMENT_METHODS.map((m) => <option key={m}>{m}</option>)}
                    </select>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="edit-status">Status Pembayaran</Label>
                    <select
                      id="edit-status"
                      value={editPaymentStatus}
                      onChange={(e) => setEditPaymentStatus(e.target.value as typeof editPaymentStatus)}
                      className="h-10 w-full rounded-xl border border-input bg-background px-3 text-sm"
                    >
                      <option value="LUNAS">Lunas</option>
                      <option value="BON_PIUTANG">Piutang / Bon</option>
                      <option value="DP_SEBAGIAN">DP Sebagian</option>
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1.5">
                      <Label htmlFor="edit-diskon">Diskon (Rp)</Label>
                      <Input id="edit-diskon" inputMode="numeric" value={editDiscount} onChange={(e) => setEditDiscount(digitsOnly(e.target.value))} />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="edit-bayar">Jumlah Bayar (Rp)</Label>
                      <Input id="edit-bayar" inputMode="numeric" value={editPaidAmount} onChange={(e) => setEditPaidAmount(digitsOnly(e.target.value))} />
                    </div>
                  </div>
                  <div className="flex gap-2 pt-1">
                    <Button variant="outline" onClick={() => setIsEditing(false)} className="flex-1 rounded-xl">Batal</Button>
                    <Button onClick={() => void saveEdit()} disabled={savingEdit} className="flex-1 rounded-xl">
                      {savingEdit ? "Menyimpan..." : "Simpan"}
                    </Button>
                  </div>
                </div>
              ) : (
                /* D46: dipanggil sebagai fungsi render — alasan sama dengan
                   RiwayatView/TransaksiBaruView di atas */
                DetailTransaksiBody({ trans: detailTransaction, fmt })
              )}

              {!isEditing && (
                <div className="flex gap-2">
                  <Button
                    variant="secondary"
                    className="h-10 flex-[1.3] rounded-xl"
                    onClick={() => {
                      setReceiptTransaction(detailTransaction);
                      setDetailTransaction(null);
                    }}
                  >
                    <Receipt className="size-4" aria-hidden /> Struk
                  </Button>
                  {isAdmin && (
                    <>
                      <Button variant="outline" className="h-10 flex-1 rounded-xl" onClick={() => setIsEditing(true)}>
                        <Pencil className="size-4" aria-hidden /> Edit
                      </Button>
                      {!detailTransaction.isVoided && (
                        <Button
                          variant="destructive"
                          className="h-10 flex-1 rounded-xl"
                          disabled={!voidWindowOpen(detailTransaction.timestamp)}
                          title={!voidWindowOpen(detailTransaction.timestamp) ? "Batas void hari yang sama terlewati (D36) — gunakan Refund" : undefined}
                          onClick={() => {
                            setVoidTarget(detailTransaction);
                            setVoidReason("");
                            setVoidPin("");
                            setDetailTransaction(null);
                          }}
                        >
                          <Ban className="size-4" aria-hidden /> Batal
                        </Button>
                      )}
                      {!detailTransaction.isVoided &&
                        detailTransaction.docType !== "REFUND" &&
                        !liveRefundFor(detailTransaction) &&
                        detailTransaction.paidAmount > 0 && (
                          <Button
                            variant="outline"
                            className="h-10 flex-1 rounded-xl border-amber-300 text-amber-700 hover:bg-amber-50"
                            onClick={() => {
                              setRefundTarget(detailTransaction);
                              setRefundReason("");
                              setRefundPin("");
                              setDetailTransaction(null);
                            }}
                          >
                            <Undo2 className="size-4" aria-hidden /> Refund
                          </Button>
                        )}
                    </>
                  )}
                </div>
              )}
              {/* D38 (aturan 3) — koreksi lewat transaksi pengganti dengan nomor referensi */}
              {!isEditing && isAdmin && detailTransaction.isVoided && detailTransaction.docType !== "REFUND" && (
                <Button
                  variant="outline"
                  className="h-10 w-full rounded-xl"
                  onClick={() => {
                    resetTransactionForm();
                    setReplacementRef(detailTransaction.invoiceNumber);
                    setDetailTransaction(null);
                    setView("BARU");
                  }}
                >
                  <Repeat className="size-4" aria-hidden /> Buat Transaksi Pengganti
                </Button>
              )}
              {!isEditing && detailTransaction.isVoided && detailTransaction.voidReason && (
                <p className="rounded-xl bg-muted px-3 py-2 text-[11px] text-muted-foreground">
                  Dibatalkan{detailTransaction.voidedBy ? ` oleh ${detailTransaction.voidedBy}` : ""}: “{detailTransaction.voidReason}”
                </p>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* ===== Konfirmasi void (ala "Batalkan/Hapus Transaksi") ===== */}
      <AlertDialog open={voidTarget !== null} onOpenChange={(open) => !open && setVoidTarget(null)}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Batalkan/Hapus Transaksi</AlertDialogTitle>
            <AlertDialogDescription>
              {voidTarget && (
                <>
                  Transaksi <b>{voidTarget.invoiceNumber}</b> ({voidTarget.customerName}) akan dibatalkan.
                  Stok item retail dikembalikan dan poin loyalitas pelanggan ditarik otomatis. Tindakan ini
                  tidak dapat dibatalkan.
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-1.5">
            <Label htmlFor="void-alasan">Alasan Pembatalan (wajib)</Label>
            <Textarea
              id="void-alasan"
              value={voidReason}
              onChange={(e) => setVoidReason(e.target.value)}
              placeholder="cth. Salah input kasir"
              rows={3}
            />
          </div>
          {/* D36 — batas waktu void: hari kalender yang sama (WIB) */}
          {voidTarget && !voidWindowOpen(voidTarget.timestamp) && (
            <p className="rounded-xl bg-red-50 px-3 py-2 text-[11px] font-semibold text-red-800">
              Melewati batas waktu void — pembatalan hanya boleh pada hari yang sama (D36).
              Gunakan Refund untuk koreksi nota lama.
            </p>
          )}
          {/* D48/(a) — jawaban user "2 opsi (dikembalikan atau tidak)": bila nota ini
              transaksi tiket servis yang memakai part internal, tanyakan pengembalian
              stok partnya. Retail tetap selalu dikembalikan. */}
          {voidTarget && voidTarget.docType !== "REFUND" &&
            parseReceiptItems(voidTarget.itemsJson).some((it) => it.itemType === "sparepart") && (
            <div className="space-y-1.5 rounded-xl border bg-muted/40 p-3" data-testid="void-part-opsi">
              <Label className="text-[12px] font-bold">Sparepart internal tiket — dikembalikan ke stok?</Label>
              <RadioGroup
                value={voidReturnInternal ? "ya" : "tidak"}
                onValueChange={(v) => setVoidReturnInternal(v === "ya")}
                className="gap-2"
              >
                <div className="flex items-start gap-2">
                  <RadioGroupItem value="ya" id="void-part-ya" className="mt-0.5" />
                  <Label htmlFor="void-part-ya" className="text-[12px] font-normal leading-snug">
                    <b>Ya, kembalikan ke stok</b> — part masih layak dipakai (default)
                  </Label>
                </div>
                <div className="flex items-start gap-2">
                  <RadioGroupItem value="tidak" id="void-part-tidak" className="mt-0.5" />
                  <Label htmlFor="void-part-tidak" className="text-[12px] font-normal leading-snug">
                    <b>Tidak</b> — part rusak/hilang/sudah terpasang di unit pelanggan
                  </Label>
                </div>
              </RadioGroup>
            </div>
          )}
          {/* D35 — PIN otorisasi supervisor (aturan 4) */}
          <div className="space-y-1.5">
            <Label htmlFor="void-pin">PIN Otorisasi Supervisor (wajib)</Label>
            <PinInput
              id="void-pin"
              variant="field"
              value={voidPin}
              onChange={setVoidPin}
              errorTick={voidErrorTick}
              autoFocus={false}
              ariaLabel="PIN otorisasi supervisor"
            />
            <p className="text-[10px] text-muted-foreground">
              D35 — void wajib persetujuan supervisor: masukkan PIN akun Admin.
            </p>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Tutup</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                void processVoid();
              }}
              disabled={
                voiding ||
                !voidReason.trim() ||
                !voidPin.trim() ||
                (voidTarget !== null && !voidWindowOpen(voidTarget.timestamp))
              }
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {voiding ? "Memproses..." : "Ya, Batalkan"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ===== D38 — Konfirmasi refund (aturan 2: dokumen negatif merujuk nota asli) ===== */}
      <AlertDialog open={refundTarget !== null} onOpenChange={(open) => !open && setRefundTarget(null)}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Refund / Retur Transaksi</AlertDialogTitle>
            <AlertDialogDescription>
              {refundTarget && (
                <>
                  Nota <b>{refundTarget.invoiceNumber}</b> ({refundTarget.customerName}) akan dibuatkan
                  dokumen refund bernilai <b>{formatCurrency(refundTarget.paidAmount)}</b> yang merujuk nota
                  asli. Stok item retail kembali masuk dan poin loyalitas ditarik otomatis; nota asli tetap
                  tersimpan sebagai jejak.
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-1.5">
            <Label htmlFor="refund-alasan">Alasan Refund (wajib)</Label>
            <Textarea
              id="refund-alasan"
              value={refundReason}
              onChange={(e) => setRefundReason(e.target.value)}
              placeholder="cth. Barang diretur pelanggan"
              rows={3}
            />
          </div>
          {/* D35 — PIN otorisasi supervisor juga berlaku untuk refund */}
          <div className="space-y-1.5">
            <Label htmlFor="refund-pin">PIN Otorisasi Supervisor (wajib)</Label>
            <PinInput
              id="refund-pin"
              variant="field"
              value={refundPin}
              onChange={setRefundPin}
              errorTick={refundErrorTick}
              autoFocus={false}
              ariaLabel="PIN otorisasi supervisor"
            />
            <p className="text-[10px] text-muted-foreground">
              D35 — refund wajib persetujuan supervisor: masukkan PIN akun Admin.
            </p>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Tutup</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                void processRefund();
              }}
              disabled={refunding || !refundReason.trim() || !refundPin.trim()}
              className="bg-amber-600 text-white hover:bg-amber-600/90"
            >
              {refunding ? "Memproses..." : "Ya, Proses Refund"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );

  // ===================== sub-komponen tampilan =====================

  // ===== D37 — kartu laporan void & refund harian per kasir =====
  function MiniVoidTable({ title, rows }: { title: string; rows: VoidReportRow[] }) {
    return (
      <div>
        <p className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">{title}</p>
        {rows.length === 0 ? (
          <p className="mt-1 text-xs text-muted-foreground">Tidak ada.</p>
        ) : (
          <table className="mt-1 w-full text-xs">
            <thead>
              <tr className="border-b text-left text-[10px] uppercase tracking-wide text-muted-foreground">
                <th className="py-1 font-bold">Kasir / Admin</th>
                <th className="py-1 text-center font-bold">Jumlah</th>
                <th className="py-1 text-right font-bold">Total Nilai</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.name} className="border-b last:border-0">
                  <td className="py-1.5 font-semibold">{r.name}</td>
                  <td className="py-1.5 text-center tabular-nums">{r.count}</td>
                  <td className="py-1.5 text-right font-bold tabular-nums">{fmt(r.total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    );
  }

  function LaporanVoidCard() {
    const rep = voidReport;
    return (
      <Card className="rounded-2xl">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              className="flex items-center gap-2 text-left"
              onClick={() => setShowVoidReport((v) => !v)}
              aria-expanded={showVoidReport}
            >
              <ClipboardList className="size-4 text-primary" aria-hidden />
              <span className="text-sm font-extrabold text-primary">Laporan Void &amp; Refund Harian</span>
              <span className="text-[10px] font-bold text-muted-foreground">
                [{showVoidReport ? "Sembunyikan ▴" : "Tampilkan ▾"}]
              </span>
            </button>
            <Input
              type="date"
              value={voidReportDay}
              onChange={(e) => setVoidReportDay(e.target.value || dayKeyWIB(new Date()))}
              className="ml-auto h-8 w-40 rounded-xl text-xs"
              aria-label="Tanggal laporan void"
            />
          </div>
          {showVoidReport && (
            <div className="mt-3 space-y-4">
              {voidReportLoading ? (
                <p className="text-xs text-muted-foreground">Memuat laporan...</p>
              ) : !rep ? (
                <p className="text-xs text-muted-foreground">Gagal memuat laporan.</p>
              ) : (
                <>
                  {/* D46: dipanggil sebagai fungsi render — alasan sama */}
                  {MiniVoidTable({ title: "Pembatalan (Void) per Kasir", rows: rep.voids.rows })}
                  {MiniVoidTable({ title: "Refund per Kasir", rows: rep.refunds.rows })}
                  {rep.voids.details.length > 0 && (
                    <div className="space-y-1.5">
                      <p className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
                        Detail pembatalan (maks. 8 terbaru)
                      </p>
                      {rep.voids.details.slice(0, 8).map((d) => (
                        <div key={d.id} className="rounded-xl border px-2.5 py-1.5 text-[11px]">
                          <div className="flex flex-wrap items-center gap-x-2">
                            <span className="font-mono font-bold text-primary">{d.invoiceNumber}</span>
                            <span className="text-muted-foreground">{d.voidedAt ? formatDateTime(d.voidedAt) : ""}</span>
                            <span className="text-muted-foreground">
                              oleh {d.voidedBy ?? "—"} (kasir: {d.createdBy})
                            </span>
                            <span className="ml-auto font-bold tabular-nums">{fmt(d.grandTotal)}</span>
                          </div>
                          <p className="mt-0.5 text-muted-foreground">
                            Alasan: {d.voidReason ?? "—"}
                            {d.referenceNumber ? ` · Pengganti: ${d.referenceNumber}` : ""}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                  {rep.voids.rows.length === 0 && rep.refunds.rows.length === 0 && (
                    <p className="rounded-xl bg-muted p-3 text-center text-xs text-muted-foreground">
                      Tidak ada pembatalan/refund pada tanggal ini.
                    </p>
                  )}
                </>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  function RiwayatView() {
    return (
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <div className="me-auto flex items-center gap-2">
            <h2 className="text-base font-extrabold text-primary">Riwayat Transaksi</h2>
            <FinCountChip count={filteredTransactions.length} unit="transaksi" />
          </div>
          <div className="relative w-full sm:w-64">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
            <Input
              value={appliedSearchQuery}
              onChange={(e) => setAppliedSearchQuery(e.target.value)}
              placeholder="Cari invoice, pelanggan, item..."
              className="h-9 rounded-xl pl-8"
              aria-label="Cari riwayat transaksi"
            />
          </div>
          <Button
            variant="outline"
            className="relative h-9 rounded-xl"
            onClick={() => {
              setTempCheckboxes(new Set(appliedCheckboxes));
              setTempCreatedBy(appliedCreatedBy);
              setTempSearchQuery(appliedSearchQuery);
              setShowFilterDialog(true);
            }}
            aria-label="Filter riwayat"
          >
            Filter
            {activeFilterCount > 0 && (
              <span className="absolute -right-1.5 -top-1.5 flex size-5 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-white">
                {activeFilterCount}
              </span>
            )}
          </Button>
          {/* D72: Tambah Transaksi memunculkan pilihan jenis — ala FAB referensi
              (CashierSection baris 1762–1794): "Transaksi Kasir" buka POS,
              "Terima Servis" pindah ke tab Servis + form tiket langsung terbuka */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button className="h-9 rounded-xl">
                <Plus className="size-4" aria-hidden /> Tambah Transaksi
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuItem
                className="font-semibold"
                onClick={() => { resetTransactionForm(); setReplacementRef(""); setView("BARU"); }}
              >
                <ShoppingCart className="size-4 text-primary" aria-hidden /> Transaksi Kasir
              </DropdownMenuItem>
              <DropdownMenuItem
                className="font-semibold"
                onClick={() => onOpenServiceForm?.()}
              >
                <Wrench className="size-4 text-primary" aria-hidden /> Terima Servis
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* D37 — laporan void & refund harian per kasir (aturan 8: pantau fraud) */}
        {isAdmin && LaporanVoidCard()}

        {loading ? (
          <p className="py-16 text-center text-sm text-muted-foreground">Memuat transaksi...</p>
        ) : groupedTransactions.length === 0 ? (
          <Card className="rounded-2xl">
            <CardContent className="flex flex-col items-center gap-2 py-14 text-center">
              <Inbox className="size-10 text-muted-foreground" aria-hidden />
              <p className="text-sm font-bold">Belum ada transaksi</p>
              <p className="text-xs text-muted-foreground">Transaksi POS akan tampil di sini setelah pembayaran pertama.</p>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Desktop: buku besar transaksi standar industri keuangan (D10) — baris rapat,
                No. urut, invoice mono, angka rata kanan, urut Waktu/Total dari header, total footer */}
            <div className="hidden overflow-x-auto rounded-2xl border bg-card shadow-sm md:block xl:overflow-x-visible">
              <Table>
                <TableHeader className="[&_tr]:border-b-0">
                  <tr>
                    <FinTh corner="first" align="center" className="w-10">#</FinTh>
                    <FinSortTh label="Waktu" k="WAKTU" sortKey={rSortKey} asc={rSortAscending} onSort={sortRiwayatBy} />
                    <FinTh>No. Invoice</FinTh>
                    <FinTh>Pelanggan</FinTh>
                    <FinTh>Item</FinTh>
                    <FinTh>Metode</FinTh>
                    <FinTh align="center">Status</FinTh>
                    <FinSortTh label="Total" k="TOTAL" sortKey={rSortKey} asc={rSortAscending} onSort={sortRiwayatBy} align="right" corner="last" />
                  </tr>
                </TableHeader>
                <TableBody>
                  {sortedRiwayat.map((t, i) => {
                    const items = parseReceiptItems(t.itemsJson);
                    return (
                      <FinRow key={t.id} zebra={i % 2 === 1} muted={t.isVoided} onClick={() => openDetail(t)}>
                        <FinIndexTd>{i + 1}</FinIndexTd>
                        <FinTd className="text-[12px] tabular-nums text-muted-foreground">{formatDateTime(t.timestamp)}</FinTd>
                        <FinTd className="font-mono text-[12px] font-bold text-primary">{t.invoiceNumber}</FinTd>
                        <FinTd className="max-w-[170px] truncate font-semibold">{t.customerName}</FinTd>
                        <FinTd className="max-w-[240px] truncate text-muted-foreground">
                          {items.length > 0
                            ? `${items[0].qty}x ${items[0].name}${items.length > 1 ? ` +${items.length - 1} lainnya` : ""}`
                            : "—"}
                        </FinTd>
                        <FinTd className="text-muted-foreground">{t.paymentMethod}</FinTd>
                        <FinTd className="text-center">
                          <span className="inline-flex items-center gap-1">
                            <span
                              className={
                                "rounded px-1.5 py-0.5 text-[9px] font-black " +
                                (t.paymentStatus === "LUNAS" ? "bg-green-100 text-green-800" : "bg-amber-100 text-amber-800")
                              }
                            >
                              {statusLabelShort(t.paymentStatus)}
                            </span>
                            {t.isVoided && (
                              <span className="rounded bg-red-100 px-1.5 py-0.5 text-[9px] font-black text-red-800">VOID</span>
                            )}
                            {t.docType === "REFUND" && (
                              <span className="rounded bg-orange-100 px-1.5 py-0.5 text-[9px] font-black text-orange-800">REFUND</span>
                            )}
                          </span>
                        </FinTd>
                        <FinTd
                          className={
                            "text-right font-black tabular-nums " +
                            (t.isVoided ? "text-muted-foreground line-through" : "text-primary")
                          }
                        >
                          {fmt(t.grandTotal)}
                        </FinTd>
                      </FinRow>
                    );
                  })}
                </TableBody>
                <FinTfoot>
                  <tr>
                    <FinFootTd colSpan={7}>
                      Total {sortedRiwayat.length} transaksi
                      {riwayatVoidCount > 0 ? ` · ${riwayatVoidCount} void tidak dihitung` : ""}
                    </FinFootTd>
                    <FinFootTd className="text-right text-[12px] normal-case tracking-normal tabular-nums text-primary">
                      {fmt(riwayatTotalNilai)}
                    </FinFootTd>
                  </tr>
                </FinTfoot>
              </Table>
            </div>

            {/* Mobile: kartu per grup tanggal (persis CashierSection referensi) */}
            <div className="space-y-4 md:hidden">
          {groupedTransactions.map(([dateKey, list]) => (
            <div key={dateKey} className="space-y-2">
              <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">{dateKey}</p>
              {list.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => openDetail(t)}
                  className={
                    "block w-full rounded-2xl border bg-card p-4 text-left transition-colors hover:border-primary/40 hover:bg-accent/40 " +
                    (t.isVoided ? "opacity-70" : "")
                  }
                >
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-[13px] font-bold text-primary">{t.invoiceNumber}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {formatDateTime(t.timestamp)} · {t.customerName} · {t.createdBy}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-semibold text-muted-foreground">{t.paymentMethod}</span>
                      <span
                        className={
                          "rounded px-1.5 py-0.5 text-[9px] font-black " +
                          (t.paymentStatus === "LUNAS" ? "bg-green-100 text-green-800" : "bg-amber-100 text-amber-800")
                        }
                      >
                        {statusLabelShort(t.paymentStatus)}
                      </span>
                      {t.isVoided && (
                        <span className="rounded bg-red-100 px-1.5 py-0.5 text-[9px] font-black text-red-800">VOID</span>
                      )}
                      {t.docType === "REFUND" && (
                        <span className="rounded bg-orange-100 px-1.5 py-0.5 text-[9px] font-black text-orange-800">REFUND</span>
                      )}
                    </div>
                  </div>
                  <div className="mt-2 space-y-0.5">
                    {parseReceiptItems(t.itemsJson).map((it, i) => (
                      <div key={i} className="flex justify-between text-[12px]">
                        <span className="truncate pr-2 text-muted-foreground">{it.qty}x {it.name}</span>
                        <span className="font-bold tabular-nums">{fmt(it.price * it.qty)}</span>
                      </div>
                    ))}
                  </div>
                  <div className="mt-2 flex items-center justify-between border-t pt-2">
                    <span className="text-xs text-muted-foreground">Total</span>
                    <span className="text-sm font-black text-primary tabular-nums">{fmt(t.grandTotal)}</span>
                  </div>
                </button>
              ))}
            </div>
          ))}
            </div>
          </>
        )}

        {/* Dialog filter riwayat (ala Filter & Cari Riwayat) */}
        <Dialog open={showFilterDialog} onOpenChange={setShowFilterDialog}>
          <DialogContent className="rounded-2xl sm:max-w-sm">
            <DialogHeader>
              <DialogTitle>Filter &amp; Cari Riwayat</DialogTitle>
              <DialogDescription>Kombinasikan kategori filter — semua yang dipilih harus terpenuhi.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-1">
                <p className="text-xs font-bold text-primary">Kategori Filter</p>
                {FILTER_OPTIONS.map((opt) => (
                  <label key={opt} className="flex cursor-pointer items-center gap-2 rounded-lg py-1.5 text-sm hover:bg-muted">
                    <Checkbox
                      checked={tempCheckboxes.has(opt)}
                      onCheckedChange={(checked) => {
                        const next = new Set(tempCheckboxes);
                        if (checked) next.add(opt); else next.delete(opt);
                        setTempCheckboxes(next);
                      }}
                    />
                    {opt}
                  </label>
                ))}
              </div>
              <div className="space-y-1.5">
                <p className="text-xs font-bold text-primary">Dibuat Oleh</p>
                <select
                  value={tempCreatedBy}
                  onChange={(e) => setTempCreatedBy(e.target.value)}
                  className="h-10 w-full rounded-xl border border-input bg-background px-3 text-sm"
                  aria-label="Filter dibuat oleh"
                >
                  <option>Semua</option>
                  {creatorOptions.map((c) => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div className="space-y-1.5">
                <p className="text-xs font-bold text-primary">Kata Kunci</p>
                <Input value={tempSearchQuery} onChange={(e) => setTempSearchQuery(e.target.value)} placeholder="Invoice / pelanggan / item" />
              </div>
            </div>
            <DialogFooter className="gap-2 sm:gap-0">
              <Button
                variant="outline"
                onClick={() => {
                  setTempCheckboxes(new Set());
                  setTempCreatedBy("Semua");
                  setTempSearchQuery("");
                }}
              >
                Reset
              </Button>
              <Button
                onClick={() => {
                  setAppliedCheckboxes(tempCheckboxes);
                  setAppliedCreatedBy(tempCreatedBy);
                  setAppliedSearchQuery(tempSearchQuery);
                  setShowFilterDialog(false);
                }}
              >
                Terapkan
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  function TransaksiBaruView() {
    return (
      <div className="space-y-4">
        {/* Top bar form (ala baris 344–455) */}
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="ghost" size="icon" className="size-9" onClick={() => setView("RIWAYAT")} aria-label="Kembali ke riwayat">
            <ChevronLeft className="size-5" aria-hidden />
          </Button>
          <h2 className="text-base font-extrabold text-primary">Kasir POS</h2>
          <div className="ml-auto flex items-center gap-2">
            {/* Pemilih pelanggan */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  type="button"
                  className="flex h-8 items-center gap-1.5 rounded-lg border border-primary/50 px-2.5 text-[11px] font-bold text-primary"
                  aria-label="Pilih pelanggan"
                >
                  <User className="size-3.5" aria-hidden />
                  <span className="max-w-[140px] truncate">{checkoutCustomerName}</span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="max-h-64 w-56 overflow-y-auto">
                <DropdownMenuItem onClick={() => { setCheckoutCustomerId(null); setCheckoutCustomerName("Umum"); }}>
                  Umum / Guest
                </DropdownMenuItem>
                {customers.map((c) => (
                  <DropdownMenuItem key={c.id} onClick={() => { setCheckoutCustomerId(c.id); setCheckoutCustomerName(c.name); }}>
                    {c.name} <span className="ml-auto text-[10px] text-muted-foreground">{c.loyaltyPoints} poin</span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            {/* Keranjang dengan badge */}
            <Button variant="outline" size="icon" className="relative size-9" onClick={() => setCartDialogOpen(true)} aria-label="Keranjang belanja">
              <ShoppingCart className={"size-4 " + (totalCartItems > 0 ? "text-primary" : "text-muted-foreground")} aria-hidden />
              {cartBadge !== null && (
                <span className="absolute -right-1.5 -top-1.5 flex size-5 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-white">
                  {cartBadge}
                </span>
              )}
            </Button>
          </div>
        </div>

        {/* D38 (aturan 3) — banner transaksi pengganti dengan nomor referensi */}
        {replacementRef && (
          <div className="flex items-center gap-2 rounded-xl border border-amber-300 bg-amber-50 px-3 py-2">
            <Repeat className="size-4 shrink-0 text-amber-700" aria-hidden />
            <p className="min-w-0 flex-1 text-[11px] font-semibold text-amber-900">
              Transaksi pengganti — no. referensi <b className="font-mono">{replacementRef}</b> akan tercatat
              pada nota baru (aturan koreksi D38).
            </p>
            <Button
              variant="ghost"
              size="icon"
              className="size-7 shrink-0"
              onClick={() => setReplacementRef("")}
              aria-label="Hapus referensi pengganti"
            >
              <X className="size-3.5" aria-hidden />
            </Button>
          </div>
        )}

        {/* ===== Kartu tagihan tiket servis (ala repair bill card referensi, Tahap 4.6) ===== */}
        {pendingRepair && (
          <Card className="rounded-2xl border-primary/30 bg-primary/5">
            <CardContent className="p-4">
              {!showRepairBillDetail ? (
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-[12px] font-bold">
                      ID Servis: {serviceIdOf(pendingRepair.createdAt)} · {pendingRepair.deviceModel}
                    </p>
                    <button
                      type="button"
                      onClick={() => setShowRepairBillDetail(true)}
                      className="text-left"
                    >
                      <span className="text-sm font-black text-primary tabular-nums">{formatCurrency(repairBillTotal)}</span>
                      <span className="ml-2 text-[11px] font-bold text-primary">[Lihat Rincian ▾]</span>
                    </button>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="shrink-0 rounded-lg border-red-300 text-[11px] font-bold text-red-600 hover:bg-red-50"
                    onClick={() => resetTransactionForm()}
                  >
                    Batal
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-black text-primary">Rincian Biaya Servis HP</p>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost" size="sm"
                        className="h-8 rounded-lg text-[11px] font-bold"
                        onClick={() => setShowRepairBillDetail(false)}
                      >
                        [Sembunyikan ▴]
                      </Button>
                      <Button
                        variant="outline" size="sm"
                        className="h-8 rounded-lg border-red-300 text-[11px] font-bold text-red-600 hover:bg-red-50"
                        onClick={() => resetTransactionForm()}
                      >
                        Batal Bayar Servis
                      </Button>
                    </div>
                  </div>
                  <div className="rounded-lg bg-background p-2.5 text-[12px]">
                    <p className="font-bold">ID Servis: {serviceIdOf(pendingRepair.createdAt)}</p>
                    <p className="font-bold">HP: {pendingRepair.deviceModel}</p>
                    <p className="text-muted-foreground">Kerusakan: {pendingRepair.damageDescription}</p>
                  </div>
                  {/* 1. Jasa (bisa diedit) */}
                  <div className="space-y-1">
                    <Label htmlFor="fee-servis" className="text-[11px] font-bold">1. Biaya Jasa Servis (Bisa Diedit)</Label>
                    <Input
                      id="fee-servis"
                      inputMode="numeric"
                      value={serviceFeeInput}
                      onChange={(e) => setServiceFeeInput(digitsOnly(e.target.value))}
                      className="h-9 rounded-lg"
                      placeholder="0"
                    />
                  </div>
                  {/* 2. Sparepart terpasang (dari tiket, harga dari DB saat checkout) */}
                  <div>
                    <p className="text-[11px] font-bold">2. Sparepart Terpasang</p>
                    {parseUsedParts(pendingRepair.usedPartsJson).length === 0 ? (
                      <p className="pl-2 text-[11px] text-muted-foreground">• Tidak ada sparepart inventaris terpasang</p>
                    ) : (
                      parseUsedParts(pendingRepair.usedPartsJson).map((p, i) => (
                        <div key={i} className="flex justify-between pl-2 text-[12px]">
                          <span>
                            • {p.name} ×{p.qty}
                            {/* D64: part external dari tiket ikut tampil dengan penanda */}
                            {p.isExternal ? " (Toko Lain)" : ""}
                          </span>
                          <b className="tabular-nums">{formatCurrency(p.sellPrice * p.qty)}</b>
                        </div>
                      ))
                    )}
                  </div>
                  {/* 3. Sparepart dari toko lain */}
                  <div>
                    <p className="text-[11px] font-bold">3. Sparepart Dari Toko Lain (Part Luar)</p>
                    {externalParts.length === 0 ? (
                      <p className="pl-2 text-[11px] text-muted-foreground">• Belum ada part dari toko lain</p>
                    ) : (
                      externalParts.map((p, i) => (
                        <div key={i} className="flex items-center justify-between gap-2 pl-2 text-[12px]">
                          <div className="min-w-0">
                            <p className="truncate">• {p.name} ×{p.qty}</p>
                            <p className="text-[10px] text-muted-foreground">
                              Beli: {formatCurrency(p.costPrice)} · Jual: {formatCurrency(p.sellPrice)}
                            </p>
                          </div>
                          <button
                            type="button"
                            aria-label={`Hapus ${p.name}`}
                            onClick={() => setExternalParts((prev) => prev.filter((_, idx) => idx !== i))}
                            className="size-7 shrink-0 rounded-lg border text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="mx-auto size-3.5" aria-hidden />
                          </button>
                        </div>
                      ))
                    )}
                    <div className="mt-1.5 grid grid-cols-2 gap-1.5 rounded-lg border bg-background p-2 sm:grid-cols-4">
                      <Input
                        value={extName}
                        onChange={(e) => setExtName(e.target.value)}
                        placeholder="Nama part"
                        aria-label="Nama sparepart toko lain"
                        className="h-8 rounded-lg text-[11px]"
                      />
                      <Input
                        value={extCost}
                        onChange={(e) => setExtCost(digitsOnly(e.target.value))}
                        placeholder="Harga beli"
                        aria-label="Harga beli part toko lain"
                        inputMode="numeric"
                        className="h-8 rounded-lg text-[11px]"
                      />
                      <Input
                        value={extSell}
                        onChange={(e) => setExtSell(digitsOnly(e.target.value))}
                        placeholder="Harga jual"
                        aria-label="Harga jual part toko lain"
                        inputMode="numeric"
                        className="h-8 rounded-lg text-[11px]"
                      />
                      <div className="flex gap-1">
                        <Input
                          value={extQty}
                          onChange={(e) => setExtQty(digitsOnly(e.target.value))}
                          placeholder="Qty"
                          aria-label="Qty part toko lain"
                          inputMode="numeric"
                          className="h-8 rounded-lg text-[11px]"
                        />
                        <Button
                          size="sm"
                          className="h-8 shrink-0 rounded-lg px-2 text-[11px]"
                          disabled={!extName.trim() || Number(extSell) <= 0}
                          onClick={() => {
                            setExternalParts((prev) => [
                              ...prev,
                              {
                                name: extName.trim(),
                                costPrice: Number(extCost) || 0,
                                sellPrice: Number(extSell) || 0,
                                qty: Math.max(1, Number(extQty) || 1),
                              },
                            ]);
                            setExtName(""); setExtCost(""); setExtSell(""); setExtQty("1");
                          }}
                        >
                          <Plus className="size-3.5" aria-hidden />
                        </Button>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between border-t pt-2">
                    <span className="text-[13px] font-black text-primary">Total Biaya Servis</span>
                    <span className="text-base font-black text-primary tabular-nums">{formatCurrency(repairBillTotal)}</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
          {/* ===== Katalog ===== */}
          <div className="space-y-4">
            <div className="relative">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
              <Input
                value={pSearchQuery}
                onChange={(e) => setPSearchQuery(e.target.value)}
                placeholder="Cari Sparepart atau SKU..."
                className="h-9 rounded-xl pl-8 pr-8"
                aria-label="Cari katalog POS"
              />
              {pSearchQuery && (
                <button
                  type="button"
                  onClick={() => setPSearchQuery("")}
                  aria-label="Bersihkan pencarian"
                  className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-muted-foreground hover:text-foreground"
                >
                  <X className="size-4" aria-hidden />
                </button>
              )}
            </div>

            <Card className="overflow-hidden rounded-2xl">
              <CardContent className="p-2 md:p-0">
                {/* Mobile: judul + chip urut (persis sebelumnya) */}
                <div className="flex items-center justify-between px-2 py-1.5 md:hidden">
                  <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Sparepart Retail</p>
                  <div className="flex gap-1">
                    {(["NAMA", "HARGA", "STOK"] as const).map((k) => (
                      <button
                        key={k}
                        type="button"
                        onClick={() => sortBy(k)}
                        className={
                          "rounded-md px-2 py-1 text-[10px] font-bold transition-colors " +
                          (pSortKey === k ? "bg-primary/15 text-primary" : "text-muted-foreground hover:bg-muted")
                        }
                      >
                        {k}{pSortKey === k ? (pSortAscending ? " ▲" : " ▼") : ""}
                      </button>
                    ))}
                  </div>
                </div>
                {/* Desktop: tabel standar industri keuangan (D10) — klik baris = tambah ke keranjang */}
                {filteredPOSParts.length === 0 ? (
                  <p className="rounded-xl bg-muted/40 py-8 text-center text-sm text-muted-foreground">Tidak ada sparepart cocok.</p>
                ) : (
                  <>
                    <div className="hidden md:block">
                      <Table>
                        <TableHeader className="[&_tr]:border-b-0">
                          <tr>
                            <FinTh sticky={false} corner="first">Nama Sparepart</FinTh>
                            <FinSortTh sticky={false} label="Stok Tersedia" k="STOK" sortKey={pSortKey} asc={pSortAscending} onSort={sortBy} align="right" />
                            <FinSortTh sticky={false} label="Harga Jual" k="HARGA" sortKey={pSortKey} asc={pSortAscending} onSort={sortBy} align="right" corner="last" />
                          </tr>
                        </TableHeader>
                        <TableBody>
                          {filteredPOSParts.map((part) => {
                            const isOutOfStock = part.stock <= 0;
                            const cartQty = cart.find((it) => it.partId === part.id)?.qty ?? 0;
                            const remaining = part.stock - cartQty;
                            const disabled = isOutOfStock || remaining <= 0;
                            return (
                              <FinRow
                                key={part.id}
                                onClick={disabled ? undefined : () => addPart(part)}
                                className={
                                  (disabled ? "pointer-events-none opacity-50" : "") +
                                  (cartQty > 0 ? " bg-primary/5" : "")
                                }
                              >
                                <FinTd className="max-w-[320px]">
                                  <p className="truncate font-bold">
                                    {part.name}
                                    {cartQty > 0 && <span className="ml-1.5 text-[10px] font-black text-primary">×{cartQty} di keranjang</span>}
                                  </p>
                                  <p className="font-mono text-[11px] text-muted-foreground">{part.sku || "—"}</p>
                                </FinTd>
                                <FinTd
                                  className={
                                    "text-right font-bold tabular-nums " +
                                    (isOutOfStock
                                      ? "text-destructive"
                                      : remaining <= 2
                                        ? "text-warning"
                                        : "text-success")
                                  }
                                >
                                  {isOutOfStock ? "Habis" : remaining}
                                </FinTd>
                                <FinTd className="text-right font-black tabular-nums text-primary">
                                  {formatCurrency(part.sellPrice)}
                                </FinTd>
                              </FinRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </div>
                    {/* Mobile: daftar sentuh (persis CashierSection referensi) */}
                    <div className="divide-y md:hidden">
                    {filteredPOSParts.map((part) => {
                      const isOutOfStock = part.stock <= 0;
                      const cartQty = cart.find((it) => it.partId === part.id)?.qty ?? 0;
                      const remaining = part.stock - cartQty;
                      const disabled = isOutOfStock || remaining <= 0;
                      return (
                        <button
                          key={part.id}
                          type="button"
                          disabled={disabled}
                          onClick={() => addPart(part)}
                          className={
                            "flex w-full items-center gap-3 px-2 py-2.5 text-left transition-colors " +
                            (disabled ? "cursor-not-allowed opacity-50" : "hover:bg-accent/50") +
                            (cartQty > 0 ? " bg-primary/5" : "")
                          }
                        >
                          <div className="min-w-0 flex-1">
                            <p className={"truncate text-[13px] font-bold " + (isOutOfStock ? "text-muted-foreground" : "")}>
                              {part.name}
                              {cartQty > 0 && <span className="ml-1.5 text-[10px] font-black text-primary">×{cartQty} di keranjang</span>}
                            </p>
                            <span
                              className={
                                "mt-0.5 inline-block rounded px-1.5 py-0.5 text-[10px] font-bold " +
                                (isOutOfStock
                                  ? "bg-red-100 text-red-700"
                                  : remaining <= 2
                                    ? "bg-amber-100 text-amber-800"
                                    : "bg-green-100 text-green-800")
                              }
                            >
                              {isOutOfStock ? "Habis" : `Stok: ${remaining}`}
                            </span>
                          </div>
                          <span className="text-[13px] font-black text-primary tabular-nums">{formatCurrency(part.sellPrice)}</span>
                        </button>
                      );
                    })}
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            <Card className="overflow-hidden rounded-2xl">
              <CardContent className="p-2 md:p-0">
                {/* Mobile: judul (persis sebelumnya) */}
                <p className="px-2 py-1.5 text-xs font-bold uppercase tracking-wide text-muted-foreground md:hidden">Katalog Produk Jasa</p>
                {filteredPOSServices.length === 0 ? (
                  <p className="rounded-xl bg-muted/40 py-8 text-center text-sm text-muted-foreground">
                    {services.length === 0 ? "Belum ada produk jasa — tambahkan di tab Inventaris." : "Tidak ada jasa cocok."}
                  </p>
                ) : (
                  <>
                    {/* Desktop: tabel standar industri keuangan (D10) — klik baris = tambah ke keranjang */}
                    <div className="hidden md:block">
                      <Table>
                        <TableHeader className="[&_tr]:border-b-0">
                          <tr>
                            <FinTh sticky={false} corner="first">Nama Produk Jasa</FinTh>
                            <FinTh sticky={false} align="right">Poin Teknisi</FinTh>
                            <FinSortTh sticky={false} label="Harga Dasar" k="HARGA" sortKey={sSortKey} asc={sSortAscending} onSort={sortServiceBy} align="right" corner="last" />
                          </tr>
                        </TableHeader>
                        <TableBody>
                          {filteredPOSServices.map((svc) => {
                            const cartQty = cart.find((it) => it.serviceId === svc.id)?.qty ?? 0;
                            return (
                              <FinRow key={svc.id} onClick={() => addService(svc)} className={cartQty > 0 ? "bg-primary/5" : ""}>
                                <FinTd className="max-w-[320px]">
                                  <p className="truncate font-bold">
                                    {svc.name}
                                    {cartQty > 0 && <span className="ml-1.5 text-[10px] font-black text-primary">×{cartQty} di keranjang</span>}
                                  </p>
                                  <p className="text-[11px] text-muted-foreground">Poin teknisi: {svc.points}</p>
                                </FinTd>
                                <FinTd className="text-right tabular-nums text-muted-foreground">{svc.points}</FinTd>
                                <FinTd className="text-right font-black tabular-nums text-primary">{formatCurrency(svc.basePrice)}</FinTd>
                              </FinRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </div>
                    {/* Mobile: daftar sentuh (persis CashierSection referensi) */}
                    <div className="divide-y md:hidden">
                      {filteredPOSServices.map((svc) => {
                        const cartQty = cart.find((it) => it.serviceId === svc.id)?.qty ?? 0;
                        return (
                          <button
                            key={svc.id}
                            type="button"
                            onClick={() => addService(svc)}
                            className={"flex w-full items-center gap-3 px-2 py-2.5 text-left transition-colors hover:bg-accent/50" + (cartQty > 0 ? " bg-primary/5" : "")}
                          >
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-[13px] font-bold">
                                {svc.name}
                                {cartQty > 0 && <span className="ml-1.5 text-[10px] font-black text-primary">×{cartQty} di keranjang</span>}
                              </p>
                              <p className="text-[11px] text-muted-foreground">Poin teknisi: {svc.points}</p>
                            </div>
                            <span className="text-[13px] font-black text-primary tabular-nums">{formatCurrency(svc.basePrice)}</span>
                          </button>
                        );
                      })}
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>

          {/* ===== Ringkasan & bayar ===== */}
          <div className="space-y-3 lg:sticky lg:top-16 lg:self-start">
            <Card className="rounded-2xl">
              <CardContent className="space-y-3 p-4">
                <div className="max-h-52 space-y-1.5 overflow-y-auto pr-1">
                  {pendingRepair && (
                    <div className="rounded-lg bg-primary/5 px-2 py-1.5">
                      <div className="flex justify-between gap-2 text-[12px]">
                        <span className="truncate font-bold text-primary">1x Jasa Servis ({pendingRepair.deviceModel})</span>
                        <span className="font-bold tabular-nums">{formatCurrency(repairFee)}</span>
                      </div>
                      {repairInternalPartsTotal > 0 && (
                        <div className="flex justify-between gap-2 text-[12px]">
                          <span className="truncate text-muted-foreground">Sparepart terpakai (tiket)</span>
                          <span className="font-bold tabular-nums">{formatCurrency(repairInternalPartsTotal)}</span>
                        </div>
                      )}
                      {externalParts.map((p, i) => (
                        <div key={i} className="flex justify-between gap-2 text-[12px]">
                          <span className="truncate text-muted-foreground">{p.qty}x {p.name} (Toko Lain)</span>
                          <span className="font-bold tabular-nums">{formatCurrency(p.sellPrice * p.qty)}</span>
                        </div>
                      ))}
                      {repairDownPayment > 0 && (
                        <div className="flex justify-between gap-2 text-[12px]">
                          <span className="truncate text-muted-foreground">DP / Uang Muka tiket</span>
                          <span className="font-bold tabular-nums text-emerald-700">- {formatCurrency(repairDownPayment)}</span>
                        </div>
                      )}
                    </div>
                  )}
                  {!pendingRepair && cart.length === 0 && otherFee <= 0 ? (
                    <p className="py-4 text-center text-xs text-muted-foreground">Keranjang kosong — klik item katalog untuk menambah.</p>
                  ) : (
                    <>
                      {cart.map((it) => (
                        <div key={it.key} className="flex justify-between gap-2 text-[12px]">
                          <span className="truncate text-muted-foreground">{it.qty}x {it.name}</span>
                          <span className="font-bold tabular-nums">{formatCurrency(it.price * it.qty)}</span>
                        </div>
                      ))}
                      {otherFee > 0 && (
                        <div className="flex justify-between gap-2 text-[12px]">
                          <span className="text-muted-foreground">1x Biaya Lainnya</span>
                          <span className="font-bold tabular-nums">{formatCurrency(otherFee)}</span>
                        </div>
                      )}
                    </>
                  )}
                </div>
                <div className="space-y-2 border-t pt-2">
                  <div className="flex items-center justify-between gap-2">
                    <Label htmlFor="diskon-pos" className="text-xs">Diskon (Rp)</Label>
                    <Input
                      id="diskon-pos"
                      inputMode="numeric"
                      value={discountInput}
                      onChange={(e) => setDiscountInput(digitsOnly(e.target.value))}
                      className="h-8 w-32 rounded-lg text-right tabular-nums"
                    />
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <Label htmlFor="lain-pos" className="text-xs">Biaya Lainnya (Rp)</Label>
                    <Input
                      id="lain-pos"
                      inputMode="numeric"
                      value={otherFeeInput}
                      onChange={(e) => setOtherFeeInput(digitsOnly(e.target.value))}
                      className="h-8 w-32 rounded-lg text-right tabular-nums"
                      placeholder="0"
                    />
                  </div>
                </div>
                <div className="flex items-end justify-between border-t pt-3">
                  <div>
                    <p className="text-xs font-bold text-muted-foreground">GRAND TOTAL:</p>
                    <button
                      type="button"
                      onClick={() => setShowPaymentDetail(true)}
                      className="text-[11px] font-bold text-primary hover:underline"
                    >
                      [Detail Pembayaran ▾]
                    </button>
                    {amountPaid > grandTotal && (
                      <p className="text-[11px] font-bold text-destructive">Kembali: {formatCurrency(changeAmount)}</p>
                    )}
                  </div>
                  <p className="text-2xl font-black text-primary tabular-nums">{formatCurrency(grandTotal)}</p>
                </div>
                <Button className="h-12 w-full rounded-xl text-sm font-bold tracking-wide" onClick={handleBayarClick}>
                  BAYAR
                </Button>
                <p className="text-center text-[10px] text-muted-foreground">
                  {checkoutCustomerName !== "Umum" && checkoutCustomerId
                    ? `Poin untuk ${checkoutCustomerName}: +${Math.floor(grandTotal / 10000)} (per Rp 10.000)`
                    : "Pilih pelanggan terdaftar agar poin loyalitas bertambah"}
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  function DetailTransaksiBody({ trans, fmt }: { trans: Transaction; fmt: (v: number) => string }) {
    const items = parseReceiptItems(trans.itemsJson);
    return (
      <div className="space-y-3 text-sm">
        <div className="flex items-center justify-between rounded-xl bg-muted p-3">
          <div>
            <p className="text-[11px] text-muted-foreground">Metode / Status</p>
            <p className="text-[13px] font-bold">{trans.paymentMethod} · {statusLabel(trans.paymentStatus)}</p>
          </div>
          <div className="text-right">
            <p className="text-[11px] text-muted-foreground">Dibuat Oleh</p>
            <p className="text-[13px] font-bold">{trans.createdBy}</p>
          </div>
        </div>
        <div>
          <p className="text-[11px] font-bold text-primary">Daftar Item / Jasa:</p>
          <div className="mt-1 space-y-1 rounded-xl bg-muted/50 p-3">
            {items.map((it, i) => (
              <div key={i} className="flex justify-between gap-2 text-[12px]">
                <span className="truncate text-muted-foreground">{it.qty}x {it.name}</span>
                <span className="font-bold tabular-nums">{fmt(it.price * it.qty)}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="space-y-1">
          <div className="flex justify-between text-[12px]"><span className="text-muted-foreground">Subtotal:</span><span className="tabular-nums">{fmt(trans.subtotal)}</span></div>
          {trans.discount > 0 && (
            <div className="flex justify-between text-[12px]"><span className="text-muted-foreground">Diskon:</span><span className="tabular-nums text-red-600">-{fmt(trans.discount)}</span></div>
          )}
          <div className="flex justify-between"><span className="font-bold">Total:</span><span className="font-black text-primary tabular-nums">{fmt(trans.grandTotal)}</span></div>
          <div className="flex justify-between text-[12px]"><span className="text-muted-foreground">Dibayar:</span><span className="tabular-nums">{fmt(trans.paidAmount)}</span></div>
          {trans.changeAmount > 0 && (
            <div className="flex justify-between text-[12px]"><span className="text-muted-foreground">Kembalian:</span><span className="tabular-nums">{fmt(trans.changeAmount)}</span></div>
          )}
        </div>
        {trans.isVoided && trans.voidReason && (
          <div className="rounded-xl bg-red-50 p-3 text-[11px] text-red-800">
            <p className="font-bold">Alasan Void/Batal:</p>
            <p>{trans.voidReason}</p>
            <p className="text-[10px] text-muted-foreground">Oleh: {trans.voidedBy ?? "Admin"} · {trans.voidedAt ? formatDateTime(trans.voidedAt) : ""}</p>
          </div>
        )}
      </div>
    );
  }
}

// Struk 58mm — dipisah agar id #struk-print stabil untuk print CSS
function StrukBody({
  trans, settings, cashierName, fmt,
}: {
  trans: Transaction;
  settings: ShopSettingsLite;
  cashierName: string;
  fmt: (v: number) => string;
}) {
  const items = parseReceiptItems(trans.itemsJson);
  return (
    <div id="struk-print" className="mx-auto w-full max-w-[58mm] bg-white py-2 font-mono text-[11px] leading-relaxed text-black">
      <p className="text-center text-[13px] font-bold uppercase">{settings.shopName}</p>
      {settings.address && <p className="text-center text-[10px] text-gray-700">{settings.address}</p>}
      {settings.phone && <p className="text-center text-[10px] text-gray-700">Telp/WA: {settings.phone}</p>}
      <div className="my-2 border-t border-dashed border-gray-400" />
      <p className="text-center text-[12px] font-bold">Struk Pembayaran / Nota</p>
      {trans.isVoided && (
        <div className="mt-1.5 border-2 border-red-600 px-2 py-1 text-center text-[12px] font-black uppercase text-red-600">
          Transaksi Dibatalkan (Void)
        </div>
      )}
      <div className="mt-1.5 space-y-0.5">
        <div className="flex justify-between"><span>No Nota:</span><span>{trans.invoiceNumber}</span></div>
        <div className="flex justify-between"><span>Pelanggan:</span><span className="font-bold">{trans.customerName}</span></div>
        <div className="flex justify-between"><span>Metode:</span><span>{trans.paymentMethod}</span></div>
        <div className="flex justify-between"><span>Status:</span><span className="font-bold">{statusLabelStruk(trans.paymentStatus)}</span></div>
        <div className="flex justify-between"><span>Dibuat Oleh:</span><span>{cashierName}</span></div>
      </div>
      <div className="my-2 border-t border-dashed border-gray-400" />
      <div className="space-y-1.5">
        {items.map((it, i) => (
          <div key={i}>
            {/* D23 (D18/D19): struk memakai Nama di Struk (alias) bila diisi di Inventaris */}
            <p className="text-[11px] font-bold">{it.alias?.trim() || it.name}</p>
            <div className="flex justify-between text-[10px] text-gray-700">
              <span>{it.qty} x {fmt(it.price)}</span>
              <span className="text-[11px] font-bold text-black">{fmt(it.price * it.qty)}</span>
            </div>
          </div>
        ))}
      </div>
      <div className="my-2 border-t border-dashed border-gray-400" />
      <div className="space-y-0.5">
        <div className="flex justify-between"><span>Subtotal:</span><span>{fmt(trans.subtotal)}</span></div>
        {trans.discount > 0 && <div className="flex justify-between"><span>Diskon:</span><span className="text-red-600">- {fmt(trans.discount)}</span></div>}
        <div className="flex justify-between text-[13px] font-bold"><span>Total Bayar:</span><span>{fmt(trans.grandTotal)}</span></div>
        <div className="flex justify-between"><span>Tunai/Dibayar:</span><span>{fmt(trans.paidAmount)}</span></div>
        <div className="flex justify-between"><span>Kembalian:</span><span>{fmt(trans.changeAmount)}</span></div>
      </div>
      {/* D15: status transaksi selalu tercetak di struk — LUNAS / DP / BELUM LUNAS */}
      {trans.paymentStatus === "LUNAS" ? (
        <div className="mt-1.5 border-2 border-black px-2 py-1.5 text-center text-[12px] font-black uppercase tracking-widest">
          ** LUNAS **
        </div>
      ) : (
        <div className="mt-1.5 border-2 border-red-600 px-2 py-1.5 text-center text-[12px] font-black uppercase leading-snug text-red-600">
          {trans.paymentStatus === "DP_SEBAGIAN" ? "DP — Sisa " : "BELUM LUNAS — Sisa "}
          {fmt(Math.max(0, trans.grandTotal - trans.paidAmount))}
        </div>
      )}
      <div className="my-2 border-t border-dashed border-gray-400" />
      {settings.receiptFooter && <p className="text-center text-[10px] font-bold">{settings.receiptFooter}</p>}
      <p className="text-center text-[9px] text-gray-600">Barang yang sudah diservis digaransi 1 bulan.</p>
    </div>
  );
}
