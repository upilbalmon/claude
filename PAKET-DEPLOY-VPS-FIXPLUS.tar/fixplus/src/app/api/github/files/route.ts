import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { loadCreds, listBackupFiles } from "@/lib/github-backup";

// D68 — GET /api/github/files?requesterUsername=
// Daftar file cadangan di folder repo GitHub (terbaru dulu).
export async function GET(req: NextRequest) {
  const actor = await resolveActor(req.nextUrl.searchParams.get("requesterUsername"));
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);
  try {
    const c = await loadCreds();
    if (!c.token || !c.repo) {
      return errAction("GitHub belum terhubung — simpan token & repo terlebih dahulu", 400);
    }
    const files = await listBackupFiles(
      c.token,
      c.repo,
      c.branch ?? "main",
      c.folder ?? "fixplus-backup"
    );
    return NextResponse.json({ ok: true, repo: c.repo, files });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("github files error", e);
    return errAction(msg, 400);
  }
}
