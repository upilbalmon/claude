"use client";

// ============================================================================
// LAPORAN — Tahap 5A (D48, disetujui user 11 Nov 2026, jawaban a–h)
// Satu pintu laporan dari data yang sudah ada:
//  5A.1 Ringkasan Keuangan (omzet kotor − diskon − void − REFUND = omzet net)
//  5A.2 Laba kotor (Admin saja — jawaban g; catatan "sebagian tanpa HPP" — jawaban h)
//  5A.3 Penjualan per kategori / metode bayar / kasir / teknisi
//  5A.4 Servis aktif + SELESAI belum diambil (umur, sorot >30) + masa garansi (jawaban f)
//  5A.5 Poin & kinerja teknisi
//  5A.6 Daftar piutang (BON + DP sebagian)
//  5A.7 Nilai stok + stok menipis (Admin saja — jawaban g)
//  5A.8 Grafik per hari (bar HTML/CSS, tanpa library)
//  5A.9 Rekap omzet bruto bulanan (UMKM) + ekspor CSV
//  5A.10 Integrasi kartu D37 (void & refund harian) — satu pintu di sini
//  5A.11 Rekap omzet harian (D90) — tabel per hari sesuai filter periode + TOTAL + CSV
// D60 — laporan dikelompokkan MULTI-TAB (keputusan user 12 Nov 2026):
//  TAB Ringkasan = 5A.1 + 5A.8 · TAB Penjualan = 5A.3×4 + 5A.9 ·
//  TAB Servis & Teknisi = 5A.4 + 5A.5 · TAB Piutang & Void = 5A.6 + 5A.10 (Admin) ·
//  TAB Inventaris = 5A.7 (Admin). Blok 5A.9 & 5A.10 dipindah agar satu grup
//  berdekatan; data, API, dan angka TIDAK berubah — murni penataan UI.
// Semua angka dihitung server; laba/nilai stok divalidasi Admin di API (bukan cuma UI).
// ============================================================================

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  BarChart3,
  Boxes,
  Download,
  HandCoins,
  ShieldCheck,
  ShoppingCart,
  Wrench,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  FinCountChip,
  FinFootTd,
  FinRow,
  FinTd,
  FinTh,
  FinTfoot,
} from "@/components/app/fin-table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"; // D60 — multi-tab
import { formatCurrency, formatDate, dayKeyWIB } from "@/lib/format";
import { downloadCsv, stampDay, type CsvRow } from "@/lib/csv";
import { SPARE_CATEGORY_LABEL } from "@/lib/spare-category";
import { REPAIR_STATUS_LABEL } from "@/lib/app-types";
import type { SafeUser } from "@/lib/app-types";

// ===== tipe respons API =====
type SalesReport = {
  from: string; to: string; isAdmin: boolean;
  ringkasan: {
    omzetKotor: number; diskonTotal: number; refundTotal: number; refundCount: number;
    omzetNet: number; txCount: number; servisCount: number; avgTicket: number;
    voidCount: number; voidTotal: number;
    hppTotal: number | null; labaKotor: number | null; tanpaHppCount: number | null;
  };
  perMethod: { metode: string; penjualan: number; refund: number; net: number; count: number }[];
  perKasir: { kasir: string; penjualan: number; refund: number; net: number; count: number }[];
  perKategori: { kategori: string; omzet: number; qty: number; hpp: number | null }[];
  perTeknisi: { teknisi: string; tiket: number; jasa: number; poin: number }[];
  daily: { day: string; omzet: number; refund: number; net: number; count: number; servisCount: number; hpp: number | null }[];
};
type ServicesReport = {
  from: string; to: string;
  aktifTotal: number;
  aktifPerStatus: { status: string; count: number }[];
  aktif: { id: number; serviceId: string; customerName: string; deviceModel: string; status: string; teknisi: string | null; umurHari: number; total: number }[];
  belumDiambilTotal: number;
  belumDiambil: { id: number; serviceId: string; customerName: string; deviceModel: string; completedAt: string; umurHari: number; total: number }[];
  garansi: { id: number; serviceId: string; customerName: string; deviceModel: string; completedAt: string; warrantyDays: number; berakhirPada: string; sisaHari: number }[];
  kinerja: { teknisi: string; selesai: number; omzetJasa: number; poin: number; sulit: number }[];
};
type PiutangReport = {
  rows: { id: number; invoiceNumber: string; customerName: string; timestamp: string; createdBy: string; status: string; total: number; dibayar: number; sisa: number; umurHari: number }[];
  totalSisa: number; totalBon: number; totalDp: number; count: number;
};
type StockReport = {
  rows: { id: number; name: string; sku: string; kategori: string; kategoriLabel: string; stock: number; minStock: number; costPrice: number; sellPrice: number; nilaiBeli: number; nilaiJual: number; menipis: boolean }[];
  perKategori: { kategori: string; kategoriLabel: string; nilaiBeli: number; nilaiJual: number; item: number; unit: number }[];
  menipis: StockReport["rows"];
  totalNilaiBeli: number; totalNilaiJual: number; count: number;
};
type MonthlyReport = {
  year: number; isAdmin: boolean;
  rows: { bulan: number; label: string; omzetKotor: number; refund: number; omzetNet: number; count: number; hpp: number | null; labaKotor: number | null }[];
  totalOmzetKotor: number; totalRefund: number; totalNet: number; totalCount: number;
};
type VoidReportMini = {
  from: string; to: string;
  voids: { rows: { name: string; count: number; total: number }[]; detailsCount: number };
  refunds: { rows: { name: string; count: number; total: number }[]; detailsCount: number };
};

type Preset = "HARI_INI" | "7_HARI" | "BULAN_INI" | "KUSTOM";

const KATEGORI_LABEL: Record<string, string> = {
  ...SPARE_CATEGORY_LABEL,
  SPAREPART: "Sparepart",
};

// D90 — label tanggal harian "Sen, 16 Nov 2026" dari kunci "YYYY-MM-DD" (kalender WIB)
const HARIAN_TGL_FMT = new Intl.DateTimeFormat("id-ID", { weekday: "short", day: "2-digit", month: "short", year: "numeric" });
function tglHarian(day: string): string {
  return HARIAN_TGL_FMT.format(new Date(`${day}T00:00:00Z`));
}

// D60 — kelompok tab Laporan; Inventaris hanya Admin (5A.7 memang Admin-only)
type LaporanTabKey = "ringkasan" | "penjualan" | "servis" | "piutang" | "inventaris";
const TABS_LAPORAN: {
  key: LaporanTabKey;
  label: string;
  icon: typeof BarChart3;
  adminOnly?: boolean;
}[] = [
  { key: "ringkasan", label: "Ringkasan", icon: BarChart3 },
  { key: "penjualan", label: "Penjualan", icon: ShoppingCart },
  { key: "servis", label: "Servis & Teknisi", icon: Wrench },
  { key: "piutang", label: "Piutang & Void", icon: HandCoins },
  { key: "inventaris", label: "Inventaris", icon: Boxes, adminOnly: true },
];

async function apiJson<T>(url: string): Promise<T> {
  const res = await fetch(url);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string }).error ?? "Terjadi kesalahan");
  return data as T;
}

export function LaporanSection({ user }: { user: SafeUser }) {
  const isAdmin = user.role === "Admin";
  const q = `requesterUsername=${encodeURIComponent(user.username)}`;

  const today = dayKeyWIB(new Date());
  const [preset, setPreset] = useState<Preset>("HARI_INI");
  const [from, setFrom] = useState(today);
  const [to, setTo] = useState(today);

  const [sales, setSales] = useState<SalesReport | null>(null);
  const [services, setServices] = useState<ServicesReport | null>(null);
  const [piutang, setPiutang] = useState<PiutangReport | null>(null);
  const [stock, setStock] = useState<StockReport | null>(null);
  const [monthly, setMonthly] = useState<MonthlyReport | null>(null);
  const [voidMini, setVoidMini] = useState<VoidReportMini | null>(null);
  const [year, setYear] = useState(Number(today.slice(0, 4)));
  const [voidDay, setVoidDay] = useState(today);
  const [error, setError] = useState("");
  // D60 — tab laporan aktif; bila sesi pindah dari Admin ke non-Admin di tab
  // Inventaris, kembali ke Ringkasan agar tidak menampilkan tab kosong
  const [tabLaporan, setTabLaporan] = useState<LaporanTabKey>("ringkasan");
  useEffect(() => {
    if (!isAdmin && tabLaporan === "inventaris") setTabLaporan("ringkasan");
  }, [isAdmin, tabLaporan]);

  // ganti preset → set rentang (WIB)
  function applyPreset(p: Preset) {
    setPreset(p);
    if (p === "HARI_INI") {
      setFrom(today);
      setTo(today);
    } else if (p === "7_HARI") {
      setFrom(dayKeyWIB(new Date(Date.now() - 6 * 86400000)));
      setTo(today);
    } else if (p === "BULAN_INI") {
      setFrom(`${today.slice(0, 8)}01`);
      setTo(today);
    }
  }

  const loadRange = useCallback(async (f: string, t: string) => {
    setError("");
    try {
      const [s, sv, p] = await Promise.all([
        apiJson<SalesReport>(`/api/reports/sales?from=${f}&to=${t}&${q}`),
        apiJson<ServicesReport>(`/api/reports/services?from=${f}&to=${t}&${q}`),
        apiJson<PiutangReport>(`/api/reports/piutang?${q}`),
      ]);
      setSales(s);
      setServices(sv);
      setPiutang(p);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Gagal memuat laporan");
    }
  }, [q]);

  const loadAdmin = useCallback(async () => {
    if (!isAdmin) return;
    try {
      const [st, mo, vm] = await Promise.all([
        apiJson<StockReport>(`/api/reports/stock?${q}`),
        apiJson<MonthlyReport>(`/api/reports/monthly?year=${year}&${q}`),
        apiJson<VoidReportMini>(`/api/reports/void?from=${voidDay}&to=${voidDay}`),
      ]);
      setStock(st);
      setMonthly(mo);
      // API void mengembalikan details juga — simpan versi ringkas
      setVoidMini({ ...vm, voids: { ...vm.voids, detailsCount: vm.voids.rows.reduce((s, r) => s + r.count, 0) }, refunds: { ...vm.refunds, detailsCount: vm.refunds.rows.reduce((s, r) => s + r.count, 0) } });
    } catch (e) {
      // 403 dsb. — kartu admin tetap disembunyikan angkanya
      setError(e instanceof Error ? e.message : "Gagal memuat laporan admin");
    }
  }, [isAdmin, q, year, voidDay]);

  useEffect(() => {
    void loadRange(from, to);
  }, [loadRange, from, to]);

  useEffect(() => {
    void loadAdmin();
  }, [loadAdmin]);

  // ===== ekspor CSV (5A.9) =====
  function exportCsv(nama: string, rows: CsvRow[]) {
    downloadCsv(`laporan-${nama}-${stampDay(from)}-${stampDay(to)}`, rows);
  }

  const maxDaily = useMemo(() => {
    if (!sales) return 0;
    // D90 — skala bar = bar terbesar yang tampil (omzet ATAU laba harian; dulu pakai hpp mentah)
    return Math.max(1, ...sales.daily.map((d) => Math.max(d.omzet, sales.isAdmin ? Math.max(0, d.net - (d.hpp ?? 0)) : 0)));
  }, [sales]);

  // D90 — total kolom rekap harian (5A.11); invarian: Σ harian = angka ringkasan 5A.1
  const harianTotal = useMemo(() => {
    const rows = sales?.daily ?? [];
    return {
      omzet: rows.reduce((s, d) => s + d.omzet, 0),
      refund: rows.reduce((s, d) => s + d.refund, 0),
      net: rows.reduce((s, d) => s + d.net, 0),
      count: rows.reduce((s, d) => s + d.count, 0),
      servis: rows.reduce((s, d) => s + d.servisCount, 0),
      hpp: rows.reduce((s, d) => s + (d.hpp ?? 0), 0),
      laba: rows.reduce((s, d) => s + d.net - (d.hpp ?? 0), 0),
    };
  }, [sales]);

  const presetBtn = (p: Preset, label: string) => (
    <Button
      key={p}
      type="button"
      variant={preset === p ? "default" : "outline"}
      size="sm"
      className="h-9 rounded-xl"
      onClick={() => applyPreset(p)}
    >
      {label}
    </Button>
  );

  return (
    <div className="space-y-4">
      {/* ===== Header + filter periode ===== */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="me-auto flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-xl bg-primary/10">
            <BarChart3 className="size-5 text-primary" aria-hidden />
          </div>
          <div>
            <h1 className="text-xl font-bold">Laporan</h1>
            <p className="text-sm text-muted-foreground">
              {formatDate(new Date(`${from}T00:00:00Z`))} — {formatDate(new Date(`${to}T00:00:00Z`))}
              {!isAdmin && " · angka laba & nilai stok hanya untuk Admin"}
            </p>
          </div>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        {presetBtn("HARI_INI", "Hari ini")}
        {presetBtn("7_HARI", "7 hari")}
        {presetBtn("BULAN_INI", "Bulan ini")}
        {presetBtn("KUSTOM", "Rentang kustom")}
        {preset === "KUSTOM" && (
          <>
            <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="h-9 w-40 rounded-xl" aria-label="Dari tanggal" />
            <span className="text-sm text-muted-foreground">s/d</span>
            <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="h-9 w-40 rounded-xl" aria-label="Sampai tanggal" />
          </>
        )}
        <FinCountChip count={sales?.ringkasan.txCount ?? 0} unit="nota" />
      </div>
      {error && (
        <p className="rounded-xl bg-red-50 px-3 py-2 text-sm font-semibold text-red-800">{error}</p>
      )}

      {/* ===== D60 — kelompok multi-tab laporan ===== */}
      <Tabs value={tabLaporan} onValueChange={(v) => setTabLaporan(v as LaporanTabKey)} className="gap-4">
        <TabsList className="h-auto w-full flex-wrap justify-start gap-1 rounded-2xl p-1.5">
          {TABS_LAPORAN.filter((t) => !t.adminOnly || isAdmin).map((t) => {
            const Icon = t.icon;
            return (
              <TabsTrigger
                key={t.key}
                value={t.key}
                data-testid={`tab-laporan-${t.key}`}
                className="gap-1.5 rounded-xl px-3 py-1.5 text-[13px] data-[state=active]:font-bold data-[state=active]:text-primary"
              >
                <Icon className="size-4" aria-hidden />
                {t.label}
              </TabsTrigger>
            );
          })}
        </TabsList>

        {/* ===== TAB Ringkasan — 5A.1 KPI + 5A.8 grafik harian ===== */}
        <TabsContent value="ringkasan" data-testid="panel-laporan-ringkasan" className="mt-0 space-y-4">
      {/* ===== 5A.1 Ringkasan Keuangan ===== */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-2">
          <CardDescription>Ringkasan Keuangan (void tidak dihitung)</CardDescription>
          <CardTitle className="text-base">5A.1 — Omzet & kesehatan kas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">
            <Kpi label="Omzet Kotor" value={sales?.ringkasan.omzetKotor} />
            <Kpi label="Diskon" value={sales?.ringkasan.diskonTotal} />
            <Kpi label={`Refund (${sales?.ringkasan.refundCount ?? 0})`} value={sales?.ringkasan.refundTotal} negatif />
            <Kpi label="Omzet Net" value={sales?.ringkasan.omzetNet} strong />
            <Kpi label="Jumlah Transaksi" value={(sales?.ringkasan.txCount ?? 0).toLocaleString("id-ID")} teks />
            <Kpi label="Rata-rata / Nota" value={sales?.ringkasan.avgTicket} />
            <Kpi label="Nota Servis" value={(sales?.ringkasan.servisCount ?? 0).toLocaleString("id-ID")} teks />
            <Kpi label={`Void (${sales?.ringkasan.voidCount ?? 0})`} value={sales?.ringkasan.voidTotal} negatif />
            {isAdmin && (
              <>
                <Kpi label="HPP (modal terjual)" value={sales?.ringkasan.hppTotal} />
                <Kpi label="Laba Kotor" value={sales?.ringkasan.labaKotor} strong />
              </>
            )}
          </div>
          {/* jawaban h — catatan, bukan pemotongan tanggal */}
          {isAdmin && (sales?.ringkasan.tanpaHppCount ?? 0) > 0 && (
            <p className="mt-3 flex items-start gap-2 rounded-xl bg-amber-50 px-3 py-2 text-[12px] text-amber-900">
              <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden />
              <span>
                <b>{sales!.ringkasan.tanpaHppCount} nota</b> di periode ini tanpa HPP (data lama sebelum pencatatan
                harga beli) — laba kotor bisa lebih tinggi dari kenyataan.
              </span>
            </p>
          )}
        </CardContent>
      </Card>

      {/* ===== 5A.8 Grafik per hari ===== */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-2">
          <CardDescription>Grafik per hari (bar HTML/CSS)</CardDescription>
          <CardTitle className="text-base">5A.8 — Omzet{isAdmin ? " & Laba" : ""} / Jumlah Servisan</CardTitle>
        </CardHeader>
        <CardContent>
          {!sales || sales.daily.length === 0 ? (
            <p className="text-sm text-muted-foreground">Tidak ada data.</p>
          ) : (
            <div className="flex items-end gap-1 overflow-x-auto pb-2 pt-4" data-testid="grafik-harian">
              {sales.daily.map((d) => {
                const hOmzet = Math.round((d.omzet / maxDaily) * 120);
                const hLaba = isAdmin && d.hpp !== null ? Math.round((Math.max(0, d.net - d.hpp) / maxDaily) * 120) : 0;
                return (
                  <div key={d.day} className="flex min-w-[34px] flex-1 flex-col items-center gap-1" title={`${d.day} · Omzet ${formatCurrency(d.omzet)} · Refund ${formatCurrency(d.refund)} · Net ${formatCurrency(d.net)}${isAdmin && d.hpp !== null ? ` · Laba ${formatCurrency(d.net - d.hpp)} · HPP ${formatCurrency(d.hpp)}` : ""} · ${d.count} nota · ${d.servisCount} servis`}>
                    <div className="flex h-[130px] items-end gap-0.5">
                      <div className="w-2.5 rounded-t bg-primary/80" style={{ height: `${Math.max(d.omzet > 0 ? 3 : 0, hOmzet)}px` }} />
                      {isAdmin && (
                        <div className="w-2.5 rounded-t bg-emerald-500/80" style={{ height: `${Math.max(hLaba > 0 ? 3 : 0, hLaba)}px` }} />
                      )}
                    </div>
                    <span className="text-[10px] tabular-nums text-muted-foreground">{d.day.slice(8)}</span>
                    {d.servisCount > 0 && <span className="text-[9px] font-semibold text-primary">{d.servisCount} srv</span>}
                  </div>
                );
              })}
            </div>
          )}
          <p className="mt-2 text-[11px] text-muted-foreground">
            <span className="mr-3 inline-flex items-center gap-1"><span className="inline-block size-2.5 rounded-sm bg-primary/80" aria-hidden />Omzet</span>
            {isAdmin && <span className="inline-flex items-center gap-1"><span className="inline-block size-2.5 rounded-sm bg-emerald-500/80" aria-hidden />Laba harian</span>}
            <span className="ml-3">× srv = jumlah servisan</span>
          </p>
        </CardContent>
      </Card>

      {/* ===== 5A.11 Rekap Omzet Harian (D90) — tabel per hari sesuai filter periode di atas;
           Σ harian selalu = angka ringkasan 5A.1 (satu sumber data: sales.daily) ===== */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-2">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <CardTitle className="text-base">5A.11 — Rekap Omzet Harian</CardTitle>
              <CardDescription>
                {sales?.daily.length ?? 0} hari dalam periode aktif · total net {formatCurrency(harianTotal.net)}{isAdmin && ` · laba kotor ${formatCurrency(harianTotal.laba)}`}
              </CardDescription>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="h-9 rounded-xl"
              data-testid="btn-csv-rekap-harian"
              onClick={() => {
                if (!sales) return;
                exportCsv("rekap-harian", [
                  ["Tanggal", "Omzet Kotor", "Refund", "Omzet Net", "Nota", "Servis", ...(sales.isAdmin ? ["HPP", "Laba Kotor"] : [])],
                  ...sales.daily.map((d) => [d.day, d.omzet, d.refund, d.net, d.count, d.servisCount, ...(sales.isAdmin ? [d.hpp ?? 0, d.net - (d.hpp ?? 0)] : [])]),
                  ["TOTAL", harianTotal.omzet, harianTotal.refund, harianTotal.net, harianTotal.count, harianTotal.servis, ...(sales.isAdmin ? [harianTotal.hpp, harianTotal.laba] : [])],
                ]);
              }}
            >
              <Download className="size-4" aria-hidden /> CSV
            </Button>
          </div>
        </CardHeader>
        <CardContent className="overflow-x-auto xl:overflow-x-visible">
          <Table>
            <TableHeader>
              <TableRow>
                <FinTh>Tanggal</FinTh><FinTh align="right">Omzet Kotor</FinTh><FinTh align="right">Refund</FinTh><FinTh align="right">Omzet Net</FinTh><FinTh align="right">Nota</FinTh><FinTh align="right">Servis</FinTh>
                {isAdmin && <FinTh align="right">HPP</FinTh>}
                {isAdmin && <FinTh align="right">Laba Kotor</FinTh>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {(sales?.daily ?? []).map((d) => (
                <FinRow key={d.day} data-testid={`rekap-harian-${d.day}`} muted={d.net === 0 && d.count === 0}>
                  <FinTd className="font-medium">{tglHarian(d.day)}</FinTd>
                  <FinTd className="text-right tabular-nums">{formatCurrency(d.omzet)}</FinTd>
                  <FinTd className="text-right tabular-nums text-red-700">{d.refund > 0 ? `-${formatCurrency(d.refund)}` : "—"}</FinTd>
                  <FinTd className="text-right font-semibold tabular-nums">{formatCurrency(d.net)}</FinTd>
                  <FinTd className="text-right tabular-nums">{d.count}</FinTd>
                  <FinTd className="text-right tabular-nums">{d.servisCount}</FinTd>
                  {isAdmin && <FinTd className="text-right tabular-nums">{formatCurrency(d.hpp ?? 0)}</FinTd>}
                  {isAdmin && <FinTd className="text-right font-semibold tabular-nums">{formatCurrency(d.net - (d.hpp ?? 0))}</FinTd>}
                </FinRow>
              ))}
              {!sales && <BarisKosong col={isAdmin ? 8 : 6} />}
            </TableBody>
            {sales && (
              <FinTfoot>
                <TableRow>
                  <FinFootTd>TOTAL PERIODE</FinFootTd>
                  <FinFootTd className="text-right tabular-nums">{formatCurrency(harianTotal.omzet)}</FinFootTd>
                  <FinFootTd className="text-right tabular-nums">{formatCurrency(harianTotal.refund)}</FinFootTd>
                  <FinFootTd className="text-right tabular-nums">{formatCurrency(harianTotal.net)}</FinFootTd>
                  <FinFootTd className="text-right tabular-nums">{harianTotal.count}</FinFootTd>
                  <FinFootTd className="text-right tabular-nums">{harianTotal.servis}</FinFootTd>
                  {isAdmin && <FinFootTd className="text-right tabular-nums">{formatCurrency(harianTotal.hpp)}</FinFootTd>}
                  {isAdmin && <FinFootTd className="text-right tabular-nums">{formatCurrency(harianTotal.laba)}</FinFootTd>}
                </TableRow>
              </FinTfoot>
            )}
          </Table>
        </CardContent>
      </Card>
        </TabsContent>

        {/* ===== TAB Penjualan — 5A.3 (kategori/metode/kasir/teknisi) + 5A.9 rekap bulanan ===== */}
        <TabsContent value="penjualan" data-testid="panel-laporan-penjualan" className="mt-0 space-y-4">
      <div className="grid gap-4 xl:grid-cols-2">
        {/* ===== 5A.3 per kategori ===== */}
        <ReportCard title="5A.3 — Penjualan per Kategori" desc="4 jalur pendapatan (referensi bisnis konter)" onCsv={() => exportCsv("kategori", [
          ["Kategori", "Qty", "Omzet", ...(isAdmin ? ["HPP"] : [])],
          ...(sales?.perKategori.map((r) => [KATEGORI_LABEL[r.kategori] ?? r.kategori, r.qty, r.omzet, ...(isAdmin ? [r.hpp ?? 0] : [])]) ?? []),
        ])}>
          <Table>
            <TableHeader>
              <TableRow><FinTh>Kategori</FinTh><FinTh align="right">Qty</FinTh><FinTh align="right">Omzet</FinTh>{isAdmin && <FinTh align="right">HPP</FinTh>}</TableRow>
            </TableHeader>
            <TableBody>
              {(sales?.perKategori ?? []).map((r) => (
                <FinRow key={r.kategori}>
                  <FinTd className="font-medium">{KATEGORI_LABEL[r.kategori] ?? r.kategori}</FinTd>
                  <FinTd className="text-right tabular-nums">{r.qty}</FinTd>
                  <FinTd className="text-right tabular-nums">{formatCurrency(r.omzet)}</FinTd>
                  {isAdmin && <FinTd className="text-right tabular-nums">{r.hpp !== null ? formatCurrency(r.hpp) : "—"}</FinTd>}
                </FinRow>
              ))}
              {(sales?.perKategori.length ?? 0) === 0 && <BarisKosong col={isAdmin ? 4 : 3} />}
            </TableBody>
          </Table>
        </ReportCard>

        {/* ===== 5A.3 per metode bayar ===== */}
        <ReportCard title="5A.3 — Penjualan per Metode Bayar" desc="Tunai, Transfer, QRIS, E-Wallet, Kartu" onCsv={() => exportCsv("metode", [
          ["Metode", "Nota", "Penjualan", "Refund", "Net"],
          ...(sales?.perMethod.map((r) => [r.metode, r.count, r.penjualan, r.refund, r.net]) ?? []),
        ])}>
          <Table>
            <TableHeader>
              <TableRow><FinTh>Metode</FinTh><FinTh align="right">Nota</FinTh><FinTh align="right">Penjualan</FinTh><FinTh align="right">Refund</FinTh><FinTh align="right">Net</FinTh></TableRow>
            </TableHeader>
            <TableBody>
              {(sales?.perMethod ?? []).map((r) => (
                <FinRow key={r.metode}>
                  <FinTd className="font-medium">{r.metode}</FinTd>
                  <FinTd className="text-right tabular-nums">{r.count}</FinTd>
                  <FinTd className="text-right tabular-nums">{formatCurrency(r.penjualan)}</FinTd>
                  <FinTd className="text-right tabular-nums text-red-700">{r.refund > 0 ? `-${formatCurrency(r.refund)}` : "—"}</FinTd>
                  <FinTd className="text-right font-semibold tabular-nums">{formatCurrency(r.net)}</FinTd>
                </FinRow>
              ))}
              {(sales?.perMethod.length ?? 0) === 0 && <BarisKosong col={5} />}
            </TableBody>
          </Table>
        </ReportCard>

        {/* ===== 5A.3 per kasir ===== */}
        <ReportCard title="5A.3 — Penjualan per Kasir" desc="Oleh kasir yang membuat nota" onCsv={() => exportCsv("kasir", [
          ["Kasir", "Nota", "Penjualan", "Refund", "Net"],
          ...(sales?.perKasir.map((r) => [r.kasir, r.count, r.penjualan, r.refund, r.net]) ?? []),
        ])}>
          <Table>
            <TableHeader>
              <TableRow><FinTh>Kasir</FinTh><FinTh align="right">Nota</FinTh><FinTh align="right">Penjualan</FinTh><FinTh align="right">Refund</FinTh><FinTh align="right">Net</FinTh></TableRow>
            </TableHeader>
            <TableBody>
              {(sales?.perKasir ?? []).map((r) => (
                <FinRow key={r.kasir}>
                  <FinTd className="font-medium">{r.kasir}</FinTd>
                  <FinTd className="text-right tabular-nums">{r.count}</FinTd>
                  <FinTd className="text-right tabular-nums">{formatCurrency(r.penjualan)}</FinTd>
                  <FinTd className="text-right tabular-nums text-red-700">{r.refund > 0 ? `-${formatCurrency(r.refund)}` : "—"}</FinTd>
                  <FinTd className="text-right font-semibold tabular-nums">{formatCurrency(r.net)}</FinTd>
                </FinRow>
              ))}
              {(sales?.perKasir.length ?? 0) === 0 && <BarisKosong col={5} />}
            </TableBody>
          </Table>
        </ReportCard>

        {/* ===== 5A.3 jasa per teknisi ===== */}
        <ReportCard title="5A.3 — Omzet Jasa per Teknisi" desc="Dari nota servis yang di-checkout" onCsv={() => exportCsv("jasa-teknisi", [
          ["Teknisi", "Tiket", "Omzet Jasa", "Poin"],
          ...(sales?.perTeknisi.map((r) => [r.teknisi, r.tiket, r.jasa, r.poin]) ?? []),
        ])}>
          <Table>
            <TableHeader>
              <TableRow><FinTh>Teknisi</FinTh><FinTh align="right">Tiket</FinTh><FinTh align="right">Omzet Jasa</FinTh><FinTh align="right">Poin</FinTh></TableRow>
            </TableHeader>
            <TableBody>
              {(sales?.perTeknisi ?? []).map((r) => (
                <FinRow key={r.teknisi}>
                  <FinTd className="font-medium">{r.teknisi}</FinTd>
                  <FinTd className="text-right tabular-nums">{r.tiket}</FinTd>
                  <FinTd className="text-right tabular-nums">{formatCurrency(r.jasa)}</FinTd>
                  <FinTd className="text-right tabular-nums">{r.poin.toLocaleString("id-ID")}</FinTd>
                </FinRow>
              ))}
              {(sales?.perTeknisi.length ?? 0) === 0 && <BarisKosong col={4} />}
            </TableBody>
          </Table>
        </ReportCard>
      </div>

      {/* ===== 5A.9 Rekap Omzet Bruto Bulanan — grup Penjualan (dipindah D60) ===== */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-2">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <CardTitle className="text-base">5A.9 — Rekap Omzet Bruto Bulanan (dasar pajak UMKM)</CardTitle>
              <CardDescription>
                Tahun {monthly?.year ?? year} · total net {formatCurrency(monthly?.totalNet ?? 0)}{isAdmin && ` · laba kotor tahunan ${formatCurrency(monthly?.rows.reduce((s, r) => s + (r.labaKotor ?? 0), 0) ?? 0)}`}
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <select
                value={year}
                onChange={(e) => setYear(Number(e.target.value))}
                className="h-9 rounded-xl border bg-background px-3 text-sm"
                aria-label="Pilih tahun"
              >
                {Array.from({ length: 5 }, (_, i) => Number(today.slice(0, 4)) - i).map((y) => (
                  <option key={y} value={y}>{y}</option>
                ))}
              </select>
              <Button variant="outline" size="sm" className="h-9 rounded-xl" onClick={() => {
                if (!monthly) return;
                downloadCsv(`laporan-rekap-bulanan-${monthly.year}`, [
                  ["Bulan", "Omzet Kotor", "Refund", "Omzet Net", "Nota", ...(monthly.isAdmin ? ["HPP", "Laba Kotor"] : [])],
                  ...monthly.rows.map((r) => [r.label, r.omzetKotor, r.refund, r.omzetNet, r.count, ...(monthly.isAdmin ? [r.hpp ?? 0, r.labaKotor ?? 0] : [])]),
                  ["TOTAL", monthly.totalOmzetKotor, monthly.totalRefund, monthly.totalNet, monthly.totalCount, ...(monthly.isAdmin ? [monthly.rows.reduce((s, r) => s + (r.hpp ?? 0), 0), monthly.rows.reduce((s, r) => s + (r.labaKotor ?? 0), 0)] : [])],
                ]);
              }}>
                <Download className="size-4" aria-hidden /> CSV
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="overflow-x-auto xl:overflow-x-visible">
          <Table>
            <TableHeader>
              <TableRow>
                <FinTh>Bulan</FinTh><FinTh align="right">Omzet Kotor</FinTh><FinTh align="right">Refund</FinTh><FinTh align="right">Omzet Net</FinTh><FinTh align="right">Nota</FinTh>
                {isAdmin && <FinTh align="right">HPP</FinTh>}
                {isAdmin && <FinTh align="right">Laba Kotor</FinTh>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {(monthly?.rows ?? []).map((r) => (
                <FinRow key={r.bulan} muted={r.omzetNet === 0 && r.count === 0}>
                  <FinTd className="font-medium">{r.label}</FinTd>
                  <FinTd className="text-right tabular-nums">{formatCurrency(r.omzetKotor)}</FinTd>
                  <FinTd className="text-right tabular-nums text-red-700">{r.refund > 0 ? `-${formatCurrency(r.refund)}` : "—"}</FinTd>
                  <FinTd className="text-right font-semibold tabular-nums">{formatCurrency(r.omzetNet)}</FinTd>
                  <FinTd className="text-right tabular-nums">{r.count}</FinTd>
                  {isAdmin && <FinTd className="text-right tabular-nums">{r.hpp !== null ? formatCurrency(r.hpp) : "—"}</FinTd>}
                  {isAdmin && <FinTd className="text-right tabular-nums">{r.labaKotor !== null ? formatCurrency(r.labaKotor) : "—"}</FinTd>}
                </FinRow>
              ))}
              {!monthly && <BarisKosong col={isAdmin ? 7 : 5} />}
            </TableBody>
            {monthly && (
              <FinTfoot>
                <TableRow>
                  <FinFootTd>TOTAL {monthly.year}</FinFootTd>
                  <FinFootTd className="text-right tabular-nums">{formatCurrency(monthly.totalOmzetKotor)}</FinFootTd>
                  <FinFootTd className="text-right tabular-nums">{formatCurrency(monthly.totalRefund)}</FinFootTd>
                  <FinFootTd className="text-right tabular-nums">{formatCurrency(monthly.totalNet)}</FinFootTd>
                  <FinFootTd className="text-right tabular-nums">{monthly.totalCount}</FinFootTd>
                  {isAdmin && <FinFootTd className="text-right tabular-nums">{formatCurrency(monthly.rows.reduce((s, r) => s + (r.hpp ?? 0), 0))}</FinFootTd>}
                  {isAdmin && <FinFootTd className="text-right tabular-nums">{formatCurrency(monthly.rows.reduce((s, r) => s + (r.labaKotor ?? 0), 0))}</FinFootTd>}
                </TableRow>
              </FinTfoot>
            )}
          </Table>
        </CardContent>
      </Card>
        </TabsContent>

        {/* ===== TAB Servis & Teknisi — 5A.4 kartu servis + 5A.5 kinerja ===== */}
        <TabsContent value="servis" data-testid="panel-laporan-servis" className="mt-0 space-y-4">
      {/* ===== 5A.4 Kartu servis ===== */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base"><Wrench className="size-4 text-primary" aria-hidden /> 5A.4 — Kartu Servis</CardTitle>
          <CardDescription>Aktif {services?.aktifTotal ?? 0} · Selesai belum diambil {services?.belumDiambilTotal ?? 0} · Dalam garansi {services?.garansi.length ?? 0}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {(services?.aktifPerStatus ?? []).map((s) => (
              <Badge key={s.status} variant={s.count > 0 ? "default" : "outline"} className="rounded-full">
                {REPAIR_STATUS_LABEL[s.status] ?? s.status}: {s.count}
              </Badge>
            ))}
          </div>
          <div>
            <p className="mb-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">Selesai belum diambil (umur hari — sorot &gt; 30)</p>
            <div className="overflow-x-auto rounded-xl border xl:overflow-x-visible">
              <Table>
                <TableHeader>
                  <TableRow><FinTh>ID</FinTh><FinTh>Pelanggan</FinTh><FinTh>Perangkat</FinTh><FinTh>Selesai</FinTh><FinTh align="right">Umur</FinTh><FinTh align="right">Total</FinTh></TableRow>
                </TableHeader>
                <TableBody>
                  {(services?.belumDiambil ?? []).map((r) => (
                    <FinRow key={r.id} className={r.umurHari > 30 ? "bg-red-50" : undefined}>
                      <FinTd className="font-mono text-[11px]">{r.serviceId}</FinTd>
                      <FinTd>{r.customerName}</FinTd>
                      <FinTd>{r.deviceModel}</FinTd>
                      <FinTd>{formatDate(r.completedAt)}</FinTd>
                      <FinTd className="text-right tabular-nums">
                        {r.umurHari > 30 ? <Badge className="bg-red-600 text-white">{r.umurHari} hari</Badge> : `${r.umurHari} hari`}
                      </FinTd>
                      <FinTd className="text-right tabular-nums">{formatCurrency(r.total)}</FinTd>
                    </FinRow>
                  ))}
                  {(services?.belumDiambil.length ?? 0) === 0 && <BarisKosong col={6} />}
                </TableBody>
              </Table>
            </div>
          </div>
          <div>
            <p className="mb-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">Masih dalam masa garansi (klaim garansi menyusul di 5D)</p>
            <div className="overflow-x-auto rounded-xl border xl:overflow-x-visible">
              <Table>
                <TableHeader>
                  <TableRow><FinTh>ID</FinTh><FinTh>Pelanggan</FinTh><FinTh>Perangkat</FinTh><FinTh>Ditambahkan garansi</FinTh><FinTh>Berakhir</FinTh><FinTh align="right">Sisa</FinTh></TableRow>
                </TableHeader>
                <TableBody>
                  {(services?.garansi ?? []).map((g) => (
                    <FinRow key={g.id}>
                      <FinTd className="font-mono text-[11px]">{g.serviceId}</FinTd>
                      <FinTd>{g.customerName}</FinTd>
                      <FinTd>{g.deviceModel}</FinTd>
                      <FinTd>{formatDate(g.completedAt)} · {g.warrantyDays} hari</FinTd>
                      <FinTd>{formatDate(g.berakhirPada)}</FinTd>
                      <FinTd className="text-right tabular-nums">{g.sisaHari} hari</FinTd>
                    </FinRow>
                  ))}
                  {(services?.garansi.length ?? 0) === 0 && <BarisKosong col={6} />}
                </TableBody>
              </Table>
            </div>
          </div>
        </CardContent>
      </Card>

        {/* ===== 5A.5 kinerja teknisi ===== */}
        <ReportCard title="5A.5 — Kinerja Teknisi" desc="Tiket selesai dalam periode (poin & kesulitan)" onCsv={() => exportCsv("kinerja-teknisi", [
          ["Teknisi", "Selesai", "Omzet Jasa", "Poin", "Kesulitan Tinggi"],
          ...(services?.kinerja.map((k) => [k.teknisi, k.selesai, k.omzetJasa, k.poin, k.sulit]) ?? []),
        ])}>
          <Table>
            <TableHeader>
              <TableRow><FinTh>Teknisi</FinTh><FinTh align="right">Selesai</FinTh><FinTh align="right">Omzet Jasa</FinTh><FinTh align="right">Poin</FinTh><FinTh align="right">Sulit</FinTh></TableRow>
            </TableHeader>
            <TableBody>
              {(services?.kinerja ?? []).map((k) => (
                <FinRow key={k.teknisi}>
                  <FinTd className="font-medium">{k.teknisi}</FinTd>
                  <FinTd className="text-right tabular-nums">{k.selesai}</FinTd>
                  <FinTd className="text-right tabular-nums">{formatCurrency(k.omzetJasa)}</FinTd>
                  <FinTd className="text-right font-semibold tabular-nums">{k.poin.toLocaleString("id-ID")}</FinTd>
                  <FinTd className="text-right tabular-nums">{k.sulit}</FinTd>
                </FinRow>
              ))}
              {(services?.kinerja.length ?? 0) === 0 && <BarisKosong col={5} />}
            </TableBody>
          </Table>
        </ReportCard>
        </TabsContent>

        {/* ===== TAB Piutang & Void — 5A.6 piutang + 5A.10 void/refund (Admin) ===== */}
        <TabsContent value="piutang" data-testid="panel-laporan-piutang" className="mt-0 space-y-4">
        {/* ===== 5A.6 piutang ===== */}
        <ReportCard
          title="5A.6 — Piutang (BON + DP Sebagian)"
          desc={`Sisa total ${formatCurrency(piutang?.totalSisa ?? 0)} · Bon ${formatCurrency(piutang?.totalBon ?? 0)} · DP ${formatCurrency(piutang?.totalDp ?? 0)}`}
          onCsv={() => exportCsv("piutang", [
            ["Invoice", "Pelanggan", "Tanggal", "Status", "Total", "Dibayar", "Sisa", "Umur (hari)"],
            ...(piutang?.rows.map((r) => [r.invoiceNumber, r.customerName, formatDate(r.timestamp), r.status === "BON_PIUTANG" ? "Bon" : "DP Sebagian", r.total, r.dibayar, r.sisa, r.umurHari]) ?? []),
          ])}
        >
          <Table>
            <TableHeader>
              <TableRow><FinTh>Invoice</FinTh><FinTh>Pelanggan</FinTh><FinTh align="right">Sisa</FinTh><FinTh align="right">Umur</FinTh></TableRow>
            </TableHeader>
            <TableBody>
              {(piutang?.rows ?? []).map((r) => (
                <FinRow key={r.id}>
                  <FinTd className="font-mono text-[11px]">{r.invoiceNumber}</FinTd>
                  <FinTd>{r.customerName}</FinTd>
                  <FinTd className="text-right font-semibold tabular-nums">{formatCurrency(r.sisa)}</FinTd>
                  <FinTd className="text-right tabular-nums">{r.umurHari} hari</FinTd>
                </FinRow>
              ))}
              {(piutang?.rows.length ?? 0) === 0 && <BarisKosong col={4} />}
            </TableBody>
            {(piutang?.rows.length ?? 0) > 0 && (
              <FinTfoot>
                <TableRow>
                  <FinFootTd colSpan={2}>Total sisa ({piutang!.count} nota)</FinFootTd>
                  <FinFootTd className="text-right tabular-nums">{formatCurrency(piutang!.totalSisa)}</FinFootTd>
                  <FinFootTd />
                </TableRow>
              </FinTfoot>
            )}
          </Table>
          <p className="mt-2 text-[11px] text-muted-foreground">Pelunasan bertahap (terima pembayaran sisa) menyusul di Tahap 5B.</p>
        </ReportCard>

      {/* ===== 5A.10 integrasi D37 — void & refund harian (grup Piutang — dipindah D60) ===== */}
      {isAdmin && (
        <Card className="rounded-2xl">
          <CardHeader className="pb-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <CardTitle className="flex items-center gap-2 text-base"><ShieldCheck className="size-4 text-primary" aria-hidden /> Void &amp; Refund Harian <Badge variant="outline" className="rounded-full text-[10px]">D37</Badge></CardTitle>
                <CardDescription>Satu pintu dari tab Laporan; kartu lengkap per dokumen tetap tersedia di tab Kasir</CardDescription>
              </div>
              <Input type="date" value={voidDay} onChange={(e) => setVoidDay(e.target.value)} className="h-9 w-40 rounded-xl" aria-label="Tanggal laporan void" />
            </div>
          </CardHeader>
          <CardContent className="grid gap-4 xl:grid-cols-2">
            <div>
              <p className="mb-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">Dibatalkan (void) per kasir — {voidMini?.voids.detailsCount ?? 0} dokumen</p>
              <div className="overflow-x-auto rounded-xl border xl:overflow-x-visible">
                <Table>
                  <TableHeader>
                    <TableRow><FinTh>Kasir</FinTh><FinTh align="right">Dokumen</FinTh><FinTh align="right">Nilai</FinTh></TableRow>
                  </TableHeader>
                  <TableBody>
                    {(voidMini?.voids.rows ?? []).map((r) => (
                      <FinRow key={r.name}>
                        <FinTd className="font-medium">{r.name}</FinTd>
                        <FinTd className="text-right tabular-nums">{r.count}</FinTd>
                        <FinTd className="text-right tabular-nums">{formatCurrency(r.total)}</FinTd>
                      </FinRow>
                    ))}
                    {(voidMini?.voids.rows.length ?? 0) === 0 && <BarisKosong col={3} />}
                  </TableBody>
                </Table>
              </div>
            </div>
            <div>
              <p className="mb-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">Refund per kasir — {voidMini?.refunds.detailsCount ?? 0} dokumen</p>
              <div className="overflow-x-auto rounded-xl border xl:overflow-x-visible">
                <Table>
                  <TableHeader>
                    <TableRow><FinTh>Kasir</FinTh><FinTh align="right">Dokumen</FinTh><FinTh align="right">Nilai</FinTh></TableRow>
                  </TableHeader>
                  <TableBody>
                    {(voidMini?.refunds.rows ?? []).map((r) => (
                      <FinRow key={r.name}>
                        <FinTd className="font-medium">{r.name}</FinTd>
                        <FinTd className="text-right tabular-nums">{r.count}</FinTd>
                        <FinTd className="text-right tabular-nums">{formatCurrency(r.total)}</FinTd>
                      </FinRow>
                    ))}
                    {(voidMini?.refunds.rows.length ?? 0) === 0 && <BarisKosong col={3} />}
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
        </TabsContent>

        {/* ===== TAB Inventaris (khusus Admin) — 5A.7 nilai stok & stok menipis ===== */}
        <TabsContent value="inventaris" data-testid="panel-laporan-inventaris" className="mt-0 space-y-4">
      {/* ===== 5A.7 stok (Admin) ===== */}
      {isAdmin && (
        <Card className="rounded-2xl">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base"><Boxes className="size-4 text-primary" aria-hidden /> 5A.7 — Nilai Stok & Stok Menipis</CardTitle>
            <CardDescription>
              Total beli {formatCurrency(stock?.totalNilaiBeli ?? 0)} · total jual {formatCurrency(stock?.totalNilaiJual ?? 0)} · Admin saja (jawaban g)
            </CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4 xl:grid-cols-2">
            <div className="overflow-x-auto rounded-xl border xl:overflow-x-visible">
              <Table>
                <TableHeader>
                  <TableRow><FinTh>Kategori</FinTh><FinTh align="right">Item</FinTh><FinTh align="right">Unit</FinTh><FinTh align="right">Nilai Beli</FinTh><FinTh align="right">Nilai Jual</FinTh></TableRow>
                </TableHeader>
                <TableBody>
                  {(stock?.perKategori ?? []).map((k) => (
                    <FinRow key={k.kategori}>
                      <FinTd className="font-medium">{k.kategoriLabel}</FinTd>
                      <FinTd className="text-right tabular-nums">{k.item}</FinTd>
                      <FinTd className="text-right tabular-nums">{k.unit}</FinTd>
                      <FinTd className="text-right tabular-nums">{formatCurrency(k.nilaiBeli)}</FinTd>
                      <FinTd className="text-right tabular-nums">{formatCurrency(k.nilaiJual)}</FinTd>
                    </FinRow>
                  ))}
                  {(stock?.perKategori.length ?? 0) === 0 && <BarisKosong col={5} />}
                </TableBody>
              </Table>
            </div>
            <div className="overflow-x-auto rounded-xl border xl:overflow-x-visible">
              <Table>
                <TableHeader>
                  <TableRow><FinTh>Stok menipis (≤ min)</FinTh><FinTh align="right">Stok</FinTh><FinTh align="right">Min</FinTh></TableRow>
                </TableHeader>
                <TableBody>
                  {(stock?.menipis ?? []).map((r) => (
                    <FinRow key={r.id}>
                      <FinTd>{r.name}</FinTd>
                      <FinTd className="text-right tabular-nums">{r.stock}</FinTd>
                      <FinTd className="text-right tabular-nums">{r.minStock}</FinTd>
                    </FinRow>
                  ))}
                  {(stock?.menipis.length ?? 0) === 0 && <BarisKosong col={3} />}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
        </TabsContent>
      </Tabs>

      <p className="flex items-start gap-2 rounded-xl bg-muted/60 px-3 py-2 text-[11px] text-muted-foreground">
        <HandCoins className="mt-0.5 size-4 shrink-0" aria-hidden />
        <span>
          Angka void/refund mengikuti aturan D36/D38; omzet net sudah mengurangi dokumen refund aktif. Tahap 5B
          (Pengeluaran, Pelunasan Piutang, Tutup Kasir Harian, Laba Rugi Bulanan, Aging, Arus Kas) menyusul —
          rencana: <b>RENCANA-TAHAP-5-LAPORAN-REVISI2.md</b>.
        </span>
      </p>
    </div>
  );
}

// ===== komponen kecil =====
function Kpi({ label, value, negatif, strong, teks }: { label: string; value?: number | string | null; negatif?: boolean; strong?: boolean; teks?: boolean }) {
  return (
    <div className="rounded-xl border bg-muted/30 px-3 py-2">
      <p className="text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className={`mt-0.5 text-lg font-bold tabular-nums ${negatif ? "text-red-700" : ""} ${strong ? "text-primary" : ""}`}>
        {value === undefined || value === null ? "—" : teks ? value : formatCurrency(Number(value))}
      </p>
    </div>
  );
}

function ReportCard({ title, desc, onCsv, children }: { title: string; desc: string; onCsv?: () => void; children: React.ReactNode }) {
  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <div>
            <CardTitle className="text-base">{title}</CardTitle>
            <CardDescription>{desc}</CardDescription>
          </div>
          {onCsv && (
            <Button variant="outline" size="sm" className="h-8 rounded-xl" onClick={onCsv}>
              <Download className="size-3.5" aria-hidden /> CSV
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="overflow-x-auto xl:overflow-x-visible">{children}</CardContent>
    </Card>
  );
}

function BarisKosong({ col }: { col: number }) {
  return (
    <TableRow>
      <TableCell colSpan={col} className="py-6 text-center text-sm text-muted-foreground">
        Tidak ada data pada periode ini
      </TableCell>
    </TableRow>
  );
}
