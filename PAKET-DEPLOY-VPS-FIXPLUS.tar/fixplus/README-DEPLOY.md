# Panduan Deploy FixPlus di VPS (Paket Sumber — Opsi A)

Paket ini berisi **kode sumber lengkap** aplikasi FixPlus (kasir POS + servis HP)
beserta **database SQLite Anda saat ini** (`db/custom.db`). Aplikasi dibangun
(build) langsung di VPS.

> Kredensial backup (GitHub/Google Drive) dan `.env` asli **tidak** dibawa di
> dalam paket. Masukkan ulang kredensial lewat menu **Setting > Backup** di
> aplikasi setelah berjalan.

## Struktur Paket

```
fixplus/
├── src/                    # kode sumber aplikasi (Next.js)
├── public/                 # aset statis
├── prisma/schema.prisma    # skema database
├── scripts/prune-standalone.mjs  # skrip build (pemangkas paket, D86)
├── db/custom.db            # DATABASE ANDA (ikut terbawa)
├── package.json / package-lock.json
├── next.config.ts / tsconfig.json / postcss.config.mjs
├── components.json / eslint.config.mjs
├── .env.example            # contoh environment (tanpa rahasia)
├── README-DEPLOY.md        # file ini
└── deploy/
    ├── fixplus.service     # unit systemd (auto-start saat boot)
    ├── nginx-fixplus.conf  # contoh reverse proxy Nginx
    ├── backup-cron.sh      # backup harian DB + retensi 7 hari
    └── seed-admin.mjs      # buat akun admin awal (khusus DB baru)
```

## 1. Prasyarat VPS

- Ubuntu 22.04/24.04 atau Debian 12, arsitektur **x64**.
- Akses root/sudo.
- **Node.js 20.6+** (untuk `--env-file`). Instal bila belum ada:

  ```bash
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt install -y nodejs sqlite3
  ```

- Ruang kosong minimal 1,5 GB (node_modules + hasil build).
- RAM minimal 1,5 GB saat build (bila 1 GB, tambahkan swap 2 GB — lihat
  lampiran di bawah).

## 2. Ekstrak dan Letakkan Aplikasi

```bash
# contoh: paket diunggah ke /root
cd /opt
sudo tar xzf /root/PAKET-DEPLOY-VPS-FIXPLUS.tar.gz   # menghasilkan /opt/fixplus
sudo chown -R $USER:$USER /opt/fixplus
cd /opt/fixplus
```

## 3. Siapkan Environment

```bash
cp .env.example .env
nano .env
```

Isi `DATABASE_URL` dengan **path absolut** ke database:

```
DATABASE_URL="file:/opt/fixplus/db/custom.db"
```

Database `db/custom.db` di dalam paket adalah **salinan data Anda saat ini**
(akun, pelanggan, transaksi, tiket servis, dll). Jika ingin mulai dari database
kosong, lihat Bagian 9.

## 4. Instal Dependensi dan Build

```bash
npm ci
npx prisma generate
npm run build          # ± 2–4 menit
```

Hasil build adalah folder `.next/standalone/` — server produksi siap jalan
(`server.js`), dengan node_modules yang sudah dipangkas khusus untuk Linux x64
glibc (D86).

## 5. Uji Jalankan Manual

```bash
node .next/standalone/server.js
# buka http://IP-VPS:3000  → login dengan akun Anda (PIN sama seperti sekarang)
```

Tekan `Ctrl+C` untuk berhenti, lanjut ke langkah auto-start.

## 6. Auto-start dengan systemd

```bash
sudo cp deploy/fixplus.service /etc/systemd/system/
sudo nano /etc/systemd/system/fixplus.service   # cek User= dan path
sudo systemctl daemon-reload
sudo systemctl enable --now fixplus
sudo systemctl status fixplus                   # harus "active (running)"
```

Log aplikasi: `journalctl -u fixplus -f`

Secara default unit mengikat ke `127.0.0.1:3000` (hanya lewat Nginx). Jika
ingin akses langsung ke port 3000 tanpa Nginx, ubah `HOSTNAME=0.0.0.0` lalu
`sudo ufw allow 3000/tcp`.

## 7. Nginx + HTTPS (Disarankan)

```bash
sudo apt install -y nginx
sudo cp deploy/nginx-fixplus.conf /etc/nginx/sites-available/fixplus
sudo nano /etc/nginx/sites-available/fixplus     # ganti server_name
sudo ln -s /etc/nginx/sites-available/fixplus /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# SSL gratis Let's Encrypt (butuh domain mengarah ke IP VPS):
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d domain-anda.com
```

Firewall:

```bash
sudo ufw allow OpenSSH && sudo ufw allow 80/tcp && sudo ufw allow 443/tcp
sudo ufw enable
```

## 8. Backup Otomatis Harian

```bash
# sqlite3 sudah terinstal di langkah 1
sudo nano deploy/backup-cron.sh      # cek path APP_DIR/DB_PATH/BACKUP_DIR
chmod +x deploy/backup-cron.sh
sudo crontab -e                      # tambahkan baris:
0 2 * * * /opt/fixplus/deploy/backup-cron.sh >> /var/log/fixplus-backup.log 2>&1
```

Backup tersimpan di `/var/backups/fixplus/` dengan retensi 7 hari dan diuji
integritasnya. Fitur backup GitHub/Google Drive di dalam aplikasi tetap bisa
dipakai — isi ulang kredensial via **Setting > Backup**.

**Cara pulihkan** (misal file backup `custom-2026-11-19_020000.db`):

```bash
sudo systemctl stop fixplus
cp /var/backups/fixplus/custom-2026-11-19_020000.db /opt/fixplus/db/custom.db
sudo systemctl start fixplus
```

## 9. Mulai dari Database Kosong (Opsional)

Lewati bagian ini jika memakai data bawaan paket.

```bash
rm db/custom.db
npx prisma db push                    # buat struktur database baru
node --env-file=.env deploy/seed-admin.mjs   # akun awal admin / PIN 1234
```

Login pertama: username `admin`, PIN `1234` — segera ganti PIN di menu
pengguna. Sesuai alur D92, login pertama hari itu akan diminta mengisi kas laci.

## 10. Pembaruan Aplikasi di Masa Depan

```bash
deploy/backup-cron.sh                 # amankan data dulu
# timpa source baru (src/, package.json, dll) — JANGAN menimpa db/custom.db
npm ci && npx prisma generate && npm run build
sudo systemctl restart fixplus
```

## Lampiran: Tambah Swap (RAM 1 GB)

```bash
sudo fallocate -l 2G /swapfile && sudo chmod 600 /swapfile
sudo mkswap /swapfile && sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

## Masalah Umum

| Gejala | Solusi |
|---|---|
| Build gagal "Killed" | RAM kurang → tambah swap (lampiran), build ulang |
| `P2023 Conversion failed` di log | File DB bukan format Prisma/SQLite yang benar → pastikan `DATABASE_URL` menunjuk `db/custom.db` dari paket |
| Port 3000 tak bisa diakses | Unit systemd default bind 127.0.0.1 — pakai Nginx, atau ubah `HOSTNAME=0.0.0.0` |
| Nginx 413 saat restore upload | `client_max_body_size` sudah diatur 50M di contoh conf — naikkan bila perlu |
