import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { resolveActor, errAction } from "@/lib/action-guard";
import { withHeal } from "@/lib/users-guard";
import { dayKeyWIB } from "@/lib/format";

// D73 — Absensi Karyawan.
//
// D92 — ALUR BARU: absen masuk & keluar OTOMATIS.
//  - Absen masuk dicatat SERVER saat login berhasil (/api/auth/login — jam
//    server WIB, klien tidak bisa memalsukan tanggal/jam).
//  - Absen keluar dicatat SERVER saat "Tutup Laci" (/api/drawer PUT) yang
//    sekaligus mengakhiri sesi (logout).
//  Jalur absen mandiri (POST/PUT tanpa userId/id) DIHAPUS — endpoint ini kini
//  hanya untuk CATATAN MANUAL Admin (mis. IZIN/SAKIT/ALPA/LIBUR atau lupa
//  absen), koreksi, dan penghapusan.
//
// Catat manual (HANYA Admin): POST dengan `userId` + tanggal, PUT dengan `id`
// untuk koreksi, DELETE hapus.
//
// Satu catatan per orang per hari (indeks unik Attendance_userId_date_key).
// userName disimpan sebagai snapshot agar riwayat tetap terbaca setelah akun
// dihapus (userId → NULL, ON DELETE SET NULL).

const STATUS_LIST = ["HADIR", "TERLAMBAT", "IZIN", "SAKIT", "ALPA", "LIBUR"] as const;
const STATUS_LABEL: Record<string, string> = {
  HADIR: "Hadir",
  TERLAMBAT: "Terlambat",
  IZIN: "Izin",
  SAKIT: "Sakit",
  ALPA: "Alpa",
  LIBUR: "Libur",
};
// Status hari-libur (IZIN/SAKIT/ALPA/LIBUR) ditetapkan Admin — absen otomatis
// tidak menimpanya (aturan D92 dijalankan di lib/drawer.ts & /api/drawer).

const WIB_OFFSET_MS = 7 * 60 * 60 * 1000;

/** "HH:mm" WIB dari sebuah instant */
function timeStrWIB(d: Date): string {
  return new Date(d.getTime() + WIB_OFFSET_MS).toISOString().slice(11, 16);
}

/** Gabungkan "YYYY-MM-DD" + "HH:mm" → instant (zona WIB, UTC+7) */
function parseWibDateTime(date: string, hhmm: string): Date | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return null;
  if (!/^([01]\d|2[0-3]):([0-5]\d)$/.test(hhmm)) return null;
  const d = new Date(`${date}T${hhmm}:00+07:00`);
  return Number.isNaN(d.getTime()) ? null : d;
}

function isValidDateKey(s: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(`${s}T00:00:00+07:00`);
  return !Number.isNaN(d.getTime()) && dayKeyWIB(d) === s;
}

function serialize(r: {
  id: number; userId: number | null; userName: string; date: string;
  checkIn: Date | null; checkOut: Date | null; status: string;
  notes: string; recordedBy: string; createdAt: Date; updatedAt: Date;
}) {
  return {
    id: r.id,
    userId: r.userId,
    userName: r.userName,
    date: r.date,
    checkIn: r.checkIn ? r.checkIn.toISOString() : null,
    checkOut: r.checkOut ? r.checkOut.toISOString() : null,
    status: r.status,
    notes: r.notes,
    recordedBy: r.recordedBy,
    createdAt: r.createdAt.toISOString(),
    updatedAt: r.updatedAt.toISOString(),
  };
}

// ===== GET /api/attendance?requesterUsername=U&month=YYYY-MM =====
// Admin: semua catatan bulan itu + daftar pengguna (untuk Catat Manual).
// Non-admin: hanya catatan sendiri. Selalu ikut `myToday` (status hari ini).
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const actor = await resolveActor(url.searchParams.get("requesterUsername"), false);
  if (!actor) return errAction("Sesi tidak valid — silakan masuk kembali", 401);

  const month = url.searchParams.get("month") || dayKeyWIB(new Date()).slice(0, 7);
  if (!/^\d{4}-\d{2}$/.test(month)) {
    return errAction("Format bulan tidak valid (harus YYYY-MM)", 400);
  }

  try {
    return await withHeal(async () => {
      const isAdmin = actor.role === "Admin";
      const dateFilter = { startsWith: `${month}-` } as const;
      const records = await db.attendance.findMany({
        where: isAdmin ? { date: dateFilter } : { userId: actor.id, date: dateFilter },
        orderBy: [{ date: "desc" }, { userName: "asc" }],
      });

      const users = isAdmin
        ? await db.user.findMany({
            select: { id: true, name: true, username: true, role: true },
            orderBy: [{ role: "asc" }, { name: "asc" }],
          })
        : null;

      const today = dayKeyWIB(new Date());
      const myToday = await db.attendance.findFirst({
        where: { userId: actor.id, date: today },
      });

      return NextResponse.json({
        month,
        today,
        isAdmin,
        records: records.map(serialize),
        users,
        myToday: myToday ? serialize(myToday) : null,
      });
    });
  } catch (e) {
    console.error("attendance GET error", e);
    return NextResponse.json({ error: "Gagal memuat absensi" }, { status: 500 });
  }
}

// ===== POST /api/attendance =====
// Catat manual Admin: { requesterUsername, userId, date, status, checkIn?, checkOut?, notes? }.
// (D92 — absen masuk mandiri dihapus: kini otomatis saat login.)
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;

  try {
    return await withHeal(async () => {
      // --- catat manual Admin ---
      if (body.userId !== undefined && body.userId !== null && body.userId !== "") {
        const admin = await resolveActor(body.requesterUsername, true);
        if (!admin) return errAction("Hanya Admin yang dapat mencatat absensi manual", 403);

        const userId = Number(body.userId);
        if (!Number.isInteger(userId) || userId <= 0) {
          return errAction("Karyawan wajib dipilih", 400);
        }
        const target = await db.user.findUnique({ where: { id: userId } });
        if (!target) return errAction("Akun karyawan tidak ditemukan", 404);

        const date = String(body.date ?? "").trim();
        if (!isValidDateKey(date)) {
          return errAction("Tanggal tidak valid (harus YYYY-MM-DD)", 400);
        }
        const today = dayKeyWIB(new Date());
        if (date > today) {
          return errAction("Tidak dapat mencatat absensi untuk tanggal masa depan", 400);
        }

        const status = String(body.status ?? "HADIR").trim().toUpperCase();
        if (!STATUS_LIST.includes(status as (typeof STATUS_LIST)[number])) {
          return errAction(`Status harus salah satu dari: ${STATUS_LIST.join(", ")}`, 400);
        }

        const ciRaw = String(body.checkIn ?? "").trim();
        const coRaw = String(body.checkOut ?? "").trim();
        const checkIn = ciRaw ? parseWibDateTime(date, ciRaw) : null;
        const checkOut = coRaw ? parseWibDateTime(date, coRaw) : null;
        if (ciRaw && !checkIn) return errAction("Jam masuk tidak valid (format HH:mm)", 400);
        if (coRaw && !checkOut) return errAction("Jam keluar tidak valid (format HH:mm)", 400);
        if (checkIn && checkOut && checkOut < checkIn) {
          return errAction("Jam keluar tidak boleh lebih awal dari jam masuk", 400);
        }

        const dobel = await db.attendance.findFirst({ where: { userId, date } });
        if (dobel) {
          return NextResponse.json(
            { error: `${target.name} sudah punya catatan absensi tanggal ${date} — gunakan Edit untuk mengubahnya` },
            { status: 409 }
          );
        }

        const notes = String(body.notes ?? "").trim().slice(0, 300);
        const created = await db.attendance.create({
          data: {
            userId: target.id,
            userName: target.name,
            date,
            checkIn,
            checkOut,
            status,
            notes,
            recordedBy: admin.name,
          },
        });

        await db.auditLog.create({
          data: {
            action: "ABSENSI_MANUAL",
            details: `${admin.name} mencatat absensi ${target.name} (${date}) — ${STATUS_LABEL[status] ?? status}${checkIn ? `, masuk ${timeStrWIB(checkIn)}` : ""}${checkOut ? `, keluar ${timeStrWIB(checkOut)}` : ""}${notes ? `; catatan: ${notes}` : ""}`,
            performedBy: admin.name,
          },
        });

        return NextResponse.json(serialize(created), { status: 201 });
      }

      // --- absen masuk mandiri DIHAPUS (D92) — kini otomatis saat login ---
      return errAction(
        "Absen masuk kini otomatis saat login — tidak perlu (dan tidak bisa) dicatat manual dari sini",
        400
      );
    });
  } catch (e) {
    console.error("attendance POST error", e);
    return NextResponse.json({ error: "Gagal menyimpan absensi" }, { status: 500 });
  }
}

// ===== PUT /api/attendance =====
// Koreksi manual Admin: { requesterUsername, id, status?, checkIn?, checkOut?, notes? }.
// (D92 — absen keluar mandiri dihapus: kini otomatis lewat "Tutup Laci".)
export async function PUT(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;

  try {
    return await withHeal(async () => {
      // --- (b) koreksi manual Admin ---
      if (body.id !== undefined && body.id !== null && body.id !== "") {
        const admin = await resolveActor(body.requesterUsername, true);
        if (!admin) return errAction("Hanya Admin yang dapat mengubah catatan absensi", 403);

        const id = Number(body.id);
        const rec = await db.attendance.findUnique({ where: { id } });
        if (!rec) return errAction("Catatan absensi tidak ditemukan", 404);

        const data: {
          status?: string; checkIn?: Date | null; checkOut?: Date | null; notes?: string;
        } = {};

        if (body.status !== undefined) {
          const status = String(body.status).trim().toUpperCase();
          if (!STATUS_LIST.includes(status as (typeof STATUS_LIST)[number])) {
            return errAction(`Status harus salah satu dari: ${STATUS_LIST.join(", ")}`, 400);
          }
          data.status = status;
        }

        if (body.checkIn !== undefined) {
          const raw = String(body.checkIn ?? "").trim();
          if (!raw) data.checkIn = null;
          else {
            const d = parseWibDateTime(rec.date, raw);
            if (!d) return errAction("Jam masuk tidak valid (format HH:mm)", 400);
            data.checkIn = d;
          }
        }
        if (body.checkOut !== undefined) {
          const raw = String(body.checkOut ?? "").trim();
          if (!raw) data.checkOut = null;
          else {
            const d = parseWibDateTime(rec.date, raw);
            if (!d) return errAction("Jam keluar tidak valid (format HH:mm)", 400);
            data.checkOut = d;
          }
        }
        const finalIn = data.checkIn !== undefined ? data.checkIn : rec.checkIn;
        const finalOut = data.checkOut !== undefined ? data.checkOut : rec.checkOut;
        if (finalIn && finalOut && finalOut < finalIn) {
          return errAction("Jam keluar tidak boleh lebih awal dari jam masuk", 400);
        }

        if (body.notes !== undefined) data.notes = String(body.notes ?? "").trim().slice(0, 300);

        const updated = await db.attendance.update({ where: { id }, data });

        await db.auditLog.create({
          data: {
            action: "EDIT_ABSENSI",
            details: `${admin.name} mengubah absensi ${rec.userName} (${rec.date}) — ${STATUS_LABEL[updated.status] ?? updated.status}${updated.checkIn ? `, masuk ${timeStrWIB(updated.checkIn)}` : ", tanpa jam masuk"}${updated.checkOut ? `, keluar ${timeStrWIB(updated.checkOut)}` : ""}`,
            performedBy: admin.name,
          },
        });

        return NextResponse.json(serialize(updated));
      }

      // --- absen keluar mandiri DIHAPUS (D92) — kini otomatis lewat "Tutup Laci" ---
      return errAction(
        "Absen keluar kini otomatis lewat tombol \"Tutup Laci\" (sekaligus mengakhiri sesi)",
        400
      );
    });
  } catch (e) {
    console.error("attendance PUT error", e);
    return NextResponse.json({ error: "Gagal memperbarui absensi" }, { status: 500 });
  }
}

// ===== DELETE /api/attendance?requesterUsername=U&id=N =====
// HANYA Admin — hapus catatan keliru (mis. dobel / salah orang).
export async function DELETE(req: NextRequest) {
  const url = new URL(req.url);
  const admin = await resolveActor(url.searchParams.get("requesterUsername"), true);
  if (!admin) return errAction("Hanya Admin yang dapat menghapus catatan absensi", 403);

  const id = Number(url.searchParams.get("id"));
  if (!Number.isInteger(id) || id <= 0) {
    return errAction("ID catatan absensi tidak valid", 400);
  }

  try {
    return await withHeal(async () => {
      const rec = await db.attendance.findUnique({ where: { id } });
      if (!rec) return errAction("Catatan absensi tidak ditemukan", 404);

      await db.attendance.delete({ where: { id } });
      await db.auditLog.create({
        data: {
          action: "HAPUS_ABSENSI",
          details: `${admin.name} menghapus absensi ${rec.userName} (${rec.date} — ${STATUS_LABEL[rec.status] ?? rec.status})`,
          performedBy: admin.name,
        },
      });

      return NextResponse.json({ ok: true });
    });
  } catch (e) {
    console.error("attendance DELETE error", e);
    return NextResponse.json({ error: "Gagal menghapus absensi" }, { status: 500 });
  }
}
