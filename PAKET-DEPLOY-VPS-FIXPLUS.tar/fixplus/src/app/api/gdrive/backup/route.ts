import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { performDriveBackup } from "@/lib/gdrive";

// D67 — POST /api/gdrive/backup — cadangkan database sekarang ke Google Drive.
// Body JSON: { requesterUsername, method: "auto"|"oauth"|"sa" }
// Mengunggah file .db penuh (checkpoint WAL dulu) dengan nama bertanggal
// waktu-Jakarta, lalu memangkas cadangan lama di atas batas keepLast.
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as {
    requesterUsername?: unknown;
    method?: unknown;
  };
  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const methodRaw = String(body.method ?? "auto");
  const method = methodRaw === "oauth" || methodRaw === "sa" ? methodRaw : "auto";
  try {
    const out = await performDriveBackup(actor.name, method);
    return NextResponse.json({
      ok: true,
      method: out.method,
      fileName: out.fileName,
      size: out.size,
      pruned: out.pruned,
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("gdrive backup error", e);
    return errAction(msg, 400);
  }
}
