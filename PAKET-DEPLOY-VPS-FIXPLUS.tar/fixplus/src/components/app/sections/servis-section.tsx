"use client";

// RepairSection.kt (3356 baris) → versi web (Tahap 4 — SERVIS HP)
// Alur persis referensi: daftar per grup tanggal (mobile) / tabel keuangan (desktop, D10),
// filter tab status + pencarian (nama/model/ID), Cek Estimasi, terima servis
// (Reguler / Kilat), alur 9 status dengan tombol status berikutnya:
//   ANTRI→DIAGNOSA (konfirmasi) · DIAGNOSA→KONFIRMASI (dialog diagnosa: catatan,
//   jasa, sparepart) · KONFIRMASI→DISETUJUI/DIBATALKAN (persetujuan pelanggan) ·
//   DISETUJUI→DIKERJAKAN→SELESAI (konfirmasi) · SELESAI→Bayar/POS (checkout) ·
//   DIAMBIL terkunci. Rollback status via form edit wajib otorisasi Admin (PIN).
// Non-admin tidak melihat tiket DIAMBIL (4.8). Nota A5, WA per status, estimator
// ada di servis-extras.tsx; integrasi checkout ke Kasir lewat onCheckoutRepair.
// D21: (1) struk pelunasan hanya dibuat di Kasir — dialog nota servis hanya
// tanda terima + Unduh JPG/Bagikan; (2) footer Simpan/Batal dialog Terima Servis
// selalu terlihat (body saja yang scroll); (3) diagnosa tersimpan → dialog
// konfirmasi + kirim WhatsApp ke pelanggan muncul otomatis (DiagnosaSentWaDialog).
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Ban,
  CalendarDays,
  Calculator,
  Info,
  Lock,
  PackageCheck,
  PackagePlus,
  Pencil,
  Plus,
  Printer,
  Search,
  Send,
  ShoppingCart,
  Trash2,
  Wrench,
  X,
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Table, TableBody, TableHeader } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import {
  FinCountChip,
  FinFootTd,
  FinIndexTd,
  FinRow,
  FinTd,
  FinTh,
  FinTfoot,
} from "@/components/app/fin-table";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { formatCurrency, formatDateTime } from "@/lib/format";
import {
  DEFAULT_DAMAGES,
  DEFAULT_DEVICE_MODELS,
  REPAIR_STATUS_BADGE,
  difficultyPoints,
  menungguPartAktif,
  parseRequestedParts,
  parseUsedParts,
  pendingRequestedParts,
  repairStatusNext,
  requestedPartsTotal,
  serviceIdOf,
  type RequestedPart,
} from "@/lib/repair-utils";
import { REPAIR_STATUS_LABEL, type SafeUser } from "@/lib/app-types";
import {
  CustomerPickerDialog,
  DiagnosaSentWaDialog,
  PriceEstimationDialog,
  RepairReceiptDialog,
  SparePartPickerDialog,
  WhatsAppEditorDialog,
} from "@/components/app/sections/servis-extras";
import { partsSumOf, type Repair, type SparePartLite } from "@/components/app/sections/servis-receipt";

type CustomerLite = { id: number; name: string; phone: string; loyaltyPoints: number };
type TechnicianLite = { id: number; name: string; phone: string; isAvailable: boolean };
// D89: editTransactionDate ikut diambil — toggle "Edit Tanggal Transaksi"
// kini juga mengatur form Terima Servis (bukan hanya kasir).
type SettingsLite = {
  shopName: string;
  address: string;
  phone: string;
  receiptFooter: string;
  editTransactionDate?: boolean;
};

async function apiJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string }).error ?? "Terjadi kesalahan");
  return data as T;
}

type SelectedPart = { part: SparePartLite; qty: number };
// D64 — part external (toko lain) di tiket: nama & harga diketik petugas,
// partId 0 di usedPartsJson (isExternal true) — tanpa stok, ikut total & HPP.
type ExternalPartInput = { name: string; qty: number; sellPrice: number; costPrice: number };

export function ServisSection({
  user,
  onCheckoutRepair,
  openServiceForm,
  onOpenServiceFormConsumed,
}: {
  user: SafeUser;
  onCheckoutRepair: (r: Repair) => void;
  // D72: pemicu "Tambah Transaksi → Terima Servis" dari halaman Kasir —
  // form tiket baru langsung terbuka; dipakai sekali lalu parent mereset.
  openServiceForm?: boolean;
  onOpenServiceFormConsumed?: () => void;
}) {
  const { toast } = useToast();
  const isAdmin = user.role === "Admin";

  const [repairs, setRepairs] = useState<Repair[]>([]);
  const [customers, setCustomers] = useState<CustomerLite[]>([]);
  const [technicians, setTechnicians] = useState<TechnicianLite[]>([]);
  const [parts, setParts] = useState<SparePartLite[]>([]);
  const [settings, setSettings] = useState<SettingsLite>({
    shopName: "Servis HP & POS",
    address: "",
    phone: "",
    receiptFooter: "Terima kasih telah berbelanja!",
  });
  const [waMap, setWaMap] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);

  // 4.8: admin melihat semua, peran lain tidak melihat tiket Diambil
  const repairsToShow = useMemo(
    () => (isAdmin ? repairs : repairs.filter((r) => r.status !== "DIAMBIL")),
    [repairs, isAdmin]
  );

  const [searchInput, setSearchInput] = useState("");
  const [appliedQuery, setAppliedQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("Semua");
  const [estimasiOpen, setEstimasiOpen] = useState(false);

  // dialog utama
  const [detailRepair, setDetailRepair] = useState<Repair | null>(null);
  const [deleteRepair, setDeleteRepair] = useState<Repair | null>(null);
  const [waRepair, setWaRepair] = useState<Repair | null>(null);
  const [receiptRepair, setReceiptRepair] = useState<Repair | null>(null);
  const [diagnosaRepair, setDiagnosaRepair] = useState<Repair | null>(null);
  // D21: tiket yang baru saja diagnosa-nya disimpan → pemicu dialog kirim WA pelanggan
  const [diagnosaWaRepair, setDiagnosaWaRepair] = useState<Repair | null>(null);
  const [konfirmasiRepair, setKonfirmasiRepair] = useState<Repair | null>(null);
  const [standardConfirm, setStandardConfirm] = useState<Repair | null>(null);
  const [busyStatus, setBusyStatus] = useState(false);
  // D28: tiket yang sparepart pesanannya sudah datang → dialog penanganan part
  const [partDatangRepair, setPartDatangRepair] = useState<Repair | null>(null);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      const [rp, cs, ts, ps, st] = await Promise.all([
        apiJson<Repair[]>("/api/repairs"),
        apiJson<CustomerLite[]>("/api/customers"),
        apiJson<TechnicianLite[]>("/api/technicians"),
        apiJson<SparePartLite[]>("/api/spare-parts"),
        apiJson<SettingsLite & { waTemplates?: string }>("/api/settings"),
      ]);
      setRepairs(rp);
      setCustomers(cs);
      setTechnicians(ts);
      setParts(ps);
      setSettings({
        shopName: st.shopName,
        address: st.address,
        phone: st.phone,
        receiptFooter: st.receiptFooter,
        editTransactionDate: st.editTransactionDate === true,
      });
      try {
        const parsed = JSON.parse(st.waTemplates ?? "{}");
        if (parsed && typeof parsed === "object") setWaMap(parsed as Record<string, string>);
      } catch {
        /* template default dipakai */
      }
    } catch (e) {
      toast({
        title: "Gagal memuat data servis",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    load();
  }, [load]);

  // ===== Filter tab status (persis ScrollableTabRow: Semua + status yang ada datanya) =====
  const statusTabs = useMemo(() => {
    const present = Array.from(new Set(repairsToShow.map((r) => r.status)));
    const ordered = ["ANTRI", "DIAGNOSA", "KONFIRMASI", "DISETUJUI", "DIKERJAKAN", "SELESAI", "DIAMBIL", "DIBATALKAN", "TIDAK_BISA"].filter(
      (s) => present.includes(s)
    );
    // D28+D31: chip khusus "Menunggu Part" — hanya aktif setelah pelanggan
    // menyetujui penawaran (terkonfirmasi) & masih ada part pesanan belum datang
    const tabs: string[] = ["Semua", ...ordered];
    if (repairsToShow.some((r) => menungguPartAktif(r.status) && nPendingRequested(r) > 0)) tabs.push("MENUNGGU_PART");
    return tabs;
  }, [repairsToShow]);

  const filteredRepairs = useMemo(() => {
    const q = appliedQuery.trim().toLowerCase();
    return repairsToShow.filter((r) => {
      // D28+D31: chip "Menunggu Part" = tiket yang sudah dikonfirmasi pelanggan
      // (Disetujui ke atas) dan part pesanannya belum datang
      const okStatus =
        filterStatus === "Semua"
          ? true
          : filterStatus === "MENUNGGU_PART"
            ? menungguPartAktif(r.status) && nPendingRequested(r) > 0
            : r.status === filterStatus;
      const okQuery =
        q === "" ||
        r.customerName.toLowerCase().includes(q) ||
        r.deviceModel.toLowerCase().includes(q) ||
        serviceIdOf(r.createdAt).toLowerCase().includes(q) ||
        String(r.id) === q;
      return okStatus && okQuery;
    });
  }, [repairsToShow, filterStatus, appliedQuery]);

  // ===== Tombol status (persis onStatusClick RepairSection.kt) =====
  const onStatusClick = (repair: Repair) => {
    if (repair.status === "DIAMBIL") {
      toast({ title: "Transaksi ini sudah diambil & lunas pembayaran. Status terkunci!" });
      return;
    }
    switch (repair.status) {
      case "DIAGNOSA":
        setDiagnosaRepair(repair);
        break;
      case "KONFIRMASI":
        setKonfirmasiRepair(repair);
        break;
      case "SELESAI":
        // persis referensi: klik status Selesai → checkout POS
        onCheckoutRepair(repair);
        break;
      default:
        // ANTRI/DISETUJUI/DIKERJAKAN → konfirmasi status berikutnya;
        // DIBATALKAN/TIDAK_BISA (final) → konfirmasi kembali ke Antri (next ?: ANTRI)
        setStandardConfirm(repair);
    }
  };

  const ubahStatus = async (repair: Repair, target: string): Promise<Repair | null> => {
    try {
      setBusyStatus(true);
      const updated = await apiJson<Repair>(`/api/repairs/${repair.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          op: "status",
          status: target,
          userRole: user.role,
          performedBy: user.name,
        }),
      });
      setRepairs((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
      toast({
        title: "Status diperbarui",
        description: `${updated.deviceModel} (${serviceIdOf(updated.createdAt)}): ${REPAIR_STATUS_LABEL[repair.status]} → ${REPAIR_STATUS_LABEL[updated.status]}`,
      });
      // SAH-3512/4.7: notifikasi WA per status — dibuka manual dari detail (persis referensi)
      return updated;
    } catch (e) {
      toast({
        title: "Gagal mengubah status",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
      return null;
    } finally {
      setBusyStatus(false);
      setStandardConfirm(null);
    }
  };

  const hapusTiket = async (repair: Repair) => {
    try {
      await apiJson(`/api/repairs/${repair.id}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requesterUsername: user.username }), // D34: diverifikasi server
      });
      setRepairs((prev) => prev.filter((r) => r.id !== repair.id));
      toast({ title: "Tiket servis dihapus", description: `${repair.deviceModel} — ${repair.customerName}` });
    } catch (e) {
      toast({
        title: "Gagal menghapus tiket",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    }
  };

  // ===== Form tambah/edit (Terima Servis) =====
  const [formOpen, setFormOpen] = useState(false);
  // D89: tanggal & waktu terima servis (datetime-local) — hanya boleh diubah
  // bila pengaturan "Edit Tanggal Transaksi" aktif (paritas D39 di kasir).
  const [terimaDate, setTerimaDate] = useState("");
  const [editRepairId, setEditRepairId] = useState(0);
  const [isQuickService, setIsQuickService] = useState(false);
  const [customerId, setCustomerId] = useState(0);
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [deviceModel, setDeviceModel] = useState("");
  const [serialImei, setSerialImei] = useState("");
  const [damage, setDamage] = useState("");
  const [technicianId, setTechnicianId] = useState<string>("none");
  const [serviceFee, setServiceFee] = useState("50000");
  const [estimatedCost, setEstimatedCost] = useState("");
  const [downPayment, setDownPayment] = useState("");
  const [difficulty, setDifficulty] = useState("Sedang");
  const [warrantyDays, setWarrantyDays] = useState("0");
  const [pointsReward, setPointsReward] = useState("");
  const [estimatedTime, setEstimatedTime] = useState("");
  const [notes, setNotes] = useState("");
  const [inputStatus, setInputStatus] = useState("ANTRI");
  const [originalStatus, setOriginalStatus] = useState("ANTRI");
  const [selectedPartsList, setSelectedPartsList] = useState<SelectedPart[]>([]);
  // D64: part external (toko lain) — langsung di tiket tanpa alur pesan→datang
  const [externalParts, setExternalParts] = useState<ExternalPartInput[]>([]);
  const [extDialogOpen, setExtDialogOpen] = useState(false);
  const [customerPickerOpen, setCustomerPickerOpen] = useState(false);
  const [partPickerOpen, setPartPickerOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [rollbackTarget, setRollbackTarget] = useState<string | null>(null);
  // kredensial Admin hasil otorisasi rollback (diverifikasi ulang server saat PUT)
  const [rollbackAuth, setRollbackAuth] = useState<{ username: string; pin: string } | null>(null);

  const resetForm = () => {
    setEditRepairId(0);
    setIsQuickService(false);
    // D72 (permintaan user): tiket baru default "Pelanggan Umum" (walk-in) —
    // sama seperti transaksi kasir. Bisa diganti pelanggan terdaftar via
    // Pilih/Cari (dulu selalu wajib pilih dulu → merepotkan pelanggan langganan
    // yang mau langsung antar unit). customerId tetap 0 → tidak dicatat ke
    // daftar pelanggan & tidak dapat poin loyalitas.
    setCustomerId(0);
    setCustomerName("Umum");
    setCustomerPhone("");
    setDeviceModel("");
    setSerialImei("");
    setDamage("");
    setTechnicianId(technicians[0] ? String(technicians[0].id) : "none");
    setServiceFee("50000");
    setEstimatedCost("");
    setDownPayment("");
    setDifficulty("Sedang");
    setWarrantyDays("0");
    setPointsReward("");
    setEstimatedTime("");
    setNotes("");
    setInputStatus("ANTRI");
    setOriginalStatus("ANTRI");
    setSelectedPartsList([]);
    setExternalParts([]); // D64
    // D89: default tanggal terima = waktu saat ini; dapat diubah bila
    // pengaturan "Edit Tanggal Transaksi" aktif (input tampil di form).
    setTerimaDate(new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16));
  };

  const openCreate = () => {
    resetForm();
    setFormOpen(true);
  };

  // D72: pemicu dari halaman Kasir — buka form tiket baru sekali, lalu
  // konsumsi (reset di AppShell) agar remount tab tidak membukanya lagi.
  const lastOpenServiceForm = useRef(false);
  useEffect(() => {
    if (openServiceForm && !lastOpenServiceForm.current) {
      openCreate();
      onOpenServiceFormConsumed?.();
    }
    lastOpenServiceForm.current = !!openServiceForm;
  }, [openServiceForm, onOpenServiceFormConsumed]);

  const openEdit = (repair: Repair) => {
    setEditRepairId(repair.id);
    setIsQuickService(false);
    setCustomerId(repair.customerId ?? 0);
    setCustomerName(repair.customerName);
    setCustomerPhone(repair.customerPhone);
    setDeviceModel(repair.deviceModel);
    setSerialImei(repair.serialOrImei);
    setDamage(repair.damageDescription);
    setTechnicianId(repair.technicianId ? String(repair.technicianId) : "none");
    setServiceFee(String(Math.trunc(repair.serviceFee)));
    setEstimatedCost(repair.estimatedCost ? String(Math.trunc(repair.estimatedCost)) : "");
    setDownPayment(repair.downPayment ? String(Math.trunc(repair.downPayment)) : "");
    setDifficulty(repair.difficulty);
    setWarrantyDays(String(repair.warrantyDays));
    setPointsReward(repair.pointsReward ? String(repair.pointsReward) : "");
    setEstimatedTime(repair.estimatedCompletionTime);
    setNotes(repair.notes);
    setInputStatus(repair.status);
    setOriginalStatus(repair.status);
    setSelectedPartsList(
      parseUsedParts(repair.usedPartsJson)
        .filter((p) => p.partId > 0 && !p.isExternal)
        .map((p) => ({
          part: { id: p.partId, name: p.name, sku: "", stock: 999999, costPrice: p.costPrice ?? 0, sellPrice: p.sellPrice },
          qty: p.qty,
        }))
    );
    // D64: muat part external yang sudah ada di tiket agar tidak hilang saat edit
    setExternalParts(
      parseUsedParts(repair.usedPartsJson)
        .filter((p) => p.isExternal)
        .map((p) => ({ name: p.name, qty: p.qty, sellPrice: Number(p.sellPrice) || 0, costPrice: Number(p.costPrice) || 0 }))
    );
    setFormOpen(true);
  };

  const simpanForm = async () => {
    if (!deviceModel.trim() || !damage.trim()) {
      toast({ title: "Model HP dan deskripsi kerusakan wajib diisi", variant: "destructive" });
      return;
    }
    if (editRepairId === 0 && !isNewCustomerPicked()) {
      toast({ title: "Pilih pelanggan terlebih dahulu", variant: "destructive" });
      return;
    }
    try {
      setSaving(true);
      const payload = {
        customerId: customerId > 0 ? customerId : null,
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(), // D52: nomor WA opsional — boleh kosong (tanpa lagi fallback "081" palsu)
        deviceModel: deviceModel.trim(),
        serialOrImei: serialImei.trim(),
        damageDescription: damage.trim(),
        technicianId: technicianId !== "none" ? Number(technicianId) : null,
        serviceFee: editRepairId !== 0 || isQuickService ? Number(serviceFee) || 0 : 0,
        usedParts: [
          ...selectedPartsList.map((s) => ({ partId: s.part.id, qty: s.qty })),
          // D64: part external (toko lain) ikut tersimpan di tiket — partId 0,
          // harga beli & jual dari input dialog (tanpa stok)
          ...externalParts.map((p) => ({
            partId: 0,
            name: p.name,
            qty: p.qty,
            sellPrice: p.sellPrice,
            costPrice: p.costPrice,
            isExternal: true,
          })),
        ],
        difficulty,
        notes: notes.trim(),
        estimatedCost: estimatedCost === "" ? null : Number(estimatedCost),
        downPayment: downPayment === "" ? null : Number(downPayment),
        estimatedCompletionTime: estimatedTime.trim(),
        warrantyDays: Number(warrantyDays) || 0,
        pointsReward: pointsReward === "" ? null : Number(pointsReward),
        createdByUser: user.name,
        status: editRepairId === 0 ? (isQuickService ? "SELESAI" : "ANTRI") : inputStatus,
        // D89: bila "Edit Tanggal Transaksi" aktif dan tanggal terima diisi,
        // kirim timestamp — server memvalidasi (setting aktif, maks 1 hari ke depan)
        // lalu memakainya sebagai createdAt tiket (nomor tiket ikut tanggal ini).
        ...(editRepairId === 0 && settings.editTransactionDate && terimaDate
          ? { timestamp: terimaDate }
          : {}),
      };
      if (editRepairId === 0) {
        // D48/(b): respons POST bisa membawa `warnings` janji stok (tanpa reservasi)
        const created = await apiJson<Repair & { warnings?: string[] }>("/api/repairs", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        setRepairs((prev) => [created, ...prev]);
        toast({ title: "Tiket servis dibuat", description: `${serviceIdOf(created.createdAt)} — ${created.deviceModel}` });
        if (created.warnings?.length) {
          toast({
            title: `Peringatan stok (${created.warnings.length})`,
            description: created.warnings.join("\n"),
            variant: "destructive",
          });
        }
        setFormOpen(false);
        if (isQuickService) {
          // persis referensi: Servis Kilat langsung dibawa ke pembayaran POS
          onCheckoutRepair(created);
        }
      } else {
        const isRollback = statusOrderIdx(payload.status) < statusOrderIdx(originalStatus) && statusOrderIdx(originalStatus) >= 0;
        // D48/(b): respons PUT juga bisa membawa `warnings` bila part diubah
        const updated = await apiJson<Repair & { warnings?: string[] }>(`/api/repairs/${editRepairId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ...payload,
            op: "edit",
            userRole: user.role,
            performedBy: user.name,
            ...(isRollback && rollbackAuth
              ? { adminUsername: rollbackAuth.username, adminPin: rollbackAuth.pin }
              : {}),
          }),
        });
        setRepairs((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
        toast({ title: "Tiket servis diperbarui", description: `${updated.deviceModel} — ${updated.customerName}` });
        if (updated.warnings?.length) {
          toast({
            title: `Peringatan stok (${updated.warnings.length})`,
            description: updated.warnings.join("\n"),
            variant: "destructive",
          });
        }
        setFormOpen(false);
      }
    } catch (e) {
      toast({
        title: "Gagal menyimpan tiket",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const isNewCustomerPicked = () => customerId > 0 || customerName.trim() !== "";

  // D72: pilih Pelanggan Umum (walk-in) — tidak dicatat ke daftar pelanggan,
  // persis "Umum / Guest" pada transaksi kasir.
  const pilihUmum = () => {
    setCustomerId(0);
    setCustomerName("Umum");
    setCustomerPhone("");
  };

  // tambah pelanggan baru dari picker (ala insertCustomerAndGetId)
  const tambahPelangganBaru = async (name: string, phone: string) => {
    try {
      const created = await apiJson<CustomerLite>("/api/customers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, phone }), // D52: phone kosong dibolehkan (tanpa lagi fallback "081" palsu)
      });
      setCustomers((prev) => [...prev, created].sort((a, b) => a.name.localeCompare(b.name, "id")));
      setCustomerId(created.id);
      setCustomerName(created.name);
      setCustomerPhone(created.phone);
      toast({ title: "Pelanggan baru ditambahkan", description: created.name });
    } catch (e) {
      toast({
        title: "Gagal menambah pelanggan",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    }
  };

  // ===== Suggestion chips (filteredDevices/filteredDamages referensi) =====
  const modelSuggestions = useMemo(() => {
    const fromDb = Array.from(new Set(repairs.map((r) => r.deviceModel).filter((m) => m.trim())));
    const source = fromDb.length ? fromDb : DEFAULT_DEVICE_MODELS;
    return source.filter((m) => m.toLowerCase() !== deviceModel.toLowerCase()).slice(0, 6);
  }, [repairs, deviceModel]);

  const damageSuggestions = useMemo(() => {
    const fromDb = Array.from(new Set(repairs.map((r) => r.damageDescription).filter((d) => d.trim())));
    const source = fromDb.length ? fromDb : DEFAULT_DAMAGES;
    return source.filter((d) => d.toLowerCase() !== damage.toLowerCase()).slice(0, 6);
  }, [repairs, damage]);

  // D64: total part = inventaris + external (toko lain)
  const totalPartsForm =
    selectedPartsList.reduce((s, sp) => s + sp.part.sellPrice * sp.qty, 0) +
    externalParts.reduce((s, p) => s + p.sellPrice * p.qty, 0);
  const totalForm = (Number(serviceFee) || 0) + totalPartsForm;

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="mr-auto flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-xl bg-primary/10">
            <Wrench className="size-5 text-primary" aria-hidden />
          </div>
          <div>
            <h1 className="text-xl font-bold">Pencatatan Servis HP</h1>
            <p className="text-xs text-muted-foreground">Tiket servis, alur status & nota A5</p>
          </div>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-2.5 size-4 text-muted-foreground" aria-hidden />
          <Input
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") setAppliedQuery(searchInput);
            }}
            onBlur={() => setAppliedQuery(searchInput)}
            placeholder="Cari pelanggan, model, atau ID servis..."
            aria-label="Cari tiket servis"
            className="w-56 pl-9 sm:w-64"
          />
        </div>
        <Button type="button" variant="secondary" onClick={() => setEstimasiOpen(true)}>
          <Calculator className="size-4" aria-hidden /> Cek Estimasi
        </Button>
        <Button type="button" onClick={openCreate}>
          <Plus className="size-4" aria-hidden /> Terima Servis
        </Button>
      </div>

      {/* Filter status (chips dengan jumlah, ala tab referensi) */}
      <div className="flex flex-wrap items-center gap-1.5">
        {statusTabs.map((s) => {
          const count =
            s === "Semua"
              ? repairsToShow.length
              : s === "MENUNGGU_PART"
                ? repairsToShow.filter((r) => menungguPartAktif(r.status) && nPendingRequested(r) > 0).length
                : repairsToShow.filter((r) => r.status === s).length;
          const active = filterStatus === s;
          return (
            <button
              key={s}
              type="button"
              onClick={() => setFilterStatus(s)}
              className={cn(
                "rounded-full border px-3 py-1.5 text-[12px] font-bold transition-colors",
                active
                  ? "border-primary bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-muted"
              )}
            >
              {s === "Semua" ? "Semua" : s === "MENUNGGU_PART" ? "Menunggu Part" : REPAIR_STATUS_LABEL[s]} ({count})
            </button>
          );
        })}
        <span className="ml-auto">
          <FinCountChip count={filteredRepairs.length} unit="tiket" />
        </span>
      </div>

      {/* Daftar */}
      {loading ? (
        <p className="py-10 text-center text-sm text-muted-foreground">Memuat tiket servis...</p>
      ) : filteredRepairs.length === 0 ? (
        <p className="py-10 text-center text-sm text-muted-foreground">
          Belum ada riwayat servis untuk kriteria ini.
        </p>
      ) : (
        <>
          {/* Desktop: tabel gaya keuangan (D10) — overflow-x-auto agar bisa digeser
              ke kanan saat sempit, xl:overflow-x-visible agar header sticky (FinTh)
              menempel ke scroll halaman, bukan ke container ini */}
          <div className="hidden overflow-x-auto rounded-2xl border md:block xl:overflow-x-visible">
            <Table>
              <TableHeader>
                <tr>
                  <FinTh corner="first" className="w-10 text-center">#</FinTh>
                  <FinTh>ID Servis</FinTh>
                  <FinTh>Waktu</FinTh>
                  <FinTh>Pelanggan</FinTh>
                  <FinTh>Model HP</FinTh>
                  <FinTh>Kerusakan</FinTh>
                  <FinTh>Teknisi</FinTh>
                  <FinTh align="center">Status (klik = lanjut)</FinTh>
                  <FinTh align="right" corner="last">Total Biaya</FinTh>
                </tr>
              </TableHeader>
              <TableBody>
                {filteredRepairs.map((r, i) => {
                  const sId = serviceIdOf(r.createdAt);
                  return (
                    <FinRow key={r.id} zebra={i % 2 === 1} onClick={() => setDetailRepair(r)} muted={r.status === "DIAMBIL"}>
                      <FinIndexTd>{i + 1}</FinIndexTd>
                      <FinTd className="font-mono text-[12px] font-bold text-primary">{sId}</FinTd>
                      <FinTd className="text-[12px] text-muted-foreground">{formatDateTime(r.createdAt)}</FinTd>
                      <FinTd className="font-bold">{r.customerName}</FinTd>
                      <FinTd className="font-semibold">{r.deviceModel}</FinTd>
                      <FinTd className="max-w-56 truncate text-muted-foreground">{r.damageDescription}</FinTd>
                      <FinTd className="text-muted-foreground">{r.technicianName ?? "-"}</FinTd>
                      <FinTd align="center">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onStatusClick(r);
                          }}
                          aria-label={`Ubah status ${sId}`}
                          className={cn(
                            "rounded-full px-2.5 py-1 text-[11px] font-bold transition-transform hover:scale-105",
                            REPAIR_STATUS_BADGE[r.status]
                          )}
                        >
                          {REPAIR_STATUS_LABEL[r.status]}
                        </button>
                        {/* D28+D31: badge tiket terkonfirmasi yang masih menunggu part */}
                        {menungguPartAktif(r.status) && nPendingRequested(r) > 0 && (
                          <span className="ml-1.5 inline-block rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-bold align-middle text-amber-800">
                            Menunggu Part
                          </span>
                        )}
                      </FinTd>
                      <FinTd align="right" className="font-bold tabular-nums">
                        {formatCurrency(r.totalPrice)}
                      </FinTd>
                    </FinRow>
                  );
                })}
              </TableBody>
              <FinTfoot>
                <tr>
                  <FinFootTd colSpan={7}>
                    TOTAL {filteredRepairs.length} TIKET
                  </FinFootTd>
                  <FinFootTd className="text-center">{/* kolom status */}</FinFootTd>
                  <FinFootTd align="right" className="tabular-nums text-foreground">
                    Rp {Math.trunc(filteredRepairs.reduce((s, r) => s + r.totalPrice, 0)).toLocaleString("id-ID")}
                  </FinFootTd>
                </tr>
              </FinTfoot>
            </Table>
          </div>

          {/* Mobile: kartu per grup tanggal (persis referensi) */}
          <div className="space-y-5 md:hidden">
            {Array.from(
              filteredRepairs.reduce((map, r) => {
                const key = new Intl.DateTimeFormat("id-ID", {
                  weekday: "long",
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                }).format(new Date(r.createdAt));
                if (!map.has(key)) map.set(key, []);
                map.get(key)!.push(r);
                return map;
              }, new Map<string, Repair[]>())
            ).map(([tanggal, list]) => (
              <div key={tanggal} className="space-y-2">
                <div className="flex items-center gap-2">
                  <CalendarDays className="size-4 text-primary" aria-hidden />
                  <p className="text-[12px] font-bold text-primary">{tanggal}</p>
                  <div className="h-px flex-1 bg-primary/20" />
                </div>
                {list.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => setDetailRepair(r)}
                    className="block w-full rounded-2xl border bg-card p-4 text-left shadow-sm transition-colors hover:bg-primary/5"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="font-mono text-[12px] font-medium text-primary">{serviceIdOf(r.createdAt)}</p>
                        <p className="truncate font-bold">
                          {r.deviceModel} <span className="font-normal text-muted-foreground">· {r.damageDescription}</span>
                        </p>
                      </div>
                      <div className="flex shrink-0 flex-col items-end gap-1">
                        <span
                          onClick={(e) => {
                            e.stopPropagation();
                            onStatusClick(r);
                          }}
                          role="button"
                          tabIndex={0}
                          onKeyDown={(e) => {
                            if (e.key === "Enter" || e.key === " ") {
                              e.stopPropagation();
                              onStatusClick(r);
                            }
                          }}
                          className={cn("shrink-0 rounded-full px-2.5 py-1 text-[11px] font-bold", REPAIR_STATUS_BADGE[r.status])}
                        >
                          {REPAIR_STATUS_LABEL[r.status]}
                        </span>
                        {/* D28+D31: badge tiket terkonfirmasi yang masih menunggu part */}
                        {menungguPartAktif(r.status) && nPendingRequested(r) > 0 && (
                          <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-bold text-amber-800">
                            Menunggu Part
                          </span>
                        )}
                      </div>
                    </div>
                    <p className="mt-2 text-[13px] text-muted-foreground">
                      Pelanggan: <b className="text-foreground">{r.customerName}</b>
                    </p>
                  </button>
                ))}
              </div>
            ))}
          </div>
        </>
      )}

      {/* ===== Dialog detail (RepairDetailDialog.kt) ===== */}
      <RepairDetailDialog
        repair={detailRepair}
        user={user}
        onClose={() => setDetailRepair(null)}
        onEdit={(r) => {
          setDetailRepair(null);
          openEdit(r);
        }}
        onCheckout={(r) => {
          setDetailRepair(null);
          onCheckoutRepair(r);
        }}
        onDelete={(r) => {
          setDetailRepair(null);
          setDeleteRepair(r);
        }}
        onWa={(r) => {
          setWaRepair(r);
          setDetailRepair(null);
        }}
        onReceipt={(r) => {
          setReceiptRepair(r);
          setDetailRepair(null);
        }}
        onPartDatang={(r) => {
          setDetailRepair(null);
          setPartDatangRepair(r);
        }}
      />

      {/* D28: dialog penanganan sparepart pesanan yang sudah datang */}
      <PartDatangDialog
        repair={partDatangRepair}
        parts={parts}
        user={user}
        onClose={() => setPartDatangRepair(null)}
        onSaved={(updated) => {
          setRepairs((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
          setPartDatangRepair(null);
          if (updated.status === "DIKERJAKAN") {
            toast({
              title: "Sparepart datang — perbaikan dimulai",
              description: `${updated.deviceModel} lanjut ke status Dikerjakan.`,
            });
          } else if (updated.status === "KONFIRMASI") {
            // D31: pelanggan belum menyetujui — badge "Menunggu Part" belum aktif
            toast({
              title: "Part pesanan diproses",
              description: `${updated.deviceModel} masih menunggu konfirmasi pelanggan — badge Menunggu Part baru aktif setelah tiket disetujui.`,
            });
          } else {
            toast({
              title: "Part pesanan diproses",
              description: `${updated.deviceModel} masih menunggu sparepart lain — badge Menunggu Part tetap tampil.`,
            });
          }
        }}
      />

      {/* ===== Form terima/edit servis — D21: footer selalu terlihat ===== */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="flex max-h-[92vh] flex-col overflow-hidden rounded-2xl sm:max-w-2xl">
          <DialogHeader className="shrink-0">
            <DialogTitle>{editRepairId === 0 ? "Terima Servis" : "Edit Detail Servis"}</DialogTitle>
            <DialogDescription>
              {editRepairId === 0
                ? "Isi data pelanggan, perangkat, dan keluhan — status awal Antri."
                : "Perubahan disimpan langsung; menurunkan status butuh otorisasi Admin."}
            </DialogDescription>
          </DialogHeader>

          {/* D21: hanya bagian ini yang scroll — header & tombol Simpan/Batal selalu terlihat */}
          <div className="min-h-0 flex-1 space-y-4 overflow-y-auto">
            {/* Mode (hanya tiket baru) — persis referensi */}
            {editRepairId === 0 && (
              <div className="grid grid-cols-2 gap-1 rounded-xl bg-muted p-1">
                {(
                  [
                    [false, "Servis Reguler"],
                    [true, "Servis Kilat (Quick)"],
                  ] as const
                ).map(([v, label]) => (
                  <button
                    key={label}
                    type="button"
                    onClick={() => setIsQuickService(v)}
                    className={cn(
                      "rounded-lg px-3 py-2 text-[13px] font-bold transition-colors",
                      isQuickService === v
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:bg-background"
                    )}
                  >
                    {label}
                  </button>
                ))}
              </div>
            )}

            {/* D89: tanggal & waktu terima — tampil HANYA saat tiket baru dan
                pengaturan "Edit Tanggal Transaksi" aktif (paritas D39 kasir);
                server tetap menolak bila setting mati (UI bukan satu-satunya penjaga). */}
            {editRepairId === 0 && settings.editTransactionDate && (
              <div className="space-y-1 rounded-xl border bg-muted/40 p-3">
                <Label htmlFor="terima-tanggal">Tanggal &amp; Waktu Terima</Label>
                <Input
                  id="terima-tanggal"
                  type="datetime-local"
                  value={terimaDate}
                  onChange={(e) => setTerimaDate(e.target.value)}
                  className="rounded-xl"
                />
                <p className="text-[11px] text-muted-foreground">
                  "Edit Tanggal Transaksi" aktif — ubah bila menerima servis mundur (mis. unit datang kemarin);
                  nomor tiket mengikuti tanggal ini.
                </p>
              </div>
            )}

            {/* 1. Data Pelanggan */}
            <section className="space-y-2 rounded-xl border p-3">
              <p className="flex items-center gap-1.5 text-[12px] font-bold text-primary">
                Pilih / Cari Pelanggan
              </p>
              <div className="flex gap-2">
                <div className="relative min-w-0 flex-1">
                  <Input
                    readOnly
                    value={customerName || "Belum Memilih Pelanggan"}
                    placeholder="Klik Cari Pelanggan..."
                    className={cn("font-bold", !customerName && "text-muted-foreground")}
                  />
                </div>
                {/* D72: tombol cepat Pelanggan Umum (walk-in) — tanpa mencatat data,
                    persis "Umum / Guest" pada transaksi kasir */}
                <Button
                  type="button"
                  variant={customerId === 0 && customerName === "Umum" ? "default" : "outline"}
                  onClick={pilihUmum}
                  title="Pelanggan Umum — tidak dicatat ke daftar pelanggan"
                >
                  Umum
                </Button>
                <Button type="button" variant="outline" onClick={() => setCustomerPickerOpen(true)}>
                  Pilih/Cari
                </Button>
              </div>
              {customerId > 0 ? (
                <p className="text-[12px] font-semibold text-emerald-700">
                  Pelanggan Terdaftar: {customers.find((c) => c.id === customerId)?.phone ?? "-"}
                </p>
              ) : customerName === "Umum" ? (
                <p className="text-[12px] font-semibold text-muted-foreground">
                  Pelanggan umum (walk-in) — tidak dicatat ke daftar pelanggan, tidak dapat poin loyalitas.
                </p>
              ) : null}
            </section>

            {/* 2. Data Perangkat */}
            <section className="space-y-2 rounded-xl border p-3">
              <p className="flex items-center gap-1.5 text-[12px] font-bold text-primary">Data Perangkat</p>
              <div className="space-y-1">
                <Label htmlFor="srv-model">Model HP</Label>
                <Input
                  id="srv-model"
                  value={deviceModel}
                  onChange={(e) => setDeviceModel(e.target.value)}
                  placeholder="Contoh: iPhone 11 Pro"
                />
              </div>
              <div className="flex flex-wrap gap-1.5">
                {modelSuggestions.map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setDeviceModel(m)}
                    className="rounded-lg border border-primary/15 bg-primary/5 px-2.5 py-1 text-[11px] font-medium text-primary hover:bg-primary/10"
                  >
                    {m}
                  </button>
                ))}
              </div>
              <div className="space-y-1">
                <Label htmlFor="srv-imei">Serial / IMEI (opsional)</Label>
                <Input
                  id="srv-imei"
                  value={serialImei}
                  onChange={(e) => setSerialImei(e.target.value)}
                  placeholder="IMEI atau nomor seri unit"
                  className="font-mono"
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="srv-damage">Deskripsi Kerusakan</Label>
                <Textarea
                  id="srv-damage"
                  value={damage}
                  onChange={(e) => setDamage(e.target.value)}
                  rows={2}
                  placeholder="Contoh: Layar pecah, sentuh tidak berfungsi"
                />
              </div>
              <div className="flex flex-wrap gap-1.5">
                {damageSuggestions.map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setDamage(d)}
                    className="rounded-lg border border-primary/15 bg-primary/5 px-2.5 py-1 text-[11px] font-medium text-primary hover:bg-primary/10"
                  >
                    {d}
                  </button>
                ))}
              </div>
            </section>

            {/* 3. Biaya & Sparepart */}
            <section className="space-y-3 rounded-xl border p-3">
              <p className="flex items-center gap-1.5 text-[12px] font-bold text-primary">Biaya &amp; Sparepart</p>
              {!isQuickService && (
                <div className="space-y-1">
                  <Label htmlFor="srv-est">Estimasi Biaya Total (Rp)</Label>
                  <Input
                    id="srv-est"
                    value={estimatedCost}
                    onChange={(e) => setEstimatedCost(e.target.value.replace(/\D/g, ""))}
                    inputMode="numeric"
                    placeholder="Perkiraan total biaya ke pelanggan"
                  />
                </div>
              )}
              <div className="space-y-1">
                <Label htmlFor="srv-fee">Biaya Jasa Servis (Rp)</Label>
                <Input
                  id="srv-fee"
                  value={serviceFee}
                  onChange={(e) => setServiceFee(e.target.value.replace(/\D/g, ""))}
                  inputMode="numeric"
                />
              </div>
              {!isQuickService && (
                <div className="space-y-1">
                  <Label htmlFor="srv-dp">DP / Down Payment jika ada (Rp)</Label>
                  <Input
                    id="srv-dp"
                    value={downPayment}
                    onChange={(e) => setDownPayment(e.target.value.replace(/\D/g, ""))}
                    inputMode="numeric"
                    placeholder="0"
                  />
                </div>
              )}
              <div className="space-y-1">
                <Label>Tingkat Kesulitan (poin teknisi)</Label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(
                    [
                      ["Rendah", "10 poin"],
                      ["Sedang", "25 poin"],
                      ["Tinggi", "50 poin"],
                    ] as const
                  ).map(([k, poin]) => (
                    <button
                      key={k}
                      type="button"
                      onClick={() => setDifficulty(k)}
                      className={cn(
                        "rounded-lg border px-2 py-1.5 text-[12px] font-bold transition-colors",
                        difficulty === k
                          ? "border-primary bg-primary/10 text-primary"
                          : "text-muted-foreground hover:bg-muted"
                      )}
                    >
                      {k}
                      <span className="block text-[10px] font-normal">{poin}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="border-t pt-2">
                <p className="text-[12px] font-bold">Sparepart Terpakai</p>
                {selectedPartsList.length === 0 && externalParts.length === 0 ? (
                  <p className="py-1 text-[12px] text-muted-foreground">Belum ada sparepart yang ditambahkan.</p>
                ) : (
                  <div className="space-y-1.5 py-1">
                    {selectedPartsList.map(({ part, qty }) => (
                      <div key={part.id} className="flex items-center gap-2 rounded-lg bg-muted/50 px-2.5 py-1.5">
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-[13px] font-bold">{part.name}</p>
                          <p className="text-[11px] text-muted-foreground">
                            Stok: {part.stock} · {formatCurrency(part.sellPrice)}
                          </p>
                        </div>
                        <button
                          type="button"
                          aria-label={`Kurangi ${part.name}`}
                          onClick={() =>
                            setSelectedPartsList((prev) =>
                              prev
                                .map((s) => (s.part.id === part.id ? { ...s, qty: s.qty - 1 } : s))
                                .filter((s) => s.qty > 0)
                            )
                          }
                          className="size-7 rounded-lg border text-sm font-bold hover:bg-background"
                        >
                          −
                        </button>
                        <span className="w-6 text-center text-[13px] font-bold tabular-nums">{qty}</span>
                        <button
                          type="button"
                          aria-label={`Tambah ${part.name}`}
                          onClick={() =>
                            setSelectedPartsList((prev) =>
                              prev.map((s) =>
                                s.part.id === part.id && s.qty < s.part.stock ? { ...s, qty: s.qty + 1 } : s
                              )
                            )
                          }
                          className="size-7 rounded-lg border text-sm font-bold hover:bg-background"
                        >
                          +
                        </button>
                        <button
                          type="button"
                          aria-label={`Hapus ${part.name}`}
                          onClick={() => setSelectedPartsList((prev) => prev.filter((s) => s.part.id !== part.id))}
                          className="size-7 rounded-lg border text-sm text-red-600 hover:bg-background"
                        >
                          <Trash2 className="mx-auto size-3.5" aria-hidden />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
                {/* D64: daftar part external (toko lain) di tiket */}
                {externalParts.length > 0 && (
                  <div className="space-y-1.5 py-1">
                    {externalParts.map((p, i) => (
                      <div
                        key={`ext-${p.name}-${i}`}
                        className="flex items-center gap-2 rounded-lg border border-amber-200 bg-amber-50/60 px-2.5 py-1.5"
                      >
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-[13px] font-bold">
                            {p.name} ×{p.qty}
                            <Badge
                              variant="outline"
                              className="ml-1.5 border-amber-300 bg-amber-100 text-[9px] font-bold text-amber-800"
                            >
                              Toko Lain
                            </Badge>
                          </p>
                          <p className="text-[11px] text-muted-foreground">
                            Beli: {formatCurrency(p.costPrice)} · Jual: {formatCurrency(p.sellPrice)}
                          </p>
                        </div>
                        <button
                          type="button"
                          aria-label={`Hapus part external ${p.name}`}
                          onClick={() => setExternalParts((prev) => prev.filter((_, idx) => idx !== i))}
                          className="size-7 shrink-0 rounded-lg border text-sm text-red-600 hover:bg-background"
                        >
                          <Trash2 className="mx-auto size-3.5" aria-hidden />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
                <Button
                  type="button"
                  variant="secondary"
                  className="mt-1 w-full"
                  onClick={() => setPartPickerOpen(true)}
                >
                  Pilih Sparepart dari Inventaris
                </Button>
                {/* D64: part external (toko lain) — tanpa stok, harga beli & jual diinput */}
                <Button
                  type="button"
                  variant="outline"
                  className="w-full border-amber-300 text-amber-800 hover:bg-amber-50"
                  onClick={() => setExtDialogOpen(true)}
                >
                  <PackagePlus className="size-4" aria-hidden /> Tambah Part External (Toko Lain)
                </Button>
              </div>
            </section>

            {/* 4. Info Tambahan */}
            <section className="space-y-3 rounded-xl border p-3">
              <p className="flex items-center gap-1.5 text-[12px] font-bold text-primary">
                <Info className="size-3.5" aria-hidden /> Info Tambahan
              </p>

              {/* Status (hanya saat edit) — rollback butuh otorisasi Admin */}
              {editRepairId !== 0 && (
                <div className="space-y-1">
                  <Label>Status Perbaikan</Label>
                  <Select
                    value={inputStatus}
                    onValueChange={(v) => {
                      const isRollback =
                        statusOrderIdx(v) < statusOrderIdx(originalStatus) &&
                        statusOrderIdx(originalStatus) >= 0;
                      if (isRollback && user.role !== "Admin") {
                        setRollbackTarget(v);
                      } else {
                        setInputStatus(v);
                        setRollbackAuth(null);
                      }
                    }}
                  >
                    <SelectTrigger id="srv-status">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(REPAIR_STATUS_LABEL).map(([k, label]) => (
                        <SelectItem key={k} value={k}>
                          {label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {/* Teknisi (checklist 4.3 penugasan teknisi) */}
              <div className="space-y-1">
                <Label>Teknisi Penanggung Jawab</Label>
                <Select value={technicianId} onValueChange={setTechnicianId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih teknisi" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Belum ditugaskan</SelectItem>
                    {technicians.map((t) => (
                      <SelectItem key={t.id} value={String(t.id)}>
                        {t.name} {t.isAvailable ? "" : "(sibuk)"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {!isQuickService && (
                <div className="space-y-1">
                  <Label htmlFor="srv-time">Estimasi Tanggal &amp; Jam Selesai</Label>
                  <Input
                    id="srv-time"
                    value={estimatedTime}
                    onChange={(e) => setEstimatedTime(e.target.value)}
                    placeholder="Contoh: Besok Jam 17:00 atau dd/MM/yyyy HH:mm"
                  />
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        const d = new Date(Date.now() + 3 * 3600 * 1000);
                        setEstimatedTime(`+3 Jam (${formatDateTime(d)})`);
                      }}
                      className="rounded-full border px-2.5 py-1 text-[11px] font-semibold text-muted-foreground hover:bg-muted"
                    >
                      +3 Jam
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const d = new Date(Date.now() + 24 * 3600 * 1000);
                        d.setHours(17, 0, 0, 0);
                        setEstimatedTime(`Besok Sore (${formatDateTime(d)})`);
                      }}
                      className="rounded-full border px-2.5 py-1 text-[11px] font-semibold text-muted-foreground hover:bg-muted"
                    >
                      Besok
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const d = new Date(Date.now() + 3 * 24 * 3600 * 1000);
                        d.setHours(17, 0, 0, 0);
                        setEstimatedTime(`3 Hari (${formatDateTime(d)})`);
                      }}
                      className="rounded-full border px-2.5 py-1 text-[11px] font-semibold text-muted-foreground hover:bg-muted"
                    >
                      3 Hari
                    </button>
                  </div>
                </div>
              )}

              {/* Garansi hari (checklist 4.1) */}
              <div className="space-y-1">
                <Label>Garansi Servis (hari)</Label>
                <div className="flex flex-wrap gap-1.5">
                  {[0, 3, 7, 14, 30].map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setWarrantyDays(String(d))}
                      className={cn(
                        "rounded-lg border px-2.5 py-1 text-[11px] font-bold transition-colors",
                        Number(warrantyDays) === d
                          ? "border-primary bg-primary/10 text-primary"
                          : "text-muted-foreground hover:bg-muted"
                      )}
                    >
                      {d === 0 ? "Tanpa" : `${d} Hari`}
                    </button>
                  ))}
                </div>
              </div>

              {user.role === "Admin" && (
                <div className="space-y-1">
                  <Label htmlFor="srv-poin">Poin Teknisi Kustom (opsional)</Label>
                  <Input
                    id="srv-poin"
                    value={pointsReward}
                    onChange={(e) => setPointsReward(e.target.value.replace(/\D/g, ""))}
                    inputMode="numeric"
                    placeholder={`Kosongkan = otomatis (${difficultyPoints(difficulty)} poin)`}
                  />
                </div>
              )}

              <div className="space-y-1">
                <Label htmlFor="srv-notes">Catatan Tambahan (Kondisi Fisik, dsb)</Label>
                <Textarea id="srv-notes" value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} />
              </div>

              {/* Ringkasan total (jasa + part) */}
              <div className="flex items-center justify-between rounded-lg bg-muted/60 px-3 py-2 text-[13px]">
                <span className="font-semibold">Total Biaya (Jasa + Sparepart)</span>
                <b className="tabular-nums text-primary">{formatCurrency(totalForm)}</b>
              </div>
            </section>
          </div>

          <DialogFooter className="shrink-0 gap-2 border-t pt-3">
            <Button type="button" variant="ghost" onClick={() => setFormOpen(false)}>
              Batal
            </Button>
            <Button type="button" onClick={simpanForm} disabled={saving}>
              {isQuickService && editRepairId === 0 ? "Bayar" : "Simpan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Picker pelanggan & sparepart */}
      <CustomerPickerDialog
        customers={customers}
        open={customerPickerOpen}
        onOpenChange={setCustomerPickerOpen}
        onSelect={(c) => {
          setCustomerId(c.id);
          setCustomerName(c.name);
          setCustomerPhone(c.phone);
        }}
        onAddNew={tambahPelangganBaru}
        onUmum={pilihUmum}
      />
      <SparePartPickerDialog
        parts={parts}
        open={partPickerOpen}
        onOpenChange={setPartPickerOpen}
        onSelect={(p) =>
          setSelectedPartsList((prev) => {
            const found = prev.find((s) => s.part.id === p.id);
            if (found) {
              return prev.map((s) => (s.part.id === p.id && s.qty < p.stock ? { ...s, qty: s.qty + 1 } : s));
            }
            return [...prev, { part: p, qty: 1 }];
          })
        }
      />

      {/* D64: dialog part external (toko lain) — Terima/Edit Servis */}
      <ExternalPartDialog
        open={extDialogOpen}
        onClose={() => setExtDialogOpen(false)}
        onAdd={(p) => setExternalParts((prev) => [...prev, p])}
      />

      {/* Estimator */}
      <PriceEstimationDialog repairs={repairs} parts={parts} open={estimasiOpen} onOpenChange={setEstimasiOpen} />

      {/* Konfirmasi status berikutnya (standard) */}
      <AlertDialog
        open={standardConfirm !== null}
        onOpenChange={(v) => !v && setStandardConfirm(null)}
      >
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Konfirmasi Perubahan Status</AlertDialogTitle>
            <AlertDialogDescription>
              {standardConfirm && (
                <>
                  Apakah Anda yakin ingin mengubah status HP {serviceIdOf(standardConfirm.createdAt)} (
                  {standardConfirm.deviceModel}) dari &quot;{REPAIR_STATUS_LABEL[standardConfirm.status]}
                  &quot; menjadi &quot;
                  {REPAIR_STATUS_LABEL[repairStatusNext(standardConfirm.status) ?? "ANTRI"]}&quot;?
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              disabled={busyStatus}
              onClick={(e) => {
                e.preventDefault();
                if (standardConfirm) {
                  ubahStatus(standardConfirm, repairStatusNext(standardConfirm.status) ?? "ANTRI");
                }
              }}
            >
              Ya, Ubah
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Dialog diagnosa (DIAGNOSA → KONFIRMASI) */}
      <DiagnosaDialog
        repair={diagnosaRepair}
        parts={parts}
        user={user}
        busy={busyStatus}
        onClose={() => setDiagnosaRepair(null)}
        onSaved={(updated) => {
          setRepairs((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
          setDiagnosaRepair(null);
          if (updated.status === "TIDAK_BISA") {
            // D24: diagnosa di-void — unit tidak bisa dilanjutkan
            toast({
              title: "Servis di-void (Tidak Bisa)",
              description: `${updated.deviceModel} tidak dapat dilanjutkan — kabari pelanggan untuk mengambil unit.`,
            });
          } else {
            toast({
              title: "Diagnosa disimpan",
              description: `${updated.deviceModel} lanjut ke Konfirmasi — estimasi ${formatCurrency(updated.totalPrice)}`,
            });
          }
          // D21: otomatis buka dialog konfirmasi hasil diagnosa + kirim WA ke pelanggan
          setDiagnosaWaRepair(updated);
        }}
      />

      {/* D21: konfirmasi diagnosa tersimpan + kirim WhatsApp pelanggan (otomatis) */}
      {diagnosaWaRepair && (
        <DiagnosaSentWaDialog
          repair={diagnosaWaRepair}
          waMap={waMap}
          shop={{ name: settings.shopName, phone: settings.phone }}
          open
          onOpenChange={(v) => !v && setDiagnosaWaRepair(null)}
        />
      )}

      {/* Dialog persetujuan pelanggan (KONFIRMASI → DISETUJUI / DIBATALKAN) */}
      <AlertDialog
        open={konfirmasiRepair !== null}
        onOpenChange={(v) => !v && setKonfirmasiRepair(null)}
      >
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Konfirmasi Persetujuan Pelanggan</AlertDialogTitle>
            <AlertDialogDescription>
              Pilih respon pelanggan terhadap estimasi biaya perbaikan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          {konfirmasiRepair && (
            <div className="space-y-1 rounded-xl bg-muted/50 p-3 text-[13px]">
              <p>
                <span className="text-muted-foreground">Hasil Diagnosa:</span>{" "}
                {konfirmasiRepair.notes || "-"}
              </p>
              <p>
                <span className="text-muted-foreground">Estimasi Total Biaya:</span>{" "}
                <b className="text-primary">
                  {formatCurrency(
                    konfirmasiRepair.serviceFee +
                      partsSumOf(parseUsedParts(konfirmasiRepair.usedPartsJson)) +
                      // D28: estimasi part yang akan dipesan ikut total yang disetujui
                      requestedPartsTotal(pendingRequestedParts(konfirmasiRepair.requestedPartsJson))
                  )}
                </b>
              </p>
              {pendingRequestedParts(konfirmasiRepair.requestedPartsJson).length > 0 && (
                <p className="text-[11px] text-amber-800">
                  Termasuk estimasi sparepart yang akan dipesan (belum tersedia di inventaris).
                </p>
              )}
            </div>
          )}
          <AlertDialogFooter className="flex-row gap-2">
            <div className="mr-auto">
              <AlertDialogCancel>Tutup</AlertDialogCancel>
            </div>
            {/* D24: void — unit ternyata tidak bisa dilanjutkan (hasil diagnosa) */}
            <Button
              type="button"
              variant="outline"
              className="border-red-600 font-bold text-red-600 hover:bg-red-50"
              disabled={busyStatus}
              onClick={() => {
                if (konfirmasiRepair) {
                  void (async () => {
                    const updated = await ubahStatus(konfirmasiRepair, "TIDAK_BISA");
                    if (updated) setDiagnosaWaRepair(updated);
                  })();
                  setKonfirmasiRepair(null);
                }
              }}
            >
              <Ban className="size-4" aria-hidden /> Tidak Bisa (Void)
            </Button>
            <Button
              type="button"
              className="bg-red-600 text-white hover:bg-red-700"
              disabled={busyStatus}
              onClick={() => {
                if (konfirmasiRepair) {
                  ubahStatus(konfirmasiRepair, "DIBATALKAN");
                  setKonfirmasiRepair(null);
                }
              }}
            >
              Dibatalkan
            </Button>
            <Button
              type="button"
              className="bg-emerald-700 text-white hover:bg-emerald-800"
              disabled={busyStatus}
              onClick={() => {
                if (konfirmasiRepair) {
                  ubahStatus(konfirmasiRepair, "DISETUJUI");
                  setKonfirmasiRepair(null);
                }
              }}
            >
              Disetujui
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Otorisasi rollback (non-admin menurunkan status di form edit) */}
      <RollbackAuthDialog
        open={rollbackTarget !== null}
        onClose={() => setRollbackTarget(null)}
        onSuccess={(cred) => {
          if (rollbackTarget) {
            setInputStatus(rollbackTarget);
            setRollbackAuth(cred);
          }
          setRollbackTarget(null);
        }}
      />

      {/* Hapus tiket */}
      <AlertDialog open={deleteRepair !== null} onOpenChange={(v) => !v && setDeleteRepair(null)}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Rekam Servis</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteRepair &&
                `Apakah Anda yakin ingin menghapus rekam servis untuk "${deleteRepair.deviceModel}" (${deleteRepair.customerName})? Tindakan ini tidak dapat dibatalkan.`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 text-white hover:bg-red-700"
              onClick={(e) => {
                e.preventDefault();
                if (deleteRepair) {
                  hapusTiket(deleteRepair);
                  setDeleteRepair(null);
                }
              }}
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Nota A5 & editor WA */}
      {receiptRepair && (
        <RepairReceiptDialog
          repair={receiptRepair}
          settings={settings}
          cashierName={user.name}
          waMap={waMap}
          open
          onOpenChange={(v) => !v && setReceiptRepair(null)}
        />
      )}
      {waRepair && (
        <WhatsAppEditorDialog
          repair={waRepair}
          waMap={waMap}
          shop={{ name: settings.shopName, phone: settings.phone }}
          onSaved={(map) => {
            setWaMap(map);
            setWaRepair(null);
          }}
          open
          onOpenChange={(v) => !v && setWaRepair(null)}
        />
      )}
    </div>
  );
}

function statusOrderIdx(status: string): number {
  const order = ["ANTRI", "DIAGNOSA", "KONFIRMASI", "DISETUJUI", "DIKERJAKAN", "SELESAI", "DIAMBIL", "DIBATALKAN", "TIDAK_BISA"];
  return order.indexOf(status);
}

// D28: jumlah part pesanan yang belum ditangani (untuk badge & filter "Menunggu Part")
function nPendingRequested(r: Repair): number {
  return pendingRequestedParts(r.requestedPartsJson).length;
}

// ============================================================
// RepairDetailDialog.kt — detail + aksi (Struk / WA / Edit / Hapus / Bayar POS)
// ============================================================
function RepairDetailDialog({
  repair,
  user,
  onClose,
  onEdit,
  onCheckout,
  onDelete,
  onWa,
  onReceipt,
  onPartDatang,
}: {
  repair: Repair | null;
  user: SafeUser;
  onClose: () => void;
  onEdit: (r: Repair) => void;
  onCheckout: (r: Repair) => void;
  onDelete: (r: Repair) => void;
  onWa: (r: Repair) => void;
  onReceipt: (r: Repair) => void;
  onPartDatang: (r: Repair) => void;
}) {
  const { toast } = useToast();
  const isAdmin = user.role === "Admin";
  const r = repair;
  const parts = r ? parseUsedParts(r.usedPartsJson) : [];
  const partsSum = partsSumOf(parts);
  // D28: part pesanan yang belum datang
  const reqPending = r ? pendingRequestedParts(r.requestedPartsJson) : [];
  // D30: part pesanan yang sudah datang & punya harga beli (tampil sebagai jejak biaya)
  const reqDoneCost = r
    ? parseRequestedParts(r.requestedPartsJson).filter((p) => p.done && (Number(p.costPrice) || 0) > 0)
    : [];

  return (
    <Dialog open={r !== null} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-2xl sm:max-w-md">
        {r && (
          <>
            <DialogHeader>
              <DialogTitle>Detail Servis</DialogTitle>
              <DialogDescription>Tinjau tiket & lakukan aksi selanjutnya.</DialogDescription>
            </DialogHeader>

            <div className="space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-[11px] text-muted-foreground">ID Servis</p>
                  <p className="font-mono text-sm font-bold text-primary">{serviceIdOf(r.createdAt)}</p>
                </div>
                <span className={cn("rounded-full px-2.5 py-1 text-[11px] font-bold", REPAIR_STATUS_BADGE[r.status])}>
                  {REPAIR_STATUS_LABEL[r.status]}
                </span>
                {/* D31: badge hanya aktif setelah pelanggan menyetujui (terkonfirmasi) */}
                {menungguPartAktif(r.status) && reqPending.length > 0 && (
                  <span className="mt-1 inline-block rounded-full bg-amber-100 px-2.5 py-1 text-[11px] font-bold text-amber-800">
                    Menunggu Part
                  </span>
                )}
              </div>

              <div className="rounded-xl border p-3">
                <p className="mb-1 text-[11px] font-bold uppercase tracking-wide text-primary">Informasi Pelanggan</p>
                <div className="flex justify-between text-[12px]">
                  <span className="text-muted-foreground">Nama</span>
                  <b>{r.customerName}</b>
                </div>
                <div className="flex justify-between text-[12px]">
                  <span className="text-muted-foreground">No. HP / WA</span>
                  <b className="font-mono">{r.customerPhone || "—"}</b>
                </div>
              </div>

              <div className="rounded-xl border p-3">
                <p className="mb-1 text-[11px] font-bold uppercase tracking-wide text-primary">Unit &amp; Kerusakan</p>
                <div className="flex justify-between text-[12px]">
                  <span className="text-muted-foreground">Model HP</span>
                  <b>{r.deviceModel}</b>
                </div>
                {r.serialOrImei && (
                  <div className="flex justify-between text-[12px]">
                    <span className="text-muted-foreground">Serial / IMEI</span>
                    <span className="font-mono">{r.serialOrImei}</span>
                  </div>
                )}
                <p className="mt-1 text-[12px]">
                  <span className="text-muted-foreground">Kerusakan: </span>
                  {r.damageDescription}
                </p>
                {r.technicianName && (
                  <div className="mt-1 flex justify-between text-[12px]">
                    <span className="text-muted-foreground">Teknisi</span>
                    <b>{r.technicianName}</b>
                  </div>
                )}
                {r.status !== "DIAMBIL" && (
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    Poin kesulitan: <b>{difficultyPoints(r.difficulty, r.pointsReward)}</b> ({r.difficulty})
                    {r.warrantyDays > 0 ? ` · Garansi ${r.warrantyDays} hari` : ""}
                  </p>
                )}
              </div>

              {parts.length > 0 && (
                <div className="rounded-xl border p-3">
                  <p className="mb-1 text-[11px] font-bold uppercase tracking-wide text-primary">Sparepart Terpakai</p>
                  {parts.map((p, i) => (
                    <div key={i} className="flex justify-between text-[12px]">
                      <span className="text-muted-foreground">
                        {p.qty} × {p.name}
                        {p.isExternal ? " (Toko Lain)" : ""}
                      </span>
                      <b className="tabular-nums">{formatCurrency(p.sellPrice * p.qty)}</b>
                    </div>
                  ))}
                  {/* D30: jejak harga beli part pesanan yang sudah datang (internal) */}
                  {reqDoneCost.length > 0 && (
                    <p className="mt-1 border-t pt-1 text-[11px] text-muted-foreground">
                      Harga beli part pesanan:{" "}
                      {reqDoneCost
                        .map((p) => `${p.name} ${formatCurrency(Number(p.costPrice))}/unit`)
                        .join(" · ")}
                    </p>
                  )}
                </div>
              )}

              {/* D28: daftar sparepart pesanan yang belum datang */}
              {reqPending.length > 0 && (
                <div className="rounded-xl border border-amber-200 bg-amber-50/60 p-3">
                  <p className="mb-1 text-[11px] font-bold uppercase tracking-wide text-amber-800">
                    Sparepart Perlu Dipesan
                  </p>
                  {reqPending.map((p, i) => (
                    <div key={i} className="flex justify-between text-[12px]">
                      <span className="text-amber-900">
                        {p.qty} × {p.name} — akan dipesan
                      </span>
                      <b className="tabular-nums text-amber-900">{formatCurrency(p.estPrice * p.qty)}</b>
                    </div>
                  ))}
                  <p className="mt-1 text-[11px] text-amber-800">
                    Estimasi part dipesan sudah termasuk dalam Total Biaya.
                  </p>
                </div>
              )}

              <div className="rounded-xl border p-3">
                <p className="mb-1 text-[11px] font-bold uppercase tracking-wide text-primary">Rincian Biaya</p>
                <div className="flex justify-between text-[12px]">
                  <span className="text-muted-foreground">Jasa Servis</span>
                  <span className="tabular-nums">{formatCurrency(r.serviceFee)}</span>
                </div>
                {partsSum > 0 && (
                  <div className="flex justify-between text-[12px]">
                    <span className="text-muted-foreground">Total Sparepart</span>
                    <span className="tabular-nums">{formatCurrency(partsSum)}</span>
                  </div>
                )}
                {reqPending.length > 0 && (
                  <div className="flex justify-between text-[12px]">
                    <span className="text-muted-foreground">Estimasi Part Dipesan</span>
                    <span className="tabular-nums">{formatCurrency(requestedPartsTotal(reqPending))}</span>
                  </div>
                )}
                <div className="mt-1 flex justify-between border-t pt-1 text-[13px] font-bold">
                  <span>Total Biaya</span>
                  <span className="tabular-nums text-primary">
                    {formatCurrency(r.serviceFee + partsSum + requestedPartsTotal(reqPending))}
                  </span>
                </div>
                {(r.estimatedCost != null || r.downPayment != null) && (
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    Estimasi: {formatCurrency(r.estimatedCost ?? 0)} · DP: {formatCurrency(r.downPayment ?? 0)}
                    {r.estimatedCompletionTime ? ` · Estimasi selesai: ${r.estimatedCompletionTime}` : ""}
                  </p>
                )}
                {r.notes && <p className="mt-1 text-[11px] text-muted-foreground">Catatan: {r.notes}</p>}
              </div>

              {/* D28: tombol penanganan sparepart pesanan yang sudah datang */}
              {(r.status === "KONFIRMASI" || r.status === "DISETUJUI") && reqPending.length > 0 && (
                <Button
                  type="button"
                  className="w-full bg-amber-600 text-white hover:bg-amber-700"
                  onClick={() => onPartDatang(r)}
                >
                  <PackageCheck className="size-4" aria-hidden /> Sparepart Sudah Datang
                </Button>
              )}

              {/* Aksi */}
              <div className="grid grid-cols-3 gap-2">
                <Button type="button" variant="secondary" onClick={() => onReceipt(r)}>
                  <Printer className="size-4" aria-hidden /> Struk
                </Button>
                <Button type="button" className="bg-[#25D366] text-white hover:bg-[#1eb856]" onClick={() => onWa(r)}>
                  <Send className="size-4" aria-hidden /> Kirim WA
                </Button>
                <Button
                  type="button"
                  onClick={() => {
                    if (!isAdmin) {
                      toast({ title: "Edit hanya bisa dilakukan oleh Admin!", variant: "destructive" });
                      return;
                    }
                    if (r.status === "DIAMBIL") {
                      toast({ title: "Transaksi ini sudah diambil & lunas pembayaran. Terkunci!" });
                      return;
                    }
                    onEdit(r);
                  }}
                >
                  {r.status === "DIAMBIL" ? (
                    <>
                      <Lock className="size-4" aria-hidden /> Kunci
                    </>
                  ) : (
                    <>
                      <Pencil className="size-4" aria-hidden /> Edit
                    </>
                  )}
                </Button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  type="button"
                  variant="outline"
                  className="border-red-600 font-bold text-red-600 hover:bg-red-50"
                  onClick={() => onDelete(r)}
                >
                  <Trash2 className="size-4" aria-hidden /> Hapus
                </Button>
                {/* D25: pengambilan/checkout hanya untuk status SELESAI atau VOID */}
                {(r.status === "SELESAI" || r.status === "TIDAK_BISA") && (
                  <Button type="button" onClick={() => onCheckout(r)}>
                    <ShoppingCart className="size-4" aria-hidden />
                    {r.status === "TIDAK_BISA" ? "Ambil Unit (POS)" : "Bayar (POS)"}
                  </Button>
                )}
              </div>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ============================================================
// DiagnosaDialog — "Lengkapi Diagnosa & Estimasi" (DIAGNOSA → KONFIRMASI)
// ============================================================
function DiagnosaDialog({
  repair,
  parts,
  user,
  busy,
  onClose,
  onSaved,
}: {
  repair: Repair | null;
  parts: SparePartLite[];
  user: SafeUser;
  busy: boolean;
  onClose: () => void;
  onSaved: (r: Repair) => void;
}) {
  const { toast } = useToast();
  const [diagNotes, setDiagNotes] = useState("");
  const [diagFee, setDiagFee] = useState("");
  const [selected, setSelected] = useState<SelectedPart[]>([]);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  // D28: part pesanan — sparepart yang perlu dipesan karena tidak ada di inventaris
  const [requested, setRequested] = useState<RequestedPart[]>([]);
  const [reqName, setReqName] = useState("");
  const [reqQty, setReqQty] = useState("1");
  const [reqPrice, setReqPrice] = useState("");
  // D64: part external (toko lain) — langsung di diagnosa tanpa alur pesan→datang
  const [extParts, setExtParts] = useState<ExternalPartInput[]>([]);
  const [extDialogOpen, setExtDialogOpen] = useState(false);

  useEffect(() => {
    if (repair) {
      setDiagNotes(repair.notes);
      setDiagFee(repair.serviceFee > 0 ? String(Math.trunc(repair.serviceFee)) : "");
      setSelected(
        parseUsedParts(repair.usedPartsJson)
          .filter((p) => p.partId > 0 && !p.isExternal)
          .map((p) => {
            const exact = parts.find((x) => x.id === p.partId);
            return exact
              ? { part: exact, qty: p.qty }
              : {
                  part: { id: p.partId, name: p.name, sku: "", stock: 999999, costPrice: p.costPrice ?? 0, sellPrice: p.sellPrice },
                  qty: p.qty,
                };
          })
      );
      setQ("");
      // D64: muat part external yang sudah ada agar tidak hilang saat simpan diagnosa
      setExtParts(
        parseUsedParts(repair.usedPartsJson)
          .filter((p) => p.isExternal)
          .map((p) => ({ name: p.name, qty: p.qty, sellPrice: Number(p.sellPrice) || 0, costPrice: Number(p.costPrice) || 0 }))
      );
      // D28: muat part pesanan lama (entri done dipertahankan agar jejak tak hilang)
      setRequested(parseRequestedParts(repair.requestedPartsJson));
      setReqName("");
      setReqQty("1");
      setReqPrice("");
      setOpen(true);
    } else {
      setExtParts([]); // D64
      setOpen(false);
    }
  }, [repair, parts]);

  const matched = q.trim()
    ? parts
        .filter(
          (p) =>
            p.name.toLowerCase().includes(q.toLowerCase()) ||
            p.sku.toLowerCase().includes(q.toLowerCase())
        )
        .slice(0, 4)
    : [];

  const [voidConfirm, setVoidConfirm] = useState(false);

  // D28: tambah permintaan part pesanan (nama bebas — part memang belum ada di katalog)
  const tambahPermintaan = () => {
    const name = reqName.trim();
    const qty = Math.trunc(Number(reqQty) || 0);
    const est = Math.max(0, Number(reqPrice) || 0);
    if (!name) {
      toast({ title: "Nama sparepart wajib diisi", variant: "destructive" });
      return;
    }
    if (qty <= 0) {
      toast({ title: "Jumlah minimal 1", variant: "destructive" });
      return;
    }
    setRequested((prev) => [...prev, { name, qty, estPrice: est }]);
    setReqName("");
    setReqQty("1");
    setReqPrice("");
  };

  const reqPending = requested.filter((p) => !p.done);
  const reqTotal = requestedPartsTotal(reqPending);
  // D64: estimasi ikut menghitung part external
  const extTotal = extParts.reduce((s, p) => s + p.sellPrice * p.qty, 0);
  const totalEstimasi =
    (Number(diagFee) || 0) +
    partsSumOf(selected.map((s) => ({ sellPrice: s.part.sellPrice, qty: s.qty }))) +
    extTotal +
    reqTotal;

  // D24: simpan diagnosa → KONFIRMASI, atau VOID (TIDAK_BISA) bila unit tidak
  // bisa dilanjutkan. Catatan, jasa & sparepart yang sudah diisi tetap tersimpan
  // (jasa/cek bila ada diselesaikan di Kasir saat pengambilan unit).
  const submitDiagnosa = async (status: "KONFIRMASI" | "TIDAK_BISA") => {
    if (!repair) return;
    try {
      setSaving(true);
      const fee = Number(diagFee) || 0;
      const updated = await apiJson<Repair>(`/api/repairs/${repair.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          op: "status",
          status,
          notes: diagNotes.trim(),
          serviceFee: fee,
          usedParts: [
            ...selected.map((s) => ({ partId: s.part.id, qty: s.qty })),
            // D64: part external ikut tersimpan di tiket saat diagnosa
            ...extParts.map((p) => ({
              partId: 0,
              name: p.name,
              qty: p.qty,
              sellPrice: p.sellPrice,
              costPrice: p.costPrice,
              isExternal: true,
            })),
          ],
          requestedParts: requested, // D28: part pesanan (estimasi ikut total biaya)
          userRole: user.role,
          performedBy: user.name,
        }),
      });
      setVoidConfirm(false);
      onSaved(updated);
    } catch (e) {
      toast({
        title: "Gagal menyimpan diagnosa",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };
  const simpan = () => submitDiagnosa("KONFIRMASI");

  return (
    <>
      <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-2xl sm:max-w-md">
        {repair && (
          <>
            <DialogHeader>
              <DialogTitle>Lengkapi Diagnosa &amp; Estimasi</DialogTitle>
              <DialogDescription>
                HP: {repair.deviceModel} (ID: {serviceIdOf(repair.createdAt)})
              </DialogDescription>
            </DialogHeader>
            <p className="text-[13px] text-muted-foreground">
              Lengkapi hasil pemeriksaan sebelum mengirim estimasi biaya ke pelanggan.
            </p>
            <div className="space-y-1">
              <Label htmlFor="diag-notes">Hasil Diagnosa / Keluhan Detail</Label>
              <Textarea
                id="diag-notes"
                value={diagNotes}
                onChange={(e) => setDiagNotes(e.target.value)}
                rows={3}
                placeholder="Contoh: IC Power rusak, perlu ganti PMIC"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="diag-fee">Biaya Jasa Servis (Rp)</Label>
              <Input
                id="diag-fee"
                value={diagFee}
                onChange={(e) => setDiagFee(e.target.value.replace(/\D/g, ""))}
                inputMode="numeric"
                placeholder="Contoh: 100000"
              />
            </div>

            <div>
              <p className="mb-1 text-[12px] font-bold">Pilih Sparepart Terpakai (Jika ada)</p>
              {selected.length === 0 && extParts.length === 0 ? (
                <p className="text-[12px] text-muted-foreground">Belum ada sparepart ditambahkan.</p>
              ) : (
                <div className="space-y-1.5">
                  {selected.map(({ part, qty }) => (
                    <div key={part.id} className="flex items-center gap-2 rounded-lg bg-muted/50 px-2.5 py-1.5">
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-bold">{part.name}</p>
                        <p className="text-[11px] text-muted-foreground">
                          Stok: {part.stock} · {formatCurrency(part.sellPrice)}
                        </p>
                      </div>
                      <button
                        type="button"
                        aria-label={`Kurangi ${part.name}`}
                        onClick={() =>
                          setSelected((prev) =>
                            prev
                              .map((s) => (s.part.id === part.id ? { ...s, qty: s.qty - 1 } : s))
                              .filter((s) => s.qty > 0)
                          )
                        }
                        className="size-7 rounded-lg border text-sm font-bold hover:bg-background"
                      >
                        −
                      </button>
                      <span className="w-6 text-center text-[13px] font-bold tabular-nums">{qty}</span>
                      <button
                        type="button"
                        aria-label={`Tambah ${part.name}`}
                        onClick={() =>
                          setSelected((prev) =>
                            prev.map((s) =>
                              s.part.id === part.id && s.qty < s.part.stock ? { ...s, qty: s.qty + 1 } : s
                            )
                          )
                        }
                        className="size-7 rounded-lg border text-sm font-bold hover:bg-background"
                      >
                        +
                      </button>
                      <button
                        type="button"
                        aria-label={`Hapus ${part.name}`}
                        onClick={() => setSelected((prev) => prev.filter((s) => s.part.id !== part.id))}
                        className="size-7 rounded-lg border text-sm text-red-600 hover:bg-background"
                      >
                        <X className="mx-auto size-3.5" aria-hidden />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              {/* D64: daftar part external (toko lain) */}
              {extParts.length > 0 && (
                <div className="mt-1.5 space-y-1.5">
                  {extParts.map((p, i) => (
                    <div
                      key={`diag-ext-${p.name}-${i}`}
                      className="flex items-center gap-2 rounded-lg border border-amber-200 bg-amber-50/60 px-2.5 py-1.5"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-bold">
                          {p.name} ×{p.qty}
                          <Badge
                            variant="outline"
                            className="ml-1.5 border-amber-300 bg-amber-100 text-[9px] font-bold text-amber-800"
                          >
                            Toko Lain
                          </Badge>
                        </p>
                        <p className="text-[11px] text-muted-foreground">
                          Beli: {formatCurrency(p.costPrice)} · Jual: {formatCurrency(p.sellPrice)}
                        </p>
                      </div>
                      <button
                        type="button"
                        aria-label={`Hapus part external ${p.name}`}
                        onClick={() => setExtParts((prev) => prev.filter((_, idx) => idx !== i))}
                        className="size-7 shrink-0 rounded-lg border text-sm text-red-600 hover:bg-background"
                      >
                        <Trash2 className="mx-auto size-3.5" aria-hidden />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              {/* D64: tombol tambah part external */}
              <Button
                type="button"
                variant="outline"
                className="mt-2 w-full border-amber-300 text-amber-800 hover:bg-amber-50"
                onClick={() => setExtDialogOpen(true)}
              >
                <PackagePlus className="size-4" aria-hidden /> Tambah Part External (Toko Lain)
              </Button>
              <div className="relative mt-2">
                <Search className="absolute left-3 top-2.5 size-4 text-muted-foreground" aria-hidden />
                <Input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Cari sparepart..."
                  className="pl-9"
                />
              </div>
              {q.trim() !== "" && (
                <div className="mt-1 divide-y rounded-xl border">
                  {matched.length === 0 ? (
                    <p className="p-3 text-[12px] text-muted-foreground">Tidak ada sparepart cocok.</p>
                  ) : (
                    matched.map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => {
                          setSelected((prev) => {
                            const found = prev.find((s) => s.part.id === p.id);
                            if (found) {
                              return prev.map((s) => (s.part.id === p.id && s.qty < p.stock ? { ...s, qty: s.qty + 1 } : s));
                            }
                            return [...prev, { part: p, qty: 1 }];
                          });
                          setQ("");
                        }}
                        className="flex w-full items-center justify-between px-3 py-2 text-left text-[12px] hover:bg-primary/5"
                      >
                        <span className="min-w-0 truncate font-semibold">{p.name}</span>
                        <span className="shrink-0 tabular-nums text-muted-foreground">
                          Stok {p.stock} · {formatCurrency(p.sellPrice)}
                        </span>
                      </button>
                    ))
                  )}
                </div>
              )}
            </div>

            {/* D28: sparepart perlu dipesan — tidak tersedia di inventaris */}
            <div>
              <p className="mb-1 text-[12px] font-bold">
                Sparepart Perlu Dipesan{" "}
                <span className="font-normal text-muted-foreground">(belum tersedia di inventaris)</span>
              </p>
              {reqPending.length === 0 ? (
                <p className="text-[12px] text-muted-foreground">
                  Belum ada permintaan. Part yang dipesan ikut estimasi biaya pelanggan.
                </p>
              ) : (
                <div className="space-y-1.5">
                  {reqPending.map((p, idx) => (
                    <div
                      key={`${p.name}-${idx}`}
                      className="flex items-center gap-2 rounded-lg bg-amber-50 px-2.5 py-1.5 ring-1 ring-amber-200"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[13px] font-bold text-amber-900">{p.name}</p>
                        <p className="text-[11px] text-amber-800">
                          {p.qty} × {formatCurrency(p.estPrice)} = {formatCurrency(p.estPrice * p.qty)} · akan dipesan
                        </p>
                      </div>
                      <button
                        type="button"
                        aria-label={`Hapus permintaan ${p.name}`}
                        onClick={() => setRequested((prev) => prev.filter((x) => x !== p))}
                        className="size-7 rounded-lg border text-sm text-red-600 hover:bg-background"
                      >
                        <X className="mx-auto size-3.5" aria-hidden />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <div className="mt-2 grid grid-cols-[1fr_3.5rem_5.5rem_auto] gap-1.5">
                <Input
                  value={reqName}
                  onChange={(e) => setReqName(e.target.value)}
                  placeholder="Nama sparepart (mis. LCD iPhone 11)"
                  className="text-[12px]"
                />
                <Input
                  value={reqQty}
                  onChange={(e) => setReqQty(e.target.value.replace(/\D/g, ""))}
                  inputMode="numeric"
                  placeholder="Qty"
                  aria-label="Jumlah"
                  className="text-[12px]"
                />
                <Input
                  value={reqPrice}
                  onChange={(e) => setReqPrice(e.target.value.replace(/\D/g, ""))}
                  inputMode="numeric"
                  placeholder="Est. harga"
                  aria-label="Estimasi harga"
                  className="text-[12px]"
                />
                <Button
                  type="button"
                  variant="outline"
                  className="h-9 shrink-0 px-3 text-[12px]"
                  onClick={tambahPermintaan}
                >
                  <Plus className="size-3.5" aria-hidden /> Tambah
                </Button>
              </div>
            </div>

            {/* D28: ringkasan estimasi (jasa + part stok + part external + part dipesan) */}
            <div className="flex items-center justify-between rounded-lg bg-muted/60 px-3 py-2 text-[13px]">
              <span className="font-semibold">
                Total Estimasi (Jasa + Sparepart{extParts.length > 0 ? " + Part External" : ""}{reqPending.length > 0 ? " + Part Dipesan" : ""})
              </span>
              <b className="tabular-nums text-primary">{formatCurrency(totalEstimasi)}</b>
            </div>

            <DialogFooter className="gap-2">
              {/* D24: void — unit ternyata tidak bisa dilanjutkan langsung dari dialog diagnosa */}
              <Button
                type="button"
                variant="outline"
                className="mr-auto border-red-600 font-bold text-red-600 hover:bg-red-50"
                onClick={() => setVoidConfirm(true)}
                disabled={saving || busy}
              >
                <Ban className="size-4" aria-hidden /> Tidak Bisa (Void)
              </Button>
              <Button type="button" variant="ghost" onClick={onClose}>
                Batal
              </Button>
              <Button type="button" onClick={simpan} disabled={saving || busy}>
                Simpan &amp; Lanjut ke Konfirmasi
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
      </Dialog>

      {/* D64: dialog part external (toko lain) — Diagnosa */}
      <ExternalPartDialog
        open={extDialogOpen}
        onClose={() => setExtDialogOpen(false)}
        onAdd={(p) => setExtParts((prev) => [...prev, p])}
      />

      {/* D24: konfirmasi void diagnosa */}
      <AlertDialog open={voidConfirm} onOpenChange={(v) => !v && setVoidConfirm(false)}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Void Servis (Tidak Bisa)?</AlertDialogTitle>
            <AlertDialogDescription>
              {repair && (
                <>
                  HP {serviceIdOf(repair.createdAt)} ({repair.deviceModel}) akan berstatus{" "}
                  <b>Tidak Bisa (void)</b> — perbaikan dihentikan dan pelanggan tinggal mengambil
                  unitnya. Biaya jasa/cek bila ada diselesaikan di Kasir saat pengambilan.
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 text-white hover:bg-red-700"
              disabled={saving || busy}
              onClick={(e) => {
                e.preventDefault();
                void submitDiagnosa("TIDAK_BISA");
              }}
            >
              Ya, Void
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

// ============================================================
// D64 — ExternalPartDialog: tambah sparepart EXTERNAL (toko lain)
// langsung di tiket (Terima/Edit Servis incl. Servis Kilat & dialog
// Diagnosa) tanpa lewat alur pesan→datang. Nama & harga bebas diketik:
// harga BELI = modal toko (boleh 0 bila gratis/garansi), harga JUAL =
// yang ditagihkan ke pelanggan (wajib > 0). Tersimpan di usedPartsJson
// sebagai {partId: 0, isExternal: true, ...} — tidak menyentuh stok,
// ikut total biaya tiket, struk, dan HPP laporan profit (satu pola
// dengan part toko lain di kartu tagihan Kasir).
// ============================================================
function ExternalPartDialog({
  open,
  onClose,
  onAdd,
}: {
  open: boolean;
  onClose: () => void;
  onAdd: (part: ExternalPartInput) => void;
}) {
  const [name, setName] = useState("");
  const [qty, setQty] = useState("1");
  const [cost, setCost] = useState("");
  const [sell, setSell] = useState("");

  // reset + tutup dalam satu langkah — field bersih untuk part berikutnya
  // (tanpa effect: pola eslint react-hooks/set-state-in-effect)
  const closeAndReset = () => {
    setName("");
    setQty("1");
    setCost("");
    setSell("");
    onClose();
  };

  const qtyNum = Math.trunc(Number(qty) || 0);
  const sellNum = Number(sell) || 0;
  const valid = name.trim() !== "" && qtyNum > 0 && sellNum > 0;

  const tambah = () => {
    if (!valid) return;
    onAdd({
      name: name.trim(),
      qty: qtyNum,
      sellPrice: sellNum,
      costPrice: Number(cost) || 0,
    });
    closeAndReset();
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && closeAndReset()}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-2xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Tambah Part External (Toko Lain)</DialogTitle>
          <DialogDescription>
            Part dibeli dari luar & langsung dipasang — tidak menyentuh stok inventaris.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-1">
          <Label htmlFor="ext-nama">Nama Part</Label>
          <Input
            id="ext-nama"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Contoh: LCD iPhone 11 (beli di toko sebelah)"
          />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1">
            <Label htmlFor="ext-beli">Harga Beli (Rp)</Label>
            <Input
              id="ext-beli"
              value={cost}
              onChange={(e) => setCost(e.target.value.replace(/\D/g, ""))}
              inputMode="numeric"
              placeholder="0"
            />
            <p className="text-[10px] text-muted-foreground">Modal toko — boleh 0 bila gratis/garansi.</p>
          </div>
          <div className="space-y-1">
            <Label htmlFor="ext-jual">Harga Jual (Rp)</Label>
            <Input
              id="ext-jual"
              value={sell}
              onChange={(e) => setSell(e.target.value.replace(/\D/g, ""))}
              inputMode="numeric"
              placeholder="Wajib"
            />
            <p className="text-[10px] text-muted-foreground">Ditagihkan ke pelanggan.</p>
          </div>
        </div>
        <div className="space-y-1">
          <Label htmlFor="ext-qty">Jumlah</Label>
          <Input
            id="ext-qty"
            value={qty}
            onChange={(e) => setQty(e.target.value.replace(/\D/g, ""))}
            inputMode="numeric"
          />
        </div>
        <DialogFooter>
          <Button type="button" variant="ghost" onClick={closeAndReset}>
            Batal
          </Button>
          <Button type="button" onClick={tambah} disabled={!valid}>
            Tambah ke Tiket
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================
// D28 — PartDatangDialog: penanganan sparepart pesanan yang sudah datang.
// Per part dipilih jalurnya: (1) Masuk Inventaris — pilih part katalog existing
// (stok += qty) atau kosongkan pencarian → part katalog BARU dibuat otomatis
// dari permintaan (stok = qty, harga jual = estimasi, SKU pola D22); part lalu
// dicatat sebagai part terpakai internal → dipotong stok saat checkout.
// (2) Langsung Pasang — dicatat sebagai part isExternal (ala part toko lain),
// tidak menyentuh stok. D30: harga beli per unit wajib diisi di sini (momen
// barang datang) — tercatat di tiket, katalog, & jejak part terpakai. Semua
// permintaan beres & status Disetujui → tiket otomatis lanjut Dikerjakan
// (server).
// ============================================================
function PartDatangDialog({
  repair,
  parts,
  user,
  onClose,
  onSaved,
}: {
  repair: Repair | null;
  parts: SparePartLite[];
  user: SafeUser;
  onClose: () => void;
  onSaved: (r: Repair) => void;
}) {
  const { toast } = useToast();
  // daftar permintaan dengan index ASLI di requestedPartsJson (dipakai API)
  const items = repair
    ? parseRequestedParts(repair.requestedPartsJson)
        .map((p, index) => ({ ...p, index }))
        .filter((p) => !p.done)
    : [];
  const [modes, setModes] = useState<Record<number, "STOK" | "EXTERNAL">>({});
  const [picked, setPicked] = useState<Record<number, number>>({});
  const [search, setSearch] = useState<Record<number, string>>({});
  // D30: harga beli per part (string agar bisa diketik bebas; divalidasi saat simpan)
  const [costs, setCosts] = useState<Record<number, string>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (repair) {
      setModes({});
      setPicked({});
      setSearch({});
      setCosts({});
    }
  }, [repair]);

  if (!repair) return null;

  const modeOf = (i: number): "STOK" | "EXTERNAL" => modes[i] ?? "STOK";
  const matchedFor = (i: number) => {
    const q = (search[i] ?? "").trim().toLowerCase();
    if (!q) return [];
    return parts
      .filter((p) => p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q))
      .slice(0, 4);
  };

  const simpan = async () => {
    // D30: harga beli wajib untuk semua part (boleh 0 bila gratis/garansi)
    const kosong = items.filter((p) => !/^\d+$/.test((costs[p.index] ?? "").trim()));
    if (kosong.length > 0) {
      toast({
        title: "Harga beli belum lengkap",
        description: `Isi harga beli untuk semua part pesanan (boleh 0 bila gratis) — mulai dari: ${kosong[0].name}`,
        variant: "destructive",
      });
      return;
    }
    try {
      setSaving(true);
      const updated = await apiJson<Repair>(`/api/repairs/${repair.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          op: "partDatang",
          items: items.map((p) => ({
            index: p.index,
            mode: modeOf(p.index),
            partId: picked[p.index] || 0,
            costPrice: Number(costs[p.index]), // D30: harga beli aktual
          })),
          userRole: user.role,
          performedBy: user.name,
        }),
      });
      onSaved(updated);
    } catch (e) {
      toast({
        title: "Gagal memproses part datang",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-2xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Sparepart Sudah Datang</DialogTitle>
          <DialogDescription>
            HP: {repair.deviceModel} (ID: {serviceIdOf(repair.createdAt)}) — pilih penanganan tiap
            part pesanan dan isi harga belinya.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          {items.map((p) => {
            const mode = modeOf(p.index);
            const matched = matchedFor(p.index);
            return (
              <div key={p.index} className="rounded-xl border p-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-[13px] font-bold">{p.name}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {p.qty} × est. {formatCurrency(p.estPrice)} = {formatCurrency(p.estPrice * p.qty)}
                    </p>
                  </div>
                  <div className="flex shrink-0 gap-1">
                    <button
                      type="button"
                      onClick={() => setModes((prev) => ({ ...prev, [p.index]: "STOK" }))}
                      className={cn(
                        "rounded-lg px-2 py-1 text-[11px] font-bold transition-colors",
                        mode === "STOK"
                          ? "bg-primary text-primary-foreground"
                          : "border text-muted-foreground hover:bg-muted"
                      )}
                    >
                      Masuk Stok
                    </button>
                    <button
                      type="button"
                      onClick={() => setModes((prev) => ({ ...prev, [p.index]: "EXTERNAL" }))}
                      className={cn(
                        "rounded-lg px-2 py-1 text-[11px] font-bold transition-colors",
                        mode === "EXTERNAL"
                          ? "bg-primary text-primary-foreground"
                          : "border text-muted-foreground hover:bg-muted"
                      )}
                    >
                      Langsung Pasang
                    </button>
                  </div>
                </div>

                {mode === "STOK" ? (
                  <div className="mt-2 space-y-1.5">
                    <Input
                      value={search[p.index] ?? ""}
                      onChange={(e) => setSearch((prev) => ({ ...prev, [p.index]: e.target.value }))}
                      placeholder="Cari part katalog (kosongkan = buat part baru otomatis)"
                      className="text-[12px]"
                    />
                    {matched.length > 0 && (
                      <div className="divide-y rounded-lg border">
                        {matched.map((part) => (
                          <button
                            key={part.id}
                            type="button"
                            onClick={() => {
                              setPicked((prev) => ({ ...prev, [p.index]: part.id }));
                              setSearch((prev) => ({ ...prev, [p.index]: "" }));
                              // D30: prefill harga beli dgn harga beli katalog (kalau kosong)
                              setCosts((prev) =>
                                (prev[p.index] ?? "") === ""
                                  ? { ...prev, [p.index]: part.costPrice > 0 ? String(part.costPrice) : "" }
                                  : prev
                              );
                            }}
                            className="flex w-full items-center justify-between gap-2 px-3 py-1.5 text-left text-[12px] hover:bg-primary/5"
                          >
                            <span className="min-w-0 truncate font-semibold">{part.name}</span>
                            <span className="shrink-0 tabular-nums text-muted-foreground">
                              Stok {part.stock} · {formatCurrency(part.sellPrice)}
                            </span>
                          </button>
                        ))}
                      </div>
                    )}
                    <p className="text-[11px] text-muted-foreground">
                      {picked[p.index]
                        ? `Stok part terpilih akan ditambah ${p.qty} lalu part dicatat terpakai (dipotong lagi saat checkout). Harga beli di bawah ikut memperbarui katalog.`
                        : `Part katalog baru dibuat otomatis: stok ${p.qty}, harga jual ${formatCurrency(p.estPrice)}, harga beli sesuai di bawah, SKU pola otomatis.`}
                    </p>
                  </div>
                ) : (
                  <p className="mt-2 text-[11px] text-muted-foreground">
                    Dicatat sebagai part toko lain (tanpa stok) — tidak menyentuh inventaris; harga
                    beli di bawah ikut tercatat di tiket.
                  </p>
                )}

                {/* D30: input harga beli (berlaku utk kedua mode) */}
                <div className="mt-2 rounded-lg bg-muted/60 p-2">
                  <label
                    htmlFor={`cost-${p.index}`}
                    className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground"
                  >
                    Harga Beli / Unit <span className="text-red-500">*</span>
                  </label>
                  <Input
                    id={`cost-${p.index}`}
                    inputMode="numeric"
                    value={costs[p.index] ?? ""}
                    onChange={(e) =>
                      setCosts((prev) => ({ ...prev, [p.index]: e.target.value.replace(/\D/g, "") }))
                    }
                    placeholder="cth: 350000"
                    className="mt-1 text-[13px] font-bold tabular-nums"
                  />
                  {(costs[p.index] ?? "") !== "" && (
                    <p
                      className={cn(
                        "mt-1 text-[11px] font-semibold",
                        p.estPrice * p.qty - Number(costs[p.index]) * p.qty >= 0
                          ? "text-emerald-700"
                          : "text-red-600"
                      )}
                    >
                      Untung est: {formatCurrency(p.estPrice * p.qty - Number(costs[p.index]) * p.qty)}{" "}
                      <span className="font-normal text-muted-foreground">
                        (jual {formatCurrency(p.estPrice * p.qty)} − beli{" "}
                        {formatCurrency(Number(costs[p.index]) * p.qty)})
                      </span>
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <DialogFooter className="gap-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Batal
          </Button>
          <Button type="button" onClick={simpan} disabled={saving}>
            Simpan &amp; Proses
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================
// RollbackAdminAuthDialog.kt — otorisasi Admin untuk menurunkan status
// ============================================================
function RollbackAuthDialog({
  open,
  onClose,
  onSuccess,
}: {
  open: boolean;
  onClose: () => void;
  onSuccess: (cred: { username: string; pin: string }) => void;
}) {
  const { toast } = useToast();
  // verifikasi dilakukan server saat PUT (adminUsername + adminPin);
  // dialog ini meminta kredensial Admin lalu menandainya untuk form.
  const [pin, setPin] = useState("");
  // Admin tunggal umumnya cukup; nama admin diambil saat simpan form (server validasi)
  // → dialog hanya konfirmasi PIN milik "akun Admin" yang login melalui prompt ini.
  const [adminName, setAdminName] = useState("Admin");

  const verify = async () => {
    // verifikasi cepat via endpoint login (tanpa mengubah sesi)
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: adminName, pin }),
      });
      const data = await res.json().catch(() => ({}));
      if (data?.user?.role === "Admin") {
        onSuccess({ username: adminName.trim(), pin });
        setPin("");
        return;
      }
      // bukan admin → coba cari admin lain via dialog? referensi memilih dari daftar;
      // versi web: username admin = "admin" default, dapat diubah di input.
      toast({
        title: "Otorisasi Admin gagal",
        description: data?.message ?? "Username/PIN bukan Admin yang valid.",
        variant: "destructive",
      });
    } catch {
      toast({ title: "Otorisasi gagal", description: "Periksa koneksi.", variant: "destructive" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="rounded-2xl sm:max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-red-600">Otorisasi Admin Diperlukan</DialogTitle>
          <DialogDescription>
            Menurunkan (rollback) status tiket servis memerlukan persetujuan Administrator. Masukkan
            username &amp; PIN Admin.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <Label htmlFor="rb-user">Username Admin</Label>
            <Input id="rb-user" value={adminName} onChange={(e) => setAdminName(e.target.value)} placeholder="admin" />
          </div>
          <div className="space-y-1">
            <Label htmlFor="rb-pin">PIN 4-Digit</Label>
            <Input
              id="rb-pin"
              type="password"
              inputMode="numeric"
              maxLength={4}
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
              onKeyDown={(e) => {
                if (e.key === "Enter" && pin.length === 4) verify();
              }}
            />
          </div>
          <div className="flex gap-2">
            <Button type="button" variant="outline" className="flex-1" onClick={onClose}>
              Batal
            </Button>
            <Button type="button" className="flex-1" disabled={pin.length !== 4} onClick={verify}>
              Otorisasi
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
