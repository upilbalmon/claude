// Tipe & konstanta bersama — setia pada MainLayout.kt (ShopTab, isTabAllowed)
export type SafeUser = {
  id: number;
  name: string;
  username: string;
  role: string;
  mustChangePin: boolean;
  permissionDashboard: boolean;
  permissionCashier: boolean;
  permissionServices: boolean;
  permissionInventory: boolean;
  permissionCustomers: boolean;
  permissionUsers: boolean;
  permissionSettings: boolean;
};

export type ShopTab = "LAPORAN" | "SERVIS" | "KASIR" | "INVENTARIS" | "BELANJA" | "PELANGGAN" | "ABSENSI" | "SETTING";

// D75 — saran repo backup default (tampil terisi di layar bootstrap pra-login
// & Pengaturan → Data & Backup). Milik pemilik deployment ini; kolom Repo
// tetap bisa diganti bebas bila mau memakai repo lain.
export const SUGGESTED_REPO = "upilbalmon/fixplus-backup";

export const SHOP_TABS: { key: ShopTab; label: string }[] = [
  { key: "LAPORAN", label: "Laporan" },
  { key: "SERVIS", label: "Servis" },
  { key: "KASIR", label: "Kasir" },
  { key: "INVENTARIS", label: "Inventaris" },
  { key: "BELANJA", label: "Belanja" },
  { key: "PELANGGAN", label: "Pelanggan" },
  // D73 — Absensi Karyawan: terlihat untuk SEMUA role (absen masuk/keluar
  // mandiri); alat pengelolaan (rekap semua karyawan + catat manual) hanya
  // tampil & dijaga server untuk Admin — di dalam halaman, bukan izin tab.
  { key: "ABSENSI", label: "Absensi" },
  { key: "SETTING", label: "Setting" },
];

// isTabAllowed() MainLayout.kt — BELANJA ikut izin inventory
export function isTabAllowed(tab: ShopTab, user: SafeUser | null): boolean {
  if (!user) return false;
  switch (tab) {
    case "LAPORAN":
      return user.permissionDashboard;
    case "SERVIS":
      return user.permissionServices;
    case "KASIR":
      return user.permissionCashier;
    case "INVENTARIS":
      return user.permissionInventory;
    case "BELANJA":
      return user.permissionInventory;
    case "PELANGGAN":
      return user.permissionCustomers;
    case "ABSENSI":
      // D73 — absensi mandiri dibuka untuk semua role (kasir & teknisi juga
      // perlu absen); data orang lain tidak pernah dikirim ke non-Admin.
      return true;
    case "SETTING":
      return user.permissionSettings;
  }
}

export const TAB_LABEL: Record<ShopTab, string> = Object.fromEntries(
  SHOP_TABS.map((t) => [t.key, t.label])
) as Record<ShopTab, string>;

// Alur status RepairStatus.kt — dipakai modul Servis nanti, didokumentasikan di sini
export const REPAIR_STATUS_ORDER: string[] = [
  "ANTRI",
  "DIAGNOSA",
  "KONFIRMASI",
  "DISETUJUI",
  "DIKERJAKAN",
  "SELESAI",
  "DIAMBIL",
];
export const REPAIR_STATUS_LABEL: Record<string, string> = {
  ANTRI: "Antri",
  DIAGNOSA: "Diagnosa",
  KONFIRMASI: "Konfirmasi",
  DISETUJUI: "Disetujui Pelanggan",
  DIKERJAKAN: "Dikerjakan",
  SELESAI: "Selesai",
  DIAMBIL: "Diambil",
  DIBATALKAN: "Dibatalkan Pelanggan",
  TIDAK_BISA: "Tidak Bisa",
};
