"use client";

// ============================================================================
// D50 — Asisten AI (bubble mengambang, keputusan user 12 Nov 2026):
//  - Bubble kanan-bawah di semua halaman; panel chat slide-up
//  - Menjawab dari DATA TOKO nyata (konteks dibangun server-side, role-aware:
//    laba kotor/HPP/nilai stok hanya Admin — konsisten D48 jawaban g)
//  - Riwayat TIDAK disimpan (hilang saat tutup/refresh) — tidak ada tabel baru
//  - Gaya jawaban singkat & poin; chip pertanyaan cepat siap-klik
// D51 —
//  - Mode LAYAR PENUH (tombol perbesar di header, keluar via tombol yang sama
//    atau Esc); kolom pesan terpusat agar nyaman dibaca di desktop
//  - Tombol "Coba lagi" saat gagal — mengulang pertanyaan tanpa mengetik ulang
// D59 — HANYA Administrator/Owner (keputusan user 12 Nov 2026):
//  - Role lain (Kasir/Teknisi) tidak melihat bubble — app-shell tidak merender
//    komponen ini, dan komponen juga menjaga dirinya sendiri (return null)
//  - API /api/ai/assistant menolak non-Admin/Owner dengan 403 server-side
// Komponen ini hanya memanggil POST /api/ai/assistant — SDK AI tidak pernah
// diimporkan ke client.
// ============================================================================
import { useEffect, useRef, useState } from "react";
import { Bot, Eraser, Maximize2, Minimize2, SendHorizontal, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { SafeUser } from "@/lib/app-types";
import { bolehAsistenAi } from "@/lib/user-utils"; // D59 — gate Asisten AI

type ChatMsg = { role: "user" | "assistant"; content: string };

const CHIP_DASAR = [
  "Berapa omzet hari ini?",
  "Stok apa yang menipis?",
  "Servis apa yang belum diambil?",
  "Siapa saja yang masih bon?",
];

export function AiAssistant({ user }: { user: SafeUser }) {
  const isAdmin = user.role === "Admin";
  const chips = isAdmin
    ? [...CHIP_DASAR, "Bagaimana laba 7 hari terakhir?"]
    : CHIP_DASAR;

  const [open, setOpen] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const [msgs, setMsgs] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [lastQuestion, setLastQuestion] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  // auto-scroll ke pesan terbaru
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [msgs, loading, open, fullscreen]);

  // D51: saat layar penuh — kunci scroll body & tombol Esc untuk keluar
  useEffect(() => {
    if (!fullscreen) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setFullscreen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [fullscreen]);

  // D59: pertahanan ganda — selain app-shell tidak merender komponen ini untuk
  // role selain Admin/Owner, komponen juga menolak merender dirinya sendiri.
  // Diletakkan SETELAH semua hooks agar urutan hooks selalu konsisten.
  if (!bolehAsistenAi(user.role)) return null;

  function closePanel() {
    setOpen(false);
    setFullscreen(false); // tutup dari layar penuh → buka lagi dalam mode normal
  }

  async function ask(text: string, isRetry = false) {
    const question = text.trim();
    if (!question || loading) return;
    setError("");
    if (!isRetry) {
      setInput("");
      setLastQuestion(question);
      setMsgs((prev) => [...prev, { role: "user", content: question }]);
    }
    // D51 (retry): pertanyaan yang gagal sudah ada sebagai bubble terakhir —
    // jangan dikirim ulang dalam history agar konteks tidak dobel.
    const base =
      isRetry && msgs.length > 0 && msgs[msgs.length - 1].role === "user"
        ? msgs.slice(0, -1)
        : msgs;
    const history = base.slice(-10); // konteks terbatas — riwayat tidak disimpan
    setLoading(true);
    try {
      const res = await fetch("/api/ai/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requesterUsername: user.username,
          message: question,
          history,
        }),
      });
      const data = (await res.json().catch(() => ({}))) as { reply?: string; error?: string };
      if (!res.ok || !data.reply) {
        setError(data.error ?? "Asisten AI sedang tidak tersedia — coba lagi sebentar");
      } else {
        setMsgs((prev) => [...prev, { role: "assistant", content: data.reply! }]);
      }
    } catch {
      setError("Koneksi bermasalah — periksa jaringan lalu coba lagi");
    } finally {
      setLoading(false);
    }
  }

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Buka Asisten AI"
        title="Asisten AI — tanya data toko"
        className="fixed bottom-20 right-4 z-40 flex size-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition-transform hover:scale-105 active:scale-95 md:bottom-6 md:right-6"
      >
        <Bot className="size-6" aria-hidden />
      </button>
    );
  }

  return (
    <div
      role="dialog"
      aria-label="Asisten AI"
      aria-modal={fullscreen || undefined}
      data-testid="panel-ai"
      data-fullscreen={fullscreen ? "true" : "false"}
      className={
        fullscreen
          ? "fixed inset-0 z-50 flex flex-col overflow-hidden bg-card"
          : "fixed bottom-20 right-4 z-40 flex h-[min(68vh,32rem)] w-[min(calc(100vw-2rem),24rem)] flex-col overflow-hidden rounded-2xl border bg-card shadow-xl md:bottom-6 md:right-6"
      }
    >
      {/* Header */}
      <div className="flex items-center gap-2.5 border-b px-3 py-2.5">
        <div className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-primary/10">
          <Bot className="size-5 text-primary" aria-hidden />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-bold leading-tight">Asisten AI</p>
          <p className="truncate text-[11px] text-muted-foreground">
            Menjawab dari data toko · riwayat tidak disimpan
          </p>
        </div>
        {msgs.length > 0 && (
          <button
            type="button"
            onClick={() => {
              setMsgs([]);
              setError("");
              setLastQuestion("");
            }}
            aria-label="Mulai ulang percakapan"
            title="Mulai ulang percakapan"
            className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
          >
            <Eraser className="size-4" aria-hidden />
          </button>
        )}
        {/* D51: tampilan layar penuh */}
        <button
          type="button"
          onClick={() => setFullscreen((v) => !v)}
          aria-label={fullscreen ? "Keluar dari layar penuh" : "Tampilan layar penuh"}
          title={fullscreen ? "Keluar layar penuh (Esc)" : "Tampilan layar penuh"}
          data-testid="btn-fullscreen"
          className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
        >
          {fullscreen ? (
            <Minimize2 className="size-4" aria-hidden />
          ) : (
            <Maximize2 className="size-4" aria-hidden />
          )}
        </button>
        <button
          type="button"
          onClick={closePanel}
          aria-label="Tutup Asisten AI"
          title="Tutup"
          className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground"
        >
          <X className="size-4" aria-hidden />
        </button>
      </div>

      {/* Area pesan (fullscreen: kolom terpusat agar mudah dibaca) */}
      <div
        ref={scrollRef}
        className={
          fullscreen
            ? "mx-auto w-full max-w-2xl flex-1 space-y-2 overflow-y-auto p-3 md:p-4"
            : "flex-1 space-y-2 overflow-y-auto p-3"
        }
      >
        {msgs.length === 0 && !loading && (
          <div className="space-y-2.5">
            <div className="rounded-2xl rounded-bl-md bg-muted px-3 py-2 text-[13px] leading-relaxed">
              Halo {user.name.split(" ")[0]}! Tanya apa saja tentang data toko — omzet, stok,
              piutang, atau status servis.
            </div>
            <div className="flex flex-wrap gap-1.5 pt-0.5">
              {chips.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => void ask(c)}
                  className="rounded-full border bg-background px-3 py-1.5 text-[12px] transition-colors hover:bg-muted"
                >
                  {c}
                </button>
              ))}
            </div>
            {!isAdmin && (
              <p className="text-[11px] text-muted-foreground">
                Angka laba kotor &amp; nilai stok hanya bisa dijawab untuk Admin.
              </p>
            )}
          </div>
        )}

        {msgs.map((m, i) =>
          m.role === "user" ? (
            <div
              key={i}
              className="ml-auto max-w-[85%] rounded-2xl rounded-br-md bg-primary px-3 py-2 text-[13px] leading-relaxed text-primary-foreground"
            >
              {m.content}
            </div>
          ) : (
            <div
              key={i}
              className="max-w-[88%] whitespace-pre-wrap rounded-2xl rounded-bl-md bg-muted px-3 py-2 text-[13px] leading-relaxed"
            >
              {m.content}
            </div>
          ),
        )}

        {loading && (
          <div
            className="flex max-w-[60%] items-center gap-1.5 rounded-2xl rounded-bl-md bg-muted px-3 py-2.5"
            aria-label="Asisten sedang mengetik"
          >
            <span className="size-1.5 animate-bounce rounded-full bg-primary/70 [animation-delay:0ms]" />
            <span className="size-1.5 animate-bounce rounded-full bg-primary/70 [animation-delay:150ms]" />
            <span className="size-1.5 animate-bounce rounded-full bg-primary/70 [animation-delay:300ms]" />
          </div>
        )}

        {error && (
          <div className="space-y-1.5">
            <p className="rounded-xl bg-red-50 px-3 py-2 text-[12px] font-semibold text-red-800">
              {error}
            </p>
            {lastQuestion && !loading && (
              <button
                type="button"
                onClick={() => void ask(lastQuestion, true)}
                data-testid="btn-retry-ai"
                className="rounded-full border bg-background px-3 py-1.5 text-[12px] font-semibold text-red-800 transition-colors hover:bg-red-50"
              >
                Coba lagi
              </button>
            )}
          </div>
        )}
      </div>

      {/* Input */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          void ask(input);
        }}
        className={
          fullscreen
            ? "mx-auto flex w-full max-w-2xl items-center gap-2 border-t p-2.5 md:p-3"
            : "flex items-center gap-2 border-t p-2.5"
        }
      >
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={loading}
          maxLength={1000}
          placeholder="Tanya data toko…"
          aria-label="Pertanyaan untuk Asisten AI"
          className="h-9 rounded-xl"
        />
        <Button
          type="submit"
          size="icon"
          disabled={loading || input.trim() === ""}
          aria-label="Kirim pertanyaan"
          className="size-9 shrink-0 rounded-xl"
        >
          <SendHorizontal className="size-4" aria-hidden />
        </Button>
      </form>
    </div>
  );
}
