"use client";

// ============================================================================
// D81 — LONCENG NOTIFIKASI + PANEL NOTIFIKASI APLIKASI (bisa dibuka kapan saja)
// Permintaan pemilik: "notif cuma tampil sebentar kadang kita tidak sempat
// membacanya" → toast dipuji dengan PANEL PERMANEN di header, terlihat dari
// halaman manapun. Riwayat tersimpan di server (tabel AppNotification — lihat
// pushNotification di lib/notifications.ts) sehingga tetap ada setelah
// reload, ganti tab, maupun ganti perangkat.
//
// Dirancang ekstensibel untuk fitur lain di masa depan: notifikasi baru cukup
// push dengan type baru; panel memetakan ikon/warna per type dan punya ikon
// bawaan (Bell) untuk type yang belum dikenal.
//
// Pemantau: daftar diambil saat panel dibuka, badge "belum dibaca" disegarkan
// tiap 45 detik + saat tab kembali terlihat/fokus (pola sama seperti chip
// backup D80). Klik item = tandai dibaca; tombol "Tandai semua dibaca".
// D83 — KELOLA RIWAYAT: tombol X di tiap item = hapus satu (muncul saat
// hover, dikonfirmasi server), tombol "Hapus semua" di kepala panel dengan
// konfirmasi dua-langkah (klik pertama jadi "Yakin?", klik kedua menjalankan)
// supaya riwayat tidak hilang tak sengaja. HANYA dirender untuk Admin — API
// /api/notifications juga menolak non-Admin server-side (action-guard), UI
// bukan satu-satunya penjaga.
// ============================================================================
import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArchiveRestore,
  Bell,
  CheckCheck,
  CloudAlert,
  CloudCheck,
  Loader2,
  Trash2,
  X,
} from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { formatDateTime } from "@/lib/format";

type NotificationItem = {
  id: number;
  type: string;
  title: string;
  message: string;
  meta: Record<string, unknown> | null;
  readAt: string | null;
  createdAt: string;
};

// Ikon + warna per type notifikasi (ekstensibel — type tak dikenal = Bell abu)
function typeFace(type: string): {
  icon: React.ComponentType<{ className?: string }>;
  cls: string;
} {
  switch (type) {
    case "BACKUP_SUCCESS":
      return { icon: CloudCheck, cls: "text-emerald-600 dark:text-emerald-400" };
    case "BACKUP_FAILED":
      return { icon: CloudAlert, cls: "text-red-600 dark:text-red-400" };
    case "SYNC_CONFLICT":
      return { icon: CloudAlert, cls: "text-amber-600 dark:text-amber-400" };
    case "SYNC_ERROR":
      return { icon: CloudAlert, cls: "text-amber-600 dark:text-amber-400" };
    case "RESTORE":
      return { icon: ArchiveRestore, cls: "text-sky-600 dark:text-sky-400" };
    default:
      return { icon: Bell, cls: "text-muted-foreground" };
  }
}

const POLL_MS = 45_000;

export function NotificationBell({ requesterUsername }: { requesterUsername: string }) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [unread, setUnread] = useState(0);
  const [loading, setLoading] = useState(false);
  const [markingAll, setMarkingAll] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const [confirmClear, setConfirmClear] = useState(false); // D83 — konfirmasi dua-langkah
  const clearTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const fetchList = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(
        `/api/notifications?requesterUsername=${encodeURIComponent(requesterUsername)}`,
        { cache: "no-store" }
      );
      if (!res.ok) return; // 403 non-Admin / gangguan — biarkan data terakhir
      const j = (await res.json()) as { items?: NotificationItem[]; unreadCount?: number };
      setItems(Array.isArray(j.items) ? j.items : []);
      setUnread(typeof j.unreadCount === "number" ? j.unreadCount : 0);
    } catch {
      /* offline — biarkan tampilan terakhir */
    } finally {
      setLoading(false);
    }
  }, [requesterUsername]);

  // Badge "belum dibaca" disegarkan berkala walau panel tertutup.
  const refreshBadge = useCallback(async () => {
    if (typeof document !== "undefined" && document.visibilityState !== "visible") return;
    try {
      const res = await fetch(
        `/api/notifications?requesterUsername=${encodeURIComponent(requesterUsername)}`,
        { cache: "no-store" }
      );
      if (!res.ok) return;
      const j = (await res.json()) as { items?: NotificationItem[]; unreadCount?: number };
      setUnread(typeof j.unreadCount === "number" ? j.unreadCount : 0);
      if (open) setItems(Array.isArray(j.items) ? j.items : []);
    } catch {
      /* offline */
    }
  }, [open, requesterUsername]);

  useEffect(() => {
    void refreshBadge();
    const id = setInterval(refreshBadge, POLL_MS);
    const onVisible = () => {
      if (document.visibilityState === "visible") void refreshBadge();
    };
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("focus", onVisible);
    return () => {
      clearInterval(id);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("focus", onVisible);
    };
  }, [refreshBadge]);

  const onOpenChange = useCallback(
    (v: boolean) => {
      setOpen(v);
      setConfirmClear(false); // D83 — tutup panel = batal konfirmasi hapus
      if (v) void fetchList(); // selalu segar saat panel dibuka
    },
    [fetchList]
  );

  // Klik item = tandai item itu dibaca (optimistis di UI, server yang memutuskan)
  const markOne = useCallback(
    async (id: number) => {
      setItems((prev) =>
        prev.map((n) => (n.id === id && !n.readAt ? { ...n, readAt: new Date().toISOString() } : n))
      );
      setUnread((u) => Math.max(0, u - 1));
      try {
        const res = await fetch("/api/notifications", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ requesterUsername, action: "read", ids: [id] }),
        });
        if (!res.ok) {
          void fetchList(); // gagal → kembalikan dari server
          return;
        }
        const j = (await res.json()) as { unreadCount?: number };
        if (typeof j.unreadCount === "number") setUnread(j.unreadCount);
      } catch {
        void fetchList();
      }
    },
    [fetchList, requesterUsername]
  );

  const markAll = useCallback(async () => {
    setMarkingAll(true);
    try {
      const res = await fetch("/api/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requesterUsername, action: "readAll" }),
      });
      if (res.ok) {
        const j = (await res.json()) as { unreadCount?: number };
        setUnread(typeof j.unreadCount === "number" ? j.unreadCount : 0);
        setItems((prev) =>
          prev.map((n) => (n.readAt ? n : { ...n, readAt: new Date().toISOString() }))
        );
      }
    } catch {
      /* biarkan keadaan terakhir */
    } finally {
      setMarkingAll(false);
    }
  }, [requesterUsername]);

  // D83 — hapus SATU notifikasi (optimis di UI; kegagalan → muat ulang server)
  const delOne = useCallback(
    async (id: number) => {
      setDeletingId(id);
      try {
        const res = await fetch("/api/notifications", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ requesterUsername, action: "delete", ids: [id] }),
        });
        if (res.ok) {
          const j = (await res.json()) as { unreadCount?: number };
          setItems((prev) => prev.filter((n) => n.id !== id));
          if (typeof j.unreadCount === "number") setUnread(j.unreadCount);
        } else {
          void fetchList();
        }
      } catch {
        void fetchList();
      } finally {
        setDeletingId(null);
      }
    },
    [fetchList, requesterUsername]
  );

  // D83 — hapus SEMUA riwayat (dijalankan hanya setelah konfirmasi dua-langkah)
  const delAll = useCallback(async () => {
    setMarkingAll(true);
    try {
      const res = await fetch("/api/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requesterUsername, action: "deleteAll" }),
      });
      if (res.ok) {
        setItems([]);
        setUnread(0);
      }
    } catch {
      /* biarkan keadaan terakhir */
    } finally {
      setMarkingAll(false);
      setConfirmClear(false);
    }
  }, [requesterUsername]);

  // D83 — konfirmasi "Hapus semua" batal sendiri bila dibiarkan 4 detik
  useEffect(() => {
    if (!confirmClear) return;
    clearTimer.current = setTimeout(() => setConfirmClear(false), 4000);
    return () => {
      if (clearTimer.current) clearTimeout(clearTimer.current);
    };
  }, [confirmClear]);

  return (
    <Popover open={open} onOpenChange={onOpenChange}>
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-label={`Notifikasi${unread > 0 ? ` — ${unread} belum dibaca` : ""}`}
          title="Notifikasi aplikasi"
          className="relative rounded-lg p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
        >
          <Bell className="size-5" aria-hidden />
          {unread > 0 && (
            <span
              className="absolute -right-0.5 -top-0.5 flex min-w-4 items-center justify-center rounded-full bg-red-600 px-1 text-[10px] font-bold leading-4 text-white"
              aria-hidden
            >
              {unread > 99 ? "99+" : unread}
            </span>
          )}
        </button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-[340px] overflow-hidden p-0 sm:w-[380px]">
        <div className="flex items-center justify-between gap-2 border-b px-3 py-2">
          <p className="flex items-center gap-2 text-sm font-bold">
            Notifikasi
            {loading && <Loader2 className="size-3.5 animate-spin text-muted-foreground" aria-hidden />}
          </p>
          <div className="flex items-center gap-3">
            {unread > 0 && (
              <button
                type="button"
                onClick={markAll}
                disabled={markingAll}
                className="flex items-center gap-1 text-xs font-semibold text-primary hover:underline disabled:opacity-50"
              >
                {markingAll ? (
                  <Loader2 className="size-3.5 animate-spin" aria-hidden />
                ) : (
                  <CheckCheck className="size-3.5" aria-hidden />
                )}
                Tandai semua dibaca
              </button>
            )}
            {items.length > 0 && !confirmClear && (
              <button
                type="button"
                onClick={() => setConfirmClear(true)}
                title="Hapus seluruh riwayat notifikasi"
                className="flex items-center gap-1 text-xs font-semibold text-muted-foreground hover:text-red-600 hover:underline"
              >
                <Trash2 className="size-3.5" aria-hidden />
                Hapus semua
              </button>
            )}
            {confirmClear && (
              <span className="flex items-center gap-1.5 text-xs font-semibold text-red-600">
                Hapus semua riwayat?
                <button
                  type="button"
                  onClick={delAll}
                  disabled={markingAll}
                  className="rounded bg-red-600 px-2 py-0.5 text-[11px] font-bold text-white hover:bg-red-700 disabled:opacity-50"
                >
                  {markingAll ? <Loader2 className="size-3.5 animate-spin" aria-hidden /> : "Yakin"}
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmClear(false)}
                  className="text-[11px] text-muted-foreground hover:underline"
                >
                  Batal
                </button>
              </span>
            )}
          </div>
        </div>

        <ScrollArea className="max-h-80">
          {items.length === 0 ? (
            <div className="flex flex-col items-center gap-1.5 px-4 py-8 text-center">
              <Bell className="size-6 text-muted-foreground/50" aria-hidden />
              <p className="text-xs text-muted-foreground">
                Belum ada notifikasi. Kejadian penting (mis. hasil backup GitHub)
                akan muncul di sini dan tersimpan — tidak hilang seperti toast.
              </p>
            </div>
          ) : (
            <ul className="divide-y">
              {items.map((n) => {
                const face = typeFace(n.type);
                const Icon = face.icon;
                const belum = !n.readAt;
                return (
                  // D83 — li jadi dua tombol BERDAMPING (bukan bersarang):
                  // tombol utama = tandai dibaca; tombol X = hapus notifikasi.
                  <li key={n.id} className="group flex items-stretch">
                    <button
                      type="button"
                      onClick={() => markOne(n.id)}
                      title={belum ? "Klik untuk tandai dibaca" : "Sudah dibaca"}
                      className={
                        "flex min-w-0 flex-1 items-start gap-2.5 px-3 py-2.5 text-left transition-colors hover:bg-muted/60 " +
                        (belum ? "bg-accent/40" : "")
                      }
                    >
                      <Icon className={"mt-0.5 size-4 shrink-0 " + face.cls} aria-hidden />
                      <span className="min-w-0 flex-1">
                        <span
                          className={
                            "block text-[13px] leading-snug " +
                            (belum ? "font-bold" : "font-medium text-muted-foreground")
                          }
                        >
                          {n.title}
                        </span>
                        {n.message && (
                          <span className="mt-0.5 block text-xs leading-snug text-muted-foreground">
                            {n.message}
                          </span>
                        )}
                        <span className="mt-1 block text-[10px] text-muted-foreground/80">
                          {formatDateTime(n.createdAt)}
                        </span>
                      </span>
                      {belum && (
                        <span className="mt-1.5 size-2 shrink-0 rounded-full bg-primary" aria-hidden />
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => delOne(n.id)}
                      disabled={deletingId === n.id}
                      aria-label={`Hapus notifikasi: ${n.title}`}
                      title="Hapus notifikasi"
                      className="flex w-8 shrink-0 items-center justify-center text-muted-foreground/40 transition-colors hover:bg-red-50 hover:text-red-600 disabled:opacity-40 dark:hover:bg-red-950/40 sm:opacity-0 sm:group-hover:opacity-100 sm:focus-visible:opacity-100"
                    >
                      {deletingId === n.id ? (
                        <Loader2 className="size-3.5 animate-spin" aria-hidden />
                      ) : (
                        <X className="size-4" aria-hidden />
                      )}
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </ScrollArea>

        <div className="border-t px-3 py-1.5 text-[10px] text-muted-foreground">
          Riwayat tersimpan di server — 100 kejadian terbaru.
        </div>
      </PopoverContent>
    </Popover>
  );
}
