// RepairUtils — port dari RepairStatus.kt, RepairRecord.kt (serviceId/difficultyPoints),
// getWhatsAppTemplate/getFormattedWhatsAppMessage (AppViewModel.kt) & parseUsedParts.
// Sumber kebenaran: contoh/app/src/main/java/com/example/*
export const REPAIR_STATUSES = [
  "ANTRI",
  "DIAGNOSA",
  "KONFIRMASI",
  "DISETUJUI",
  "DIKERJAKAN",
  "SELESAI",
  "DIAMBIL",
  "DIBATALKAN",
  "TIDAK_BISA",
] as const;
export type RepairStatus = (typeof REPAIR_STATUSES)[number];

// label persis RepairStatus.kt (REPAIR_STATUS_LABEL di app-types sudah sama)
export function repairStatusNext(status: string): RepairStatus | null {
  const order: RepairStatus[] = ["ANTRI", "DIAGNOSA", "KONFIRMASI", "DISETUJUI", "DIKERJAKAN", "SELESAI", "DIAMBIL"];
  const idx = order.indexOf(status as RepairStatus);
  if (idx === -1 || idx === order.length - 1) return null; // final / tak dikenal
  return order[idx + 1];
}
export function repairStatusIsFinal(status: string): boolean {
  return repairStatusNext(status) === null;
}
export function repairStatusIndex(status: string): number {
  const order: RepairStatus[] = ["ANTRI", "DIAGNOSA", "KONFIRMASI", "DISETUJUI", "DIKERJAKAN", "SELESAI", "DIAMBIL", "DIBATALKAN", "TIDAK_BISA"];
  return order.indexOf(status as RepairStatus);
}

// D31 — status turunan "Menunggu Part" hanya AKTIF setelah pelanggan menyetujui
// penawaran (terkonfirmasi pelanggan). Saat tiket masih KONFIRMASI, part dipesan
// boleh dicatat (estimasi biaya tetap akurat), tetapi tiket tampil sebagai
// "menunggu konfirmasi pelanggan" — bukan "menunggu part". Aktif mulai DISETUJUI
// sampai SELESAI; DIAMBIL/DIBATALKAN/TIDAK_BISA = tiket tertutup → tidak dihitung.
export function menungguPartAktif(status: string): boolean {
  return status === "DISETUJUI" || status === "DIKERJAKAN" || status === "SELESAI";
}

// RepairRecord.kt — difficultyPoints: override pointsReward atau tabel kesulitan
export function difficultyPoints(difficulty: string, pointsReward?: number | null): number {
  if (pointsReward != null && pointsReward > 0) return pointsReward;
  if (difficulty === "Rendah") return 10;
  if (difficulty === "Tinggi") return 50;
  return 25; // Sedang & fallback persis referensi
}

// RepairRecord.serviceId: "SRV-<epoch detik createdAt>"
export function serviceIdOf(createdAt: string | Date): string {
  const t = typeof createdAt === "string" ? new Date(createdAt).getTime() : createdAt.getTime();
  return `SRV-${Math.floor(t / 1000)}`;
}

// usedPartsJson: [{partId, name, alias?, qty, sellPrice, costPrice?, isExternal?}]
// alias (D23/D18/D19): "Nama di Struk" — snapshot saat part dipakai di tiket
export type UsedPart = {
  partId: number;
  name: string;
  alias?: string | null;
  qty: number;
  sellPrice: number;
  costPrice?: number;
  isExternal?: boolean;
};
export function parseUsedParts(json: string | null | undefined): UsedPart[] {
  if (!json || json.trim() === "" || json === "[]") return [];
  try {
    const arr = JSON.parse(json) as UsedPart[];
    if (!Array.isArray(arr)) return [];
    return arr.filter((p) => p && typeof p.name === "string");
  } catch {
    return [];
  }
}
export function usedPartsTotal(parts: UsedPart[]): number {
  return parts.reduce((sum, p) => sum + (Number(p.sellPrice) || 0) * (Number(p.qty) || 0), 0);
}

// D28 — requestedPartsJson: part PESANAN yang belum tersedia di inventaris
// (dicatat teknisi di dialog Diagnosa; estimasi harganya ikut total biaya yang
// disetujui pelanggan). done=true setelah part ditangani (masuk inventaris atau
// langsung dipasang tanpa stok) — entri done tetap disimpan sebagai jejak.
export type RequestedPart = {
  name: string;
  qty: number;
  estPrice: number;
  partId?: number | null; // terisi bila part sudah dicatat ke katalog (datang & masuk stok)
  done?: boolean;
  // D30: harga beli aktual per unit, diinput saat part datang (dialog PartDatang).
  // Internal saja (tidak tampil ke pelanggan) — dipakai jejak biaya & laporan margin.
  costPrice?: number;
};
export function parseRequestedParts(json: string | null | undefined): RequestedPart[] {
  if (!json || json.trim() === "" || json === "[]") return [];
  try {
    const arr = JSON.parse(json) as RequestedPart[];
    if (!Array.isArray(arr)) return [];
    return arr.filter((p) => p && typeof p.name === "string" && Number(p.qty) > 0);
  } catch {
    return [];
  }
}
export function pendingRequestedParts(json: string | null | undefined): RequestedPart[] {
  return parseRequestedParts(json).filter((p) => !p.done);
}
export function requestedPartsTotal(parts: RequestedPart[]): number {
  return parts.reduce((sum, p) => sum + (Number(p.estPrice) || 0) * (Number(p.qty) || 0), 0);
}

// sendWhatsAppMessage AppViewModel.kt — normalisasi 08xx/+62 → 62
export function normalizeWaPhone(phone: string): string {
  let p = phone.trim();
  if (p.startsWith("0")) p = "62" + p.substring(1);
  else if (!p.startsWith("62") && !p.startsWith("+")) p = "62" + p;
  return p.replace("+", "");
}
export function waLink(phone: string, message: string): string {
  return `https://wa.me/${normalizeWaPhone(phone)}?text=${encodeURIComponent(message)}`;
}

// === Template WhatsApp per status (persis getWhatsAppTemplate AppViewModel.kt) ===
export const WA_TEMPLATE_DEFAULT: Record<string, string> = {
  ANTRI:
    "Halo *{nama}*, HP *{hp}* Anda sudah masuk dalam antrean kami (Status: *Antri*) dengan keluhan: _{kerusakan}_. Kami akan segera melakukan pemeriksaan dan mengabari Anda kembali. Terima kasih!",
  DIAGNOSA:
    "Halo *{nama}*, HP *{hp}* Anda saat ini sedang diperiksa dan didiagnosa oleh teknisi kami (Status: *Diagnosa*). Terima kasih atas kesabaran Anda.",
  KONFIRMASI:
    "Halo *{nama}*, pemeriksaan HP *{hp}* telah selesai.\n\nHasil Diagnosa: _{diagnosa}_\nBiaya Jasa Servis: *{biaya_jasa}*{suku_cadang}\n*Estimasi Total Biaya: {total}*\n\nMohon konfirmasinya apakah Anda menyetujui perbaikan tersebut untuk kami kerjakan? Terima kasih!",
  DIBATALKAN:
    "Halo *{nama}*, perbaikan HP *{hp}* Anda dibatalkan sesuai kesepakatan (Status: *Dibatalkan*). Silakan mengambil unit Anda kembali di toko kami. Terima kasih.",
  DISETUJUI:
    "Halo *{nama}*, terima kasih atas konfirmasinya. Perbaikan HP *{hp}* Anda telah disetujui (Status: *Disetujui*) dan akan segera dikerjakan oleh teknisi kami.",
  DIKERJAKAN:
    "Halo *{nama}*, HP *{hp}* Anda saat ini sedang dalam proses perbaikan oleh teknisi kami (Status: *Dikerjakan*).",
  SELESAI:
    "Halo *{nama}*, kabar baik! HP *{hp}* Anda telah *Selesai Diperbaiki* dan siap diambil. \n\nTotal Biaya: *{total}*\n\nSilakan kunjungi toko kami untuk pengambilan barang. Terima kasih!",
  DIAMBIL:
    "Halo *{nama}*, terima kasih telah melakukan perbaikan HP *{hp}* di toko kami. Unit telah diserahkan dan pembayaran lunas. Semoga awet! Terima kasih atas kepercayaannya.",
  TIDAK_BISA:
    "Halo *{nama}*, mohon maaf, HP *{hp}* Anda tidak dapat diperbaiki (Status: *Tidak Bisa*). Silakan mengambil unit Anda kembali di toko kami. Terima kasih.",
};

// Penyimpanan template: DB ShopSettings.waTemplates (JSON per status) — bisa diedit
// dari editor WA (Tahap 4) dan dipusatkan lagi di modul Setting (Tahap 7).
// Bila kosong/tidak ada → pakai template default persis referensi.
export function getWaTemplate(status: string, customMap?: Record<string, string> | null): string {
  const custom = customMap?.[status];
  if (custom && custom.trim() !== "") return custom;
  return WA_TEMPLATE_DEFAULT[status] ?? "";
}

export function parseWaTemplates(json: string | null | undefined): Record<string, string> {
  if (!json) return {};
  try {
    const parsed = JSON.parse(json);
    return parsed && typeof parsed === "object" ? (parsed as Record<string, string>) : {};
  } catch {
    return {};
  }
}

// getFormattedWhatsAppMessage AppViewModel.kt — semua alias placeholder didukung
// D28: param opsional requestedParts — daftar part pesanan ditambahkan ke
// daftar suku cadang dengan tanda "akan dipesan" (estimasi biaya tetap akurat).
// Tahap 7.1: param opsional shop — profil toko tersedia sebagai placeholder
// {toko} / {telepon_toko} (nama & telepon dari Setting → Profil Toko).
export function formatWaMessage(
  status: string,
  customMap: Record<string, string> | null,
  repair: {
    customerName: string;
    deviceModel: string;
    damageDescription: string;
    status: string;
    notes: string;
    serviceFee: number;
    totalPrice: number;
    usedPartsJson?: string;
  },
  statusLabel: string,
  fmt: (v: number) => string,
  requestedParts?: RequestedPart[],
  shop?: { name: string; phone: string },
): string {
  const template = getWaTemplate(status, customMap);
  const parts = parseUsedParts(repair.usedPartsJson);
  let partsListStr = "";
  if (parts.length > 0) {
    partsListStr = "\nSparepart yang perlu diganti:";
    // D23 (D18/D19): nama yang tampil ke pelanggan pakai alias struk bila diisi
    // D64: part external ditandai "(Toko Lain)" — transparan ke pelanggan
    for (const p of parts)
      partsListStr += `\n- ${p.alias?.trim() || p.name}${p.isExternal ? " (Toko Lain)" : ""} (${p.qty}x)`;
  }
  // D28: part pesanan (belum ada di stok) — tetap masuk daftar supaya pelanggan
  // paham estimasinya mencakup part yang harus dipesan dulu.
  const reqPending = (requestedParts ?? []).filter((p) => !p.done);
  let requestedStr = "";
  if (reqPending.length > 0) {
    if (partsListStr === "") partsListStr = "\nSparepart yang perlu diganti:";
    for (const p of reqPending) {
      partsListStr += `\n- ${p.name} (${p.qty}x) — akan dipesan (belum tersedia di toko)`;
      requestedStr += `\n- ${p.name} (${p.qty}x) — akan dipesan (belum tersedia di toko)`;
    }
  }
  const map: Record<string, string> = {
    "{nama}": repair.customerName,
    "{customer}": repair.customerName,
    "{customer_name}": repair.customerName,
    "{hp}": repair.deviceModel,
    "{device}": repair.deviceModel,
    "{device_model}": repair.deviceModel,
    "{kerusakan}": repair.damageDescription,
    "{damage}": repair.damageDescription,
    "{damage_description}": repair.damageDescription,
    "{status}": statusLabel,
    "{diagnosa}": repair.notes ?? "",
    "{notes}": repair.notes ?? "",
    "{biaya_jasa}": fmt(repair.serviceFee),
    "{service_fee}": fmt(repair.serviceFee),
    "{total}": fmt(repair.totalPrice),
    "{total_price}": fmt(repair.totalPrice),
    "{suku_cadang}": partsListStr,
    "{parts}": partsListStr,
    "{part_dipesan}": requestedStr, // D28
    "{toko}": shop?.name ?? "", // Tahap 7.1
    "{shop}": shop?.name ?? "",
    "{telepon_toko}": shop?.phone ?? "",
    "{shop_phone}": shop?.phone ?? "",
  };
  let out = template;
  for (const [k, v] of Object.entries(map)) out = out.split(k).join(v);
  return out;
}

// Warna badge status — peta dari statusColor RepairItemCard.kt (adaptasi token Tailwind)
export const REPAIR_STATUS_BADGE: Record<string, string> = {
  ANTRI: "bg-primary/15 text-primary",
  DIAGNOSA: "bg-amber-100 text-amber-800",
  KONFIRMASI: "bg-amber-200 text-amber-900",
  DISETUJUI: "bg-teal-100 text-teal-800",
  DIKERJAKAN: "bg-sky-100 text-sky-800",
  SELESAI: "bg-emerald-100 text-emerald-800",
  DIAMBIL: "bg-muted text-muted-foreground",
  DIBATALKAN: "bg-red-100 text-red-700",
  TIDAK_BISA: "bg-red-100 text-red-800",
};

// Saran model & kerusakan bawaan (RepairSection.kt filteredDevices/filteredDamages)
export const DEFAULT_DEVICE_MODELS = [
  "iPhone 11", "iPhone 12", "iPhone 13", "iPhone 14 Pro", "iPhone 15 Pro",
  "Samsung Galaxy S22", "Samsung Galaxy S23", "Samsung Galaxy A54",
  "Oppo Reno 8", "Oppo Reno 10", "Oppo A57", "Oppo A17",
  "Xiaomi Redmi Note 12", "Xiaomi Redmi Note 11", "Xiaomi Poco X5",
  "Vivo Y22", "Vivo Y35", "Vivo V27", "Infinix Hot 30",
];
export const DEFAULT_DAMAGES = [
  "Layar Pecah / LCD Blank",
  "Baterai Drop / Kembung",
  "Konektor Charger Rusak",
  "Mati Total (Matot)",
  "Kena Air / Korosi",
  "Kamera Blur / Mati",
  "Speaker Sember / Mati",
  "Mic Tidak Berfungsi",
  "Tombol Power Keras",
  "Stuck Logo / Bootloop",
];
export const STANDARD_BRANDS = ["Samsung", "iPhone", "Xiaomi", "Oppo", "Vivo", "Realme", "Infinix", "Asus", "Lenovo", "Google Pixel"];
export const STANDARD_CASES = ["Ganti LCD", "Ganti Baterai", "Ganti Konektor Charger", "Mati Total", "Software Flash", "Kamera Rusak"];
