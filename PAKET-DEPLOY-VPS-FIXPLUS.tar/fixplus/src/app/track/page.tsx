"use client";

// /track — halaman pelacakan status servis PUBLIK (tanpa login). D26.
// Tautan & QR halaman ini tercetak di struk terima barang. D27: PENCARIAN BEBAS
// DINONAKTIFKAN — pelanggan hanya bisa melacak lewat tautan/QR unik miliknya
// (/track?id=SRV-<epoch>), sehingga pihak tak berwenang tidak bisa menelusuri
// servis pelanggan lain dengan menebak kode. Data sensitif (HP, IMEI, catatan
// internal) juga tidak ditampilkan.
import { Suspense, useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import {
  AlertTriangle,
  CheckCircle2,
  CircleDashed,
  Gift,
  Loader2,
  PackageCheck,
  Phone,
  QrCode,
  ShieldCheck,
  Smartphone,
  UserRound,
  Wrench,
} from "lucide-react";

type TrackData = {
  found: boolean;
  serviceId: string;
  customerName: string;
  deviceModel: string;
  damageDescription: string;
  status: string;
  statusLabel: string;
  createdAt: string;
  updatedAt: string;
  estimatedCompletionTime: string;
  technicianName: string | null;
  warrantyDays: number;
  // D57: poin loyalitas pelanggan pemegang tiket — null bila bukan pelanggan terdaftar
  loyaltyPoints: number | null;
  waitingParts: boolean; // D28: menunggu sparepart dipesan
  shop: { name: string; phone: string };
};

// Alur status normal (urutan progres); DIBATALKAN/TIDAK_BISA = status akhir khusus
const FLOW = [
  "ANTRI",
  "DIAGNOSA",
  "KONFIRMASI",
  "DISETUJUI",
  "DIKERJAKAN",
  "SELESAI",
  "DIAMBIL",
] as const;
const FLOW_LABEL: Record<string, string> = {
  ANTRI: "Antri",
  DIAGNOSA: "Diagnosa",
  KONFIRMASI: "Konfirmasi Biaya",
  DISETUJUI: "Disetujui",
  DIKERJAKAN: "Dikerjakan",
  SELESAI: "Selesai",
  DIAMBIL: "Diambil",
};

function fmtDate(s: string): string {
  const d = new Date(s);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function TrackClient() {
  const sp = useSearchParams();
  const initial = (sp.get("id") ?? "").trim();
  const [data, setData] = useState<TrackData | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const lastQueried = useRef("");

  const cari = useCallback(async (raw: string) => {
    const q = raw.trim();
    if (!q) return;
    setLoading(true);
    setNotFound(false);
    setError("");
    try {
      const res = await fetch(`/api/track?id=${encodeURIComponent(q)}`);
      if (res.status === 404) {
        setData(null);
        setNotFound(true);
        return;
      }
      const json = await res.json();
      if (!res.ok) {
        setError(String(json?.error ?? "Gagal memuat status servis"));
        return;
      }
      setData(json as TrackData);
    } catch {
      setError("Tidak dapat terhubung ke server. Coba lagi.");
    } finally {
      setLoading(false);
    }
  }, []);

  // D27: satu-satunya jalur pelacakan = tautan/QR unik dari struk (?id=SRV-...).
  // Tidak ada input kode manual — mencegah penyalahgunaan oleh pihak tak berwenang.
  useEffect(() => {
    if (initial && lastQueried.current !== initial) {
      lastQueried.current = initial;
      void cari(initial);
    }
  }, [initial, cari]);

  const currentIdx = data ? FLOW.indexOf(data.status as (typeof FLOW)[number]) : -1;
  const isFinalGagal = data?.status === "DIBATALKAN" || data?.status === "TIDAK_BISA";

  return (
    <div className="min-h-screen bg-muted/40 px-4 py-8">
      <div className="mx-auto w-full max-w-md space-y-4">
        {/* Header */}
        <div className="rounded-2xl border bg-card p-5 text-center shadow-sm">
          <div className="mx-auto mb-2 flex size-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <Wrench className="size-5" aria-hidden />
          </div>
          <h1 className="text-lg font-black">Lacak Servis</h1>
          <p className="mt-1 text-[13px] text-muted-foreground">
            Pantau progres perbaikan unit Anda secara online.
          </p>
        </div>

        {initial && loading && !data && (
          <div className="flex items-center justify-center gap-2 rounded-2xl border bg-card p-5 text-[13px] text-muted-foreground shadow-sm">
            <Loader2 className="size-4 animate-spin" aria-hidden />
            Memuat status servis…
          </div>
        )}

        {error && (
          <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-[13px] text-red-700">
            {error}
          </div>
        )}

        {notFound && (
          <div className="rounded-xl border bg-card p-4 text-center text-[13px] text-muted-foreground">
            Tautan pelacakan tidak valid atau servis tidak ditemukan. Pastikan Anda
            membuka tautan lengkap / QR yang tertera pada struk terima barang Anda.
          </div>
        )}

        {/* Hasil */}
        {data && (
          <div className="space-y-4">
            <div className="rounded-2xl border bg-card p-5 shadow-sm">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-[11px] text-muted-foreground">Kode Servis</p>
                  <p className="font-mono text-sm font-bold text-primary">{data.serviceId}</p>
                </div>
                <span
                  className={
                    isFinalGagal
                      ? "rounded-full bg-red-100 px-2.5 py-1 text-[11px] font-bold text-red-800"
                      : data.status === "DIAMBIL"
                        ? "rounded-full bg-muted px-2.5 py-1 text-[11px] font-bold text-muted-foreground"
                        : "rounded-full bg-emerald-100 px-2.5 py-1 text-[11px] font-bold text-emerald-800"
                  }
                >
                  {data.statusLabel}
                </span>
              </div>

              <div className="mt-3 space-y-1.5 border-t pt-3 text-[13px]">
                <div className="flex items-center gap-2">
                  <UserRound className="size-4 shrink-0 text-muted-foreground" aria-hidden />
                  <span className="text-muted-foreground">Pelanggan:</span>
                  <b>{data.customerName}</b>
                </div>
                <div className="flex items-center gap-2">
                  <Smartphone className="size-4 shrink-0 text-muted-foreground" aria-hidden />
                  <span className="text-muted-foreground">Unit:</span>
                  <b>{data.deviceModel}</b>
                </div>
                <p className="text-muted-foreground">
                  <span className="text-[12px]">Keluhan: </span>
                  <span className="text-foreground">{data.damageDescription}</span>
                </p>
              </div>
            </div>

            {/* D57: poin loyalitas pelanggan — hanya bila tiket milik pelanggan terdaftar */}
            {data.loyaltyPoints !== null && (
              <div className="flex items-center gap-3 rounded-2xl border border-primary/25 bg-primary/5 p-4 shadow-sm">
                <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <Gift className="size-5" aria-hidden />
                </div>
                <div className="min-w-0">
                  <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Poin Loyalitas Anda
                  </p>
                  <p className="text-lg font-black leading-tight text-primary">
                    {data.loyaltyPoints.toLocaleString("id-ID")} poin
                  </p>
                  <p className="text-[12px] text-muted-foreground">
                    Kumpulkan dari tiap transaksi & tukarkan dengan diskon servis di toko.
                  </p>
                </div>
              </div>
            )}

            {/* Status akhir gagal/batal — tampilkan papan info, bukan progres */}
            {isFinalGagal ? (
              <div className="rounded-2xl border border-red-200 bg-red-50 p-4">
                <div className="flex items-start gap-2 text-red-800">
                  <AlertTriangle className="mt-0.5 size-5 shrink-0" aria-hidden />
                  <div className="text-[13px]">
                    <p className="font-bold">
                      {data.status === "TIDAK_BISA"
                        ? "Unit tidak dapat dilanjutkan (void)"
                        : "Servis dibatalkan"}
                    </p>
                    <p className="mt-1 text-red-700">
                      Silakan ambil unit Anda kembali di toko{data.shop.name ? ` ${data.shop.name}` : ""}.
                      {data.estimatedCompletionTime ? "" : ""}
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="rounded-2xl border bg-card p-5 shadow-sm">
                <p className="mb-3 text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
                  Progres Perbaikan
                </p>
                <ol className="space-y-0">
                  {FLOW.map((s, i) => {
                    const done = currentIdx > i;
                    const active = currentIdx === i;
                    return (
                      <li key={s} className="relative flex gap-3 pb-4 last:pb-0">
                        {i < FLOW.length - 1 && (
                          <span
                            className={
                              "absolute left-[11px] top-6 h-[calc(100%-16px)] w-0.5 " +
                              (done ? "bg-primary" : "bg-border")
                            }
                            aria-hidden
                          />
                        )}
                        {done ? (
                          <CheckCircle2 className="z-10 mt-0.5 size-6 shrink-0 text-primary" aria-hidden />
                        ) : active ? (
                          <span className="z-10 mt-0.5 flex size-6 shrink-0 items-center justify-center">
                            <span className="absolute size-6 animate-ping rounded-full bg-primary/30" aria-hidden />
                            <span className="relative flex size-6 items-center justify-center rounded-full bg-primary text-[10px] font-black text-primary-foreground">
                              {i + 1}
                            </span>
                          </span>
                        ) : (
                          <CircleDashed className="z-10 mt-0.5 size-6 shrink-0 text-muted-foreground/50" aria-hidden />
                        )}
                        <div className="pt-0.5">
                          <p className={"text-[13px] font-bold " + (active ? "text-primary" : done ? "" : "text-muted-foreground")}>
                            {FLOW_LABEL[s]}
                          </p>
                          {active && s === "DISETUJUI" && data.waitingParts && (
                            <p className="text-[12px] text-amber-700">
                              Menunggu kedatangan sparepart — kami kabari saat part siap dipasang.
                            </p>
                          )}
                          {active && s === "SELESAI" && (
                            <p className="text-[12px] text-muted-foreground">
                              Siap diambil — selesaikan pembayaran di kasir.
                            </p>
                          )}
                        </div>
                      </li>
                    );
                  })}
                </ol>
                <div className="mt-2 space-y-1 border-t pt-3 text-[12px] text-muted-foreground">
                  {data.technicianName && (
                    <p>
                      Teknisi: <b className="text-foreground">{data.technicianName}</b>
                    </p>
                  )}
                  {data.estimatedCompletionTime && (
                    <p>
                      Estimasi selesai: <b className="text-foreground">{data.estimatedCompletionTime}</b>
                    </p>
                  )}
                  {data.warrantyDays > 0 && (
                    <p>
                      Garansi: <b className="text-foreground">{data.warrantyDays} hari</b>
                    </p>
                  )}
                  <p>
                    <PackageCheck className="mr-1 inline size-3.5" aria-hidden />
                    Diperbarui: {fmtDate(data.updatedAt)}
                  </p>
                </div>
              </div>
            )}

            <p className="pb-6 text-center text-[12px] text-muted-foreground">
              {data.shop.name || "Servis HP"} — butuh bantuan? Hubungi{" "}
              {data.shop.phone ? (
                <a href={`tel:${data.shop.phone}`} className="inline-flex items-center font-bold text-primary">
                  <Phone className="mr-1 inline size-3.5" aria-hidden />
                  {data.shop.phone}
                </a>
              ) : (
                "toko kami"
              )}
              .
            </p>
          </div>
        )}

        {!data && !notFound && !error && !initial && (
          <div className="rounded-2xl border bg-card p-5 text-center shadow-sm">
            <div className="mx-auto mb-2 flex size-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <QrCode className="size-5" aria-hidden />
            </div>
            <p className="text-[13px] font-bold">Buka tautan pelacakan dari struk Anda</p>
            <p className="mt-1 text-[12px] leading-relaxed text-muted-foreground">
              Scan <b>QR code</b> atau buka tautan <b>Lacak Servis Online</b> yang
              tertera pada tanda terima servis Anda.
            </p>
            <p className="mt-3 flex items-center justify-center gap-1.5 rounded-xl bg-muted/60 px-3 py-2 text-[11px] text-muted-foreground">
              <ShieldCheck className="size-3.5 shrink-0 text-emerald-600" aria-hidden />
              Pencarian manual tidak tersedia demi keamanan data pelanggan.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function TrackPage() {
  return (
    <Suspense
      fallback={
        <div className="flex min-h-screen items-center justify-center bg-muted/40">
          <Loader2 className="size-6 animate-spin text-muted-foreground" aria-hidden />
        </div>
      }
    >
      <TrackClient />
    </Suspense>
  );
}
