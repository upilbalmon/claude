import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

// D18: POST /api/ai/alias — saran alias struk dengan AI untuk nama barang yang polanya
// terlalu ribet bagi saran instan (src/lib/alias.ts), mis. "FLEX LAMP INFO SAMSUNG J7 PRIME".
// Sifatnya opsional (tombol ✨ di form Inventaris) — sekali panggil per barang, bukan tiap cetak struk.

const SYSTEM_PROMPT = `Kamu asisten bengkel HP di Indonesia. Tugasmu meringkas nama sparepart menjadi "alias struk": sebutan pendek yang biasa dipakai teknisi.
Aturan wajib:
1. Pola: jenis part + merek + nama unit (contoh: "lcd iphone 7", "tg universal", "batre oppo a37").
2. Maksimal 5 kata, huruf kecil semua.
3. BUANG kata kualitas/pemasaran (original, ori, quality, kwalitas, new, oem, copy, grade, kw, murah, bagus, premium, best) dan warna (hitam, black, putih, white, gold, dsb.) serta kapasitas (2000mah, inch).
4. Jangan mengarang nama unit yang tidak ada di nama asli; singkatan umum boleh (tempered glass → tg, baterai → batre, touchscreen → ts, flexible → flex).
5. Jawab HANYA alias-nya (satu baris, tanpa penjelasan, tanpa tanda kutip).`;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const nama = String(body.nama ?? "").trim();
    if (!nama) {
      return NextResponse.json({ error: "Nama barang wajib diisi" }, { status: 400 });
    }
    if (nama.length > 120) {
      return NextResponse.json({ error: "Nama barang terlalu panjang" }, { status: 400 });
    }

    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: "assistant", content: SYSTEM_PROMPT },
        { role: "user", content: `Nama sparepart: ${nama}` },
      ],
      thinking: { type: "disabled" },
    });

    const raw = (completion.choices[0]?.message?.content ?? "").trim();
    // bersihkan hasil: buang tanda kutip/baris tambahan yang menyisa, batasi 60 char
    const alias = raw
      .replace(/^["'`\s]+|["'`\s.]+$/g, "")
      .split("\n")[0]
      .slice(0, 60)
      .trim();
    if (!alias) {
      return NextResponse.json({ error: "AI tidak memberi saran — coba lagi atau ketik manual" }, { status: 502 });
    }
    return NextResponse.json({ alias });
  } catch (e) {
    console.error("ai/alias POST error", e);
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Gagal menghubungi AI" },
      { status: 500 }
    );
  }
}
