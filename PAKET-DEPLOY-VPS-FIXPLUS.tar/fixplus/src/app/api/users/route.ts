import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { generateSalt, hashPin, sanitizeUser } from "@/lib/pin-hash";
import { err, resolveManager, withHeal } from "@/lib/users-guard";
import {
  PERMISSION_FIELDS,
  USER_ROLES,
  rolePreset,
  validPinBaru,
  validUsername,
} from "@/lib/user-utils";

// Tahap 7.2 — Manajemen pengguna: daftar & tambah pengguna.
// Setiap operasi diverifikasi server: peminta (requesterUsername) WAJIB memiliki
// izin permissionUsers (guard tidak boleh hanya mengandalkan UI).

// GET /api/users?requesterUsername=… — daftar semua pengguna (tanpa PIN/salt)
// D55 — withHeal: bila database versi lama tanpa kolom baru, tabel tetap
// bisa dimuat (skema disembuhkan otomatis lalu dicoba ulang).
export async function GET(req: NextRequest) {
  try {
    return await withHeal(async () => {
      const manager = await resolveManager(req.nextUrl.searchParams.get("requesterUsername"));
      if (!manager) return err("Anda tidak memiliki izin mengelola pengguna", 403);

      const users = await db.user.findMany({ orderBy: [{ role: "asc" }, { name: "asc" }] });
      return NextResponse.json(users.map(sanitizeUser));
    });
  } catch (e) {
    console.error("users GET error", e);
    return err("Gagal memuat pengguna", 500);
  }
}

// POST /api/users — tambah pengguna baru (role, PIN awal, 7 izin)
// D55 — body dibaca SEKALI di luar withHeal: retry tidak boleh memanggil
// ulang req.json() (body request hanya bisa dibaca sekali).
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
    return await withHeal(async () => {
      const manager = await resolveManager(body.requesterUsername);
      if (!manager) return err("Anda tidak memiliki izin mengelola pengguna", 403);

      const name = String(body.name ?? "").trim();
      const username = String(body.username ?? "").trim();
      const role = String(body.role ?? "").trim();
      const pin = String(body.pin ?? "");

      if (!name) return err("Nama pengguna wajib diisi", 400);
      if (!username) return err("Username wajib diisi", 400);
      if (!validUsername(username)) {
        return err("Username 3–20 karakter, hanya huruf/angka/titik/garis (tanpa spasi)", 400);
      }
      if (!USER_ROLES.includes(role as (typeof USER_ROLES)[number])) {
        return err("Role harus salah satu dari: Admin, Kasir, Teknisi", 400);
      }
      if (!validPinBaru(pin)) {
        return err("PIN awal wajib 4 angka dan bukan PIN default (1234/1111)", 400);
      }

      // Username unik (pembanding aba besar-kecil)
      const all = await db.user.findMany({ select: { username: true } });
      const dup = all.find((u) => u.username.toLowerCase() === username.toLowerCase());
      if (dup) {
        return err(`Username "${username}" sudah dipakai`, 409);
      }

      // Izin: dari body bila dikirim, selain itu preset role
      const preset = rolePreset(role);
      const permissions: Record<string, boolean> = {};
      for (const f of PERMISSION_FIELDS) {
        permissions[f] = body[f] === undefined ? preset[f] : Boolean(body[f]);
      }

      const salt = generateSalt();
      const created = await db.user.create({
        data: {
          name,
          username,
          role,
          pin: hashPin(pin, salt),
          salt,
          mustChangePin: body.mustChangePin === undefined ? true : Boolean(body.mustChangePin),
          ...permissions,
        },
      });

      // D71 — akun role Teknisi otomatis punya profil teknisi (daftar Teknisi
      // di halaman Pelanggan) agar bisa ditugaskan pada tiket servis. Bila ada
      // profil manual bernama sama, profil itu yang ditautkan (tanpa dobel entri).
      let techNote = "";
      if (created.role === "Teknisi") {
        const orphans = await db.technician.findMany({ where: { userId: null } });
        const orphan = orphans.find(
          (t) => t.name.trim().toLowerCase() === created.name.trim().toLowerCase()
        );
        if (orphan) {
          await db.technician.update({ where: { id: orphan.id }, data: { userId: created.id } });
          techNote = ` — profil teknisi "${orphan.name}" tertaut ke akun`;
        } else {
          await db.technician.create({ data: { name: created.name, userId: created.id } });
          techNote = " — profil teknisi otomatis dibuat";
        }
      }

      await db.auditLog.create({
        data: {
          action: "TAMBAH_PENGGUNA",
          details: `${created.username} (${created.name}, role ${created.role})${techNote}`,
          performedBy: manager.name,
        },
      });

      return NextResponse.json(sanitizeUser(created), { status: 201 });
    });
  } catch (e) {
    console.error("users POST error", e);
    return err("Gagal menyimpan pengguna", 500);
  }
}
