// D23 (reimplementasi D18/D19): saranAlias — saran "Nama di Struk / Nota (Alias)".
// Gaya persis contoh user:
//   "lcd xxxxx"        → "LCD"
//   "ic power mt6582"  → "IC Power"
//   "Speaker oppo a16" → "Speaker"
// Aturan: ambil kata-kata awal yang menjelaskan JENIS part (LCD, IC, Power, Speaker,
// Baterai, Flexible, …); berhenti sebelum kata merek/model (oppo, a16, mt6582, samsung…).
// Kata singkat (≤3 huruf) jadi KAPITAL (LCD, IC, SIM); sisanya Title Case (Power, Baterai).
// PRINSIP MANUAL-FIRST (D19): hasil ini HANYA prefill di form — user bebas mengubah.

// Kata jenis part yang layak dipertahankan di alias (urutan awal nama).
const PART_WORDS = new Set([
  // jenis part umum
  "lcd", "ic", "power", "speaker", "buzzer", "mic", "mikrofon", "kamera",
  "baterai", "battery", "flex", "flexible", "flexibel", "konektor", "connector",
  "charger", "glass", "tempered", "antigores", "touchscreen", "touch", "screen",
  "housing", "casing", "backdoor", "back", "frame", "kaca", "sim", "antena",
  "sensor", "board", "mesin", "kabel", "jack", "dock", "lampu", "vibrator",
  "headphone", "earphone", "audio", "motor", "engsel", "tray", "kartu",
  // penanda kualitas/kelengkapan yang wajar muncul di struk
  "original", "ori", "fullset", "full", "set", "copy", "kw", "super",
  // posisi
  "belakang", "depan", "atas", "bawah", "kanan", "kiri", "on", "off", "unit",
]);

// Kata merek/model umum → dijamin berhenti meski tak mengandung angka
const BRAND_WORDS = new Set([
  "samsung", "xiaomi", "redmi", "poco", "oppo", "vivo", "realme", "iphone",
  "ipad", "asus", "zenfone", "rog", "nokia", "sony", "xperia", "huawei",
  "honor", "infinix", "itel", "tecno", "advan", "lenovo", "motorola", "moto",
  "oneplus", "google", "pixel", "imoo", "acl", "vsmart", "zte", "nubia",
]);

function kapitalisasiKata(word: string): string {
  const lower = word.toLowerCase();
  // ≤3 huruf → KAPITAL penuh (LCD, IC, SIM, ON, OFF); sisanya Title Case
  if (lower.length <= 3) return lower.toUpperCase();
  return lower.charAt(0).toUpperCase() + lower.slice(1);
}

function kataAdalahModel(word: string): boolean {
  const lower = word.toLowerCase();
  // model sering mengandung angka: a16, s20, mt6582, 11, note12, j7prime
  if (/\d/.test(lower)) return true;
  if (BRAND_WORDS.has(lower)) return true;
  // kode acak tanpa vokal jelas (xxxxx, abc-12) → anggap model
  if (lower.length >= 4 && !/[aeiou]/.test(lower)) return true;
  return false;
}

// saranAlias("lcd xxxxx") → "LCD" — hanya SARAN (prefill), tidak dipaksakan.
export function saranAlias(nama: string): string {
  const words = nama.trim().split(/\s+/).filter((w) => w !== "");
  if (words.length === 0) return "";

  const kept: string[] = [];
  for (const word of words.slice(0, 4)) {
    const lower = word.toLowerCase();
    if (PART_WORDS.has(lower) && !kataAdalahModel(word)) {
      kept.push(word);
      if (kept.length >= 3) break; // cukup 3 kata jenis — alias harus pendek
    } else {
      break; // kata pertama yang bukan jenis part / ketemu merek → berhenti
    }
  }
  // Nama diawali kata tak dikenal (mis. "Flexiblecable ABC") → pakai kata pertama
  if (kept.length === 0) kept.push(words[0]!);

  return kept.map(kapitalisasiKata).join(" ");
}
