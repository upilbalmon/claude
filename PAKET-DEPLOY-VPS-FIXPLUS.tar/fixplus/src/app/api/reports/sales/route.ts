import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { dayKeyWIB } from "@/lib/format";
import { deriveItemCategory } from "@/lib/spare-category";
import { isAdminRole, parseRange, resolveReporter } from "@/lib/report-utils";

// D48/5A.1–5A.3 + 5A.8 — Laporan Penjualan & Ringkasan Keuangan.
// GET /api/reports/sales?from=YYYY-MM-DD&to=YYYY-MM-DD&requesterUsername=…
// Aturan angka (D48):
//  - omzet kotor = Σ grandTotal PENJUALAN tidak void (timestamp dalam rentang WIB);
//  - omzet net  = omzet kotor − Σ |grandTotal| dokumen REFUND tidak void (D36);
//  - laba kotor (Admin saja, jawaban g) = omzet net − HPP; HPP = Σ costPrice×qty
//    snapshot itemsJson (aturan 8); dokumen refund mengembalikan HPP-nya juga;
//  - transaksi lama tanpa HPP tetap dihitung + catatan "sebagian tanpa HPP" (jawaban h);
//  - void TIDAK dihitung; info void harian tetap ditampilkan terpisah (D37).
// Item tanpa snapshot kategori (data lama) diturunkan otomatis (deriveItemCategory).
// D90: HPP kini juga diakumulasi PER HARI (daily[].hpp) dengan rumus yang sama
// dengan ringkasan periode — Σ harian selalu = angka ringkasan 5A.1.

type ItemJson = {
  name?: string; alias?: string | null; qty?: number; price?: number;
  costPrice?: number; itemType?: string; partId?: number; category?: string;
};

export type KategoriRow = { kategori: string; omzet: number; hpp: number | null; qty: number };

export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const reporter = await resolveReporter(sp.get("requesterUsername"));
    if (!reporter) {
      return NextResponse.json({ error: "Sesi tidak dikenal — masuk ulang" }, { status: 401 });
    }
    const admin = isAdminRole(reporter);

    const today = dayKeyWIB(new Date());
    const { from, to, start, end } = parseRange(sp.get("from"), sp.get("to"), today);

    const [txs, parts] = await Promise.all([
      db.transaction.findMany({
        where: { timestamp: { gte: start, lt: end } },
        orderBy: { timestamp: "asc" },
      }),
      db.sparePart.findMany(),
    ]);

    // peta katalog untuk penurunan kategori item lama (byId + byName/alias)
    const partById = new Map(parts.map((p) => [p.id, p]));
    const partByKey = new Map<string, (typeof parts)[number]>();
    for (const p of parts) {
      partByKey.set(p.name.trim().toLowerCase(), p);
      if (p.alias && p.alias.trim() !== "") partByKey.set(p.alias.trim().toLowerCase(), p);
    }

    let omzetKotor = 0;
    let diskonTotal = 0;
    let refundTotal = 0;
    let refundCount = 0;
    let hppNet = 0;
    let txCount = 0;
    let servisCount = 0;
    let tanpaHppCount = 0;

    const perMethod = new Map<string, { metode: string; penjualan: number; refund: number; net: number; count: number }>();
    const perKasir = new Map<string, { kasir: string; penjualan: number; refund: number; net: number; count: number }>();
    const perKategori = new Map<string, { kategori: string; omzet: number; qty: number; hppAcc: number; hasHpp: boolean }>();
    const perTeknisi = new Map<string, { teknisi: string; tiket: number; jasa: number; poin: number }>();
    const daily = new Map<string, { day: string; omzet: number; refund: number; count: number; servisCount: number; hpp: number }>();

    // repair yang dirujuk transaksi (teknisi) — ambil sekali
    const repairIds = [...new Set(txs.filter((t) => t.repairRecordId).map((t) => t.repairRecordId!))];
    const repairs = repairIds.length
      ? await db.repairRecord.findMany({ where: { id: { in: repairIds } }, select: { id: true, technicianName: true, pointsReward: true } })
      : [];
    const repairById = new Map(repairs.map((r) => [r.id, r]));

    function addItemKategori(items: ItemJson[], sign: number) {
      for (const it of items) {
        const kategori = deriveItemCategory(it, partById, partByKey);
        const qty = Math.max(1, Math.trunc(Number(it.qty) || 1));
        const price = Math.max(0, Number(it.price) || 0);
        const cost = Math.max(0, Number(it.costPrice) || 0);
        const row = perKategori.get(kategori) ?? { kategori, omzet: 0, qty: 0, hppAcc: 0, hasHpp: false };
        row.omzet += sign * price * qty;
        row.hppAcc += sign * cost * qty;
        row.hasHpp = true;
        row.qty += sign * qty;
        perKategori.set(kategori, row);
      }
    }

    for (const t of txs) {
      const isRefund = t.docType === "REFUND";
      const day = dayKeyWIB(t.timestamp);
      const dRow = daily.get(day) ?? { day, omzet: 0, refund: 0, count: 0, servisCount: 0, hpp: 0 };

      if (t.isVoided) continue; // void tidak dihitung (aturan 5A.9)

      let items: ItemJson[] = [];
      try {
        const parsed = JSON.parse(t.itemsJson);
        if (Array.isArray(parsed)) items = parsed;
      } catch {
        items = [];
      }
      const hppDoc = items.reduce(
        (s, it) => s + Math.max(0, Number(it.costPrice) || 0) * Math.max(1, Math.trunc(Number(it.qty) || 1)),
        0
      );
      const nilai = isRefund ? Math.abs(t.grandTotal) : t.grandTotal;

      if (isRefund) {
        refundTotal += nilai;
        refundCount += 1;
        hppNet -= hppDoc;
        dRow.refund += nilai;
        dRow.hpp -= hppDoc; // D90 — HPP harian mengikuti rumus ringkasan (refund mengembalikan HPP)
        addItemKategori(items, -1);
      } else {
        omzetKotor += t.grandTotal;
        diskonTotal += Math.max(0, t.discount || 0);
        hppNet += hppDoc;
        dRow.hpp += hppDoc; // D90 — dulu dRow.hpp tak pernah diisi (selalu 0) → bar "Laba harian" 5A.8 keliru menampilkan omzet net
        txCount += 1;
        if (t.repairRecordId) servisCount += 1;
        dRow.omzet += t.grandTotal;
        dRow.count += 1;
        if (t.repairRecordId) dRow.servisCount += 1;
        addItemKategori(items, 1);
        // deteksi "tanpa HPP" (jawaban h): ada barang (retail/sparepart/external)
        // tapi SEMUA barangnya costPrice 0 → indikasi data lama tanpa HPP
        const goods = items.filter((it) => ["retail", "sparepart", "external_sparepart"].includes(String(it.itemType)));
        if (goods.length > 0 && goods.every((it) => (Number(it.costPrice) || 0) === 0)) tanpaHppCount += 1;
      }

      const sign = isRefund ? -1 : 1;
      const m = perMethod.get(t.paymentMethod) ?? { metode: t.paymentMethod, penjualan: 0, refund: 0, net: 0, count: 0 };
      if (isRefund) m.refund += nilai; else m.penjualan += nilai;
      m.net += sign * nilai;
      m.count += 1;
      perMethod.set(t.paymentMethod, m);

      const k = perKasir.get(t.createdBy) ?? { kasir: t.createdBy, penjualan: 0, refund: 0, net: 0, count: 0 };
      if (isRefund) k.refund += nilai; else k.penjualan += nilai;
      k.net += sign * nilai;
      k.count += 1;
      perKasir.set(t.createdBy, k);

      daily.set(day, dRow);
    }

    // per teknisi (jasa) dari tiket yang di-checkout dalam rentang
    for (const t of txs) {
      if (t.isVoided || t.docType !== "PENJUALAN" || !t.repairRecordId) continue;
      const r = repairById.get(t.repairRecordId);
      if (!r) continue;
      let items: ItemJson[] = [];
      try {
        const parsed = JSON.parse(t.itemsJson);
        if (Array.isArray(parsed)) items = parsed;
      } catch {
        items = [];
      }
      const jasa = items
        .filter((it) => it.itemType === "service")
        .reduce((s, it) => s + Math.max(0, Number(it.price) || 0) * Math.max(1, Math.trunc(Number(it.qty) || 1)), 0);
      const nama = r.technicianName?.trim() || "Tanpa Teknisi";
      const row = perTeknisi.get(nama) ?? { teknisi: nama, tiket: 0, jasa: 0, poin: 0 };
      row.tiket += 1;
      row.jasa += jasa;
      row.poin += r.pointsReward ?? 0;
      perTeknisi.set(nama, row);
    }

    // info void dalam rentang (voidedAt) — tautan kartu D37
    const voidedDocs = txs.filter((t) => t.isVoided && t.voidedAt && t.voidedAt >= start && t.voidedAt < end);
    const voidTotal = voidedDocs.reduce((s, t) => s + Math.abs(t.grandTotal), 0);

    const omzetNet = omzetKotor - refundTotal;
    const hppTotal = hppNet; // sudah termasuk pengembalian HPP refund
    const labaKotor = omzetNet - hppTotal;

    const kategoriRows = [...perKategori.values()]
      .map((r) => ({
        kategori: r.kategori,
        omzet: r.omzet,
        qty: r.qty,
        hpp: admin && r.hasHpp ? r.hppAcc : null,
      }))
      .sort((a, b) => b.omzet - a.omzet);

    const dailyRows: { day: string; omzet: number; refund: number; net: number; count: number; servisCount: number; hpp: number | null }[] = [];
    const cursor = new Date(start.getTime());
    while (cursor < end) {
      const key = dayKeyWIB(cursor);
      const d = daily.get(key);
      const omzet = d?.omzet ?? 0;
      const refund = d?.refund ?? 0;
      dailyRows.push({
        day: key,
        omzet,
        refund,
        net: omzet - refund,
        count: d?.count ?? 0,
        servisCount: d?.servisCount ?? 0,
        hpp: admin ? (d?.hpp ?? 0) : null,
      });
      cursor.setUTCDate(cursor.getUTCDate() + 1);
    }

    return NextResponse.json({
      from,
      to,
      isAdmin: admin,
      ringkasan: {
        omzetKotor,
        diskonTotal,
        refundTotal,
        refundCount,
        omzetNet,
        txCount,
        servisCount,
        avgTicket: txCount > 0 ? omzetKotor / txCount : 0,
        voidCount: voidedDocs.length,
        voidTotal,
        // jawaban g: laba hanya untuk Admin — non-Admin menerima null
        hppTotal: admin ? hppTotal : null,
        labaKotor: admin ? labaKotor : null,
        tanpaHppCount: admin ? tanpaHppCount : null, // jawaban h: catatan, bukan pemotongan
      },
      perMethod: [...perMethod.values()].sort((a, b) => b.net - a.net),
      perKasir: [...perKasir.values()].sort((a, b) => b.net - a.net),
      perKategori: kategoriRows,
      perTeknisi: [...perTeknisi.values()].sort((a, b) => b.jasa - a.jasa),
      daily: dailyRows,
    });
  } catch (e) {
    console.error("reports sales GET error", e);
    return NextResponse.json({ error: "Gagal memuat laporan penjualan" }, { status: 500 });
  }
}
