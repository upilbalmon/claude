import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { errAction, resolveActor } from "@/lib/action-guard";

type Params = { params: Promise<{ id: string }> };

// PUT /api/transactions/[id] — edit transaksi (ala AppViewModel.updateTransaction).
// D34: Admin WAJIB (requesterUsername diverifikasi server — dulu hanya dibatasi UI).
// Dokumen REFUND (D38) tidak bisa diedit — koreksi keuangan otomatis, bukan input manual.
// Edit TIDAK menyentuh stok/item — persis referensi:
// grandTotal = max(0, subtotal - diskon), kembalian = max(0, bayar - total).
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return NextResponse.json({ error: "ID tidak valid" }, { status: 400 });
    }
    const existing = await db.transaction.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Transaksi tidak ditemukan" }, { status: 404 });
    }
    if (existing.isVoided) {
      return NextResponse.json({ error: "Transaksi sudah dibatalkan (void) — tidak bisa diedit" }, { status: 400 });
    }
    if (existing.docType === "REFUND") {
      return NextResponse.json({ error: "Dokumen refund tidak bisa diedit — nilainya otomatis dari nota asli" }, { status: 400 });
    }

    const body = (await req.json().catch(() => ({}))) as {
      requesterUsername?: unknown;
      customerName?: string;
      paymentMethod?: string;
      paymentStatus?: string;
      discount?: number;
      paidAmount?: number;
    };

    // D34 — aktor wajib Admin (server-side)
    const actor = await resolveActor(body.requesterUsername);
    if (!actor) {
      return errAction("Hanya Admin yang dapat mengedit transaksi", 403);
    }
    const customerName = String(body.customerName ?? existing.customerName).trim() || existing.customerName;
    const paymentMethod = ["Tunai", "Transfer", "QRIS", "E-Wallet", "Kartu"].includes(String(body.paymentMethod)) // D48/5C-1.2: + QRIS
      ? String(body.paymentMethod)
      : existing.paymentMethod;
    const paymentStatus = ["LUNAS", "DP_SEBAGIAN", "BON_PIUTANG"].includes(String(body.paymentStatus))
      ? String(body.paymentStatus)
      : existing.paymentStatus;
    const discount = Math.max(0, Number(body.discount) || 0);
    let paidAmount = Number(body.paidAmount);
    if (!Number.isFinite(paidAmount) || paidAmount < 0) paidAmount = existing.paidAmount;

    const grandTotal = Math.max(0, existing.subtotal - discount);
    if (paymentStatus === "LUNAS" && paidAmount < grandTotal) {
      const shortage = grandTotal - paidAmount;
      return NextResponse.json(
        { error: `Kurang bayar Rp ${Math.trunc(shortage).toLocaleString("id-ID")}` },
        { status: 400 }
      );
    }
    const changeAmount = paidAmount >= grandTotal ? paidAmount - grandTotal : 0;

    const updated = await db.$transaction(async (tx) => {
      const transaction = await tx.transaction.update({
        where: { id },
        data: {
          customerName,
          paymentMethod,
          paymentStatus,
          discount,
          grandTotal,
          paidAmount,
          changeAmount,
        },
      });

      // teks audit persis AppViewModel.kt: "Mengubah transaksi: Invoice X (Y)"
      // D34: performedBy dari aktor terverifikasi server
      await tx.auditLog.create({
        data: {
          action: "EDIT_TRANSAKSI",
          details: `Mengubah transaksi: Invoice ${transaction.invoiceNumber} (${transaction.customerName})`,
          performedBy: actor.name,
        },
      });

      return transaction;
    }, { timeout: 15000, maxWait: 5000 }); // D12: ruang menunggu kunci tulis SQLite saat checkout paralel

    return NextResponse.json(updated);
  } catch (e) {
    console.error("transactions PUT error", e);
    return NextResponse.json({ error: "Gagal mengubah transaksi" }, { status: 500 });
  }
}
