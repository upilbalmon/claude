// D48/5A.9 — Ekspor CSV untuk laporan (gaya keuangan D10: angka rata kanan,
// format tabel rapi). Pemisah titik-koma + BOM UTF-8 supaya Excel Indonesia
// langsung membuka kolom dengan benar; angka pakai koma desimal locale id-ID
// (tanpa simbol Rp) agar bisa dihitung ulang di spreadsheet.

export type CsvRow = (string | number | null | undefined)[];

function cell(v: string | number | null | undefined): string {
  if (v === null || v === undefined) return "";
  if (typeof v === "number") {
    return Number.isInteger(v)
      ? String(v)
      : v.toLocaleString("id-ID", { maximumFractionDigits: 2 });
  }
  const s = String(v);
  // quote bila mengandung pemisah/baris baru/kutip
  if (s.includes(";") || s.includes("\n") || s.includes('"')) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

export function toCsv(rows: CsvRow[]): string {
  return rows.map((r) => r.map(cell).join(";")).join("\r\n");
}

export function downloadCsv(filename: string, rows: CsvRow[]): void {
  const blob = new Blob(["\uFEFF" + toCsv(rows)], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename.endsWith(".csv") ? filename : `${filename}.csv`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/** Ringkas label tanggal untuk nama file: 2026-11-11 → 20261111 */
export function stampDay(day: string): string {
  return day.replace(/-/g, "");
}
