import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { loadCreds, credsSummary } from "@/lib/github-backup";
import { getDataVersion } from "@/lib/db";

// D68 — GET /api/github/status?requesterUsername=...
// Status koneksi GitHub (token, repo, branch, folder) + pengaturan auto-backup.
// Token tidak pernah dikirim utuh ke klien — hanya 4 karakter terakhir.
// Hanya Admin — kredensial & cadangan berisi data sensitif.
// D74 — respons juga memuat dataVersion (seq lokal) untuk info sinkronisasi.
export async function GET(req: NextRequest) {
  const actor = await resolveActor(req.nextUrl.searchParams.get("requesterUsername"));
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);
  try {
    const creds = await loadCreds();
    const summary = credsSummary(creds) as Record<string, unknown>;
    try {
      summary.dataVersion = await getDataVersion();
    } catch {
      summary.dataVersion = null; // tabel AppMeta belum ada (baru dibuat saat heal)
    }
    return NextResponse.json(summary);
  } catch (e) {
    console.error("github status error", e);
    return NextResponse.json({ error: "Gagal membaca status GitHub" }, { status: 500 });
  }
}
