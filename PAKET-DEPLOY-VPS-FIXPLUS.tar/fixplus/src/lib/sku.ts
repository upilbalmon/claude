// D20 — SKU otomatis: bila SKU dikosongkan di form Inventaris, dibuat dari nama barang
// mengikuti pola data yang sudah ada: JENIS-UNIT[-VARIAN], huruf besar, dipisah tanda hubung.
// Referensi pola (data existing): LCD-IP11, BAT-S20, FLEX-RN10, TG-UNIV, LCD-IP11-FS, LCD-A14.
// Instan, offline, 0 biaya, deterministik — dan hasilnya SELALU bisa ditimpa manual
// (SKU = preferensi tiap bengkel). Duplikat dicegah dengan akhiran -2, -3, …
// Catatan: file dipakai juga skrip Node (type-stripping Node 24) → hanya sintaks TS erasable,
// tanpa import apa pun.

// ===== Tokenizer: gaya sama dengan alias.ts — camelCase-safe, merek Apple tidak dipecah =====
function tokenize(nama: string): string[] {
  return nama
    .replace(/(iphone|ipad|ipod)/gi, (m) => m.toLowerCase())
    // pisah camelCase huruf→huruf besar agar "UniversalTG" → "UNIVERSAL TG";
    // digit TIDAK dipisah agar kode model "7G"/"A14"/"MT6582" tetap satu token
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .toUpperCase()
    .split(/[^A-Z0-9+]+/)
    .filter(Boolean);
}

// Kata yang DILEWATI di posisi mana pun (kualitas, warna, spek, penanda) — bukan penghenti.
const NOISE = new Set([
  // kualitas / asal
  "ORIGINAL", "ORI", "ORGINAL", "QUALITY", "KWALITAS", "KUALITAS", "NEW", "BARU", "COPY", "OEM",
  "HIGH", "REPLACEMENT", "GRADE", "PREMIUM", "SUPER", "KW", "KW1", "KW2", "KW3",
  "BNIB", "SECOND", "BEKAS", "REFURBISH",
  // spek tak penting di SKU
  "MAH", "INCH", "INC", "VOLT", "AMPERE", "AMPER",
  // warna / finish
  "HITAM", "PUTIH", "BLACK", "WHITE", "GOLD", "SILVER", "MERAH", "BIRU", "BLUE", "RED", "GREEN",
  "HIJAU", "KUNING", "YELLOW", "PINK", "UNGU", "PURPLE", "ABU", "GRAY", "GREY", "ROSE",
  "TRANSPARENT", "TRANSPARAN", "CLEAR",
  // kata sambung / pengisi
  "UNTUK", "BUAT", "DARI", "TYPE", "TIPE", "MODEL", "UNIT", "HP", "PHONE", "HANDPHONE",
  "SPAREPART", "SPARE", "PART", "RETAIL", "DAN", "WITH", "SET", "ALL",
  // pelengkap jenis part yang tak membedakan (pola existing: "LCD Screen iPhone 11" → LCD-IP11)
  "SCREEN", "DISPLAY", "LAYAR", "ON", "OFF",
]);

// Kata jualan/opsional di ekor nama → berhenti.
const STOP = new Set([
  "MURAH", "BAGUS", "BEST", "GOOD", "READY", "STOCK", "PROMO", "GARANSI", "GRATIS", "HARGA",
  "SALE", "DISKON",
]);

// Jenis part → kode SKU (pola JENIS pada data existing: LCD, BAT, FLEX, TG).
const HEAD: Record<string, string> = {
  LCD: "LCD",
  TEMPERED: "TG", TEMPEREDGLASS: "TG", TG: "TG",
  BATTERY: "BAT", BATERAI: "BAT", BATRAI: "BAT", BATRE: "BAT", BAT: "BAT",
  FLEXIBLE: "FLEX", FLEXIBEL: "FLEX", FLEXY: "FLEX", FLEX: "FLEX",
  TOUCHSCREEN: "TS", TOUCH: "TS", TS: "TS",
  SPEAKER: "SPK", BUZZER: "SPK", EARPHONE: "SPK", RINGER: "SPK",
  MIC: "MIC", MICROPHONE: "MIC", MICK: "MIC",
  KAMERA: "CAM", CAMERA: "CAM", CAM: "CAM",
  IC: "IC",
  KONEKTOR: "CONN", CONNECTOR: "CONN", CHARGING: "CONN",
  CHARGER: "CHG", ADAPTER: "CHG", CASAN: "CHG",
  CASING: "CSG", HOUSING: "CSG",
  ANTENA: "ANT", ANTENNA: "ANT",
  KACA: "KACA",
  SIM: "SIM",
  KABEL: "KBL",
};

// Pasangan token 1+2 → jenis khusus (konsumsi 2 token).
const PAIR: Record<string, Record<string, string>> = {
  TEMPERED: { GLASS: "TG" },
  KABEL: { FLEX: "FLEX", CHARGER: "FLEX", DATA: "KDATA" },
  KONEKTOR: { CHARGER: "CONN", CAS: "CONN", CHARGING: "CONN", PORT: "CONN" },
  KACA: { BELAKANG: "KBLK", BACK: "KBLK" },
  SIM: { TRAY: "SIM" },
};

// Kata jenis yang berulang di belakang nama → buang (mis. "Kabel Flex Charger Redmi Note 10").
const SYNONYMS: Record<string, Set<string>> = {
  TG: new Set(["TEMPERED", "GLASS", "TEMPEREDGLASS", "TG"]),
  LCD: new Set(["LCD"]),
  TS: new Set(["TOUCHSCREEN", "TOUCH", "TS"]),
  BAT: new Set(["BATTERY", "BATERAI", "BATRE", "BATRAI", "BAT"]),
  FLEX: new Set(["FLEX", "FLEXIBLE", "FLEXIBEL", "FLEXY", "KABEL", "CHARGER"]),
  SPK: new Set(["SPEAKER", "BUZZER", "EARPHONE", "RINGER"]),
  MIC: new Set(["MIC", "MICROPHONE", "MICK"]),
  CAM: new Set(["KAMERA", "CAMERA", "CAM"]),
  CONN: new Set(["KONEKTOR", "CONNECTOR", "CHARGING", "CHARGER", "PORT", "DC"]),
  CHG: new Set(["CHARGER", "ADAPTER", "CASAN", "CAS"]),
  CSG: new Set(["CASING", "HOUSING", "BACKDOOR"]),
  SIM: new Set(["SIM", "TRAY"]),
  IC: new Set(["IC"]),
  KBL: new Set(["KABEL"]),
  KDATA: new Set(["KABEL", "DATA"]),
  KBLK: new Set(["KACA", "BELAKANG", "BACK"]),
};

// Varian → akhiran di EKOR SKU (pola existing: "LCD Fullset iPhone 11" → LCD-IP11-FS).
const VARIANT: Record<string, string> = {
  FULLSET: "FS", COMPLETE: "FS", TOUCHSCREEN: "TS", TOUCH: "TS", TS: "TS",
};

// Merek yang kodenya saja yang dipakai (modelnya yang membedakan: S20, A14, A16, X3…).
const BRAND_DROP = new Set([
  "SAMSUNG", "GALAXY", "XIAOMI", "POCO", "OPPO", "VIVO", "REALME", "INFINIX", "ITEL", "NOKIA",
  "ASUS", "ADVAN", "HUAWEI", "HONOR", "LENOVO", "SONY", "HTC", "GOOGLE", "PIXEL", "MICROSOFT",
]);

// Merek yang butuh KODE depan agar nomor modelnya tak rancu (pola existing:
// "iPhone 11" → IP11, "Redmi Note 10" → RN10).
const BRAND_PREFIX: Record<string, string> = { IPHONE: "IP", IPAD: "IPAD", IPOD: "IPAD" };

// Kata unit generik → singkatan tetap (pola existing: "Tempered Glass Universal" → TG-UNIV).
const UNIT_SHORT: Record<string, string> = { UNIVERSAL: "UNIV", UMUM: "UNIV" };

// kandidat token unit dari daftar token: buang noise/stop/merek/varian/kapasitas
function kandidatUnit(tokens: string[], skipIdx: Set<number> = new Set()): string[] {
  const out: string[] = [];
  for (let k = 0; k < tokens.length; k++) {
    if (skipIdx.has(k)) continue;
    const t = tokens[k];
    if (STOP.has(t) || NOISE.has(t) || BRAND_DROP.has(t) || BRAND_PREFIX[t] || VARIANT[t]) continue;
    if (t === "REDMI" || t === "NOTE") continue;
    if (/^\d+(MAH|MA)$/.test(t) || /^\d+(\.\d+)?(INCH|INC)$/.test(t)) continue;
    out.push(UNIT_SHORT[t] ?? t);
  }
  return out;
}

// unit dari kandidat: token berdigit = kode model (kata alpha pendek di depannya disambung),
// tanpa digit → gabung kandidat awal sampai 6 karakter
function unitDariKandidat(candidates: string[]): string {
  const mapped = candidates.map((t) => UNIT_SHORT[t] ?? t);
  const di = mapped.findIndex((t) => /\d/.test(t));
  if (di >= 0) {
    // "Samsung S20" → S20, "Infinix Hot 12" → HOT12, "IC Power MT6582" → MT6582 (bukan POWERM)
    const before = di > 0 && /^[A-Z]+$/.test(mapped[di - 1]) ? mapped[di - 1] : "";
    const joined = before + mapped[di];
    return (joined.length <= 7 ? joined : mapped[di]).slice(0, 8);
  }
  let acc = "";
  for (const t of mapped) {
    if ((acc + t).length > 6) break;
    acc += t;
  }
  // kandidat pertama sendirian melebihi 6 karakter → potong ("Bluetooth" → BLUETO)
  if (acc === "" && mapped.length > 0) return mapped[0].slice(0, 6);
  return acc;
}

/** Saran SKU dari nama barang — pola JENIS-UNIT[-VARIAN] ala data existing. */
export function saranSku(nama: string): string {
  const tokens = tokenize(nama);
  if (tokens.length === 0) return "";

  // --- pre-pass: merek berkode depan + modelnya (dipakai bila unit tak ketemu setelah jenis)
  let prefix = "";
  let prefixModel = "";
  for (let s = 0; s < tokens.length; s++) {
    const t = tokens[s];
    if (t === "REDMI") prefix = tokens[s + 1] === "NOTE" ? "RN" : "RM";
    else if (BRAND_PREFIX[t]) prefix = BRAND_PREFIX[t];
    else continue;
    for (let k = s + 1; k < tokens.length; k++) {
      const tk = tokens[k];
      if (NOISE.has(tk) || BRAND_DROP.has(tk) || tk === "NOTE") continue;
      if (/\d/.test(tk)) {
        prefixModel = tk;
        break;
      }
    }
    break; // merek berkode pertama saja
  }

  // --- cari JENIS part pertama di seluruh nama (lewati noise & merek) ---
  let headIdx = -1;
  let head = "";
  let pairUsed = false;
  for (let s = 0; s < tokens.length; s++) {
    const t = tokens[s];
    if (NOISE.has(t) || BRAND_DROP.has(t) || BRAND_PREFIX[t] || t === "REDMI" || t === "NOTE") continue;
    const pair = PAIR[t]?.[tokens[s + 1]];
    if (pair) {
      headIdx = s;
      head = pair;
      pairUsed = true;
      break;
    }
    if (HEAD[t]) {
      headIdx = s;
      head = HEAD[t];
      break;
    }
  }

  // --- tanpa jenis part: SKU = kode merek + model ("iPhone 11" → IP11) / token pertama ---
  if (headIdx < 0) {
    if (prefix && prefixModel) return prefix + prefixModel;
    const fi = tokens.findIndex(
      (t) =>
        !NOISE.has(t) && !STOP.has(t) && !BRAND_DROP.has(t) && !BRAND_PREFIX[t] &&
        t !== "REDMI" && t !== "NOTE" && !VARIANT[t]
    );
    if (fi < 0) return "";
    const headless = tokens[fi].slice(0, 4);
    const unit = unitDariKandidat(kandidatUnit(tokens, new Set([fi])));
    return [headless, unit].filter(Boolean).join("-");
  }

  // --- unit dari token SETELAH jenis (urutan lazim: "LCD iPhone 11") ---
  const sinonim = SYNONYMS[head];
  const suffixes: string[] = [];
  let unitPrefix = ""; // kode depan unit yang muncul SETELAH jenis: IP / IPAD / RN / RM
  let unitPrefixPos = 0;
  const candidates: string[] = [];

  for (let i = headIdx + (pairUsed ? 2 : 1); i < tokens.length; i++) {
    const t = tokens[i];
    if (STOP.has(t)) break;
    if (sinonim && sinonim.has(t)) continue;
    const v = VARIANT[t];
    if (v) {
      if (!suffixes.includes(v)) suffixes.push(v);
      continue;
    }
    if (/^\d+(MAH|MA)$/.test(t) || /^\d+(\.\d+)?(INCH|INC)$/.test(t)) continue;
    if (t === "REDMI") {
      if (tokens[i + 1] === "NOTE") {
        unitPrefix = "RN";
        i++; // konsumsi NOTE
      } else {
        unitPrefix = "RM";
      }
      unitPrefixPos = candidates.length;
      continue;
    }
    if (BRAND_PREFIX[t]) {
      unitPrefix = BRAND_PREFIX[t];
      unitPrefixPos = candidates.length;
      continue;
    }
    if (BRAND_DROP.has(t) || NOISE.has(t)) continue;
    candidates.push(t);
  }

  // --- rakit unit ---
  let unit = "";
  if (unitPrefix) {
    // "iPhone 11" → IP11, "Redmi Note 10" → RN10, "iPad 9" → IPAD9
    const after = candidates.slice(unitPrefixPos);
    const di = after.findIndex((t) => /\d/.test(t));
    const digitTok = di >= 0 ? after[di] : (after[0] ?? "");
    unit = unitPrefix + digitTok;
    // varian setelah nomor model: 2 kata → inisial keduanya ("iPhone 14 Pro Max" → IP14PM),
    // 1 kata → utuh bila pendek ("iPhone 14 Pro" → IP14PRO), total ≤ 8
    const trailing = (di >= 0 ? after.slice(di + 1) : after.slice(1))
      .filter((t) => /^[A-Z]+$/.test(t) && t.length <= 6)
      .slice(0, 2);
    if (trailing.length >= 2) {
      unit += trailing.map((t) => t[0]).join("");
    } else if (trailing.length === 1) {
      const add = trailing[0].length <= 3 ? trailing[0] : trailing[0][0];
      if (unit.length + add.length <= 8) unit += add;
    }
  } else if (candidates.length > 0) {
    unit = unitDariKandidat(candidates);
  } else {
    // unit kosong — model ada SEBELUM jenis ("Infinix Hot 12 LCD" → LCD-HOT12)
    const skip = new Set([headIdx]);
    if (pairUsed) skip.add(headIdx + 1);
    if (prefix && prefixModel) unit = prefix + prefixModel;
    else unit = unitDariKandidat(kandidatUnit(tokens, skip));
  }

  // --- JENIS-UNIT[-VARIAN] ---
  return [head, unit, ...suffixes].filter(Boolean).join("-");
}

/**
 * SKU otomatis final untuk disimpan: saran dari nama + jaminan unik (banding aba
 * besar-kecil) terhadap SKU yang sudah ada — bentrok ditambah akhiran -2, -3, …
 */
export function buatSkuOtomatis(nama: string, existingSkus: string[]): string {
  const base = saranSku(nama) || "SP";
  const taken = new Set(
    existingSkus.map((s) => (s ?? "").trim().toLowerCase()).filter((s) => s !== "")
  );
  if (!taken.has(base.toLowerCase())) return base;
  for (let n = 2; n < 100; n++) {
    const c = `${base}-${n}`;
    if (!taken.has(c.toLowerCase())) return c;
  }
  return `${base}-${Date.now().toString().slice(-4)}`;
}
