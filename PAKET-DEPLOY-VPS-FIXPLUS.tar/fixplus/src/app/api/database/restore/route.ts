import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import {
  importBackup,
  parseCsv,
  csvRowsToPayload,
  BACKUP_ENTITIES,
  ENTITY_LABEL,
  type BackupEntity,
} from "@/lib/db-backup";
import { db } from "@/lib/db";

// D40 — POST /api/database/restore (parity "Impor Data Terpilih" + "Impor CSV" referensi)
// Dua mode:
//   1. JSON  : { requesterUsername, entities: [...], data: <payload exportBackup> }
//   2. CSV   : { requesterUsername, csv: { table: "customers", text: "..." } }
// Semantik MERGE aman (lihat db-backup.ts): data yang sudah ada TIDAK ditimpa,
// hanya baris baru yang diimpor. Pengguna: checkbox "Data Pengguna" mati secara
// bawaan di UI agar akun tidak tertimpa tak sengaja (persis referensi).
// Admin-only (D34) — impor massal adalah hak owner.
export async function POST(req: NextRequest) {
  let body: {
    requesterUsername?: string;
    entities?: BackupEntity[];
    data?: Record<string, unknown>;
    csv?: { table?: string; text?: string };
  };
  try {
    body = await req.json();
  } catch {
    return errAction("Body JSON tidak valid", 400);
  }

  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  try {
    let payload: Record<string, unknown> | null = null;
    let entities: BackupEntity[] = [];

    if (body.csv?.text) {
      const table = String(body.csv.table ?? "") as BackupEntity;
      if (!BACKUP_ENTITIES.some((e) => e.key === table)) {
        return errAction("Tabel CSV tidak dikenali", 400);
      }
      const rows = parseCsv(String(body.csv.text));
      if (!rows.length) return errAction("File CSV kosong atau tidak berisi data", 400);
      payload = csvRowsToPayload(table, rows);
      entities = [table];
    } else if (body.data && typeof body.data === "object") {
      payload = body.data;
      const valid = new Set(BACKUP_ENTITIES.map((e) => e.key));
      entities = Array.isArray(body.entities)
        ? body.entities.filter((e): e is BackupEntity => valid.has(e))
        : BACKUP_ENTITIES.map((e) => e.key);
    } else {
      return errAction("Tidak ada data untuk dipulihkan", 400);
    }

    const result = await importBackup(payload!, entities);
    const summary = Object.entries(result)
      .filter(([, v]) => v.imported > 0 || v.skipped > 0)
      .map(([k, v]) => `${ENTITY_LABEL(k as BackupEntity)}: ${v.imported} diimpor, ${v.skipped} dilewati`)
      .join("; ");

    await db.auditLog.create({
      data: {
        action: "RESTORE_DATABASE",
        details: body.csv?.text
          ? `Impor CSV (${body.csv.table}) — ${summary}`
          : `Impor JSON — ${summary}`,
        performedBy: actor.name,
      },
    });

    return NextResponse.json({ result, summary });
  } catch (e) {
    console.error("database restore error", e);
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Gagal memulihkan data" },
      { status: 500 }
    );
  }
}
