import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashPin } from "@/lib/pin-hash";
import { resolveActor } from "@/lib/action-guard";
import { REPAIR_STATUSES, repairStatusIndex, parseRequestedParts } from "@/lib/repair-utils";
import { partShortageWarnings } from "@/lib/part-warning";
import { saranSku, skuUnik } from "@/lib/sku-utils";

type Params = { params: Promise<{ id: string }> };

// PUT /api/repairs/[id] — edit tiket / ubah status (ala saveRepairRecord + alur
// tombol status RepairSection.kt). Aturan persis referensi:
// - Tiket DIAMBIL terkunci (transaksi sudah lunas & unit diserahkan).
// - "Edit Detail Servis" hanya Admin (toast "Edit hanya bisa dilakukan oleh Admin!").
// - Rollback (status turun ke urutan lebih awal) oleh non-admin wajib otorisasi
//   akun Admin + PIN (RollbackAdminAuthDialog.kt) → diverifikasi server di sini.
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return NextResponse.json({ error: "ID tidak valid" }, { status: 400 });
    }
    const existing = await db.repairRecord.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Tiket servis tidak ditemukan" }, { status: 404 });
    }
    if (existing.status === "DIAMBIL") {
      return NextResponse.json(
        { error: "Transaksi ini sudah diambil & lunas pembayaran. Status terkunci!" },
        { status: 400 }
      );
    }

    const body = await req.json();
    const performedBy = String(body.performedBy ?? "Tidak diketahui");
    const userRole = String(body.userRole ?? "Kasir");
    const op = String(body.op ?? "edit"); // "edit" (form admin) | "status" (tombol status)

    if (op === "edit" && userRole !== "Admin") {
      return NextResponse.json({ error: "Edit hanya bisa dilakukan oleh Admin!" }, { status: 403 });
    }

    // ===== D28: op "partDatang" — sparepart pesanan sudah datang =====
    // body.items: [{ index (posisi di requestedPartsJson), mode: "STOK"|"EXTERNAL",
    // partId?, costPrice? }] — mode STOK tanpa partId → part katalog BARU dibuat
    // otomatis dari permintaan (stok = qty, harga jual = estimasi, harga beli =
    // costPrice, SKU pola D22); dengan partId → stok part existing += qty
    // (+ costPrice diperbarui bila dikirim). costPrice = harga beli aktual
    // (D30) — wajib dari UI, dicatat di usedParts & requestedParts. Part lalu
    // dicatat sebagai part terpakai (internal → dipotong stok saat checkout /
    // eksternal tanpa stok). Semua permintaan beres & status DISETUJUI →
    // otomatis lanjut DIKERJAKAN.
    if (op === "partDatang") {
      const requested = parseRequestedParts(existing.requestedPartsJson);
      const items: { index?: unknown; mode?: unknown; partId?: unknown; costPrice?: unknown }[] =
        Array.isArray(body.items) ? body.items : [];
      if (items.length === 0) {
        return NextResponse.json({ error: "Tidak ada item part pesanan yang diproses" }, { status: 400 });
      }
      const plans: { idx: number; mode: "STOK" | "EXTERNAL"; partId: number; cost: number | null }[] = [];
      for (const it of items) {
        const idx = Math.trunc(Number(it?.index));
        if (!Number.isInteger(idx) || idx < 0 || idx >= requested.length) {
          return NextResponse.json(
            { error: `Item part pesanan tidak valid (index ${idx})` },
            { status: 400 }
          );
        }
        if (requested[idx].done) continue; // sudah ditangani sebelumnya — lewati
        const mode = it?.mode === "EXTERNAL" ? "EXTERNAL" : "STOK";
        const partId = mode === "STOK" ? Math.trunc(Number(it?.partId) || 0) : 0;
        if (mode === "STOK" && partId > 0) {
          const part = await db.sparePart.findUnique({ where: { id: partId } });
          if (!part) {
            return NextResponse.json(
              { error: `Sparepart katalog tidak ditemukan (ID ${partId})` },
              { status: 400 }
            );
          }
        }
        // D30: harga beli aktual per unit (wajib dari UI; boleh 0 bila gratis/garansi).
        let cost: number | null = null;
        if (it?.costPrice !== undefined && it?.costPrice !== null && String(it.costPrice).trim() !== "") {
          const c = Number(it.costPrice);
          if (!Number.isFinite(c) || c < 0) {
            return NextResponse.json(
              { error: `Harga beli tidak valid untuk "${requested[idx].name}" (harus angka >= 0)` },
              { status: 400 }
            );
          }
          cost = c;
        }
        plans.push({ idx, mode, partId, cost });
      }
      if (plans.length === 0) {
        return NextResponse.json({ error: "Semua item sudah ditandai selesai" }, { status: 400 });
      }

      const updated = await db.$transaction(async (tx) => {
        const used = JSON.parse(existing.usedPartsJson || "[]") as {
          partId: number;
          name: string;
          alias?: string | null;
          qty: number;
          sellPrice: number;
          costPrice?: number;
          isExternal?: boolean;
        }[];
        const touched: string[] = [];
        for (const plan of plans) {
          const req = requested[plan.idx];
          const beliStr = plan.cost !== null ? `, beli Rp ${plan.cost.toLocaleString("id-ID")}` : "";
          if (plan.mode === "STOK") {
            let part =
              plan.partId > 0 ? await tx.sparePart.findUnique({ where: { id: plan.partId } }) : null;
            if (part) {
              // barang datang → tambah stok part katalog existing
              // (D30: harga beli katalog ikut diperbarui bila harga beli dikirim)
              await tx.sparePart.update({
                where: { id: part.id },
                data: {
                  stock: { increment: req.qty },
                  ...(plan.cost !== null ? { costPrice: plan.cost } : {}),
                },
              });
            } else {
              // part katalog baru otomatis dari permintaan (SKU pola D22)
              const allSkus = (await tx.sparePart.findMany({ select: { sku: true } })).map(
                (p) => p.sku
              );
              part = await tx.sparePart.create({
                data: {
                  name: req.name,
                  sku: skuUnik(saranSku(req.name), allSkus),
                  stock: req.qty,
                  costPrice: plan.cost ?? 0, // D30: harga beli aktual
                  sellPrice: req.estPrice,
                  minStock: 5,
                },
              });
              await tx.auditLog.create({
                data: {
                  action: "TAMBAH_SPAREPART",
                  details: `${part.name} (stok ${part.stock}) — dari part pesanan tiket #${existing.id}`,
                  performedBy,
                },
              });
            }
            requested[plan.idx] = {
              ...req,
              done: true,
              partId: part.id,
              ...(plan.cost !== null ? { costPrice: plan.cost } : {}), // D30
            };
            used.push({
              partId: part.id,
              name: part.name,
              alias: part.alias ?? null,
              qty: req.qty,
              sellPrice: part.sellPrice,
              costPrice: plan.cost ?? part.costPrice ?? 0, // D30: harga beli aktual
            });
            touched.push(
              `${req.name} (${req.qty}x) masuk inventaris sebagai "${part.name}" (stok +${req.qty}${beliStr})`
            );
          } else {
            requested[plan.idx] = {
              ...req,
              done: true,
              ...(plan.cost !== null ? { costPrice: plan.cost } : {}), // D30
            };
            used.push({
              partId: 0,
              name: req.name,
              alias: null,
              qty: req.qty,
              sellPrice: req.estPrice,
              costPrice: plan.cost ?? 0, // D30: harga beli aktual
              isExternal: true,
            });
            touched.push(`${req.name} (${req.qty}x) dipasang tanpa stok (part toko lain${beliStr})`);
          }
        }

        const pendingLeft = requested.some((p) => !p.done);
        const nextStatus =
          !pendingLeft && existing.status === "DISETUJUI" ? "DIKERJAKAN" : existing.status;
        const usedSum = used.reduce(
          (s, p) => s + (Number(p.sellPrice) || 0) * (Number(p.qty) || 0),
          0
        );
        const reqPendingSum = requested
          .filter((p) => !p.done)
          .reduce((s, p) => s + (Number(p.estPrice) || 0) * (Number(p.qty) || 0), 0);
        const totalPrice = existing.serviceFee + usedSum + reqPendingSum;

        const repair = await tx.repairRecord.update({
          where: { id },
          data: {
            requestedPartsJson: JSON.stringify(requested),
            usedPartsJson: JSON.stringify(used),
            status: nextStatus,
            totalPrice,
          },
        });

        await tx.auditLog.create({
          data: {
            action: "PART_DATANG",
            details: `Sparepart pesanan tiket #${existing.id} (${repair.deviceModel}): ${touched.join("; ")}${nextStatus !== existing.status ? ` — status lanjut ${nextStatus}` : ""}`,
            performedBy,
          },
        });

        return repair;
      }, { timeout: 15000, maxWait: 5000 });

      return NextResponse.json(updated);
    }

    // ===== Status =====
    let nextStatus: string = existing.status;
    if (body.status !== undefined) {
      if (!REPAIR_STATUSES.includes(body.status)) {
        return NextResponse.json(
          { error: "Status tidak valid (9 nilai RepairStatus)" },
          { status: 400 }
        );
      }
      nextStatus = body.status;
      // Rollback = status baru berada di urutan lebih awal dari status sekarang
      const isRollback =
        repairStatusIndex(nextStatus) < repairStatusIndex(existing.status) &&
        repairStatusIndex(existing.status) >= 0;
      if (isRollback && userRole !== "Admin") {
        const adminUsername = String(body.adminUsername ?? "").trim();
        const adminPin = String(body.adminPin ?? "");
        if (!adminUsername || !adminPin) {
          return NextResponse.json(
            { error: "Menurunkan status tiket memerlukan otorisasi Admin (PIN wajib)" },
            { status: 403 }
          );
        }
        const admin = await db.user.findUnique({ where: { username: adminUsername } });
        if (!admin || admin.role !== "Admin" || hashPin(adminPin, admin.salt) !== admin.pin) {
          return NextResponse.json(
            { error: "Otorisasi Admin gagal — username/PIN salah" },
            { status: 403 }
          );
        }
      }
    }

    // ===== Field lain =====
    const deviceModel =
      body.deviceModel !== undefined ? String(body.deviceModel).trim() : existing.deviceModel;
    const damageDescription =
      body.damageDescription !== undefined
        ? String(body.damageDescription).trim()
        : existing.damageDescription;
    if (!deviceModel || !damageDescription) {
      return NextResponse.json(
        { error: "Model HP dan deskripsi kerusakan wajib diisi" },
        { status: 400 }
      );
    }
    const customerName =
      body.customerName !== undefined ? String(body.customerName).trim() : existing.customerName;
    const customerPhone =
      body.customerPhone !== undefined ? String(body.customerPhone).trim() : existing.customerPhone;
    const serialOrImei =
      body.serialOrImei !== undefined ? String(body.serialOrImei).trim() : existing.serialOrImei;
    const difficulty = ["Rendah", "Sedang", "Tinggi"].includes(body.difficulty)
      ? body.difficulty
      : existing.difficulty;
    const notes = body.notes !== undefined ? String(body.notes).trim() : existing.notes;
    const estimatedCompletionTime =
      body.estimatedCompletionTime !== undefined
        ? String(body.estimatedCompletionTime).trim()
        : existing.estimatedCompletionTime;

    // Angka: pola referensi saveRepairRecord — nilai null/kosong = pertahankan yang lama
    // (estimatedCost/downPayment hanya diubah bila dikirim eksplisit)
    const pickMoney = (v: unknown, old: number | null): number | null => {
      if (v === undefined) return old;
      if (v === null || v === "") return null;
      const n = Number(v);
      return Number.isFinite(n) && n > 0 ? n : null;
    };
    const estimatedCost = pickMoney(body.estimatedCost, existing.estimatedCost);
    const downPayment = pickMoney(body.downPayment, existing.downPayment);
    const warrantyDays =
      body.warrantyDays !== undefined
        ? Math.max(0, Math.trunc(Number(body.warrantyDays) || 0))
        : existing.warrantyDays;
    const pointsReward =
      body.pointsReward !== undefined
        ? body.pointsReward === null || Number(body.pointsReward) <= 0
          ? null
          : Math.trunc(Number(body.pointsReward))
        : existing.pointsReward;

    const serviceFee =
      body.serviceFee !== undefined ? Math.max(0, Number(body.serviceFee) || 0) : existing.serviceFee;

    // Pelanggan & teknisi (SET_NULL bila terhapus di modulnya)
    let customerId = existing.customerId;
    if (body.customerId !== undefined) {
      customerId =
        Number.isInteger(body.customerId) && Number(body.customerId) > 0
          ? Number(body.customerId)
          : null;
      if (customerId) {
        const customer = await db.customer.findUnique({ where: { id: customerId } });
        if (!customer) {
          return NextResponse.json({ error: "Pelanggan tidak ditemukan" }, { status: 400 });
        }
      }
    }
    let technicianId = existing.technicianId;
    let technicianName = existing.technicianName;
    if (body.technicianId !== undefined) {
      if (Number.isInteger(body.technicianId) && Number(body.technicianId) > 0) {
        const tech = await db.technician.findUnique({ where: { id: Number(body.technicianId) } });
        if (!tech) {
          return NextResponse.json({ error: "Teknisi tidak ditemukan" }, { status: 400 });
        }
        technicianId = tech.id;
        technicianName = tech.name;
      } else {
        technicianId = null;
        technicianName = null;
      }
    }

    // Sparepart terpakai: bila dikirim → resolve ulang dari DB (nama & harga terkini);
    // bila tidak dikirim (transisi status biasa) → pertahankan usedPartsJson lama.
    // D64: entri isExternal (part toko lain, partId 0) dibawa apa adanya — dulu
    // entri partId 0 DILEPAS diam-diam di sini (data hilang saat edit tiket).
    let usedPartsJson = existing.usedPartsJson;
    if (body.usedParts !== undefined) {
      const partsInput: {
        partId?: number;
        qty: number;
        name?: string;
        sellPrice?: number;
        costPrice?: number;
        isExternal?: boolean;
      }[] = Array.isArray(body.usedParts)
        ? body.usedParts
        : [];
      const resolved: {
        partId: number;
        name: string;
        alias: string | null; // D23 (D18/D19): snapshot "Nama di Struk" terkini
        qty: number;
        sellPrice: number;
        costPrice: number;
        isExternal?: boolean;
      }[] = [];
      for (const p of partsInput) {
        const qty = Math.trunc(Number(p?.qty) || 0);
        if (p?.isExternal) {
          // D64: part external — wajib nama; harga jual/beli ≥ 0 (beli boleh 0 bila gratis)
          const name = String(p?.name ?? "").trim();
          if (!name || qty <= 0) continue;
          resolved.push({
            partId: 0,
            name,
            alias: null,
            qty,
            sellPrice: Math.max(0, Number(p?.sellPrice) || 0),
            costPrice: Math.max(0, Number(p?.costPrice) || 0),
            isExternal: true,
          });
          continue;
        }
        const partId = Number(p?.partId);
        if (!Number.isInteger(partId) || partId <= 0 || qty <= 0) continue;
        const part = await db.sparePart.findUnique({ where: { id: partId } });
        if (!part) {
          return NextResponse.json(
            { error: `Sparepart tidak ditemukan (ID ${partId})` },
            { status: 400 }
          );
        }
        resolved.push({ partId, name: part.name, alias: part.alias ?? null, qty, sellPrice: part.sellPrice, costPrice: part.costPrice });
      }
      usedPartsJson = JSON.stringify(resolved);
    }

    // D28: part pesanan (belum tersedia di inventaris) — bila dikirim (dialog
    // Diagnosa) → simpan; bila tidak → pertahankan yang lama (transisi biasa).
    let requestedPartsJson = existing.requestedPartsJson;
    if (body.requestedParts !== undefined) {
      const reqInput: { name?: unknown; qty?: unknown; estPrice?: unknown }[] = Array.isArray(
        body.requestedParts
      )
        ? body.requestedParts
        : [];
      const reqResolved: {
        name: string;
        qty: number;
        estPrice: number;
        partId?: number | null;
        done?: boolean;
      }[] = [];
      for (const p of reqInput) {
        const name = String(p?.name ?? "").trim();
        const qty = Math.trunc(Number(p?.qty) || 0);
        const estPrice = Math.max(0, Number(p?.estPrice) || 0);
        if (!name || qty <= 0) continue;
        // entri done (sudah ditangani lewat op partDatang) dipertahankan apa adanya
        if (p && (p as { done?: boolean }).done) {
          reqResolved.push({
            name,
            qty,
            estPrice,
            partId: (p as { partId?: number | null }).partId ?? null,
            done: true,
          });
          continue;
        }
        reqResolved.push({ name, qty, estPrice });
      }
      requestedPartsJson = JSON.stringify(reqResolved);
    }

    const partsSum = usedPartsJson === "[]"
      ? 0
      : (JSON.parse(usedPartsJson) as { sellPrice: number; qty: number }[]).reduce(
          (s, p) => s + (Number(p.sellPrice) || 0) * (Number(p.qty) || 0),
          0
        );
    // D28: estimasi part yang akan dipesan ikut total biaya yang disetujui pelanggan
    const requestedPendingSum = parseRequestedParts(requestedPartsJson)
      .filter((p) => !p.done)
      .reduce((s, p) => s + (Number(p.estPrice) || 0) * (Number(p.qty) || 0), 0);
    const totalPrice = serviceFee + partsSum + requestedPendingSum;

    // completedAt persis referensi: diisi bila status masuk SELESAI/DIAMBIL, selain itu dipertahankan
    const completedAt =
      nextStatus === "SELESAI" || nextStatus === "DIAMBIL"
        ? (existing.completedAt ?? new Date())
        : existing.completedAt;

    const statusChanged = nextStatus !== existing.status;

    // D48/(b) — peringatan janji stok saat part tiket diubah (tanpa reservasi):
    // hitung ketersediaan efektif dikurangi janji di tiket TERBUKA lain (tiket ini
    // dikecualikan karena janji lamanya akan diganti).
    let warnings: string[] = [];
    if (body.usedParts !== undefined) {
      warnings = await partShortageWarnings(
        (JSON.parse(usedPartsJson) as { partId: number; qty: number }[])
          .filter((p) => Number(p.partId) > 0)
          .map((p) => ({ partId: Number(p.partId), qty: Math.max(1, Math.trunc(Number(p.qty) || 1)) })),
        id
      );
    }

    const updated = await db.$transaction(async (tx) => {
      const repair = await tx.repairRecord.update({
        where: { id },
        data: {
          customerId,
          customerName,
          customerPhone,
          deviceModel,
          serialOrImei,
          damageDescription,
          status: nextStatus,
          technicianId,
          technicianName,
          serviceFee,
          usedPartsJson,
          requestedPartsJson,
          totalPrice,
          difficulty,
          notes,
          estimatedCost,
          downPayment,
          estimatedCompletionTime,
          pointsReward,
          warrantyDays,
          completedAt,
        },
      });

      if (statusChanged) {
        await tx.auditLog.create({
          data: {
            action: "UBAH_STATUS_REPAIR",
            details: `Status ${repair.deviceModel} (${repair.customerName}): ${existing.status} → ${nextStatus}${repairStatusIndex(nextStatus) < repairStatusIndex(existing.status) ? " [rollback]" : ""}`,
            performedBy,
          },
        });
      } else {
        await tx.auditLog.create({
          data: {
            action: "EDIT_REPAIR",
            details: `Mengubah detail servis: ${repair.deviceModel} — ${repair.customerName} (Rp ${Math.trunc(repair.totalPrice).toLocaleString("id-ID")})`,
            performedBy,
          },
        });
      }

      return repair;
    }, { timeout: 15000, maxWait: 5000 });

    return NextResponse.json({ ...updated, warnings });
  } catch (e) {
    console.error("repairs PUT error", e);
    return NextResponse.json({ error: "Gagal mengubah tiket servis" }, { status: 500 });
  }
}

// DELETE /api/repairs/[id] — hapus tiket (ala deleteRepair AppViewModel.kt,
// audit "Menghapus riwayat servis: ID X (Model - Pelanggan: Y)")
// D34: hapus data = hanya Admin (aturan 4), requesterUsername di body diverifikasi server.
export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return NextResponse.json({ error: "ID tidak valid" }, { status: 400 });
    }
    const existing = await db.repairRecord.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Tiket servis tidak ditemukan" }, { status: 404 });
    }
    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
    const actor = await resolveActor(body.requesterUsername);
    if (!actor) {
      return NextResponse.json({ error: "Hanya Admin yang dapat menghapus data" }, { status: 403 });
    }

    await db.$transaction(async (tx) => {
      await tx.repairRecord.delete({ where: { id } });
      await tx.auditLog.create({
        data: {
          action: "HAPUS_REPAIR",
          details: `Menghapus riwayat servis: ID ${existing.id} (${existing.deviceModel} - Pelanggan: ${existing.customerName})`,
          performedBy: actor.name,
        },
      });
    });

    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("repairs DELETE error", e);
    return NextResponse.json({ error: "Gagal menghapus tiket servis" }, { status: 500 });
  }
}
