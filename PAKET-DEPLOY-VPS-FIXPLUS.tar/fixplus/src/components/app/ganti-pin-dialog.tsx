"use client";

// Tahap 7.3 — Ganti PIN sendiri dari dalam aplikasi (tersedia untuk SEMUA role:
// dropdown akun di topbar — kasir/teknisi tanpa izin Setting tetap bisa mengganti
// PIN-nya sendiri). Entri berurutan 3 langkah dengan PinInput adaptif (D1):
// 1) PIN saat ini (diverifikasi server, hash) → 2) PIN baru (tolak default
// 1234/1111) → 3) konfirmasi → POST /api/auth/change-pin.
import { useState } from "react";
import { KeyRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { PinInput } from "@/components/app/pin-input";
import type { SafeUser } from "@/lib/app-types";

type Step = 1 | 2 | 3;

export function GantiPinDialog({
  user,
  open,
  onOpenChange,
}: {
  user: SafeUser;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const { toast } = useToast();
  const [step, setStep] = useState<Step>(1);
  const [currentPin, setCurrentPin] = useState("");
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [errorTick, setErrorTick] = useState(0);
  const [busy, setBusy] = useState(false);

  const stepValue = step === 1 ? currentPin : step === 2 ? newPin : confirmPin;
  const stepLabel =
    step === 1 ? "PIN Saat Ini" : step === 2 ? "PIN Baru (4 Angka)" : "Konfirmasi PIN Baru";

  function reset() {
    setStep(1);
    setCurrentPin("");
    setNewPin("");
    setConfirmPin("");
    setErrorTick(0);
    setBusy(false);
  }

  function close() {
    onOpenChange(false);
    reset();
  }

  function backToCurrent() {
    setStep(1);
    setCurrentPin("");
    setNewPin("");
    setConfirmPin("");
    setErrorTick((t) => t + 1);
  }

  function handleStepComplete(pin: string) {
    if (step === 1) {
      if (pin.length !== 4) return;
      setStep(2);
      return;
    }
    if (step === 2) {
      if (pin === "1234" || pin === "1111") {
        toast({ title: "Jangan gunakan PIN default! Gunakan kombinasi lain.", variant: "destructive" });
        setNewPin("");
        setErrorTick((t) => t + 1);
        return;
      }
      setStep(3);
      return;
    }
    // langkah 3 — konfirmasi
    if (pin !== newPin) {
      toast({ title: "Konfirmasi PIN tidak cocok!", variant: "destructive" });
      setConfirmPin("");
      setErrorTick((t) => t + 1);
      return;
    }
    void simpan(pin);
  }

  async function simpan(confirm: string) {
    if (newPin.length !== 4 || !/^\d{4}$/.test(newPin)) {
      toast({ title: "PIN baru wajib berupa 4 angka!", variant: "destructive" });
      setStep(2);
      setNewPin("");
      setConfirmPin("");
      return;
    }
    if (confirm !== newPin) {
      toast({ title: "Konfirmasi PIN tidak cocok!", variant: "destructive" });
      setConfirmPin("");
      setErrorTick((t) => t + 1);
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/auth/change-pin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id, currentPin, newPin }),
      });
      const data = (await res.json()) as { status?: string; message?: string };
      if (res.ok && data.status === "SUCCESS") {
        toast({ title: "PIN berhasil diganti", description: "Gunakan PIN baru pada login berikutnya." });
        close();
      } else if (res.status === 403) {
        // PIN saat ini salah → kembali ke langkah 1
        toast({ title: data.message ?? "PIN saat ini salah!", variant: "destructive" });
        backToCurrent();
      } else {
        toast({ title: data.message ?? "Gagal mengganti PIN", variant: "destructive" });
        backToCurrent();
      }
    } catch {
      toast({ title: "Tidak dapat terhubung ke server", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  function lanjut() {
    if (step === 1) {
      if (currentPin.length !== 4) return;
      setStep(2);
      return;
    }
    if (step === 2) {
      if (newPin === "1234" || newPin === "1111") {
        toast({ title: "Jangan gunakan PIN default! Gunakan kombinasi lain.", variant: "destructive" });
        setNewPin("");
        setErrorTick((t) => t + 1);
        return;
      }
      if (newPin.length !== 4) return;
      setStep(3);
      return;
    }
    void simpan(confirmPin);
  }

  const hint =
    step === 1
      ? "Langkah 1 dari 3 — masukkan PIN yang Anda pakai sekarang."
      : step === 2
        ? "Langkah 2 dari 3 — ketik 4 angka, bukan PIN default (1234/1111)."
        : "Langkah 3 dari 3 — ulangi PIN baru yang sama.";

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) close();
        else onOpenChange(true);
      }}
    >
      <DialogContent className="rounded-2xl sm:max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <KeyRound className="size-4 text-primary" aria-hidden />
            Ganti PIN
          </DialogTitle>
          <DialogDescription>
            Ganti PIN akun <b>@{user.username}</b> kapan saja — tanpa perlu izin Setting.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col items-center gap-4">
          <div className="w-full space-y-2">
            <Label htmlFor="ganti-pin">{stepLabel}</Label>
            <PinInput
              id="ganti-pin"
              variant="field"
              value={stepValue}
              onChange={(v) =>
                step === 1 ? setCurrentPin(v) : step === 2 ? setNewPin(v) : setConfirmPin(v)
              }
              onComplete={handleStepComplete}
              errorTick={errorTick}
              disabled={busy}
              ariaLabel={stepLabel}
            />
            <p className="text-center text-xs text-muted-foreground">{hint}</p>
          </div>
          <div className="flex w-full gap-3">
            <Button variant="outline" onClick={close} className="h-10 flex-1 rounded-xl" disabled={busy}>
              Batal
            </Button>
            <Button
              onClick={lanjut}
              disabled={
                busy ||
                (step === 1 && currentPin.length < 4) ||
                (step === 2 && newPin.length < 4) ||
                (step === 3 && confirmPin.length < 4)
              }
              className="h-10 flex-1 rounded-xl"
            >
              {busy ? "Menyimpan…" : step === 3 ? "Simpan PIN" : "Lanjut"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
