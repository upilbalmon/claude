import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { resolveActor } from "@/lib/action-guard";
import { spareCategoryOf } from "@/lib/spare-category";
import {
  bisaTransisiPreorder,
  PREORDER_BISA_EDIT,
  BELANJA_PAYMENT_METHODS,
} from "@/lib/belanja-utils";

type Params = { params: Promise<{ id: string }> };

// D61 — Tahap 6.1: alur status Pre-Order (Pending → Dipesan → Tiba → Diambil,
// + Batal) dan edit isi pesanan.
//
// Aturan penting:
//  - Transisi divalidasi server (bisaTransisiPreorder) — client tidak dipercaya.
//  - "Tiba" boleh memperbarui harga final per unit (estPrice) — saat barang
//    datang harga sebenarnya baru pasti; DP tetap yang sudah dibayar.
//  - "Diambil" = pelunasan → membuat NOTA PENJUALAN (Transaction) atomik:
//    omzet masuk laporan, poin loyalitas bertambah, pre-order terkait nota
//    (transactionId) — dobel-nota dicegah (409 bila sudah ada).
//  - "Batal" wajib alasan (disimpan cancelReason); DP yang sudah diterima
//    dikembalikan offline (diingatkan UI) — tidak dibuat dokumen refund karena
//    DP belum pernah menjadi nota penjualan.
//  - Edit isi hanya saat Pending/Dipesan; DELETE hanya Admin & status Batal (D34).

export async function PATCH(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return NextResponse.json({ error: "ID tidak valid" }, { status: 400 });
    }
    const row = await db.preOrder.findUnique({ where: { id } });
    if (!row) {
      return NextResponse.json({ error: "Pre-order tidak ditemukan" }, { status: 404 });
    }

    const body = await req.json();
    const performedBy = String(body.performedBy ?? "Tidak diketahui");

    // ===== Mode aksi status =====
    if (body.action === "status") {
      const target = String(body.status ?? "");
      if (!bisaTransisiPreorder(row.status, target)) {
        return NextResponse.json(
          { error: `Pre-order berstatus "${row.status}" tidak bisa lanjut ke "${target}"` },
          { status: 400 }
        );
      }

      // --- Pending/Dipesan → Batal: alasan wajib ---
      if (target === "Batal") {
        const reason = String(body.reason ?? "").trim();
        if (reason.length < 3) {
          return NextResponse.json(
            { error: "Alasan pembatalan wajib diisi (minimal 3 karakter)" },
            { status: 400 }
          );
        }
        const updated = await db.preOrder.update({
          where: { id },
          data: { status: "Batal", cancelReason: reason },
        });
        await db.auditLog.create({
          data: {
            action: "PREORDER_BATAL",
            details: `${row.itemName} ×${row.qty} — ${row.customerName}${row.dp > 0 ? ` — DP Rp ${Math.trunc(row.dp).toLocaleString("id-ID")} dikembalikan offline` : ""} — Alasan: ${reason}`,
            performedBy,
          },
        });
        return NextResponse.json(updated);
      }

      // --- * → Dipesan (pesanan diteruskan ke supplier) ---
      if (target === "Dipesan") {
        const updated = await db.preOrder.update({ where: { id }, data: { status: "Dipesan" } });
        await db.auditLog.create({
          data: {
            action: "PREORDER_STATUS",
            details: `${row.itemName} ×${row.qty} — ${row.customerName}: Pending → Dipesan`,
            performedBy,
          },
        });
        return NextResponse.json(updated);
      }

      // --- Dipesan → Tiba (opsional: harga final per unit) ---
      if (target === "Tiba") {
        let estPrice = row.estPrice;
        if (body.finalEstPrice !== undefined && String(body.finalEstPrice).trim() !== "") {
          const p = Number(body.finalEstPrice);
          if (!Number.isFinite(p) || p < 0) {
            return NextResponse.json({ error: "Harga final tidak valid" }, { status: 400 });
          }
          estPrice = p;
        }
        const updated = await db.preOrder.update({
          where: { id },
          data: { status: "Tiba", estPrice },
        });
        await db.auditLog.create({
          data: {
            action: "PREORDER_STATUS",
            details: `${row.itemName} ×${row.qty} — ${row.customerName}: Dipesan → Tiba${estPrice !== row.estPrice ? ` — harga final Rp ${Math.trunc(estPrice).toLocaleString("id-ID")}` : ""}`,
            performedBy,
          },
        });
        return NextResponse.json(updated);
      }

      // --- Tiba → Diambil: pelunasan + nota penjualan (atomik) ---
      if (target === "Diambil") {
        if (row.transactionId) {
          return NextResponse.json(
            { error: "Pre-order ini sudah punya nota penjualan" },
            { status: 409 }
          );
        }
        const paymentMethod = String(body.paymentMethod ?? "Tunai");
        if (!(BELANJA_PAYMENT_METHODS as readonly string[]).includes(paymentMethod)) {
          return NextResponse.json({ error: "Metode bayar tidak valid" }, { status: 400 });
        }

        const estTotal = row.estPrice * row.qty;
        const sisa = Math.max(0, estTotal - row.dp); // dp > estTotal terjadi bila harga final turun
        let paidNow = Number(body.paidNow);
        if (!Number.isFinite(paidNow) || paidNow < 0) paidNow = sisa; // default: lunasi sisa
        const changeAmount = Math.max(0, paidNow - sisa);

        const effectivePaid = row.dp + Math.min(paidNow, sisa);
        const paymentStatus =
          estTotal > 0 && effectivePaid >= estTotal
            ? "LUNAS"
            : effectivePaid > 0
              ? "DP_SEBAGIAN"
              : "BON_PIUTANG";

        const paidAmount = row.dp + paidNow; // uang yang benar-benar diterima (kembalian dikembalikan)
        const itemsJson = JSON.stringify([
          { name: row.itemName, qty: row.qty, price: row.estPrice, costPrice: 0, itemType: "preorder", category: row.category },
        ]);

        const makeInvoiceNumber = () =>
          `INV-${Math.floor(Date.now() / 1000)}${Math.floor(Math.random() * 100)
            .toString()
            .padStart(2, "0")}`;
        let invoiceNumber = makeInvoiceNumber();

        const created = await db.$transaction(async (tx) => {
          let nota: Awaited<ReturnType<typeof tx.transaction.create>>;
          for (let attempt = 0; ; attempt++) {
            try {
              nota = await tx.transaction.create({
                data: {
                  invoiceNumber,
                  repairRecordId: row.repairRecordId,
                  customerId: row.customerId,
                  customerName: row.customerName,
                  subtotal: estTotal,
                  discount: 0,
                  grandTotal: estTotal,
                  paymentMethod,
                  paidAmount,
                  changeAmount,
                  itemsJson,
                  paymentStatus,
                  createdBy: performedBy,
                },
              });
              break;
            } catch (err) {
              if ((err as { code?: string }).code === "P2002" && attempt < 4) {
                invoiceNumber = makeInvoiceNumber();
                continue;
              }
              throw err;
            }
          }

          await tx.preOrder.update({
            where: { id },
            data: { status: "Diambil", transactionId: nota.id },
          });

          // poin loyalitas — konsisten dengan checkout kasir (floor(total/10000))
          if (row.customerId) {
            const points = Math.floor(estTotal / 10000);
            if (points > 0) {
              await tx.customer.update({
                where: { id: row.customerId },
                data: { loyaltyPoints: { increment: points } },
              });
            }
          }

          await tx.auditLog.create({
            data: {
              action: "TAMBAH_TRANSAKSI",
              details: `Invoice ${invoiceNumber} — ${row.customerName} — Rp ${Math.trunc(estTotal).toLocaleString("id-ID")} (${paymentMethod}) — Pre-Order ${row.itemName} ×${row.qty}`,
              performedBy,
            },
          });

          return nota;
        }, { timeout: 15000, maxWait: 5000 });

        return NextResponse.json({ ...row, status: "Diambil", transactionId: created.id, nota: created });
      }

      return NextResponse.json({ error: "Status tujuan tidak dikenal" }, { status: 400 });
    }

    // ===== Mode edit isi pesanan =====
    if (!PREORDER_BISA_EDIT.includes(row.status)) {
      return NextResponse.json(
        { error: `Hanya Pre-Order berstatus Pending/Dipesan yang bisa diedit (status kini: ${row.status})` },
        { status: 400 }
      );
    }

    const itemName = String(body.itemName ?? row.itemName).trim();
    if (!itemName) {
      return NextResponse.json({ error: "Nama barang wajib diisi" }, { status: 400 });
    }
    const qty = clampInt(body.qty, row.qty, 1, 999);
    const estPrice = clampNum(body.estPrice, row.estPrice, 0);
    const dp = clampNum(body.dp, row.dp, 0);
    const estTotal = estPrice * qty;
    if (estTotal > 0 && dp > estTotal) {
      return NextResponse.json(
        { error: `DP (${fmtRp(dp)}) tidak boleh melebihi estimasi total (${fmtRp(estTotal)})` },
        { status: 400 }
      );
    }

    // pelanggan: bila dikirim → validasi; kosong → buang kaitan (jadi umum)
    let customerId = row.customerId;
    let customerName = String(body.customerName ?? row.customerName).trim();
    let customerPhone = String(body.customerPhone ?? row.customerPhone).trim();
    if (body.customerId !== undefined) {
      if (body.customerId === null || String(body.customerId).trim() === "") {
        customerId = null;
      } else {
        const cid = Number(body.customerId);
        if (!Number.isInteger(cid)) {
          return NextResponse.json({ error: "ID pelanggan tidak valid" }, { status: 400 });
        }
        const cust = await db.customer.findUnique({ where: { id: cid } });
        if (!cust) {
          return NextResponse.json({ error: "Pelanggan tidak ditemukan" }, { status: 404 });
        }
        customerId = cid;
        if (!customerName) customerName = cust.name;
        if (!customerPhone) customerPhone = cust.phone;
      }
    }
    if (!customerName) {
      return NextResponse.json({ error: "Nama pelanggan wajib diisi" }, { status: 400 });
    }

    // tiket servis: bila dikirim → validasi; kosong → lepas kaitan
    let repairRecordId = row.repairRecordId;
    if (body.repairRecordId !== undefined) {
      if (body.repairRecordId === null || String(body.repairRecordId).trim() === "") {
        repairRecordId = null;
      } else {
        const rid = Number(body.repairRecordId);
        if (!Number.isInteger(rid)) {
          return NextResponse.json({ error: "ID tiket servis tidak valid" }, { status: 400 });
        }
        const repair = await db.repairRecord.findUnique({ where: { id: rid } });
        if (!repair) {
          return NextResponse.json({ error: "Tiket servis tidak ditemukan" }, { status: 404 });
        }
        repairRecordId = rid;
      }
    }

    const updated = await db.preOrder.update({
      where: { id },
      data: {
        itemName,
        category: body.category !== undefined ? spareCategoryOf(body.category) : row.category,
        qty,
        estPrice,
        dp,
        notes: body.notes !== undefined ? String(body.notes).trim() : row.notes,
        customerId,
        customerName,
        customerPhone,
        repairRecordId,
      },
    });

    await db.auditLog.create({
      data: {
        action: "EDIT_PREORDER",
        details: `${updated.itemName} ×${updated.qty} — ${updated.customerName} (DP Rp ${Math.trunc(updated.dp).toLocaleString("id-ID")})`,
        performedBy,
      },
    });

    return NextResponse.json(updated);
  } catch (e) {
    console.error("pre-orders PATCH error", e);
    return NextResponse.json({ error: "Gagal memperbarui pre-order" }, { status: 500 });
  }
}

// DELETE /api/pre-orders/[id]?requesterUsername=… — hapus catatan Pre-Order.
// D34: hanya Admin; hanya catatan berstatus Batal (riwayat transaksi Diambil
// tetap terjaga — nota penjualannya tidak boleh hilang jejaknya).
export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return NextResponse.json({ error: "ID tidak valid" }, { status: 400 });
    }
    const actor = await resolveActor(req.nextUrl.searchParams.get("requesterUsername"));
    if (!actor) {
      return NextResponse.json({ error: "Hanya Admin yang dapat menghapus data" }, { status: 403 });
    }
    const existing = await db.preOrder.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Pre-order tidak ditemukan" }, { status: 404 });
    }
    if (existing.status !== "Batal") {
      return NextResponse.json(
        { error: "Hanya Pre-Order berstatus Batal yang dapat dihapus — batalkan dulu" },
        { status: 400 }
      );
    }

    await db.preOrder.delete({ where: { id } });
    await db.auditLog.create({
      data: {
        action: "HAPUS_PREORDER",
        details: `${existing.itemName} ×${existing.qty} — ${existing.customerName}`,
        performedBy: actor.name,
      },
    });

    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("pre-orders DELETE error", e);
    return NextResponse.json({ error: "Gagal menghapus pre-order" }, { status: 500 });
  }
}

function clampInt(v: unknown, fallback: number, min: number, max: number): number {
  const n = Math.trunc(Number(v));
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
}

function clampNum(v: unknown, fallback: number, min: number): number {
  const n = Number(v);
  return Number.isFinite(n) && n >= min ? n : fallback;
}

function fmtRp(n: number): string {
  return `Rp ${Math.trunc(n).toLocaleString("id-ID")}`;
}
