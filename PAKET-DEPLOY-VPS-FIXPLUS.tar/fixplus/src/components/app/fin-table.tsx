"use client";

// ============================================================================
// FIN-TABLE — Standar tampilan list mode desktop "industri keuangan profesional"
// (Keputusan D10, dipakai di SELURUH bagian aplikasi: Inventaris, Pelanggan,
//  Teknisi, Kasir/Riwayat, Katalog POS, dan modul Tahap 4–7 berikutnya)
//
// Karakteristik standar (ala software keuangan/back-office):
//  1. Header kolom UPPERCASE kecil (10.5px, tracking lebar) + garis rule 2px
//     warna primary di bawahnya (via inset-shadow — aman untuk sticky, lihat D4)
//  2. Header sticky menempel di bawah app bar pada ≥1280px (xl:top-14, D4/D6)
//  3. Baris rapat (py-2, teks 13px) + zebra selang-seling bg-muted/40
//  4. Hover baris hijau lembut bg-primary/5 di SEMUA baris
//  5. Angka rata kanan `tabular-nums`; kode/ID memakai `font-mono`
//  6. Kolom No. urut (#) gaya buku besar di kolom pertama
//  7. Header bisa diurutkan (FinSortTh): klik = urutkan, klik ulang = balik ▲▼
//  8. Baris total di footer (FinTfoot) dengan garis atas 2px primary
//  9. Chip jumlah data (FinCountChip) di toolbar setiap list
//
// ⚠ PATOKAN WAJIB halaman baru (D62 — larangan copy parsial):
//  Sticky `xl:top-14` hanya benar bila konteks sticky-nya HALAMAN (app bar
//  56px di atasnya). Konteks sticky = scrollable ancestor TERDEKAT, jadi
//  wrapper tabel wajib membebaskan overflow pada xl — SALIN UTUH:
//      <div className="overflow-x-auto rounded-2xl border bg-card shadow-sm
//        xl:overflow-x-visible">
//  TANPA `xl:overflow-x-visible`, `sticky top-14` menganggap tepi ATAS KARTU
//  sebagai patokan → header terdorong 56px ke bawah walau tanpa scroll dan
//  MENIMPA baris #1 (bug visual belanja D61, diperbaiki D62 — jangan diulang).
//  Tabel pendek dalam Dialog/kartu kecil: boleh tanpa sticky — beri
//  `sticky={false}` pada FinTh, bukan mengubah offset.
// ============================================================================

import * as React from "react";
import { cn } from "@/lib/utils";
import { TableHead } from "@/components/ui/table";

// --- Kelas dasar sel header -------------------------------------------------
function finThClass(sticky: boolean, align?: "left" | "right" | "center", corner?: "first" | "last") {
  return cn(
    "h-9 whitespace-nowrap px-3 text-[10.5px] font-bold uppercase tracking-[0.08em] text-muted-foreground",
    "bg-muted shadow-[inset_0_-2px_0_0_color-mix(in_srgb,var(--primary)_30%,transparent)]",
    sticky && "xl:sticky xl:top-14 xl:z-10",
    align === "right" && "text-right",
    align === "center" && "text-center",
    corner === "first" && "rounded-tl-2xl",
    corner === "last" && "rounded-tr-2xl"
  );
}

// --- Header kolom biasa -------------------------------------------------------
export function FinTh({
  align,
  corner,
  sticky = true,
  className,
  ...props
}: React.ComponentProps<typeof TableHead> & {
  align?: "left" | "right" | "center";
  corner?: "first" | "last";
  sticky?: boolean;
}) {
  return <TableHead className={cn(finThClass(sticky, align, corner), className)} {...props} />;
}

// --- Header kolom yang bisa diklik untuk mengurutkan --------------------------
export function FinSortTh<T extends string>({
  label,
  k,
  sortKey,
  asc,
  onSort,
  align = "left",
  corner,
  sticky = true,
  className,
}: {
  label: string;
  k: T;
  sortKey: T;
  asc: boolean;
  onSort: (k: T) => void;
  align?: "left" | "right" | "center";
  corner?: "first" | "last";
  sticky?: boolean;
  className?: string;
}) {
  const active = k === sortKey;
  return (
    <TableHead className={cn(finThClass(sticky, align, corner), className)}>
      <button
        type="button"
        onClick={() => onSort(k)}
        aria-label={`Urutkan berdasarkan ${label}`}
        className={cn(
          "flex h-full w-full items-center gap-1 uppercase tracking-[0.08em] transition-colors hover:text-foreground",
          align === "right" && "justify-end",
          align === "center" && "justify-center",
          active ? "text-foreground" : "text-muted-foreground"
        )}
      >
        {label}
        <span aria-hidden className={cn("text-[9px]", active ? "text-primary" : "opacity-0")}>
          {asc ? "▲" : "▼"}
        </span>
      </button>
    </TableHead>
  );
}

// --- Baris data (zebra + hover + klik) ----------------------------------------
export function FinRow({
  zebra,
  muted,
  onClick,
  className,
  ...props
}: React.ComponentProps<"tr"> & {
  zebra?: boolean; // baris ganjil diberi latar selang-seling
  muted?: boolean; // baris nonaktif/void — redup
}) {
  return (
    <tr
      onClick={onClick}
      className={cn(
        "border-b border-border/70 transition-colors last:border-b-0 hover:bg-primary/5",
        zebra && "bg-muted/40",
        onClick && "cursor-pointer",
        muted && "opacity-60",
        className
      )}
      {...props}
    />
  );
}

// --- Sel data standar ----------------------------------------------------------
export function FinTd({ className, ...props }: React.ComponentProps<"td">) {
  return <td className={cn("whitespace-nowrap px-3 py-2 align-middle text-[13px]", className)} {...props} />;
}

// --- Kolom No. urut (#) gaya buku besar ----------------------------------------
export function FinIndexTd({ children, className, ...props }: React.ComponentProps<"td">) {
  return (
    <td
      className={cn(
        "w-10 whitespace-nowrap px-3 py-2 text-center align-middle font-mono text-[11px] text-muted-foreground/70",
        className
      )}
      {...props}
    >
      {children}
    </td>
  );
}

// --- Footer baris total ---------------------------------------------------------
export function FinTfoot({ className, ...props }: React.ComponentProps<"tfoot">) {
  return (
    <tfoot
      className={cn(
        "border-t-2 border-primary/25 bg-muted/60 text-[12px] font-semibold [&>tr]:last:border-b-0",
        className
      )}
      {...props}
    />
  );
}

export function FinFootTd({ className, ...props }: React.ComponentProps<"td">) {
  return (
    <td
      className={cn(
        "whitespace-nowrap px-3 py-2 text-left align-middle text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground",
        className
      )}
      {...props}
    />
  );
}

// --- Chip jumlah data untuk toolbar ----------------------------------------------
export function FinCountChip({ count, unit }: { count: number; unit: string }) {
  return (
    <span className="rounded-md bg-muted px-2 py-1 text-[11px] font-bold tabular-nums text-muted-foreground">
      {count.toLocaleString("id-ID")} {unit}
    </span>
  );
}
