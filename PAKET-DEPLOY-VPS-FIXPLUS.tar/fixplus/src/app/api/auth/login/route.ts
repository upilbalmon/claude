import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashPin, sanitizeUser } from "@/lib/pin-hash";
import { withHeal } from "@/lib/users-guard";
import { autoAbsenMasuk } from "@/lib/drawer";
import {
  isLocked,
  recordFailedAttempt,
  resetAttempts,
  getAttempts,
  getRemainingLockSeconds,
} from "@/lib/login-guard";

const MAX_ATTEMPTS = 5;

// POST /api/auth/login — alur attemptLogin() AppViewModel.kt
// D55 — withHeal: login tetap berfungsi pada database versi lama (kolom
// User hilang otomatis ditambahkan sebelum dicoba ulang) — tanpa ini,
// semua akun tidak bisa masuk dan manajemen pengguna tak terjangkau.
export async function POST(req: NextRequest) {
  try {
    // D55 — body dibaca SEKALI di luar withHeal (body request hanya bisa
    // dibaca sekali; retry cukup mengulang pekerjaan database).
    const { username, pin } = (await req.json().catch(() => ({}))) as {
      username?: string;
      pin?: string;
    };
    return await withHeal(async () => {
      if (!username?.trim() || !pin) {
        return NextResponse.json(
          { status: "ERROR", message: "Username dan password wajib diisi!" },
          { status: 400 }
        );
      }

      if (isLocked(username)) {
        return NextResponse.json({
          status: "LOCKED",
          lockSeconds: getRemainingLockSeconds(username),
          message: `Akun terkunci sementara! Sisa waktu: ${getRemainingLockSeconds(username)} detik`,
        });
      }

      const user = await db.user.findUnique({ where: { username: username.trim() } });
      if (!user) {
        return NextResponse.json({ status: "NOT_FOUND", message: "Username tidak terdaftar!" });
      }

      if (hashPin(pin, user.salt) !== user.pin) {
        recordFailedAttempt(username);
        if (isLocked(username)) {
          return NextResponse.json({
            status: "LOCKED",
            lockSeconds: getRemainingLockSeconds(username),
            message: `Akun terkunci sementara! Sisa waktu: ${getRemainingLockSeconds(username)} detik`,
          });
        }
        const attemptsLeft = Math.max(0, MAX_ATTEMPTS - getAttempts(username));
        return NextResponse.json({
          status: "WRONG_PIN",
          attemptsLeft,
          message: `PIN salah! Sisa percobaan: ${attemptsLeft}`,
        });
      }

      resetAttempts(username);
      await db.auditLog.create({
        data: { action: "LOGIN", details: "Login berhasil", performedBy: user.name },
      });

      // D92 — absen masuk OTOMATIS saat login (jam server WIB). Idempoten:
      // login ulang di hari yang sama tidak menimpa jam masuk pertama.
      // Juga mencakup jalur MUST_CHANGE_PIN di bawah (absen tercatat pada
      // percobaan login pertama, ganti PIN hanya lanjutan sesi).
      await autoAbsenMasuk({ id: user.id, name: user.name });

      if (user.mustChangePin) {
        return NextResponse.json({
          status: "MUST_CHANGE_PIN",
          user: sanitizeUser(user),
          message: "Demi keamanan, Anda wajib mengganti PIN default pada login pertama.",
        });
      }

      return NextResponse.json({
        status: "SUCCESS",
        user: sanitizeUser(user),
        message: `Selamat datang kembali, ${user.name}!`,
      });
    });
  } catch (e) {
    console.error("login error", e);
    return NextResponse.json({ status: "ERROR", message: "Terjadi kesalahan server" }, { status: 500 });
  }
}
