// PinHasher.kt — salt 8 karakter UUID, hash SHA-256(pin+salt) hex
import { createHash, randomUUID } from "crypto";

export function generateSalt(): string {
  return randomUUID().replace(/-/g, "").slice(0, 8);
}

export function hashPin(pin: string, salt: string): string {
  return createHash("sha256").update(pin + salt, "utf8").digest("hex");
}

// Sanitasi user sebelum dikirim ke klien: PIN & salt tidak boleh bocor
export function sanitizeUser<T extends { pin?: string; salt?: string }>(user: T) {
  const { pin: _pin, salt: _salt, ...safe } = user as T & Record<string, unknown>;
  void _pin;
  void _salt;
  return safe;
}
