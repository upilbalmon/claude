import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { resolveActor } from "@/lib/action-guard";
import { isValidPhone } from "@/lib/phone"; // T3 revisi Tahap 2
import { withHeal } from "@/lib/users-guard";

type Params = { params: Promise<{ id: string }> };

// D71 — edit/hapus profil teknisi. Edit kini HANYA Admin (guard server-side;
// sebelumnya semua peran bisa mengubah). Hapus tetap Admin (D34).
// Nama profil yang TERTAUT akun Pengguna tidak boleh diubah di sini — nama
// mengikuti akun; ubah lewat halaman Pengguna agar keduanya tetap sinkron
// (poin kinerja teknisi dicocokkan dari nama tiket ↔ nama akun).

// Cari akun Pengguna role Teknisi dengan nama sama (abaikan besar-kecil) yang
// belum tertaut ke profil manapun — untuk taut otomatis profil ↔ akun.
async function findUnlinkedTeknisiUser(name: string) {
  const candidates = await db.user.findMany({
    where: { role: "Teknisi" },
    select: { id: true, name: true, username: true },
  });
  const lower = name.trim().toLowerCase();
  for (const u of candidates) {
    if (u.name.trim().toLowerCase() !== lower) continue;
    const taken = await db.technician.findFirst({ where: { userId: u.id } });
    if (!taken) return u;
  }
  return null;
}

// D71 — tolak nama teknisi dobel (abaikan besar-kecil): satu orang satu entri.
async function findSameNameTechnician(name: string, excludeId?: number) {
  const all = await db.technician.findMany({ select: { id: true, name: true } });
  const lower = name.trim().toLowerCase();
  return (
    all.find((t) => t.name.trim().toLowerCase() === lower && t.id !== excludeId) ?? null
  );
}

// PUT /api/technicians/[id] — edit telepon/ketersediaan (HANYA Admin, D71).
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return NextResponse.json({ error: "ID tidak valid" }, { status: 400 });
    }
    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
    const actor = await resolveActor(body.requesterUsername);
    if (!actor) {
      return NextResponse.json({ error: "Hanya Admin yang dapat mengubah teknisi" }, { status: 403 });
    }
    return await withHeal(async () => {
      const existing = await db.technician.findUnique({ where: { id } });
      if (!existing) {
        return NextResponse.json({ error: "Teknisi tidak ditemukan" }, { status: 404 });
      }

      const name = String(body.name ?? "").trim();
      if (!name) {
        return NextResponse.json({ error: "Nama teknisi wajib diisi" }, { status: 400 });
      }
      // Nama profil tertaut akun = nama akun — jangan biarkan melenceng.
      if (existing.userId && name !== existing.name) {
        return NextResponse.json(
          {
            error:
              "Nama teknisi ini tertaut akun pengguna — ubah nama lewat halaman Pengguna (Setting → Pengguna) agar keduanya tetap sinkron.",
          },
          { status: 400 }
        );
      }
      // Nama baru tidak boleh dobel dengan teknisi lain.
      const dobel = await findSameNameTechnician(name, existing.id);
      if (dobel) {
        return NextResponse.json(
          { error: `Nama "${name}" sudah dipakai teknisi "${dobel.name}" — satu orang cukup satu entri` },
          { status: 409 }
        );
      }
      // T3 (revisi Tahap 2): telepon opsional — divalidasi hanya bila diisi.
      const phone = String(body.phone ?? "").trim();
      if (phone && !isValidPhone(phone)) {
        return NextResponse.json(
          { error: "Nomor telepon teknisi tidak valid — kosongkan atau isi 9–15 digit angka" },
          { status: 400 }
        );
      }

      // Profil belum tertaut & ada akun Teknisi bernama sama → taut otomatis.
      let userId = existing.userId;
      let linkedNote = "";
      if (!userId) {
        const linkUser = await findUnlinkedTeknisiUser(name);
        if (linkUser) {
          userId = linkUser.id;
          linkedNote = ` — tertaut akun ${linkUser.username}`;
        }
      }

      const technician = await db.technician.update({
        where: { id },
        data: {
          name,
          phone,
          isAvailable: body.isAvailable === undefined ? existing.isAvailable : Boolean(body.isAvailable),
          userId,
        },
        include: { user: { select: { username: true } } },
      });

      await db.auditLog.create({
        data: {
          action: "EDIT_TEKNISI",
          details: `${technician.name} (${technician.isAvailable ? "Tersedia" : "Tidak Tersedia"})${linkedNote}`,
          performedBy: actor.name,
        },
      });

      return NextResponse.json({
        ...technician,
        accountUsername: technician.user?.username ?? null,
      });
    });
  } catch (e) {
    console.error("technicians PUT error", e);
    return NextResponse.json({ error: "Gagal mengubah teknisi" }, { status: 500 });
  }
}

// DELETE /api/technicians/[id]?requesterUsername=… — hapus teknisi (ala deleteTechnician;
// teks audit persis AppViewModel.kt: "Menghapus teknisi: <nama> (Phone: <telepon>)")
// D34: hapus data = hanya Admin (aturan 4), diverifikasi server.
// Catatan D71: tiket yang pernah ditangani tetap menyimpan snapshot
// technicianName — laporan & poin kinerja tidak hilang.
export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return NextResponse.json({ error: "ID tidak valid" }, { status: 400 });
    }
    const actor = await resolveActor(req.nextUrl.searchParams.get("requesterUsername"));
    if (!actor) {
      return NextResponse.json({ error: "Hanya Admin yang dapat menghapus data" }, { status: 403 });
    }
    return await withHeal(async () => {
      const existing = await db.technician.findUnique({ where: { id } });
      if (!existing) {
        return NextResponse.json({ error: "Teknisi tidak ditemukan" }, { status: 404 });
      }

      await db.technician.delete({ where: { id } });
      await db.auditLog.create({
        data: {
          action: "HAPUS_TEKNISI",
          details: `Menghapus teknisi: ${existing.name} (Phone: ${existing.phone})${existing.userId ? " — akun penggunanya tetap ada" : ""}`,
          performedBy: actor.name,
        },
      });

      return NextResponse.json({ ok: true });
    });
  } catch (e) {
    console.error("technicians DELETE error", e);
    return NextResponse.json({ error: "Gagal menghapus teknisi" }, { status: 500 });
  }
}
