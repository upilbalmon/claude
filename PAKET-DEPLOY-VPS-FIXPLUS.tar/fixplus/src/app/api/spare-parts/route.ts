import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { saranSku, skuUnik } from "@/lib/sku-utils";
import { spareCategoryOf } from "@/lib/spare-category";

// GET /api/spare-parts — daftar semua sparepart (urut nama, ala repository.allSpareParts)
export async function GET() {
  try {
    const parts = await db.sparePart.findMany({ orderBy: { name: "asc" } });
    return NextResponse.json(parts);
  } catch (e) {
    console.error("spare-parts GET error", e);
    return NextResponse.json({ error: "Gagal memuat sparepart" }, { status: 500 });
  }
}

// POST /api/spare-parts — simpan sparepart baru (ala saveSparePart id=0)
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const name = String(body.name ?? "").trim();
    if (!name) {
      return NextResponse.json({ error: "Nama sparepart wajib diisi" }, { status: 400 });
    }

    // T4 (revisi Tahap 2): SKU wajib unik antar-part (banding aba besar-kecil).
    // D22: SKU KOSONG → diisi otomatis mengikuti pola data yang sudah ada
    // (PREFIX-SINGKATAN, contoh LCD-A14) + anti-tabrakan -2/-3 — tetap bisa
    // diubah manual lewat form Inventaris.
    const all = await db.sparePart.findMany({ select: { id: true, name: true, sku: true } });
    const skuInput = String(body.sku ?? "").trim();
    let sku = skuInput;
    if (sku) {
      const dup = all.find((p) => p.sku.trim().toLowerCase() === sku.toLowerCase());
      if (dup) {
        return NextResponse.json(
          { error: `SKU "${sku}" sudah dipakai oleh sparepart "${dup.name}"` },
          { status: 409 }
        );
      }
    } else {
      sku = skuUnik(saranSku(name), all.map((p) => p.sku));
    }

    // D23 (D18/D19): "Nama di Struk / Nota" — alias opsional; kosong → null
    // (struk mencetak alias ?? nama).
    const alias = String(body.alias ?? "").trim();

    const part = await db.sparePart.create({
      data: {
        name,
        alias: alias === "" ? null : alias,
        sku,
        stock: toInt(body.stock, 0),
        minStock: toInt(body.minStock, 5), // default Entities.kt: minStock = 5
        costPrice: toNum(body.costPrice, 0),
        sellPrice: toNum(body.sellPrice, 0),
        location: String(body.location ?? "").trim(),
        // D48/5C-1.1: kategori barang (whitelist server, default SPAREPART)
        category: spareCategoryOf(body.category),
      },
    });

    await db.auditLog.create({
      data: {
        action: "TAMBAH_SPAREPART",
        details: `${part.name} (stok ${part.stock})`,
        performedBy: String(body.performedBy ?? "Tidak diketahui"),
      },
    });

    return NextResponse.json(part, { status: 201 });
  } catch (e) {
    console.error("spare-parts POST error", e);
    return NextResponse.json({ error: "Gagal menyimpan sparepart" }, { status: 500 });
  }
}

function toInt(v: unknown, fallback: number): number {
  const n = Math.trunc(Number(v));
  return Number.isFinite(n) && n >= 0 ? n : fallback;
}

function toNum(v: unknown, fallback: number): number {
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 ? n : fallback;
}
