import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { backupStats } from "@/lib/db-backup";

// D40 — GET /api/database/stats?requesterUsername=...
// Statistik jumlah data per tabel (parity "Statistik Data Database" referensi).
// Admin-only: angka tabel pengguna & audit log tidak untuk kasa umum.
export async function GET(req: NextRequest) {
  const actor = await resolveActor(req.nextUrl.searchParams.get("requesterUsername"));
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);
  try {
    const stats = await backupStats();
    return NextResponse.json(stats);
  } catch (e) {
    console.error("database stats error", e);
    return NextResponse.json({ error: "Gagal memuat statistik database" }, { status: 500 });
  }
}
