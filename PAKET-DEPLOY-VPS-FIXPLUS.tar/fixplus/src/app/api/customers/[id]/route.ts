import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { errAction, resolveActor } from "@/lib/action-guard";
import { isValidPhone } from "@/lib/phone"; // T3 revisi Tahap 2

type Params = { params: Promise<{ id: string }> };

// PUT /api/customers/[id] — edit pelanggan (ala saveCustomer id≠0)
export async function PUT(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return NextResponse.json({ error: "ID tidak valid" }, { status: 400 });
    }
    const existing = await db.customer.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Pelanggan tidak ditemukan" }, { status: 404 });
    }

    const body = await req.json();
    const name = String(body.name ?? "").trim();
    const phone = String(body.phone ?? "").trim();
    if (!name) {
      return NextResponse.json({ error: "Nama pelanggan wajib diisi" }, { status: 400 });
    }
    // D52: nomor WA opsional — divalidasi HANYA bila diisi (boleh dikosongkan).
    if (phone && !isValidPhone(phone)) {
      return NextResponse.json(
        { error: "No WhatsApp tidak valid — masukkan 9–15 digit angka (contoh: 08123456789)" },
        { status: 400 }
      );
    }

    const customer = await db.customer.update({
      where: { id },
      data: {
        name,
        phone,
        email: String(body.email ?? "").trim(),
        address: String(body.address ?? "").trim(),
        loyaltyPoints: clampNonNegInt(body.loyaltyPoints, existing.loyaltyPoints),
      },
    });

    await db.auditLog.create({
      data: {
        action: "EDIT_PELANGGAN",
        details: `${customer.name} (poin ${customer.loyaltyPoints})`,
        performedBy: String(body.performedBy ?? "Tidak diketahui"),
      },
    });

    return NextResponse.json(customer);
  } catch (e) {
    console.error("customers PUT error", e);
    return NextResponse.json({ error: "Gagal mengubah pelanggan" }, { status: 500 });
  }
}

// DELETE /api/customers/[id]?requesterUsername=… — hapus pelanggan (ala deleteCustomer;
// teks audit persis AppViewModel.kt: "Menghapus pelanggan: <nama> (Phone: <telepon>)")
// D34: hapus data = hanya Admin (aturan 4 dokumen "Pembatalan transaksi"), server-side.
export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return errAction("ID tidak valid", 400);
    }
    const actor = await resolveActor(req.nextUrl.searchParams.get("requesterUsername"));
    if (!actor) {
      return errAction("Hanya Admin yang dapat menghapus data", 403);
    }
    const existing = await db.customer.findUnique({ where: { id } });
    if (!existing) {
      return errAction("Pelanggan tidak ditemukan", 404);
    }

    await db.customer.delete({ where: { id } });
    await db.auditLog.create({
      data: {
        action: "HAPUS_PELANGGAN",
        details: `Menghapus pelanggan: ${existing.name} (Phone: ${existing.phone})`,
        performedBy: actor.name,
      },
    });

    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("customers DELETE error", e);
    return NextResponse.json({ error: "Gagal menghapus pelanggan" }, { status: 500 });
  }
}

function clampNonNegInt(v: unknown, fallback: number): number {
  const n = Math.trunc(Number(v));
  return Number.isFinite(n) && n >= 0 ? n : fallback;
}
