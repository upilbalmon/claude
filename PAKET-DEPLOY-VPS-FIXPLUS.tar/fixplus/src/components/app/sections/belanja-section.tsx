"use client";

// ============================================================================
// BELANJA — Tahap 6 (D61, 12 Nov 2026): modul pre-order & barang pesanan
//  6.1 Tab PRE-ORDER  : pesanan barang pelanggan + DP
//        Pending → Dipesan → Tiba → Diambil (pelunasan → nota penjualan) / Batal
//  6.2 Tab BARANG PESANAN : catatan barang yang diminta (tiket/pelanggan)
//        Baru → Dipesan → Tersedia (masuk inventaris) / Ditolak
//  6.3 Tab REKOMENDASI BELANJA : saran restock otomatis (stok ≤ min. stok,
//        bisa diabaikan sementara) + daftar belanja pilihan manual
//        (SparePart.isShoppingSelected / shoppingIgnoredUntil — 6.3)
//  6.4 Kaitan pelanggan & tiket servis: form mengaitkan pre-order / barang
//        pesanan ke pelanggan terdaftar & tiket servis; nota Diambil masuk
//        laporan penjualan (kategori item di-snapshot).
// Alur status divalidasi SERVER (src/lib/belanja-utils.ts — satu sumber).
// ============================================================================

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Ban,
  CheckCircle2,
  ClipboardList,
  Download,
  Info,
  MoreVertical,
  PackageCheck,
  PackagePlus,
  PackageSearch,
  Pencil,
  Plus,
  Printer,
  Receipt,
  Search,
  Share2,
  ShoppingCart,
  Trash2,
  TriangleAlert,
  X,
} from "lucide-react";
import { toJpeg } from "html-to-image";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Table, TableBody, TableHeader } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  FinCountChip,
  FinFootTd,
  FinRow,
  FinTd,
  FinTh,
  FinTfoot,
} from "@/components/app/fin-table";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency, formatDate, formatDateTime } from "@/lib/format";
import { cetakNode } from "@/lib/print-helper";
import { SPARE_CATEGORIES, SPARE_CATEGORY_LABEL } from "@/lib/spare-category";
import {
  BELANJA_PAYMENT_METHODS,
  MAX_IGNORE_DAYS,
  PREORDER_STATUS_LABEL,
  PREORDER_STATUS_ORDER,
  REQUESTED_STATUS_LABEL,
  REQUESTED_STATUS_ORDER,
} from "@/lib/belanja-utils";
import { REPAIR_STATUS_LABEL } from "@/lib/app-types";
import type { SafeUser } from "@/lib/app-types";

// ===== tipe respons API =====
export type PreOrderRow = {
  id: number;
  customerId: number | null;
  repairRecordId: number | null;
  transactionId: number | null;
  customerName: string;
  customerPhone: string;
  dp: number;
  itemName: string;
  category: string;
  qty: number;
  estPrice: number;
  status: string;
  cancelReason: string | null;
  notes: string;
  createdAt: string;
  customer: { id: number; name: string; phone: string; loyaltyPoints: number } | null;
  // D63: createdAt ikut dari API — kode tiket SRV-<epoch> memakai tanggal tiket sebenarnya
  repairRecord: { id: number; deviceModel: string; status: string; customerName: string; createdAt: string } | null;
  transaction: { id: number; invoiceNumber: string; grandTotal: number; paymentStatus: string; timestamp: string } | null;
};

export type RequestedRow = {
  id: number;
  customerId: number | null;
  repairRecordId: number | null;
  partId: number | null;
  itemName: string;
  brandOrSpec: string;
  qty: number;
  estPrice: number;
  customerName: string;
  customerPhone: string;
  status: string;
  cancelReason: string | null;
  notes: string;
  createdAt: string;
  customer: { id: number; name: string; phone: string } | null;
  // D63: createdAt tiket ikut dari API (paritas dengan PreOrderRow)
  repairRecord: { id: number; deviceModel: string; status: string; customerName: string; createdAt: string } | null;
  part: { id: number; name: string; sku: string; stock: number } | null;
};

type SparePartRow = {
  id: number;
  name: string;
  sku: string;
  category: string;
  stock: number;
  minStock: number;
  costPrice: number;
  sellPrice: number;
  location: string;
  isShoppingSelected: boolean;
  shoppingIgnoredUntil: string | null;
};

type CustomerLite = { id: number; name: string; phone: string };
type RepairLite = { id: number; createdAt: string; deviceModel: string; status: string; customerName: string; customerId: number | null };

type PreOrderStats = {
  total: number;
  perStatus: Record<string, number>;
  aktif: number;
  dpTertahan: number;
  nilaiAktif: number;
};

type RequestedStats = {
  total: number;
  perStatus: Record<string, number>;
  aktif: number;
  nilaiAktif: number;
};

// kode tiket gaya modul Servis: SRV-<epoch detik createdAt>
function srvCode(repair: { id: number; createdAt: string }): string {
  return `SRV-${Math.floor(new Date(repair.createdAt).getTime() / 1000)}`;
}

// D63 — nomor tanda terima pre-order: PO-<epoch detik createdAt> (satu gaya dengan SRV-)
function preOrderCode(row: { createdAt: string }): string {
  return `PO-${Math.floor(new Date(row.createdAt).getTime() / 1000)}`;
}

// D63 — pengaturan toko untuk struk (pola kasir): diambil dari /api/settings saat dialog dibuka
type ShopSettingsLite = { shopName: string; address: string; phone: string; receiptFooter: string };

// D63 — konversi data URL (base64) → File agar bisa dibagikan via navigator.share (pola kasir D13)
function dataUrlToFile(dataUrl: string, filename: string): File | null {
  try {
    const [meta, b64] = dataUrl.split(",");
    const mime = meta?.match(/:(.*?);/)?.[1] ?? "image/jpeg";
    const bin = atob(b64 ?? "");
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new File([bytes], filename, { type: mime });
  } catch {
    return null;
  }
}

async function apiJson<T = unknown>(url: string, opts?: RequestInit): Promise<T> {
  const res = await fetch(url, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string }).error ?? "Terjadi kesalahan");
  return data as T;
}

// ===== badge status (alur pre-order & barang pesanan) =====
function StatusBadge({ status }: { status: string }) {
  const cls: Record<string, string> = {
    // pre-order
    Pending: "bg-warning/15 text-warning hover:bg-warning/20",
    Dipesan: "bg-primary/15 text-primary hover:bg-primary/20",
    Tiba: "bg-success/15 text-success hover:bg-success/20",
    Diambil: "bg-success/15 text-success hover:bg-success/20",
    Batal: "bg-destructive/15 text-destructive hover:bg-destructive/20",
    // barang pesanan
    Baru: "bg-warning/15 text-warning hover:bg-warning/20",
    Tersedia: "bg-success/15 text-success hover:bg-success/20",
    Ditolak: "bg-destructive/15 text-destructive hover:bg-destructive/20",
  };
  const icon =
    status === "Diambil" || status === "Tersedia" ? (
      <CheckCircle2 className="size-3" aria-hidden />
    ) : status === "Batal" || status === "Ditolak" ? (
      <Ban className="size-3" aria-hidden />
    ) : null;
  const label = PREORDER_STATUS_LABEL[status] ?? REQUESTED_STATUS_LABEL[status] ?? status;
  return (
    <Badge className={"gap-1 rounded-lg " + (cls[status] ?? "")}>
      {icon}
      {label}
    </Badge>
  );
}

function StatChip({ label, value, tone }: { label: string; value: string; tone?: "warning" | "primary" | "success" | "destructive" }) {
  const cls =
    tone === "warning"
      ? "text-warning"
      : tone === "primary"
        ? "text-primary"
        : tone === "success"
          ? "text-success"
          : tone === "destructive"
            ? "text-destructive"
            : "";
  return (
    <div className="rounded-xl border bg-card px-3 py-2 shadow-sm">
      <p className="text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className={"text-sm font-extrabold tabular-nums " + cls}>{value}</p>
    </div>
  );
}

// ============================================================================
// TAB 6.1 — PRE-ORDER
// ============================================================================
function PreOrderTab({
  user,
  rows,
  stats,
  customers,
  repairs,
  onRefresh,
}: {
  user: SafeUser;
  rows: PreOrderRow[];
  stats: PreOrderStats | null;
  customers: CustomerLite[];
  repairs: RepairLite[];
  onRefresh: () => Promise<void>;
}) {
  const { toast } = useToast();
  const isAdmin = user.role === "Admin";
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("Semua");
  const [saving, setSaving] = useState(false);

  // dialog state
  const [formOpen, setFormOpen] = useState(false);
  const [editRow, setEditRow] = useState<PreOrderRow | null>(null);
  const [tibaRow, setTibaRow] = useState<PreOrderRow | null>(null);
  const [ambilRow, setAmbilRow] = useState<PreOrderRow | null>(null);
  const [batalRow, setBatalRow] = useState<PreOrderRow | null>(null);
  const [deleteRow, setDeleteRow] = useState<PreOrderRow | null>(null);
  const [detailRow, setDetailRow] = useState<PreOrderRow | null>(null);
  // D63: struk tanda terima pre-order — dibuka otomatis setelah pesanan dicatat,
  // atau manual via menu dropdown / tombol di dialog detail.
  const [receiptRow, setReceiptRow] = useState<PreOrderRow | null>(null);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((r) => {
      if (statusFilter !== "Semua" && r.status !== statusFilter) return false;
      if (!q) return true;
      return (
        r.customerName.toLowerCase().includes(q) ||
        r.customerPhone.includes(q) ||
        r.itemName.toLowerCase().includes(q)
      );
    });
  }, [rows, search, statusFilter]);

  async function patch(id: number, body: Record<string, unknown>, okMsg: string) {
    setSaving(true);
    try {
      await apiJson(`/api/pre-orders/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...body, performedBy: user.name }),
      });
      toast({ title: okMsg });
      setTibaRow(null);
      setBatalRow(null);
      setAmbilRow(null);
      await onRefresh();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Gagal memperbarui pre-order", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    if (!deleteRow) return;
    try {
      await apiJson(
        `/api/pre-orders/${deleteRow.id}?requesterUsername=${encodeURIComponent(user.username)}`,
        { method: "DELETE" }
      );
      toast({ title: `Pre-order "${deleteRow.itemName}" dihapus` });
      setDeleteRow(null);
      await onRefresh();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Gagal menghapus pre-order", variant: "destructive" });
    }
  }

  return (
    <div className="space-y-4" data-testid="panel-belanja-preorder">
      {/* kartu ringkasan */}
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
        <StatChip label="Pesanan Aktif" value={String(stats?.aktif ?? 0)} tone="primary" />
        <StatChip label="DP Tertahan" value={formatCurrency(stats?.dpTertahan ?? 0)} tone="warning" />
        <StatChip label="Nilai Aktif" value={formatCurrency(stats?.nilaiAktif ?? 0)} />
        <StatChip label="Siap Diambil (Tiba)" value={String(stats?.perStatus?.Tiba ?? 0)} tone="success" />
        <StatChip label="Selesai / Batal" value={`${stats?.perStatus?.Diambil ?? 0} / ${stats?.perStatus?.Batal ?? 0}`} />
      </div>

      {/* toolbar */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="me-auto flex items-center gap-2">
          <h2 className="text-base font-extrabold text-primary">Pre-Order Pelanggan</h2>
          <FinCountChip count={filtered.length} unit="pesanan" />
        </div>
        <div className="relative w-full sm:w-60">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari pelanggan / barang…"
            className="h-9 rounded-xl pl-8 pr-8"
            aria-label="Cari pre-order"
          />
          {search && (
            <button
              type="button"
              onClick={() => setSearch("")}
              aria-label="Bersihkan pencarian"
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-muted-foreground hover:text-foreground"
            >
              <X className="size-4" aria-hidden />
            </button>
          )}
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="h-9 w-[150px] rounded-xl" aria-label="Filter status pre-order">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Semua">Semua Status</SelectItem>
            {PREORDER_STATUS_ORDER.map((s) => (
              <SelectItem key={s} value={s}>
                {PREORDER_STATUS_LABEL[s]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button
          size="sm"
          className="h-9 rounded-xl"
          onClick={() => {
            setEditRow(null);
            setFormOpen(true);
          }}
        >
          <Plus className="size-4" aria-hidden /> Pre-Order Baru
        </Button>
      </div>

      {/* daftar */}
      {rows.length === 0 ? (
        <Card className="rounded-2xl">
          <CardContent className="py-10 text-center">
            <ClipboardList className="mx-auto mb-2 size-8 text-muted-foreground" aria-hidden />
            <p className="text-sm text-muted-foreground">
              Belum ada pre-order. Tekan “Pre-Order Baru” untuk mencatat pesanan pelanggan + DP.
            </p>
          </CardContent>
        </Card>
      ) : filtered.length === 0 ? (
        <p className="py-8 text-center text-sm text-muted-foreground">Tidak ada pre-order yang cocok.</p>
      ) : (
        <div className="overflow-x-auto rounded-2xl border bg-card shadow-sm xl:overflow-x-visible">
          <Table>
            <TableHeader className="[&_tr]:border-b-0">
              <tr>
                <FinTh corner="first" align="center" className="w-10">#</FinTh>
                <FinTh>Dibuat</FinTh>
                <FinTh>Pelanggan</FinTh>
                <FinTh>Barang</FinTh>
                <FinTh align="right">Est. Total</FinTh>
                <FinTh align="right">DP</FinTh>
                <FinTh align="center">Status</FinTh>
                <FinTh align="center" corner="last">Aksi</FinTh>
              </tr>
            </TableHeader>
            <TableBody>
              {filtered.map((r, i) => {
                const estTotal = r.estPrice * r.qty;
                return (
                  <FinRow key={r.id} zebra={i % 2 === 1} onClick={() => setDetailRow(r)}>
                    <FinTd className="text-center font-mono text-[11px] text-muted-foreground/70">{i + 1}</FinTd>
                    <FinTd className="text-muted-foreground">{formatDate(r.createdAt)}</FinTd>
                    <FinTd>
                      <span className="font-bold">{r.customerName}</span>
                      {r.customerPhone && (
                        <p className="text-[11px] font-normal font-mono text-muted-foreground">{r.customerPhone}</p>
                      )}
                      {r.repairRecord && (
                        <p className="text-[11px] font-normal text-primary">
                          Tiket {srvCode(r.repairRecord)} · {r.repairRecord.deviceModel}
                        </p>
                      )}
                    </FinTd>
                    <FinTd>
                      <span className="font-bold">{r.itemName}</span> <span className="text-muted-foreground">×{r.qty}</span>
                      <p className="text-[11px] font-normal text-muted-foreground">
                        {SPARE_CATEGORY_LABEL[r.category] ?? r.category}
                        {r.transaction && r.transaction.invoiceNumber ? ` · Nota ${r.transaction.invoiceNumber}` : ""}
                      </p>
                    </FinTd>
                    <FinTd className="text-right tabular-nums">{formatCurrency(estTotal)}</FinTd>
                    <FinTd className="text-right tabular-nums text-warning">
                      {r.dp > 0 ? formatCurrency(r.dp) : "—"}
                    </FinTd>
                    <FinTd className="text-center">
                      <StatusBadge status={r.status} />
                    </FinTd>
                    <FinTd className="text-center" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-center gap-1">
                        {r.status === "Pending" && (
                          <Button size="sm" variant="outline" className="h-8 rounded-lg text-xs" disabled={saving}
                            onClick={() => patch(r.id, { action: "status", status: "Dipesan" }, "Pesanan diteruskan ke pemasok (Dipesan)")}>
                            Pesan
                          </Button>
                        )}
                        {r.status === "Dipesan" && (
                          <Button size="sm" variant="outline" className="h-8 rounded-lg text-xs" disabled={saving}
                            onClick={() => setTibaRow(r)}>
                            Tiba
                          </Button>
                        )}
                        {r.status === "Tiba" && (
                          <Button size="sm" className="h-8 rounded-lg text-xs" disabled={saving}
                            onClick={() => setAmbilRow(r)}>
                            <PackageCheck className="size-3.5" aria-hidden /> Diambil
                          </Button>
                        )}
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button size="icon" variant="ghost" className="size-8 rounded-lg" aria-label={`Menu aksi pre-order ${r.itemName}`}>
                              <MoreVertical className="size-4" aria-hidden />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => setDetailRow(r)}>
                              <Info className="size-4" aria-hidden /> Detail
                            </DropdownMenuItem>
                            {/* D63: tanda terima untuk pesanan aktif — Diambil sudah punya nota
                                penjualan (struk di Kasir), Batal tidak butuh bukti pesanan */}
                            {r.status !== "Diambil" && r.status !== "Batal" && (
                              <DropdownMenuItem onClick={() => setReceiptRow(r)}>
                                <Receipt className="size-4" aria-hidden /> Tanda Terima
                              </DropdownMenuItem>
                            )}
                            {(r.status === "Pending" || r.status === "Dipesan") && (
                              <DropdownMenuItem
                                onClick={() => {
                                  setEditRow(r);
                                  setFormOpen(true);
                                }}
                              >
                                <Pencil className="size-4" aria-hidden /> Edit
                              </DropdownMenuItem>
                            )}
                            {r.status !== "Diambil" && r.status !== "Batal" && (
                              <>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem onClick={() => setBatalRow(r)} className="text-destructive focus:text-destructive">
                                  <Ban className="size-4" aria-hidden /> Batalkan
                                </DropdownMenuItem>
                              </>
                            )}
                            {isAdmin && r.status === "Batal" && (
                              <>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem onClick={() => setDeleteRow(r)} className="text-destructive focus:text-destructive">
                                  <Trash2 className="size-4" aria-hidden /> Hapus
                                </DropdownMenuItem>
                              </>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </FinTd>
                  </FinRow>
                );
              })}
            </TableBody>
            <FinTfoot>
              <tr>
                <FinFootTd colSpan={4}>Total {filtered.length} pesanan tampil</FinFootTd>
                <FinFootTd className="text-right normal-case tracking-normal tabular-nums">
                  {formatCurrency(filtered.reduce((n, r) => n + r.estPrice * r.qty, 0))}
                </FinFootTd>
                <FinFootTd className="text-right normal-case tracking-normal tabular-nums text-warning">
                  {formatCurrency(filtered.reduce((n, r) => n + r.dp, 0))}
                </FinFootTd>
                <FinFootTd colSpan={2} aria-hidden />
              </tr>
            </FinTfoot>
          </Table>
        </div>
      )}

      {/* dialog form buat/edit */}
      <PreOrderFormDialog
        user={user}
        open={formOpen}
        edit={editRow}
        customers={customers}
        repairs={repairs}
        onOpenChange={(v) => {
          setFormOpen(v);
          if (!v) setEditRow(null);
        }}
        // D63: bila barusan MENCIPTAKAN pre-order → struk tanda terima langsung dibuka
        onSaved={async (created) => {
          setFormOpen(false);
          setEditRow(null);
          await onRefresh();
          if (created) setReceiptRow(created);
        }}
      />

      {/* dialog Tiba (harga final opsional) */}
      <TibaDialog
        key={tibaRow ? `tiba-${tibaRow.id}` : "none"}
        row={tibaRow}
        saving={saving}
        onOpenChange={(v) => !v && setTibaRow(null)}
        onConfirm={(finalEstPrice) =>
          tibaRow && patch(tibaRow.id, { action: "status", status: "Tiba", ...(finalEstPrice !== "" ? { finalEstPrice } : {}) }, "Barang dinyatakan Tiba")
        }
      />

      {/* dialog Diambil (pelunasan → nota) */}
      <AmbilDialog
        key={ambilRow ? `ambil-${ambilRow.id}` : "none"}
        row={ambilRow}
        saving={saving}
        onOpenChange={(v) => !v && setAmbilRow(null)}
        onConfirm={(paymentMethod, paidNow) =>
          ambilRow &&
          patch(
            ambilRow.id,
            { action: "status", status: "Diambil", paymentMethod, paidNow },
            `Pelunasan tersimpan — nota penjualan dibuat`
          )
        }
      />

      {/* dialog Batal */}
      <BatalDialog
        key={batalRow ? `batal-${batalRow.id}` : "none"}
        row={batalRow}
        saving={saving}
        kind="preorder"
        onOpenChange={(v) => !v && setBatalRow(null)}
        onConfirm={(reason) => batalRow && patch(batalRow.id, { action: "status", status: "Batal", reason }, "Pre-order dibatalkan")}
      />

      {/* dialog hapus (Admin) */}
      <Dialog open={!!deleteRow} onOpenChange={(v) => !v && setDeleteRow(null)}>
        <DialogContent className="rounded-2xl sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Hapus Pre-Order?</DialogTitle>
            <DialogDescription>
              {deleteRow && (
                <>
                  Catatan “{deleteRow.itemName} ×{deleteRow.qty} — {deleteRow.customerName}” akan dihapus permanen.
                </>
              )}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteRow(null)}>Batal</Button>
            <Button variant="destructive" onClick={confirmDelete}>Hapus</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* dialog detail */}
      <Dialog open={!!detailRow} onOpenChange={(v) => !v && setDetailRow(null)}>
        <DialogContent className="max-h-[92vh] overflow-y-auto rounded-2xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Detail Pre-Order</DialogTitle>
            <DialogDescription>Ringkasan pesanan, DP, dan nota penjualannya.</DialogDescription>
          </DialogHeader>
          {detailRow && (
            <div className="space-y-1 rounded-xl border p-3 text-[13px]">
              <DetailLine k="Barang" v={`${detailRow.itemName} ×${detailRow.qty}`} />
              <DetailLine k="Kategori" v={SPARE_CATEGORY_LABEL[detailRow.category] ?? detailRow.category} />
              <DetailLine k="Pelanggan" v={`${detailRow.customerName}${detailRow.customerPhone ? ` · ${detailRow.customerPhone}` : ""}`} />
              {detailRow.customer && <DetailLine k="Terdaftar" v={`${detailRow.customer.name} (poin ${detailRow.customer.loyaltyPoints})`} />}
              {detailRow.repairRecord && (
                <DetailLine k="Tiket Servis" v={`${srvCode(detailRow.repairRecord)} · ${detailRow.repairRecord.deviceModel}`} />
              )}
              <DetailLine k="Estimasi Total" v={formatCurrency(detailRow.estPrice * detailRow.qty)} />
              <DetailLine k="DP Diterima" v={detailRow.dp > 0 ? formatCurrency(detailRow.dp) : "—"} />
              <DetailLine k="Sisa Saat Diambil" v={formatCurrency(Math.max(0, detailRow.estPrice * detailRow.qty - detailRow.dp))} />
              <DetailLine k="Status" v={PREORDER_STATUS_LABEL[detailRow.status] ?? detailRow.status} />
              {detailRow.notes && <DetailLine k="Catatan" v={detailRow.notes} />}
              {detailRow.cancelReason && <DetailLine k="Alasan Batal" v={detailRow.cancelReason} />}
              {detailRow.transaction && (
                <>
                  <DetailLine k="Nota Penjualan" v={detailRow.transaction.invoiceNumber} />
                  <DetailLine k="Waktu Nota" v={formatDateTime(detailRow.transaction.timestamp)} />
                </>
              )}
              <DetailLine k="Dibuat" v={formatDateTime(detailRow.createdAt)} />
            </div>
          )}
          {/* D63: buka tanda terima dari detail — hanya pesanan aktif (Diambil = nota, Batal = tak ada bukti) */}
          <DialogFooter className="mt-1">
            {detailRow && detailRow.status !== "Diambil" && detailRow.status !== "Batal" && (
              <Button variant="outline" className="rounded-xl" onClick={() => setReceiptRow(detailRow)}>
                <Receipt className="size-4" aria-hidden /> Tanda Terima
              </Button>
            )}
            <Button variant="outline" className="rounded-xl" onClick={() => setDetailRow(null)}>
              Tutup
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* dialog struk tanda terima pre-order (D63) — cetak 58mm / JPG / bagikan */}
      <PreOrderStrukDialog
        key={receiptRow ? `struk-${receiptRow.id}` : "none"}
        row={receiptRow}
        user={user}
        onOpenChange={(v) => !v && setReceiptRow(null)}
      />
    </div>
  );
}

function DetailLine({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between gap-3">
      <span className="shrink-0 text-muted-foreground">{k}</span>
      <b className="min-w-0 break-words text-right">{v}</b>
    </div>
  );
}

// form buat/edit pre-order — kaitan pelanggan & tiket servis (6.4)
function PreOrderFormDialog({
  user,
  open,
  edit,
  customers,
  repairs,
  onOpenChange,
  onSaved,
}: {
  user: SafeUser;
  open: boolean;
  edit: PreOrderRow | null;
  customers: CustomerLite[];
  repairs: RepairLite[];
  onOpenChange: (v: boolean) => void;
  // D63: bila menyimpan pre-order BARU, responsnya diteruskan agar struk tanda terima
  // langsung dibuka oleh pemanggil (edit tidak meneruskan apa pun).
  onSaved: (created?: PreOrderRow) => Promise<void>;
}) {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [customerPick, setCustomerPick] = useState<string>(edit?.customerId ? String(edit.customerId) : "manual");
  const [name, setName] = useState(edit?.customerName ?? "");
  const [phone, setPhone] = useState(edit?.customerPhone ?? "");
  const [itemName, setItemName] = useState(edit?.itemName ?? "");
  const [category, setCategory] = useState<string>(edit?.category ?? "SPAREPART");
  const [qty, setQty] = useState(String(edit?.qty ?? 1));
  const [estPrice, setEstPrice] = useState(String(edit?.estPrice ?? ""));
  const [dp, setDp] = useState(String(edit?.dp ?? ""));
  const [repairPick, setRepairPick] = useState<string>(edit?.repairRecordId ? String(edit.repairRecordId) : "none");
  const [notes, setNotes] = useState(edit?.notes ?? "");

  // ganti pelanggan terdaftar → isi nama/telepon otomatis (bisa ditimpa manual)
  function pickCustomer(v: string) {
    setCustomerPick(v);
    if (v === "manual") return;
    const c = customers.find((x) => String(x.id) === v);
    if (c) {
      setName(c.name);
      setPhone(c.phone);
    }
  }

  async function save() {
    if (!itemName.trim()) {
      toast({ title: "Nama barang wajib diisi!", variant: "destructive" });
      return;
    }
    if (!name.trim()) {
      toast({ title: "Nama pelanggan wajib diisi!", variant: "destructive" });
      return;
    }
    const estNum = Number(estPrice) || 0;
    const dpNum = Number(dp) || 0;
    const qtyNum = Math.max(1, Math.trunc(Number(qty) || 1));
    if (estNum > 0 && dpNum > estNum * qtyNum) {
      toast({ title: "DP tidak boleh melebihi estimasi total!", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const body = {
        customerName: name.trim(),
        customerPhone: phone.trim(),
        customerId: customerPick !== "manual" ? customerPick : "",
        itemName: itemName.trim(),
        category,
        qty: qtyNum,
        estPrice: estNum,
        dp: dpNum,
        repairRecordId: repairPick !== "none" ? repairPick : "",
        notes: notes.trim(),
        performedBy: user.name,
      };
      if (edit) {
        await apiJson(`/api/pre-orders/${edit.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        toast({ title: "Pre-order diperbarui" });
        await onSaved();
      } else {
        const created = await apiJson<PreOrderRow>("/api/pre-orders", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        toast({ title: `Pre-order "${body.itemName}" dicatat (Pending)` });
        await onSaved(created);
      }
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Gagal menyimpan pre-order", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  const estTotal = (Number(estPrice) || 0) * (Math.trunc(Number(qty) || 1));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-2xl sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{edit ? "Edit Pre-Order" : "Pre-Order Baru"}</DialogTitle>
          <DialogDescription>
            Pesanan barang yang belum ada di toko. DP dicatat di sini; pelunasan otomatis membuat nota saat barang diambil.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="space-y-1 sm:col-span-2">
              <Label>Pelanggan Terdaftar (opsional)</Label>
              <Select value={customerPick} onValueChange={pickCustomer}>
                <SelectTrigger aria-label="Pilih pelanggan terdaftar">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="max-h-56">
                  <SelectItem value="manual">Tanpa terdaftar (isi manual)</SelectItem>
                  {customers.map((c) => (
                    <SelectItem key={c.id} value={String(c.id)}>
                      {c.name} — {c.phone || "tanpa nomor"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="pre-nama">Nama Pelanggan *</Label>
              <Input id="pre-nama" value={name} onChange={(e) => setName(e.target.value)} placeholder="cth. Budi Santoso" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="pre-wa">No. WhatsApp</Label>
              <Input id="pre-wa" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="08…" inputMode="tel" />
            </div>
            <div className="space-y-1 sm:col-span-2">
              <Label htmlFor="pre-item">Nama Barang *</Label>
              <Input id="pre-item" value={itemName} onChange={(e) => setItemName(e.target.value)} placeholder="cth. LCD iPhone 11 fullset" />
            </div>
            <div className="space-y-1">
              <Label>Kategori Item</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger aria-label="Kategori item pre-order">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SPARE_CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {SPARE_CATEGORY_LABEL[c]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="pre-qty">Jumlah</Label>
              <Input id="pre-qty" value={qty} onChange={(e) => setQty(e.target.value)} inputMode="numeric" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="pre-harga">Perkiraan Harga Satuan</Label>
              <Input id="pre-harga" value={estPrice} onChange={(e) => setEstPrice(e.target.value)} inputMode="numeric" placeholder="0" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="pre-dp">DP Diterima</Label>
              <Input id="pre-dp" value={dp} onChange={(e) => setDp(e.target.value)} inputMode="numeric" placeholder="0" />
            </div>
            <div className="space-y-1 sm:col-span-2">
              <Label>Tiket Servis Terkait (opsional)</Label>
              <Select value={repairPick} onValueChange={setRepairPick}>
                <SelectTrigger aria-label="Pilih tiket servis terkait">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="max-h-56">
                  <SelectItem value="none">Tanpa tiket servis</SelectItem>
                  {repairs.map((r) => (
                    <SelectItem key={r.id} value={String(r.id)}>
                      {srvCode(r)} · {r.deviceModel} · {REPAIR_STATUS_LABEL[r.status] ?? r.status}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1 sm:col-span-2">
              <Label htmlFor="pre-notes">Catatan</Label>
              <Textarea id="pre-notes" value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} />
            </div>
          </div>
          <div className="flex items-center justify-between rounded-xl bg-muted/60 px-3 py-2 text-[13px]">
            <span className="text-muted-foreground">Estimasi total</span>
            <b className="tabular-nums">{formatCurrency(estTotal)}</b>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Batal</Button>
          <Button onClick={save} disabled={saving}>{edit ? "Simpan" : "Catat Pre-Order"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// dialog Tiba — barang datang dari pemasok; harga final boleh diperbarui
function TibaDialog({
  row,
  saving,
  onOpenChange,
  onConfirm,
}: {
  row: PreOrderRow | null;
  saving: boolean;
  onOpenChange: (v: boolean) => void;
  onConfirm: (finalEstPrice: string) => void;
}) {
  const [finalPrice, setFinalPrice] = useState("");
  return (
    <Dialog open={!!row} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-2xl sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Barang Sudah Tiba?</DialogTitle>
          <DialogDescription>
            {row && <>“{row.itemName} ×{row.qty}” dinyatakan tiba dari pemasok.</>}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-1">
          <Label htmlFor="pre-final">Harga Final Satuan (opsional)</Label>
          <Input
            id="pre-final"
            value={finalPrice}
            onChange={(e) => setFinalPrice(e.target.value)}
            inputMode="numeric"
            placeholder={row ? `kosongkan = tetap ${formatCurrency(row.estPrice)}` : "0"}
          />
          <p className="text-[12px] text-muted-foreground">
            Isi bila harga sebenarnya berbeda dari perkiraan — sisa pelunasan dihitung dari harga ini.
          </p>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Batal</Button>
          <Button onClick={() => onConfirm(finalPrice)} disabled={saving}>Tandai Tiba</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// dialog Diambil — pelunasan + nota penjualan otomatis
function AmbilDialog({
  row,
  saving,
  onOpenChange,
  onConfirm,
}: {
  row: PreOrderRow | null;
  saving: boolean;
  onOpenChange: (v: boolean) => void;
  onConfirm: (paymentMethod: string, paidNow: number) => void;
}) {
  const [method, setMethod] = useState<string>("Tunai");
  const [paid, setPaid] = useState(() => (row ? String(Math.max(0, row.estPrice * row.qty - row.dp)) : ""));
  const sisa = row ? Math.max(0, row.estPrice * row.qty - row.dp) : 0;
  const paidNum = Number(paid) || 0;
  const kembalian = Math.max(0, paidNum - sisa);
  return (
    <Dialog open={!!row} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-2xl sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Pelunasan Pre-Order</DialogTitle>
          <DialogDescription>
            Barang diambil pelanggan — sisa tagihan dibayar sekarang dan nota penjualan dibuat otomatis.
          </DialogDescription>
        </DialogHeader>
        {row && (
          <div className="space-y-3">
            <div className="space-y-1 rounded-xl border p-3 text-[13px]">
              <DetailLine k="Barang" v={`${row.itemName} ×${row.qty}`} />
              <DetailLine k="Estimasi Total" v={formatCurrency(row.estPrice * row.qty)} />
              <DetailLine k="DP Diterima" v={formatCurrency(row.dp)} />
              <div className="flex justify-between gap-3 border-t pt-1">
                <span className="shrink-0 font-bold">Sisa</span>
                <b className="tabular-nums text-warning">{formatCurrency(sisa)}</b>
              </div>
            </div>
            <div className="space-y-1">
              <Label>Metode Bayar</Label>
              <Select value={method} onValueChange={setMethod}>
                <SelectTrigger aria-label="Metode bayar pelunasan">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {BELANJA_PAYMENT_METHODS.map((m) => (
                    <SelectItem key={m} value={m}>{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="pre-paid">Uang Diterima</Label>
              <Input id="pre-paid" value={paid} onChange={(e) => setPaid(e.target.value)} inputMode="numeric" />
              {kembalian > 0 && (
                <p className="text-[12px] text-success">Kembalian: {formatCurrency(kembalian)}</p>
              )}
            </div>
            {sisa === 0 && (
              <p className="text-[12px] text-success">DP sudah menutup seluruh tagihan — tidak ada sisa.</p>
            )}
          </div>
        )}
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Batal</Button>
          <Button onClick={() => row && onConfirm(method, paidNum)} disabled={saving}>
            <PackageCheck className="size-4" aria-hidden /> Bayar &amp; Serahkan
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// dialog Batal/Ditolak — alasan wajib
function BatalDialog({
  row,
  saving,
  kind,
  onOpenChange,
  onConfirm,
}: {
  row: PreOrderRow | RequestedRow | null;
  saving: boolean;
  kind: "preorder" | "pesanan";
  onOpenChange: (v: boolean) => void;
  onConfirm: (reason: string) => void;
}) {
  const [reason, setReason] = useState("");
  const dp = row && "dp" in row ? row.dp : 0;
  return (
    <Dialog open={!!row} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-2xl sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>{kind === "preorder" ? "Batalkan Pre-Order?" : "Tolak Barang Pesanan?"}</DialogTitle>
          <DialogDescription>
            {row && (
              <>
                “{row.itemName} ×{row.qty} — {row.customerName || "Umum"}” akan{" "}
                {kind === "preorder" ? "dibatalkan" : "ditolak"}.
              </>
            )}
          </DialogDescription>
        </DialogHeader>
        {dp > 0 && (
          <div className="flex items-start gap-2 rounded-xl border border-warning/40 bg-warning/10 p-3 text-[13px]">
            <TriangleAlert className="mt-0.5 size-4 shrink-0 text-warning" aria-hidden />
            <span>
              DP <b>{formatCurrency(dp)}</b> sudah diterima — kembalikan ke pelanggan secara terpisah (tidak
              otomatis oleh sistem).
            </span>
          </div>
        )}
        <div className="space-y-1">
          <Label htmlFor="batal-reason">Alasan *</Label>
          <Textarea id="batal-reason" value={reason} onChange={(e) => setReason(e.target.value)} rows={2} placeholder="cth. pelanggan membatalkan, barang tidak tersedia…" />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Kembali</Button>
          <Button variant="destructive" onClick={() => onConfirm(reason.trim())} disabled={saving || reason.trim().length < 3}>
            {kind === "preorder" ? "Batalkan" : "Tolak"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================================
// D63 — STRUK TANDA TERIMA PRE-ORDER (58mm — cetak / JPG / bagikan)
// Pola struk kasir (D12–D16): dokumen untuk PELANGGAN → harga angka nyata;
// id #struk-print + gate body.print-struk dipakai ulang dari globals.css
// (named page @page struk58). Belanja & Kasir tidak pernah dirender serentak,
// jadi satu id aman.
// ============================================================================
function PreOrderStrukBody({
  row,
  settings,
  petugas,
}: {
  row: PreOrderRow;
  settings: ShopSettingsLite;
  petugas: string;
}) {
  const estTotal = row.estPrice * row.qty;
  const sisa = Math.max(0, estTotal - row.dp);
  return (
    <div id="struk-print" className="mx-auto w-full max-w-[58mm] bg-white py-2 font-mono text-[11px] leading-relaxed text-black">
      <p className="text-center text-[13px] font-bold uppercase">{settings.shopName}</p>
      {settings.address && <p className="text-center text-[10px] text-gray-700">{settings.address}</p>}
      {settings.phone && <p className="text-center text-[10px] text-gray-700">Telp/WA: {settings.phone}</p>}
      <div className="my-2 border-t border-dashed border-gray-400" />
      <p className="text-center text-[12px] font-bold">TANDA TERIMA PRE-ORDER</p>
      <div className="mt-1.5 space-y-0.5">
        <div className="flex justify-between"><span>No. Pesanan:</span><span>{preOrderCode(row)}</span></div>
        <div className="flex justify-between"><span>Tgl Pesan:</span><span>{formatDateTime(row.createdAt)}</span></div>
        <div className="flex justify-between"><span>Pelanggan:</span><span className="font-bold">{row.customerName}</span></div>
        {row.customerPhone && <div className="flex justify-between"><span>Telp/WA:</span><span>{row.customerPhone}</span></div>}
        {row.repairRecord && <div className="flex justify-between"><span>Tiket Servis:</span><span>{srvCode(row.repairRecord)}</span></div>}
        <div className="flex justify-between"><span>Petugas:</span><span>{petugas}</span></div>
      </div>
      <div className="my-2 border-t border-dashed border-gray-400" />
      <div className="space-y-1">
        <p className="font-bold">{row.itemName}</p>
        <div className="flex justify-between text-[10px] text-gray-700">
          <span>{row.qty} × {estTotal > 0 ? formatCurrency(row.estPrice) : "harga menunggu"}</span>
          <span className="text-[11px] font-bold text-black">{estTotal > 0 ? formatCurrency(estTotal) : "—"}</span>
        </div>
        <p className="text-[10px] text-gray-700">Kategori: {SPARE_CATEGORY_LABEL[row.category] ?? row.category}</p>
        {row.notes && <p className="text-[10px] text-gray-700">Catatan: {row.notes}</p>}
      </div>
      <div className="my-2 border-t border-dashed border-gray-400" />
      <div className="space-y-0.5">
        <div className="flex justify-between"><span>DP Diterima:</span><span className="font-bold">{row.dp > 0 ? formatCurrency(row.dp) : "—"}</span></div>
        <div className="flex justify-between"><span>Sisa Saat Diambil:</span><span>{estTotal > 0 ? formatCurrency(sisa) : "—"}</span></div>
      </div>
      {/* kotak status DP — pelanggan langsung melihat posisi pembayarannya */}
      {row.dp > 0 ? (
        <div className="mt-1.5 border-2 border-black px-2 py-1.5 text-center text-[11px] font-black uppercase leading-snug">
          DP Diterima — Sisa {estTotal > 0 ? formatCurrency(sisa) : "saat diambil"}
        </div>
      ) : (
        <div className="mt-1.5 border-2 border-red-600 px-2 py-1.5 text-center text-[11px] font-black uppercase leading-snug text-red-600">
          Belum Ada DP
        </div>
      )}
      {row.status !== "Pending" && (
        <p className="mt-1.5 text-center text-[10px] font-bold uppercase tracking-wide">
          Status Pesanan: {PREORDER_STATUS_LABEL[row.status] ?? row.status}
        </p>
      )}
      <div className="my-2 border-t border-dashed border-gray-400" />
      <p className="text-center text-[10px] leading-snug">
        Simpan tanda terima ini sebagai bukti pesanan &amp; pembayaran DP.
        Harga akhir mengikuti harga barang saat tiba.
      </p>
      {settings.receiptFooter && <p className="mt-1 text-center text-[10px] font-bold">{settings.receiptFooter}</p>}
    </div>
  );
}

// Dialog struk tanda terima — Unduh JPG / Bagikan / Cetak 58mm
// (pola dialog struk kasir D13–D14: Unduh SELALU ada, Bagikan hanya bila browser
// mendukung share file — umumnya HP; deteksi sekali saat mount anti-hydration-mismatch)
function PreOrderStrukDialog({
  row,
  user,
  onOpenChange,
}: {
  row: PreOrderRow | null;
  user: SafeUser;
  onOpenChange: (v: boolean) => void;
}) {
  const { toast } = useToast();
  const [settings, setSettings] = useState<ShopSettingsLite>({
    shopName: "Servis HP & POS", address: "", phone: "", receiptFooter: "Terima kasih telah berbelanja!",
  });
  const [sharingJpg, setSharingJpg] = useState(false);
  const [canShareFiles, setCanShareFiles] = useState(false);

  useEffect(() => {
    apiJson<ShopSettingsLite>("/api/settings").then(setSettings).catch(() => {});
    try {
      const probe = new File([new Blob([""])], "probe.jpg", { type: "image/jpeg" });
      setCanShareFiles(typeof navigator.share === "function" && !!navigator.canShare?.({ files: [probe] }));
    } catch {
      setCanShareFiles(false);
    }
  }, []);

  function handleCetak() {
    // D16: netralisasi leluhur dialog saat cetak dipusatkan di lib/print-helper.ts
    cetakNode("struk-print", "print-struk");
  }

  async function renderStrukJpg(): Promise<string> {
    const node = document.getElementById("struk-print");
    if (!node) throw new Error("Struk tidak ditemukan");
    return toJpeg(node, {
      quality: 0.95,
      backgroundColor: "#ffffff",
      pixelRatio: 3,
      // margin putih kiri-kanan 12px ala kasir: isi tidak terpotong di tepi JPG
      width: node.clientWidth + 24,
      style: { padding: "0 12px" },
    });
  }

  function unduhDataUrl(dataUrl: string, namaFile: string) {
    const link = document.createElement("a");
    link.href = dataUrl;
    link.download = namaFile;
    link.click();
  }

  async function handleUnduh() {
    if (!row || sharingJpg) return;
    setSharingJpg(true);
    const namaFile = `tanda-terima-${preOrderCode(row)}.jpg`;
    try {
      unduhDataUrl(await renderStrukJpg(), namaFile);
      toast({
        title: "Tanda terima JPG diunduh",
        description: "Bagikan file dari folder Unduhan/Galeri ke pelanggan (WhatsApp, dsb.).",
      });
    } catch (e) {
      console.error("gagal render tanda terima jpg:", e);
      toast({ title: e instanceof Error ? e.message : "Gagal membuat JPG tanda terima", variant: "destructive" });
    } finally {
      setSharingJpg(false);
    }
  }

  async function handleBagikan() {
    if (!row || sharingJpg) return;
    setSharingJpg(true);
    const namaFile = `tanda-terima-${preOrderCode(row)}.jpg`;
    try {
      const dataUrl = await renderStrukJpg();
      const file = dataUrlToFile(dataUrl, namaFile);
      if (file && typeof navigator.share === "function" && navigator.canShare?.({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: `Tanda Terima ${preOrderCode(row)}`,
          text: `Tanda terima pre-order ${row.customerName} - ${settings.shopName}`,
        });
        toast({ title: "Tanda terima dibagikan" });
      } else {
        // Tidak mendukung share file → jatuh ke unduh supaya aksi tetap berhasil
        unduhDataUrl(dataUrl, namaFile);
        toast({
          title: "Bagikan tidak tersedia — JPG diunduh",
          description: "Bagikan file dari folder Unduhan/Galeri ke pelanggan (WhatsApp, dsb.).",
        });
      }
    } catch (e) {
      // User menutup lembar bagikan bawaan → bukan error
      if (e instanceof DOMException && e.name === "AbortError") return;
      console.error("gagal membagikan tanda terima jpg:", e);
      toast({ title: "Gagal membagikan tanda terima", variant: "destructive" });
    } finally {
      setSharingJpg(false);
    }
  }

  return (
    <Dialog open={!!row} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-2xl sm:max-w-sm">
        <DialogHeader className="sr-only">
          <DialogTitle>Tanda Terima Pre-Order</DialogTitle>
          <DialogDescription>
            Struk tanda terima siap dicetak ke printer thermal 58mm atau dibagikan ke pelanggan.
          </DialogDescription>
        </DialogHeader>
        {row && <PreOrderStrukBody row={row} settings={settings} petugas={user.name} />}
        <div className="space-y-2">
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => void handleUnduh()}
              disabled={sharingJpg}
              className="h-11 flex-1 rounded-xl"
            >
              <Download className="size-4" aria-hidden /> {sharingJpg ? "Menyiapkan..." : "Unduh JPG"}
            </Button>
            {canShareFiles && (
              <Button
                variant="outline"
                onClick={() => void handleBagikan()}
                disabled={sharingJpg}
                className="h-11 flex-1 rounded-xl"
              >
                <Share2 className="size-4" aria-hidden /> Bagikan
              </Button>
            )}
          </div>
          <div className="flex gap-2">
            <Button onClick={handleCetak} disabled={sharingJpg} className="h-11 flex-1 rounded-xl">
              <Printer className="size-4" aria-hidden /> Cetak Struk
            </Button>
            <Button variant="outline" onClick={() => onOpenChange(false)} disabled={sharingJpg} className="h-11 flex-1 rounded-xl">
              Tutup
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function BelanjaSection({ user }: { user: SafeUser }) {
  const { toast } = useToast();
  const [preData, setPreData] = useState<{ rows: PreOrderRow[]; stats: PreOrderStats } | null>(null);
  const [reqData, setReqData] = useState<{ rows: RequestedRow[]; stats: RequestedStats } | null>(null);
  const [parts, setParts] = useState<SparePartRow[]>([]);
  const [customers, setCustomers] = useState<CustomerLite[]>([]);
  const [repairs, setRepairs] = useState<RepairLite[]>([]);
  const [loading, setLoading] = useState(true);
  const [reloadKey, setReloadKey] = useState(0);

  const refresh = useCallback(async () => {
    try {
      const [pre, req, sp, cust, rep] = await Promise.all([
        apiJson<{ rows: PreOrderRow[]; stats: PreOrderStats }>("/api/pre-orders"),
        apiJson<{ rows: RequestedRow[]; stats: RequestedStats }>("/api/requested-items"),
        apiJson<SparePartRow[]>("/api/spare-parts"),
        apiJson<CustomerLite[]>("/api/customers"),
        apiJson<RepairLite[]>("/api/repairs"),
      ]);
      setPreData(pre);
      setReqData(req);
      setParts(sp);
      setCustomers(cust);
      // tiket untuk pemilih kaitan: aktif dulu (belum DIAMBIL/DIBATALKAN/TIDAK_BISA), maks 150
      const aktifRepairs = rep
        .filter((r) => !["DIAMBIL", "DIBATALKAN", "TIDAK_BISA"].includes(r.status))
        .slice(0, 150);
      setRepairs(aktifRepairs);
    } catch (e) {
      toast({
        title: e instanceof Error ? e.message : "Gagal memuat data Belanja",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    void refresh();
  }, [reloadKey]);

  const onRefresh = useCallback(async () => {
    setReloadKey((k) => k + 1);
    await refresh();
  }, [refresh]);

  if (loading) {
    return <p className="py-10 text-center text-sm text-muted-foreground">Memuat modul Belanja…</p>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="flex size-10 items-center justify-center rounded-xl bg-primary/10">
          <ShoppingCart className="size-5 text-primary" aria-hidden />
        </div>
        <div>
          <h1 className="text-xl font-bold">Belanja</h1>
          <p className="text-sm text-muted-foreground">
            Pre-Order pelanggan, barang pesanan tiket servis &amp; daftar belanja stok.
          </p>
        </div>
      </div>

      <Tabs defaultValue="preorder">
        <TabsList className="h-10 rounded-xl">
          <TabsTrigger value="preorder" className="gap-1.5 rounded-lg" data-testid="tab-belanja-preorder">
            <ClipboardList className="size-4" aria-hidden /> Pre-Order
          </TabsTrigger>
          <TabsTrigger value="pesanan" className="gap-1.5 rounded-lg" data-testid="tab-belanja-pesanan">
            <PackageSearch className="size-4" aria-hidden /> Barang Pesanan
          </TabsTrigger>
          <TabsTrigger value="rekomendasi" className="gap-1.5 rounded-lg" data-testid="tab-belanja-rekomendasi">
            <ShoppingCart className="size-4" aria-hidden /> Rekomendasi Belanja
          </TabsTrigger>
        </TabsList>
        <TabsContent value="preorder" className="mt-4">
          <PreOrderTab
            user={user}
            rows={preData?.rows ?? []}
            stats={preData?.stats ?? null}
            customers={customers}
            repairs={repairs}
            onRefresh={onRefresh}
          />
        </TabsContent>
        <TabsContent value="pesanan" className="mt-4">
          <PesananTab
            user={user}
            rows={reqData?.rows ?? []}
            stats={reqData?.stats ?? null}
            customers={customers}
            repairs={repairs}
            onRefresh={onRefresh}
          />
        </TabsContent>
        <TabsContent value="rekomendasi" className="mt-4">
          <RekomendasiTab user={user} parts={parts} onRefresh={onRefresh} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ============================================================================
// TAB 6.2 — BARANG PESANAN
// ============================================================================
function PesananTab({
  user,
  rows,
  stats,
  customers,
  repairs,
  onRefresh,
}: {
  user: SafeUser;
  rows: RequestedRow[];
  stats: RequestedStats | null;
  customers: CustomerLite[];
  repairs: RepairLite[];
  onRefresh: () => Promise<void>;
}) {
  const { toast } = useToast();
  const isAdmin = user.role === "Admin";
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("Semua");
  const [saving, setSaving] = useState(false);

  const [formOpen, setFormOpen] = useState(false);
  const [editRow, setEditRow] = useState<RequestedRow | null>(null);
  const [partRow, setPartRow] = useState<RequestedRow | null>(null);
  const [tolakRow, setTolakRow] = useState<RequestedRow | null>(null);
  const [deleteRow, setDeleteRow] = useState<RequestedRow | null>(null);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((r) => {
      if (statusFilter !== "Semua" && r.status !== statusFilter) return false;
      if (!q) return true;
      return (
        r.customerName.toLowerCase().includes(q) ||
        r.customerPhone.includes(q) ||
        r.itemName.toLowerCase().includes(q) ||
        r.brandOrSpec.toLowerCase().includes(q)
      );
    });
  }, [rows, search, statusFilter]);

  async function patch(id: number, body: Record<string, unknown>, okMsg: string) {
    setSaving(true);
    try {
      await apiJson(`/api/requested-items/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...body, performedBy: user.name }),
      });
      toast({ title: okMsg });
      setTolakRow(null);
      await onRefresh();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Gagal memperbarui barang pesanan", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    if (!deleteRow) return;
    try {
      await apiJson(
        `/api/requested-items/${deleteRow.id}?requesterUsername=${encodeURIComponent(user.username)}`,
        { method: "DELETE" }
      );
      toast({ title: `Barang pesanan "${deleteRow.itemName}" dihapus` });
      setDeleteRow(null);
      await onRefresh();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Gagal menghapus barang pesanan", variant: "destructive" });
    }
  }

  return (
    <div className="space-y-4" data-testid="panel-belanja-pesanan">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
        <StatChip label="Belum Diproses (Baru)" value={String(stats?.perStatus?.Baru ?? 0)} tone="warning" />
        <StatChip label="Sudah Dipesan" value={String(stats?.perStatus?.Dipesan ?? 0)} tone="primary" />
        <StatChip label="Tersedia" value={String(stats?.perStatus?.Tersedia ?? 0)} tone="success" />
        <StatChip label="Ditolak" value={String(stats?.perStatus?.Ditolak ?? 0)} tone="destructive" />
        <StatChip label="Perkiraan Belanja Aktif" value={formatCurrency(stats?.nilaiAktif ?? 0)} />
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <div className="me-auto flex items-center gap-2">
          <h2 className="text-base font-extrabold text-primary">Barang Pesanan</h2>
          <FinCountChip count={filtered.length} unit="item" />
        </div>
        <div className="relative w-full sm:w-60">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari barang / pelanggan…"
            className="h-9 rounded-xl pl-8 pr-8"
            aria-label="Cari barang pesanan"
          />
          {search && (
            <button
              type="button"
              onClick={() => setSearch("")}
              aria-label="Bersihkan pencarian"
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-muted-foreground hover:text-foreground"
            >
              <X className="size-4" aria-hidden />
            </button>
          )}
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="h-9 w-[150px] rounded-xl" aria-label="Filter status barang pesanan">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Semua">Semua Status</SelectItem>
            {REQUESTED_STATUS_ORDER.map((s) => (
              <SelectItem key={s} value={s}>
                {REQUESTED_STATUS_LABEL[s]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button
          size="sm"
          className="h-9 rounded-xl"
          onClick={() => {
            setEditRow(null);
            setFormOpen(true);
          }}
        >
          <Plus className="size-4" aria-hidden /> Catat Barang
        </Button>
      </div>

      {rows.length === 0 ? (
        <Card className="rounded-2xl">
          <CardContent className="py-10 text-center">
            <PackageSearch className="mx-auto mb-2 size-8 text-muted-foreground" aria-hidden />
            <p className="text-sm text-muted-foreground">
              Belum ada barang pesanan. Catat permintaan pelanggan/barang tiket servis yang belum ada di katalog.
            </p>
          </CardContent>
        </Card>
      ) : filtered.length === 0 ? (
        <p className="py-8 text-center text-sm text-muted-foreground">Tidak ada barang pesanan yang cocok.</p>
      ) : (
        <div className="overflow-x-auto rounded-2xl border bg-card shadow-sm xl:overflow-x-visible">
          <Table>
            <TableHeader className="[&_tr]:border-b-0">
              <tr>
                <FinTh corner="first" align="center" className="w-10">#</FinTh>
                <FinTh>Dibuat</FinTh>
                <FinTh>Barang</FinTh>
                <FinTh align="right">Qty</FinTh>
                <FinTh align="right">Perk. Harga</FinTh>
                <FinTh>Pelanggan / Tiket</FinTh>
                <FinTh align="center">Status</FinTh>
                <FinTh align="center" corner="last">Aksi</FinTh>
              </tr>
            </TableHeader>
            <TableBody>
              {filtered.map((r, i) => (
                <FinRow key={r.id} zebra={i % 2 === 1}>
                  <FinTd className="text-center font-mono text-[11px] text-muted-foreground/70">{i + 1}</FinTd>
                  <FinTd className="text-muted-foreground">{formatDate(r.createdAt)}</FinTd>
                  <FinTd>
                    <span className="font-bold">{r.itemName}</span>
                    {r.brandOrSpec && (
                      <p className="text-[11px] font-normal text-muted-foreground">{r.brandOrSpec}</p>
                    )}
                    {r.part && (
                      <p className="text-[11px] font-normal text-success">
                        Masuk katalog: {r.part.sku} (stok {r.part.stock})
                      </p>
                    )}
                    {r.notes && (
                      <p className="max-w-56 truncate text-[11px] font-normal text-muted-foreground" title={r.notes}>
                        {r.notes}
                      </p>
                    )}
                  </FinTd>
                  <FinTd className="text-right tabular-nums">{r.qty}</FinTd>
                  <FinTd className="text-right tabular-nums text-muted-foreground">
                    {r.estPrice > 0 ? formatCurrency(r.estPrice) : "—"}
                  </FinTd>
                  <FinTd>
                    <span className="font-bold">{r.customerName || "Umum"}</span>
                    {r.customerPhone && (
                      <p className="text-[11px] font-normal font-mono text-muted-foreground">{r.customerPhone}</p>
                    )}
                    {r.repairRecord && (
                      <p className="text-[11px] font-normal text-primary">
                        Tiket {srvCode(r.repairRecord)} · {r.repairRecord.deviceModel}
                      </p>
                    )}
                  </FinTd>
                  <FinTd className="text-center">
                    <StatusBadge status={r.status} />
                    {r.cancelReason && (
                      <p className="max-w-40 truncate text-[11px] text-destructive" title={r.cancelReason}>
                        {r.cancelReason}
                      </p>
                    )}
                  </FinTd>
                  <FinTd className="text-center">
                    <div className="flex items-center justify-center gap-1">
                      {r.status === "Baru" && (
                        <Button size="sm" variant="outline" className="h-8 rounded-lg text-xs" disabled={saving}
                          onClick={() => patch(r.id, { action: "status", status: "Dipesan" }, "Barang dipesan ke pemasok")}>
                          Pesan
                        </Button>
                      )}
                      {r.status === "Dipesan" && (
                        <Button size="sm" variant="outline" className="h-8 rounded-lg text-xs" disabled={saving}
                          onClick={() => patch(r.id, { action: "status", status: "Tersedia" }, "Barang tersedia — siap masuk inventaris")}>
                          Tersedia
                        </Button>
                      )}
                      {r.status === "Tersedia" && !r.partId && (
                        <Button size="sm" className="h-8 rounded-lg text-xs" onClick={() => setPartRow(r)}>
                          <PackagePlus className="size-3.5" aria-hidden /> Masuk Inventaris
                        </Button>
                      )}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button size="icon" variant="ghost" className="size-8 rounded-lg" aria-label={`Menu aksi barang pesanan ${r.itemName}`}>
                            <MoreVertical className="size-4" aria-hidden />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          {(r.status === "Baru" || r.status === "Dipesan") && (
                            <DropdownMenuItem
                              onClick={() => {
                                setEditRow(r);
                                setFormOpen(true);
                              }}
                            >
                              <Pencil className="size-4" aria-hidden /> Edit
                            </DropdownMenuItem>
                          )}
                          {(r.status === "Baru" || r.status === "Dipesan") && (
                            <>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => setTolakRow(r)} className="text-destructive focus:text-destructive">
                                <Ban className="size-4" aria-hidden /> Tolak
                              </DropdownMenuItem>
                            </>
                          )}
                          {isAdmin && (
                            <>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => setDeleteRow(r)} className="text-destructive focus:text-destructive">
                                <Trash2 className="size-4" aria-hidden /> Hapus
                              </DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </FinTd>
                </FinRow>
              ))}
            </TableBody>
            <FinTfoot>
              <tr>
                <FinFootTd colSpan={5}>Total {filtered.length} barang tampil</FinFootTd>
                <FinFootTd colSpan={3} className="normal-case tracking-normal tabular-nums">
                  Perkiraan aktif: {formatCurrency(filtered.filter((r) => !r.partId && r.status !== "Ditolak").reduce((n, r) => n + r.estPrice * r.qty, 0))}
                </FinFootTd>
              </tr>
            </FinTfoot>
          </Table>
        </div>
      )}

      {/* dialog buat/edit barang pesanan */}
      <PesananFormDialog
        user={user}
        open={formOpen}
        edit={editRow}
        customers={customers}
        repairs={repairs}
        onOpenChange={(v) => {
          setFormOpen(v);
          if (!v) setEditRow(null);
        }}
        onSaved={async () => {
          setFormOpen(false);
          setEditRow(null);
          await onRefresh();
        }}
      />

      {/* dialog masuk inventaris */}
      <BuatPartDialog
        key={partRow ? `part-${partRow.id}` : "none"}
        user={user}
        row={partRow}
        onOpenChange={(v) => !v && setPartRow(null)}
        onSaved={async () => {
          setPartRow(null);
          await onRefresh();
        }}
      />

      {/* dialog tolak */}
      <BatalDialog
        key={tolakRow ? `tolak-${tolakRow.id}` : "none"}
        row={tolakRow}
        saving={saving}
        kind="pesanan"
        onOpenChange={(v) => !v && setTolakRow(null)}
        onConfirm={(reason) => tolakRow && patch(tolakRow.id, { action: "status", status: "Ditolak", reason }, "Barang pesanan ditolak")}
      />

      {/* dialog hapus (Admin) */}
      <Dialog open={!!deleteRow} onOpenChange={(v) => !v && setDeleteRow(null)}>
        <DialogContent className="rounded-2xl sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Hapus Barang Pesanan?</DialogTitle>
            <DialogDescription>
              {deleteRow && <>Catatan “{deleteRow.itemName} ×{deleteRow.qty}” akan dihapus permanen.</>}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteRow(null)}>Batal</Button>
            <Button variant="destructive" onClick={confirmDelete}>Hapus</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// form buat/edit barang pesanan — pelanggan & tiket servis (auto-isi dari tiket)
function PesananFormDialog({
  user,
  open,
  edit,
  customers,
  repairs,
  onOpenChange,
  onSaved,
}: {
  user: SafeUser;
  open: boolean;
  edit: RequestedRow | null;
  customers: CustomerLite[];
  repairs: RepairLite[];
  onOpenChange: (v: boolean) => void;
  onSaved: () => Promise<void>;
}) {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [itemName, setItemName] = useState(edit?.itemName ?? "");
  const [brandOrSpec, setBrandOrSpec] = useState(edit?.brandOrSpec ?? "");
  const [qty, setQty] = useState(String(edit?.qty ?? 1));
  const [estPrice, setEstPrice] = useState(String(edit?.estPrice ?? ""));
  const [customerPick, setCustomerPick] = useState<string>(edit?.customerId ? String(edit.customerId) : "manual");
  const [name, setName] = useState(edit?.customerName ?? "");
  const [phone, setPhone] = useState(edit?.customerPhone ?? "");
  const [repairPick, setRepairPick] = useState<string>(edit?.repairRecordId ? String(edit.repairRecordId) : "none");
  const [notes, setNotes] = useState(edit?.notes ?? "");

  function pickCustomer(v: string) {
    setCustomerPick(v);
    if (v === "manual") return;
    const c = customers.find((x) => String(x.id) === v);
    if (c) {
      setName(c.name);
      setPhone(c.phone);
    }
  }

  // pilih tiket → pelanggan otomatis dari tiket (kecuali pelanggan terdaftar sudah dipilih)
  function pickRepair(v: string) {
    setRepairPick(v);
    if (v === "none") return;
    const r = repairs.find((x) => String(x.id) === v);
    if (r && customerPick === "manual") {
      setName(r.customerName);
    }
  }

  async function save() {
    if (!itemName.trim()) {
      toast({ title: "Nama barang wajib diisi!", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const body = {
        itemName: itemName.trim(),
        brandOrSpec: brandOrSpec.trim(),
        qty: Math.max(1, Math.trunc(Number(qty) || 1)),
        estPrice: Number(estPrice) || 0,
        customerId: customerPick !== "manual" ? customerPick : "",
        customerName: name.trim(),
        customerPhone: phone.trim(),
        repairRecordId: repairPick !== "none" ? repairPick : "",
        notes: notes.trim(),
        performedBy: user.name,
      };
      if (edit) {
        await apiJson(`/api/requested-items/${edit.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        toast({ title: "Barang pesanan diperbarui" });
      } else {
        await apiJson("/api/requested-items", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        toast({ title: `Barang pesanan "${body.itemName}" dicatat` });
      }
      await onSaved();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Gagal menyimpan barang pesanan", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-2xl sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{edit ? "Edit Barang Pesanan" : "Catat Barang Pesanan"}</DialogTitle>
          <DialogDescription>
            Barang yang diminta pelanggan / dibutuhkan tiket servis tetapi belum ada di katalog. Setelah tersedia,
            barang bisa dimasukkan ke inventaris satu tombol.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="space-y-1 sm:col-span-2">
              <Label htmlFor="req-item">Nama Barang *</Label>
              <Input id="req-item" value={itemName} onChange={(e) => setItemName(e.target.value)} placeholder="cth. Baterai BLP637" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="req-spec">Merek / Spesifikasi</Label>
              <Input id="req-spec" value={brandOrSpec} onChange={(e) => setBrandOrSpec(e.target.value)} placeholder="cth. original, Xiaomi Redmi 9" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="req-qty">Jumlah</Label>
              <Input id="req-qty" value={qty} onChange={(e) => setQty(e.target.value)} inputMode="numeric" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="req-harga">Perkiraan Harga Satuan</Label>
              <Input id="req-harga" value={estPrice} onChange={(e) => setEstPrice(e.target.value)} inputMode="numeric" placeholder="0" />
            </div>
            <div className="space-y-1 sm:col-span-2">
              <Label>Tiket Servis Terkait (opsional)</Label>
              <Select value={repairPick} onValueChange={pickRepair}>
                <SelectTrigger aria-label="Pilih tiket servis terkait">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="max-h-56">
                  <SelectItem value="none">Tanpa tiket servis</SelectItem>
                  {repairs.map((r) => (
                    <SelectItem key={r.id} value={String(r.id)}>
                      {srvCode(r)} · {r.deviceModel} · {REPAIR_STATUS_LABEL[r.status] ?? r.status}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1 sm:col-span-2">
              <Label>Pelanggan Terdaftar (opsional)</Label>
              <Select value={customerPick} onValueChange={pickCustomer}>
                <SelectTrigger aria-label="Pilih pelanggan terdaftar">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="max-h-56">
                  <SelectItem value="manual">Tanpa terdaftar (isi manual)</SelectItem>
                  {customers.map((c) => (
                    <SelectItem key={c.id} value={String(c.id)}>
                      {c.name} — {c.phone || "tanpa nomor"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="req-nama">Nama Pelanggan</Label>
              <Input id="req-nama" value={name} onChange={(e) => setName(e.target.value)} placeholder="kosongkan = Umum" />
            </div>
            <div className="space-y-1">
              <Label htmlFor="req-wa">No. WhatsApp</Label>
              <Input id="req-wa" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="08…" inputMode="tel" />
            </div>
            <div className="space-y-1 sm:col-span-2">
              <Label htmlFor="req-notes">Catatan</Label>
              <Textarea id="req-notes" value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Batal</Button>
          <Button onClick={save} disabled={saving}>{edit ? "Simpan" : "Catat Barang"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// dialog masuk inventaris — barang Tersedia dibuat menjadi SparePart katalog
function BuatPartDialog({
  user,
  row,
  onOpenChange,
  onSaved,
}: {
  user: SafeUser;
  row: RequestedRow | null;
  onOpenChange: (v: boolean) => void;
  onSaved: () => Promise<void>;
}) {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [costPrice, setCostPrice] = useState("");
  const [sellPrice, setSellPrice] = useState("");
  const [category, setCategory] = useState<string>("SPAREPART");
  const [minStock, setMinStock] = useState("5");
  const [location, setLocation] = useState("");

  async function save() {
    if (!row) return;
    setSaving(true);
    try {
      await apiJson(`/api/requested-items/${row.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "buatPart",
          costPrice: Number(costPrice) || 0,
          sellPrice: Number(sellPrice) || 0,
          category,
          minStock: Math.trunc(Number(minStock) || 5),
          location: location.trim(),
          performedBy: user.name,
        }),
      });
      toast({ title: `"${row.itemName}" masuk inventaris` });
      await onSaved();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Gagal memasukkan ke inventaris", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={!!row} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-2xl sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Masukkan ke Inventaris</DialogTitle>
          <DialogDescription>
            {row && <>“{row.itemName} ×{row.qty}” dibuat sebagai sparepart baru — SKU otomatis, stok awal {row.qty}.</>}
          </DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="space-y-1">
            <Label htmlFor="part-cost">Harga Beli</Label>
            <Input id="part-cost" value={costPrice} onChange={(e) => setCostPrice(e.target.value)} inputMode="numeric" placeholder="0" />
          </div>
          <div className="space-y-1">
            <Label htmlFor="part-sell">Harga Jual</Label>
            <Input id="part-sell" value={sellPrice} onChange={(e) => setSellPrice(e.target.value)} inputMode="numeric" placeholder="0" />
          </div>
          <div className="space-y-1">
            <Label>Kategori</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger aria-label="Kategori sparepart baru">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {SPARE_CATEGORIES.map((c) => (
                  <SelectItem key={c} value={c}>
                    {SPARE_CATEGORY_LABEL[c]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label htmlFor="part-min">Min. Stok</Label>
            <Input id="part-min" value={minStock} onChange={(e) => setMinStock(e.target.value)} inputMode="numeric" />
          </div>
          <div className="space-y-1 sm:col-span-2">
            <Label htmlFor="part-loc">Lokasi Rak/Laci</Label>
            <Input id="part-loc" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="cth. Rak A-3" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Batal</Button>
          <Button onClick={save} disabled={saving}>
            <PackagePlus className="size-4" aria-hidden /> Masukkan
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================================
// TAB 6.3 — REKOMENDASI BELANJA
// ============================================================================
function RekomendasiTab({
  user,
  parts,
  onRefresh,
}: {
  user: SafeUser;
  parts: SparePartRow[];
  onRefresh: () => Promise<void>;
}) {
  const { toast } = useToast();
  const isAdmin = user.role === "Admin";
  const [busyId, setBusyId] = useState<number | null>(null);
  const [catalogSearch, setCatalogSearch] = useState("");
  const now = Date.now();

  const isIgnored = useCallback(
    (p: SparePartRow) => p.shoppingIgnoredUntil !== null && new Date(p.shoppingIgnoredUntil).getTime() > now,
    [now]
  );

  // saran restock otomatis: stok ≤ min. stok, belum dipilih & tidak diabaikan
  const saran = useMemo(
    () => parts.filter((p) => p.stock <= p.minStock && !p.isShoppingSelected && !isIgnored(p)),
    [parts, isIgnored]
  );
  // daftar belanja: pilihan manual (isShoppingSelected)
  const dipilih = useMemo(() => parts.filter((p) => p.isShoppingSelected), [parts]);
  // diabaikan sementara
  const diabaikan = useMemo(() => parts.filter(isIgnored), [parts, isIgnored]);

  const kekurangan = (p: SparePartRow) => Math.max(0, p.minStock - p.stock);
  const totalBelanja = dipilih.reduce((n, p) => n + kekurangan(p) * p.costPrice, 0);
  const totalSaran = saran.reduce((n, p) => n + kekurangan(p) * p.costPrice, 0);

  const katalog = useMemo(() => {
    const q = catalogSearch.trim().toLowerCase();
    if (!q) return [];
    return parts
      .filter((p) => p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q))
      .slice(0, 12);
  }, [parts, catalogSearch]);

  async function patchShopping(p: SparePartRow, body: Record<string, unknown>) {
    setBusyId(p.id);
    try {
      await apiJson(`/api/spare-parts/${p.id}/shopping`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...body, requesterUsername: user.username, performedBy: user.name }),
      });
      await onRefresh();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Gagal memperbarui pilihan belanja", variant: "destructive" });
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="space-y-4" data-testid="panel-belanja-rekomendasi">
      <div className="flex items-start gap-2.5 rounded-2xl border border-primary/30 bg-primary/5 p-3.5">
        <Info className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
        <p className="text-sm text-muted-foreground">
          <b className="text-foreground">Cara kerja:</b> barang berstok ≤ min. stok muncul di{" "}
          <b>Saran Restock</b>. Tandai <b>Pilih Belanja</b> untuk memasukkannya ke daftar belanja, atau{" "}
          <b>Abaikan {Math.min(7, MAX_IGNORE_DAYS)} Hari</b> bila tidak berniat membeli sekarang. Barang yang
          dibeli (stok diisi) otomatis keluar dari saran.
        </p>
      </div>

      {/* kartu daftar belanja (pilihan) */}
      <Card className="rounded-2xl" data-testid="kartu-daftar-belanja">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <ShoppingCart className="size-4 text-primary" aria-hidden />
            <CardTitle className="text-base">Daftar Belanja (pilihan)</CardTitle>
            <FinCountChip count={dipilih.length} unit="item" />
            <span className="ms-auto text-sm text-muted-foreground">
              {isAdmin && (
                <>
                  Perkiraan modal: <b className="tabular-nums text-foreground">{formatCurrency(totalBelanja)}</b>
                </>
              )}
            </span>
          </div>
          <CardDescription>Barang yang Anda tandai untuk dibeli — bawa daftar ini ke pemasok/toko komponen.</CardDescription>
        </CardHeader>
        {dipilih.length === 0 ? (
          <CardContent className="pb-4">
            <p className="text-sm text-muted-foreground">
              Belum ada pilihan — tandai dari saran restock di bawah atau cari di katalog.
            </p>
          </CardContent>
        ) : (
          <CardContent className="pb-4">
            <div className="overflow-x-auto rounded-xl border xl:overflow-x-visible">
              <Table>
                <TableHeader className="[&_tr]:border-b-0">
                  <tr>
                    <FinTh corner="first">Barang</FinTh>
                    <FinTh>SKU</FinTh>
                    <FinTh align="right">Stok</FinTh>
                    <FinTh align="right">Min.</FinTh>
                    <FinTh align="right">Kekurangan</FinTh>
                    {isAdmin && <FinTh align="right">Perk. Beli</FinTh>}
                    <FinTh align="center" corner="last">Aksi</FinTh>
                  </tr>
                </TableHeader>
                <TableBody>
                  {dipilih.map((p, i) => (
                    <FinRow key={p.id} zebra={i % 2 === 1}>
                      <FinTd className="font-bold">{p.name}</FinTd>
                      <FinTd className="font-mono text-[12px] text-muted-foreground">{p.sku || "—"}</FinTd>
                      <FinTd className="text-right tabular-nums">{p.stock}</FinTd>
                      <FinTd className="text-right tabular-nums text-muted-foreground">{p.minStock}</FinTd>
                      <FinTd className="text-right font-bold tabular-nums text-warning">
                        {kekurangan(p) > 0 ? `+${kekurangan(p)}` : "aman"}
                      </FinTd>
                      {isAdmin && (
                        <FinTd className="text-right tabular-nums text-muted-foreground">
                          {kekurangan(p) > 0 ? formatCurrency(kekurangan(p) * p.costPrice) : "—"}
                        </FinTd>
                      )}
                      <FinTd className="text-center">
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 rounded-lg text-xs"
                          disabled={busyId === p.id}
                          onClick={() => patchShopping(p, { isShoppingSelected: false })}
                        >
                          <X className="size-3.5" aria-hidden /> Batalkan Pilihan
                        </Button>
                      </FinTd>
                    </FinRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        )}
      </Card>

      {/* kartu saran restock otomatis */}
      <Card className="rounded-2xl" data-testid="kartu-saran-restock">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <TriangleAlert className="size-4 text-warning" aria-hidden />
            <CardTitle className="text-base">Saran Restock Otomatis</CardTitle>
            <FinCountChip count={saran.length} unit="item" />
            <span className="ms-auto text-sm text-muted-foreground">
              {isAdmin && (
                <>
                  Perkiraan modal: <b className="tabular-nums text-foreground">{formatCurrency(totalSaran)}</b>
                </>
              )}
            </span>
          </div>
          <CardDescription>Stok sudah menyentuh / melewati batas min. stok (pemberitahuan Inventaris).</CardDescription>
        </CardHeader>
        {saran.length === 0 ? (
          <CardContent className="pb-4">
            <p className="text-sm text-success">
              <CheckCircle2 className="me-1 inline size-4" aria-hidden />
              Semua stok aman — tidak ada saran restock.
            </p>
          </CardContent>
        ) : (
          <CardContent className="pb-4">
            <div className="overflow-x-auto rounded-xl border xl:overflow-x-visible">
              <Table>
                <TableHeader className="[&_tr]:border-b-0">
                  <tr>
                    <FinTh corner="first">Barang</FinTh>
                    <FinTh>Kategori</FinTh>
                    <FinTh align="right">Stok</FinTh>
                    <FinTh align="right">Min.</FinTh>
                    <FinTh align="right">Kekurangan</FinTh>
                    {isAdmin && <FinTh align="right">Perk. Beli</FinTh>}
                    <FinTh align="center" corner="last">Aksi</FinTh>
                  </tr>
                </TableHeader>
                <TableBody>
                  {saran.map((p, i) => (
                    <FinRow key={p.id} zebra={i % 2 === 1}>
                      <FinTd>
                        <span className="font-bold">{p.name}</span>
                        <p className="text-[11px] font-normal text-muted-foreground">{p.sku || "—"}</p>
                      </FinTd>
                      <FinTd className="text-muted-foreground">{SPARE_CATEGORY_LABEL[p.category] ?? p.category}</FinTd>
                      <FinTd className="text-right font-bold tabular-nums text-destructive">{p.stock}</FinTd>
                      <FinTd className="text-right tabular-nums text-muted-foreground">{p.minStock}</FinTd>
                      <FinTd className="text-right font-bold tabular-nums text-warning">+{kekurangan(p)}</FinTd>
                      {isAdmin && (
                        <FinTd className="text-right tabular-nums text-muted-foreground">
                          {formatCurrency(kekurangan(p) * p.costPrice)}
                        </FinTd>
                      )}
                      <FinTd className="text-center">
                        <div className="flex items-center justify-center gap-1">
                          <Button
                            size="sm"
                            className="h-8 rounded-lg text-xs"
                            disabled={busyId === p.id}
                            onClick={() => patchShopping(p, { isShoppingSelected: true })}
                          >
                            <Plus className="size-3.5" aria-hidden /> Pilih Belanja
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-8 rounded-lg text-xs"
                            disabled={busyId === p.id}
                            onClick={() => patchShopping(p, { ignoreDays: 7 })}
                          >
                            Abaikan 7 Hari
                          </Button>
                        </div>
                      </FinTd>
                    </FinRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        )}
      </Card>

      {/* kartu katalog: pilih manual */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Pilih dari Katalog (manual)</CardTitle>
          <CardDescription>Stok masih aman tetapi Anda ingin membeli — cari lalu tandai.</CardDescription>
        </CardHeader>
        <CardContent className="pb-4 space-y-2">
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
            <Input
              value={catalogSearch}
              onChange={(e) => setCatalogSearch(e.target.value)}
              placeholder="Cari nama atau SKU sparepart…"
              className="h-9 rounded-xl pl-8"
              aria-label="Cari sparepart di katalog untuk daftar belanja"
            />
          </div>
          {catalogSearch.trim() !== "" && katalog.length === 0 && (
            <p className="text-sm text-muted-foreground">Tidak ada sparepart yang cocok.</p>
          )}
          {katalog.length > 0 && (
            <div className="overflow-x-auto rounded-xl border xl:overflow-x-visible">
              <Table>
                <TableHeader className="[&_tr]:border-b-0">
                  <tr>
                    <FinTh corner="first">Barang</FinTh>
                    <FinTh align="right">Stok</FinTh>
                    <FinTh align="center" corner="last">Pilihan</FinTh>
                  </tr>
                </TableHeader>
                <TableBody>
                  {katalog.map((p, i) => (
                    <FinRow key={p.id} zebra={i % 2 === 1}>
                      <FinTd>
                        <span className="font-bold">{p.name}</span>
                        <p className="text-[11px] font-normal text-muted-foreground">
                          {p.sku || "—"} · {SPARE_CATEGORY_LABEL[p.category] ?? p.category}
                        </p>
                      </FinTd>
                      <FinTd className="text-right tabular-nums">
                        {p.stock}
                        {p.stock <= p.minStock && (
                          <span className="ms-1 text-[11px] text-destructive">menipis</span>
                        )}
                      </FinTd>
                      <FinTd className="text-center">
                        <Button
                          size="sm"
                          variant={p.isShoppingSelected ? "secondary" : "outline"}
                          className="h-8 rounded-lg text-xs"
                          disabled={busyId === p.id}
                          onClick={() => patchShopping(p, { isShoppingSelected: !p.isShoppingSelected })}
                        >
                          {p.isShoppingSelected ? (
                            <>
                              <CheckCircle2 className="size-3.5" aria-hidden /> Terpilih
                            </>
                          ) : (
                            <>
                              <Plus className="size-3.5" aria-hidden /> Pilih
                            </>
                          )}
                        </Button>
                      </FinTd>
                    </FinRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* kartu diabaikan sementara */}
      {diabaikan.length > 0 && (
        <Card className="rounded-2xl">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <Ban className="size-4 text-muted-foreground" aria-hidden />
              <CardTitle className="text-base">Diabaikan Sementara</CardTitle>
              <FinCountChip count={diabaikan.length} unit="item" />
            </div>
            <CardDescription>Saran restock barang ini disembunyikan sampai tiba waktu yang ditentukan.</CardDescription>
          </CardHeader>
          <CardContent className="pb-4">
            <div className="overflow-x-auto rounded-xl border xl:overflow-x-visible">
              <Table>
                <TableHeader className="[&_tr]:border-b-0">
                  <tr>
                    <FinTh corner="first">Barang</FinTh>
                    <FinTh align="right">Stok / Min.</FinTh>
                    <FinTh>Diabaikan s.d.</FinTh>
                    <FinTh align="center" corner="last">Aksi</FinTh>
                  </tr>
                </TableHeader>
                <TableBody>
                  {diabaikan.map((p, i) => (
                    <FinRow key={p.id} zebra={i % 2 === 1}>
                      <FinTd className="font-bold">{p.name}</FinTd>
                      <FinTd className="text-right tabular-nums text-muted-foreground">
                        {p.stock} / {p.minStock}
                      </FinTd>
                      <FinTd className="text-muted-foreground">
                        {p.shoppingIgnoredUntil ? formatDate(p.shoppingIgnoredUntil) : "—"}
                      </FinTd>
                      <FinTd className="text-center">
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 rounded-lg text-xs"
                          disabled={busyId === p.id}
                          onClick={() => patchShopping(p, { ignoreDays: 0 })}
                        >
                          Hapus Abaikan
                        </Button>
                      </FinTd>
                    </FinRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

