import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import {
  exportBackup,
  entitiesToCsv,
  BACKUP_ENTITIES,
  type BackupEntity,
} from "@/lib/db-backup";

// D40 — GET /api/database/csv?table=customers&requesterUsername=...
// Ekspor CSV per tabel (parity bagian "4. Ekspor & Impor CSV" referensi yang
// menyediakan Pelanggan, Sparepart, Tiket Servis, Transaksi). Kolom round-trip:
// file hasil ekspor pasti bisa diimpor kembali lewat /api/database/restore.
// Admin-only (hash PIN tidak pernah ikut ke CSV).
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const actor = await resolveActor(sp.get("requesterUsername"));
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const table = (sp.get("table") ?? "") as BackupEntity;
  if (!BACKUP_ENTITIES.some((e) => e.key === table)) {
    return errAction("Tabel tidak dikenali", 400);
  }

  try {
    const payload = await exportBackup([table]);
    const csv = entitiesToCsv(table, payload);
    return new NextResponse(csv, {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="fixplus_${table}.csv"`,
      },
    });
  } catch (e) {
    console.error("database csv error", e);
    return NextResponse.json({ error: "Gagal mengekspor CSV" }, { status: 500 });
  }
}
