import { db } from "@/lib/db";
import { ensureSchema } from "@/lib/db-migrate";

// Guard server-side manajemen pengguna (Tahap 7.2) — file terpisah karena
// memuat Prisma (tidak boleh terimport ke bundle klien lewat user-utils.ts).

export function err(message: string, status: number) {
  return Response.json({ error: message }, { status });
}

// D55 — deteksi error skema SQLite (database versi lama / kolom hilang).
// Contoh kasus nyata: file .db lama terpasang → tabel User tanpa kolom izin
// → semua operasi pengguna gagal "no such column".
// Dua bentuk pesan yang dikenali:
//  - mentah dari SQLite: "no such column: x" / "no such table: x";
//  - dibungkus Prisma (P2021/P2022): "The table/column `…` does not exist
//    in the current database."
export function isSchemaError(e: unknown): boolean {
  const msg = e instanceof Error ? e.message : String(e);
  return (
    /no such (column|table)/i.test(msg) ||
    /does not exist in the current database/i.test(msg)
  );
}

// D55 — jaring pengaman API: bila query kena error skema, jalankan
// penyembuhan (tambah kolom/tabel yang hilang) lalu panggil handler SEKALI
// lagi. Menjamin manajemen pengguna tetap berfungsi meski heal startup
// (instrumentation) belum pernah berjalan, mis. file .db ditukar manual
// saat server hidup.
export async function withHeal<T>(fn: () => Promise<T>): Promise<T> {
  try {
    return await fn();
  } catch (e) {
    if (!isSchemaError(e)) throw e;
    console.warn(
      "[heal-db] error skema terdeteksi di API — penyembuhan dijalankan lalu permintaan dicoba ulang:",
      e instanceof Error ? e.message : e
    );
    await ensureSchema({ force: true });
    return await fn();
  }
}

// Cari user peminta permintaan; null bila tidak berhak mengelola pengguna.
// Peminta mengirim username-nya di body.requesterUsername / query string —
// server yang memeriksa izinnya, bukan mengandalkan UI.
export async function resolveManager(username: unknown) {
  const uname = String(username ?? "").trim();
  if (!uname) return null;
  const requester = await db.user.findUnique({ where: { username: uname } });
  if (!requester || !requester.permissionUsers) return null;
  return requester;
}
