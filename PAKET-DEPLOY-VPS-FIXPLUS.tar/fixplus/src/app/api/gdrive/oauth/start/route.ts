import { NextRequest, NextResponse } from "next/server";
import { errAction, resolveActor } from "@/lib/action-guard";
import { loadCreds, saveCreds, requestOrigin, OAUTH_SCOPES } from "@/lib/gdrive";
import { randomBytes } from "crypto";

// D67 — GET /api/gdrive/oauth/start?requesterUsername=...
// Membuka popup persetujuan Google: 302 ke halaman OAuth.
// State acak disimpan (kedaluwarsa 15 menit) — callback memverifikasinya
// untuk mencegah CSRF. redirect_uri dihitung dari header proxy sehingga sama
// dengan URI yang dihitung browser (wajib terdaftar di Google Cloud Console).
export async function GET(req: NextRequest) {
  const actor = await resolveActor(req.nextUrl.searchParams.get("requesterUsername"));
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const c = await loadCreds();
  if (!c.oauth?.clientId || !c.oauth?.clientSecret) {
    return errAction("Client ID / Client Secret belum disimpan", 400);
  }
  const redirectUri = `${requestOrigin(req.nextUrl.toString(), req.headers)}/api/gdrive/oauth/callback`;
  const state = randomBytes(24).toString("base64url");
  await saveCreds({
    pendingOauth: { state, redirectUri, expiry: new Date(Date.now() + 15 * 60_000).toISOString() },
  });

  const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  url.searchParams.set("client_id", c.oauth.clientId);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", OAUTH_SCOPES.join(" "));
  url.searchParams.set("access_type", "offline"); // agar dapat refresh token
  url.searchParams.set("prompt", "consent"); // selalu terbitkan refresh token
  url.searchParams.set("include_granted_scopes", "true");
  url.searchParams.set("state", state);
  return NextResponse.redirect(url.toString(), 302);
}
