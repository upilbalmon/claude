import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { resolveActor, errAction } from "@/lib/action-guard";
import { withHeal } from "@/lib/users-guard";
import { dayKeyWIB } from "@/lib/format";
import { autoAbsenMasuk, serializeSession, sumTunaiBetween } from "@/lib/drawer";

// D92 — Sesi Kas Laci (alur absensi otomatis).
//
// GET  /api/drawer?requesterUsername=U
//      Status laci hari ini untuk pemakai: sesi (bila ada), penjualan tunai
//      selama shift (live bila terbuka / snapshot bila sudah ditutup), kas
//      tercatat, dan absensi hari itu — dipakai dialog Kas Awal & Tutup Laci.
// POST { requesterUsername, openingCash }
//      BUKA laci — login pertama hari itu WAJIB mengisi jumlah kas di laci.
//      Satu sesi per orang per hari (unik userId+date).
// PUT  { requesterUsername, closingCash }
//      TUTUP laci — input kas fisik di laci → server menghitung penjualan
//      tunai & selisih, MENUTUP ABSEN (checkOut), lalu UI melakukan logout.

const MAX_KAS = 100_000_000; // sanity: Rp 100 juta

/** Validasi & rapikan input rupiah → number bulat, atau null bila tidak valid. */
function parseRupiah(v: unknown): number | null {
  const n = Number(v);
  if (!Number.isFinite(n)) return null;
  const r = Math.round(n);
  if (r < 0 || r > MAX_KAS) return null;
  return r;
}

function rupiah(n: number): string {
  return `Rp ${Math.round(n).toLocaleString("id-ID")}`;
}

// ===== GET =====
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const actor = await resolveActor(url.searchParams.get("requesterUsername"), false);
  if (!actor) return errAction("Sesi tidak valid — silakan masuk kembali", 401);

  try {
    return await withHeal(async () => {
      const date = dayKeyWIB(new Date());
      const session = await db.drawerSession.findFirst({
        where: { userId: actor.id, date },
      });
      const attendance = await db.attendance.findFirst({
        where: { userId: actor.id, date },
      });

      // Tunai selama shift: bila terbuka dihitung LIVE dari openingAt sampai
      // sekarang; bila sudah ditutup pakai snapshot saat tutup.
      const isOpen = !!session && session.closingAt === null;
      const cashIn = session
        ? isOpen
          ? await sumTunaiBetween(session.openingAt, new Date())
          : session.cashIn ?? 0
        : 0;
      const expected = session ? session.openingCash + cashIn : 0;

      return NextResponse.json({
        today: session ? serializeSession(session) : null,
        isOpen,
        cashIn,
        expected,
        attendance: attendance
          ? {
              checkIn: attendance.checkIn ? attendance.checkIn.toISOString() : null,
              checkOut: attendance.checkOut ? attendance.checkOut.toISOString() : null,
              status: attendance.status,
            }
          : null,
      });
    });
  } catch (e) {
    console.error("drawer GET error", e);
    return NextResponse.json({ error: "Gagal memuat status kas laci" }, { status: 500 });
  }
}

// ===== POST — buka laci (kas awal) =====
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  try {
    return await withHeal(async () => {
      const actor = await resolveActor(body.requesterUsername, false);
      if (!actor) return errAction("Sesi tidak valid — silakan masuk kembali", 401);

      const openingCash = parseRupiah(body.openingCash);
      if (openingCash === null) {
        return errAction("Jumlah kas awal tidak valid (0 – Rp 100.000.000)", 400);
      }

      const date = dayKeyWIB(new Date());
      const existing = await db.drawerSession.findFirst({ where: { userId: actor.id, date } });
      if (existing) {
        return NextResponse.json(
          {
            error: existing.closingAt === null
              ? `Laci sudah terbuka dengan kas awal ${rupiah(existing.openingCash)} — selesaikan lewat "Tutup Laci"`
              : "Kas laci sudah ditutup hari ini — satu sesi per hari",
          },
          { status: 409 }
        );
      }

      // Jaring pengaman: absen masuk biasanya sudah dibuat saat login —
      // bila belum (mis. DB dipulihkan), catat sekarang. Idempoten.
      await autoAbsenMasuk({ id: actor.id, name: actor.name });

      const now = new Date();
      const created = await db.drawerSession.create({
        data: {
          userId: actor.id,
          userName: actor.name,
          date,
          openingCash,
          openingAt: now,
        },
      });

      await db.auditLog.create({
        data: {
          action: "BUKA_LACI",
          details: `${actor.name} membuka laci — kas awal ${rupiah(openingCash)} (pukul ${new Date(now.getTime() + 7 * 3600_000).toISOString().slice(11, 16)} WIB)`,
          performedBy: actor.name,
        },
      });

      return NextResponse.json(serializeSession(created), { status: 201 });
    });
  } catch (e) {
    console.error("drawer POST error", e);
    return NextResponse.json({ error: "Gagal membuka kas laci" }, { status: 500 });
  }
}

// ===== PUT — tutup laci + tutup absen =====
export async function PUT(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  try {
    return await withHeal(async () => {
      const actor = await resolveActor(body.requesterUsername, false);
      if (!actor) return errAction("Sesi tidak valid — silakan masuk kembali", 401);

      const closingCash = parseRupiah(body.closingCash);
      if (closingCash === null) {
        return errAction("Jumlah kas fisik di laci tidak valid (0 – Rp 100.000.000)", 400);
      }

      const date = dayKeyWIB(new Date());
      const session = await db.drawerSession.findFirst({ where: { userId: actor.id, date } });
      if (!session) {
        return errAction("Laci belum dibuka hari ini — tidak ada yang bisa ditutup", 400);
      }
      if (session.closingAt !== null) {
        return NextResponse.json(
          { error: "Laci sudah ditutup hari ini — satu sesi per hari" },
          { status: 409 }
        );
      }

      const now = new Date();
      const cashIn = await sumTunaiBetween(session.openingAt, now);
      const expected = session.openingCash + cashIn;
      const selisih = closingCash - expected;

      const saved = await db.drawerSession.update({
        where: { id: session.id },
        data: { closingCash, cashIn, expectedCash: expected, selisih, closingAt: now },
      });

      // TUTUP ABSEN — checkOut = sekarang pada catatan hari ini. Baris tanpa
      // checkIn (kasus langka) diisi dari jam buka laci. Status hari-libur
      // pilihan Admin (IZIN/SAKIT/ALPA/LIBUR) tidak diubah.
      const absen = await db.attendance.findFirst({ where: { userId: actor.id, date } });
      const DAY_OFF = new Set(["IZIN", "SAKIT", "ALPA", "LIBUR"]);
      let attendanceOut: string | null = null;
      if (absen && !DAY_OFF.has(absen.status)) {
        const data: { checkOut?: Date; checkIn?: Date; status?: string } = {};
        if (!absen.checkOut) data.checkOut = now;
        if (!absen.checkIn) {
          data.checkIn = session.openingAt;
          data.status = "HADIR";
        }
        if (Object.keys(data).length > 0) {
          const updated = await db.attendance.update({ where: { id: absen.id }, data });
          attendanceOut = updated.checkOut ? updated.checkOut.toISOString() : null;
        }
      } else if (!absen) {
        await db.attendance.create({
          data: { userId: actor.id, userName: actor.name, date, checkIn: session.openingAt, checkOut: now, status: "HADIR" },
        });
        attendanceOut = now.toISOString();
      }

      const labelSelisih =
        selisih === 0 ? "kas cocok" : selisih > 0 ? "kas lebih" : "kas kurang";
      await db.auditLog.create({
        data: {
          action: "TUTUP_LACI",
          details: `${actor.name} menutup laci — kas awal ${rupiah(session.openingCash)}, penjualan tunai ${rupiah(cashIn)}, tercatat ${rupiah(expected)}, fisik ${rupiah(closingCash)} (selisih ${rupiah(selisih)} — ${labelSelisih})`,
          performedBy: actor.name,
        },
      });

      return NextResponse.json({
        session: serializeSession(saved),
        attendanceCheckOut: attendanceOut,
      });
    });
  } catch (e) {
    console.error("drawer PUT error", e);
    return NextResponse.json({ error: "Gagal menutup kas laci" }, { status: 500 });
  }
}
