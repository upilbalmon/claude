import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { db } from "@/lib/db";
import { readFile } from "fs/promises";

// D40 — GET /api/database/backup-db?requesterUsername=...
// Ekspor file database SQLite (.db) mentah (parity "Ekspor File .db" referensi).
// WAL di-checkpoint dulu agar seluruh data termuat ke file utama. Admin-only.
export async function GET(req: NextRequest) {
  const actor = await resolveActor(req.nextUrl.searchParams.get("requesterUsername"));
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  try {
    // Pastikan WAL ditulis ke file utama (parity viewModel.checkpointDatabase())
    await db.$queryRawUnsafe("PRAGMA wal_checkpoint(FULL)");

    const url = process.env.DATABASE_URL ?? "";
    const path = url.startsWith("file:") ? url.slice(5).trim() : "";
    if (!path) {
      return NextResponse.json({ error: "Lokasi file database tidak diketahui" }, { status: 500 });
    }
    const buf = await readFile(path);
    const stamp = new Date().toISOString().slice(0, 10);
    return new NextResponse(new Uint8Array(buf), {
      headers: {
        "Content-Type": "application/octet-stream",
        "Content-Disposition": `attachment; filename="database-fixplus-${stamp}.db"`,
      },
    });
  } catch (e) {
    console.error("backup-db error", e);
    return NextResponse.json({ error: "Gagal membaca file database" }, { status: 500 });
  }
}
