import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import {
  loadCreds,
  resolveMethod,
  tokenAndFolder,
  downloadDriveFile,
  getDriveFileInfo,
} from "@/lib/gdrive";
import { performRestoreDb, isRestoreBusy } from "@/lib/db-restore";

// D67 — POST /api/gdrive/restore — pulihkan database dari file cadangan di
// Google Drive. Unduh file → prosedur GANTI DATABASE yang persis sama dengan
// unggahan manual (performRestoreDb): validasi SQLite, salinan keamanan,
// rollback otomatis bila gagal, penyembuhan kolom usang. Body:
// { requesterUsername, fileId, method? }
export async function POST(req: NextRequest) {
  if (isRestoreBusy()) {
    return errAction("Sedang ada proses pulihkan database berjalan. Coba lagi sesaat.", 409);
  }
  const body = (await req.json().catch(() => ({}))) as {
    requesterUsername?: unknown;
    fileId?: unknown;
    method?: unknown;
  };
  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const fileId = String(body.fileId ?? "").trim();
  if (!/^[\w-]+$/.test(fileId)) return errAction("ID file tidak valid", 400);

  const methodRaw = String(body.method ?? "auto");
  const method = methodRaw === "oauth" || methodRaw === "sa" ? methodRaw : "auto";

  let fileName = fileId;
  let buf: Buffer;
  try {
    const c = await loadCreds();
    const kind = await resolveMethod(c, method);
    const { token } = await tokenAndFolder(kind, c);
    try {
      fileName = (await getDriveFileInfo(token, fileId)).name;
    } catch { /* lanjut unduh walau metadata gagal */ }
    buf = await downloadDriveFile(token, fileId);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("gdrive restore download error", e);
    return errAction(msg, 400);
  }

  const result = await performRestoreDb(buf, fileName, actor.name, actor.username, buf.length);
  if (!result.ok) return errAction(result.error, result.status);
  return NextResponse.json(result);
}
