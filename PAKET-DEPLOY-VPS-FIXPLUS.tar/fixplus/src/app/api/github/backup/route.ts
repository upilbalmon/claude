import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { performGithubBackup } from "@/lib/github-backup";
import { pushNotification } from "@/lib/notifications";

// D68 — POST /api/github/backup — cadangkan database sekarang ke GitHub.
// Body JSON: { requesterUsername }
// Meng-commit file .db penuh (checkpoint WAL dulu) dengan nama bertanggal
// waktu-Jakarta, lalu menghapus cadangan lama di atas batas keepLast.
// D81 — notifikasi sukses ditulis oleh performGithubBackup sendiri; kegagalan
// di sini masuk panel notifikasi juga (dedupe 1 menit untuk klik beruntun).
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as { requesterUsername?: unknown };
  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  try {
    const out = await performGithubBackup(actor.name);
    return NextResponse.json({
      ok: true,
      fileName: out.fileName,
      path: out.path,
      repo: out.repo,
      branch: out.branch,
      size: out.size,
      pruned: out.pruned,
      commitUrl: out.commitUrl,
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("github backup error", e);
    await pushNotification({
      type: "BACKUP_FAILED",
      title: "Backup manual GAGAL",
      message: `${msg}`,
      meta: { actor: actor.name, sumber: "MANUAL", error: msg },
      dedupeMs: 60_000,
    });
    return errAction(msg, 400);
  }
}
