// D55 — Hook startup Next.js: jalankan penyembuhan skema database SEBELUM
// aplikasi melayani request. Bekerja di dev maupun build produksi standalone
// — sehingga instance mana pun (termasuk yang databasenya pernah ditimpa
// file versi lama tanpa kolom baru) otomatis pulih saat server dinyalakan,
// tanpa kehilangan data: operasi hanya CREATE TABLE IF NOT EXISTS /
// ALTER TABLE ADD COLUMN.
export async function register() {
  console.log("[startup] instrumentation register — memasang penjadwal auto-backup");
  // Hanya runtime Node.js (Prisma/SQLite tidak berlaku di Edge runtime).
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  try {
    const { ensureSchema } = await import("@/lib/db-migrate");
    await ensureSchema();
  } catch (e) {
    // Jangan biarkan startup gagal hanya karena penyembuhan — API yang
    // memakai withHeal akan mencoba menyembuhkan lagi saat dibutuhkan.
    console.error("[heal-db] penyembuhan skema saat startup gagal:", e);
  }
  // D67 — pasang penjadwal auto-backup Google Drive harian (cek tiap 10 menit;
  // hanya berjalan bila Admin mengaktifkannya di Pengaturan → Data & Backup).
  try {
    const { startDriveAutoBackup } = await import("@/lib/gdrive");
    startDriveAutoBackup();
  } catch (e) {
    console.error("[gdrive] penjadwal auto-backup gagal dimulai:", e);
  }
  // D68/D69/D70 — pasang penjadwal auto-backup GitHub (harian + per-perubahan)
  // DAN auto-pulihkan saat database kosong; hanya jalan bila Admin mengaktifkan
  // di Pengaturan → Data & Backup → Backup GitHub.
  try {
    const { startGithubAutoBackup } = await import("@/lib/github-backup");
    startGithubAutoBackup();
  } catch (e) {
    console.error("[github] penjadwal auto-backup gagal dimulai:", e);
  }
}
