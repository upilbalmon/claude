import { NextRequest, NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";

// Tahap 7.4 — Log aktivitas (audit_logs: action, details, performedBy, waktu).
// GET /api/audit-logs?q=…&action=…&take=… — terbaru dulu, pencarian kata kunci
// mencakup action/details/performedBy. Hanya untuk yang punya izin Settings
// (UI membatasi tab; di sini cukup ringan karena datanya non-sensitif).

export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const q = (sp.get("q") ?? "").trim();
    const action = (sp.get("action") ?? "").trim();

    let take = Number(sp.get("take") ?? 100);
    if (!Number.isFinite(take)) take = 100;
    take = Math.min(Math.max(Math.trunc(take), 1), 500);

    const where: Prisma.AuditLogWhereInput = {};
    if (q) {
      where.OR = [
        { action: { contains: q } },
        { details: { contains: q } },
        { performedBy: { contains: q } },
      ];
    }
    if (action) where.action = { contains: action };

    const [items, total] = await Promise.all([
      db.auditLog.findMany({ where, orderBy: { timestamp: "desc" }, take }),
      db.auditLog.count({ where }),
    ]);

    return NextResponse.json({ items, total });
  } catch (e) {
    console.error("audit-logs GET error", e);
    return NextResponse.json({ error: "Gagal memuat log aktivitas" }, { status: 500 });
  }
}
