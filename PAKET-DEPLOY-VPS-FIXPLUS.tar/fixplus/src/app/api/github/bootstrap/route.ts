import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  loadCreds,
  saveCreds,
  testConnection,
  triggerAutoSync,
  forceRestoreLatestFromGithub, // D78 — pulihkan paksa permintaan pemilik
  isAutoRestoreSuppressed, // D85 — factory reset → jangan hidupkan data lama
  enableAutoBackupOnChangeAfterConnect, // D86 — aturan: terhubung → auto-backup per-perubahan aktif
  isDbBusinessEmpty,
  loadDeploymentDefaults,
  type DeploymentDefaults,
  credsSummary,
  normalizeFolder,
  REPO_RE,
  BRANCH_RE,
  FOLDER_RE,
  DEFAULT_BRANCH,
  DEFAULT_FOLDER,
} from "@/lib/github-backup";

// D75 — SETUP TOKEN SEBELUM LOGIN (celah #2 rancangan sinkronisasi: "token
// hilang saat reset → re-login sekali"). Saat aplikasi dibuka dan token
// BELUM ADA, layar login digantikan layar "Pulihkan dari GitHub" sehingga
// pemilik toko memasukkan token & repo SEBELUM login — begitu tersambung,
// auto-restore menarik cadangan terbaru lalu akun asli kembali dan login
// berjalan normal.
//
// GET  → status publik pra-login: { configured, businessEmpty,
//        hasSuggestedToken, defaultTokenSource, suggestedRepo,
//        suggestedBranch, suggestedFolder } — TANPA data sensitif.
//        hasSuggestedToken hanya boolean (ada/tidaknya token default di
//        server) — nilai tokennya tidak pernah dikirim ke browser.
//        defaultTokenSource: "env" (variable lingkungan hosting, mis. Vercel
//        GITHUB_BACKUP_TOKEN) / "file" (db/deployment-defaults.json) / null.
//        suggestedRepo/Branch/Folder bukan rahasia (nama repo, bukan token)
//        dan hanya dipakai mengisi form bootstrap otomatis (D76).
// POST → hubungkan GitHub pra-login. DUA PENGAMAN PENTING:
//        1. DITOLAK bila koneksi SUDAH terkonfigurasi — app yang sudah
//           hidup tidak bisa dibajak lewat endpoint ini (Admin mengubah
//           koneksi lewat Pengaturan setelah login).
//        2. DITOLAK bila database BISNIS tidak kosong — mencegah orang lain
//           mengarahkan backup ke repo asing saat data toko masih ada
//           (kebocoran data / eksfiltrasi).
//        D78 — penolakan #2 TIDAK lagi membiarkan pemilik buntu: server
//        menjawab needsConfirm=true (HTTP 403) dan layar bootstrap menampilkan
//        DIALOG PILIHAN "Tetap Pulihkan / Skip". Bila pemilik memilih Tetap
//        Pulihkan, POST dikirim ulang dengan force=true → koneksi disimpan dan
//        cadangan rujukan manifest langsung DIPULIHKAN PAKSA menggantikan data
//        lokal (salinan keamanan .pra-restore dibuat otomatis, keputusan
//        tercatat di Log Aktivitas).
//        Karena hanya bisa jalan saat app masih "pabrik", tidak ada data
//        yang bisa dicuri lewat jalur ini. Semua input divalidasi & koneksi
//        SELALU diuji ke api.github.com dulu (kredensial salah tidak
//        tersimpan). Setelah tersimpan, triggerAutoSync (D70/D74) langsung
//        dijalankan: DB kosong + repo punya cadangan → pulih otomatis.
//
// D85 — MODE OTOMATIS (permintaan pemilik): "dialog pra login dibuat auto.
//        alurnya yaitu ambil token dari vercel setelah itu restore ke
//        cadangan terakhir. dialog tidak perlu ditampilkan kecuali ada
//        error". POST dengan { auto: true }:
//        · token SELALU dari default server (loadDeploymentDefaults: env
//          hosting/Vercel > db/deployment-defaults.json > jembatan token);
//        · repo/branch/folder JUGA dari default server — nilai dari browser
//          DIBIARKAN agar otomatisasi tidak bisa diarahkan ke repo asing;
//        · kebutuhan konfirmasi data-tidak-kosong (needsConfirm) DILEWATI —
//          cadangan terakhir langsung dipulihkan paksa menggantikan data
//          lokal (salinan keamanan otomatis + audit);
//        · setelah factory reset (suppressAutoRestore) pemulihan DILEWATI
//          agar data sengaja dihapus tidak bangkit kembali;
//        · repo yang masih kosong BUKAN error (noBackups=true) — aplikasi
//          lanjut ke login dan backup pertama akan mengisinya.
//        Sukses → layar bootstrap TIDAK muncul sama sekali (langsung login);
//        gagal → respons berisi error dan layar bootstrap tampil dengan
//        banner penjelas + form manual yang sudah terisi default.
function err(msg: string, status: number) {
  return NextResponse.json({ ok: false, error: msg }, { status });
}

export async function GET() {
  const [c, defaults] = await Promise.all([loadCreds(), loadDeploymentDefaults()]);
  let businessEmpty = false;
  try {
    businessEmpty = await isDbBusinessEmpty();
  } catch {
    businessEmpty = false;
  }
  return NextResponse.json({
    configured: Boolean(c.token && c.repo),
    businessEmpty,
    hasSuggestedToken: Boolean((defaults.token ?? "").trim()),
    // D76 — asal token default (env hosting > file > jembatan Vercel): hanya
    // nama sumbernya yang dikirim, bukan isinya.
    defaultTokenSource: defaults.source ?? null,
    // D76 — saran non-sensitif untuk pengisian otomatis form bootstrap.
    suggestedRepo: defaults.repo ?? null,
    suggestedBranch: defaults.branch ?? null,
    suggestedFolder: defaults.folder ?? null,
  });
}

export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as {
    token?: unknown;
    useDefaultToken?: unknown;
    repo?: unknown;
    branch?: unknown;
    folder?: unknown;
    autoRestore?: unknown;
    force?: unknown; // D78 — konfirmasi "Tetap Pulihkan" dari dialog
    auto?: unknown; // D85 — otomatis penuh: token default server + pulihkan cadangan terakhir
  };
  const autoMode = body.auto === true;

  // Pengaman 1 — app yang sudah terhubung tidak boleh diubah pra-login.
  const current = await loadCreds();
  if (current.token && current.repo) {
    return err(
      "GitHub sudah terhubung di perangkat ini — masuk sebagai Admin dulu untuk mengubah koneksi di Pengaturan.",
      409
    );
  }

  // Pengaman 2 — hanya saat data bisnis kosong (kondisi pabrik/pemulihan).
  // D78 — KECUALI pemilik sudah mengonfirmasi "Tetap Pulihkan" di dialog
  // (force=true): data lokal yang ada akan DIGANTI cadangan repo, salinan
  // keamanan dibuat otomatis. Tanpa force, server menjawab needsConfirm=true
  // agar layar bootstrap menampilkan dialog pilihan — bukan penolakan
  // langsung tanpa jalan keluar.
  const forceRestore = body.force === true;
  let businessEmpty = false;
  try {
    businessEmpty = await isDbBusinessEmpty();
  } catch {
    businessEmpty = false;
  }
  // D85 — mode auto melewati needsConfirm: kebijakan pemilik adalah pulihkan
  // cadangan terakhir tanpa dialog (salinan keamanan + audit tetap dibuat).
  if (!businessEmpty && !forceRestore && !autoMode) {
    return NextResponse.json(
      {
        ok: false,
        needsConfirm: true,
        error:
          "Data toko di perangkat ini TIDAK kosong. Melanjutkan akan MENGGANTI seluruh data lokal dengan cadangan terbaru dari GitHub.",
      },
      { status: 403 }
    );
  }

  // Validasi input — sama ketatnya dengan /api/github/credentials.
  // D75 — token bisa datang dari dua sumber: default server (useDefaultToken)
  // atau tempelan manual. Nilai default TIDAK dikirim ke browser — hanya
  // dibaca di server pada saat dipakai.
  // D85 — mode auto: token & repo WAJIB dari default server (env Vercel →
  // file → jembatan). Nilai repo/branch/folder dari browser diabaikan agar
  // otomatisasi tidak bisa dipakai mengarahkan backup ke repo asing.
  const useDefaultToken = body.useDefaultToken === true || autoMode;
  // D76 — saat token manual, defaults kosong (sumber null) tapi tetap
  // bertipe DeploymentDefaults agar pemakaiannya aman di bawah.
  const defaults: DeploymentDefaults = useDefaultToken
    ? await loadDeploymentDefaults()
    : { source: null };
  const token = useDefaultToken
    ? String(defaults.token ?? "").trim()
    : String(body.token ?? "").trim();
  const repo = autoMode
    ? String(defaults.repo ?? "").trim()
    : String(body.repo ?? "").trim();
  const branch = (
    (autoMode ? String(defaults.branch ?? "").trim() : String(body.branch ?? "").trim()) ||
    DEFAULT_BRANCH
  ).replace(/^\/+|\/+$/g, "");
  const folder = normalizeFolder(
    (autoMode ? String(defaults.folder ?? "").trim() : String(body.folder ?? "").trim()) ||
      DEFAULT_FOLDER
  );
  if (!token) {
    return err(
      useDefaultToken
        ? autoMode
          ? "Token default tidak ditemukan di server — hubungkan GitHub secara manual di layar ini."
          : "Token default tidak ditemukan di server — masukkan token secara manual."
        : "Token GitHub wajib diisi",
      400
    );
  }
  if (!REPO_RE.test(repo)) {
    return err(
      autoMode
        ? "Repo default tidak ditemukan di server — hubungkan GitHub secara manual di layar ini."
        : 'Format repo salah — gunakan "owner/repo", mis. budi/fixplus-backup',
      400
    );
  }
  if (!BRANCH_RE.test(branch)) return err("Nama branch mengandung karakter tidak valid", 400);
  if (folder && !FOLDER_RE.test(folder)) {
    return err("Nama folder mengandung karakter tidak valid", 400);
  }

  // Uji koneksi dulu — kredensial salah tidak akan tersimpan.
  let info;
  try {
    info = await testConnection(token, repo, branch);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("github bootstrap test error", e);
    return err(msg, 400);
  }

  // Pulihkan Otomatis ikut dinyalakan di sini (default) — tanpa itu DB kosong
  // tidak akan dipulihkan otomatis saat cek sinkronisasi berikutnya.
  const autoRestore = body.autoRestore === false ? false : true;
  await saveCreds({ token, repo, branch, folder, autoRestore });

  // D86 — ATURAN PEMILIK: koneksi GitHub BERHASIL (uji koneksi lulus +
  // kredensial tersimpan) → auto-backup mode "per-perubahan data" LANGSUNG
  // AKTIF tanpa menunggu Admin mengaturnya. Berlaku untuk semua jalur di
  // endpoint ini (manual D75, paksa D78, otomatis D85) — koneksi sukses
  // adalah pemicunya, bukan hasil pemulihan.
  let autoBackupOnChange = false;
  try {
    autoBackupOnChange = await enableAutoBackupOnChangeAfterConnect("Pra-login (pemilik perangkat)");
  } catch (e) {
    console.error("[github] aturan D86 gagal (koneksi tetap tersimpan):", e);
  }

  // Jalankan pemeriksaan sinkronisasi D74 sekarang juga: DB kosong + repo
  // punya cadangan → file terbaru langsung dipulihkan sebelum login.
  // D78 — bila pemilik memilih "Tetap Pulihkan" saat data lokal TIDAK kosong,
  // JANGAN lewat tabel keputusan D74 (bisa berakhir konflik / tanpa aksi):
  // langsung pulihkan paksa cadangan rujukan manifest sekarang.
  // D85 — mode auto SELALU lewat pemulihan paksa (hasil selalu eksplisit:
  // restored / restoreError / noBackups) — dan DILEWATI begitu factory reset
  // pernah berjalan di proses ini (data sengaja dikosongkan pemilik).
  let restored = false;
  let restoredFile: string | null = null;
  let restoreError: string | null = null;
  let noBackups = false;
  let suppressedRestore = false;
  if (autoMode && isAutoRestoreSuppressed()) {
    suppressedRestore = true;
    console.log("[github] bootstrap otomatis: pulihkan dilewati (factory reset aktif)");
  } else if (autoMode || (forceRestore && !businessEmpty)) {
    const fr = await forceRestoreLatestFromGithub(
      autoMode
        ? { alasan: "otomatis pra-login (D85) — token default server", actor: "Sistem (Otomatis Pra-Login)" }
        : undefined
    ).catch((e: unknown) => ({
      ok: false as const,
      error: e instanceof Error ? e.message : String(e),
      noBackups: false,
    }));
    restored = fr.ok;
    restoredFile = fr.ok ? (fr.file ?? null) : null;
    restoreError = fr.ok ? null : (fr.error ?? "Pemulihan paksa gagal");
    noBackups = !fr.ok && fr.noBackups === true;
    if (!fr.ok) {
      console.error(
        `[github] pulihkan paksa pra-login gagal${autoMode ? " (mode otomatis D85)" : ""}:`,
        fr.error
      );
    }
  } else {
    const before = (await loadCreds()).lastAutoRestoreAt ?? null;
    try {
      await triggerAutoSync();
    } catch (e) {
      console.error("[github] bootstrap sync gagal (koneksi tetap tersimpan):", e);
    }
    const afterSync = await loadCreds();
    restored = Boolean(afterSync.lastAutoRestoreAt && afterSync.lastAutoRestoreAt !== before);
    restoredFile = restored ? (afterSync.lastAutoRestoreFile ?? null) : null;
  }
  const after = await loadCreds();

  const forcedNote = autoMode
    ? suppressedRestore
      ? " — OTOMATIS pra-login (D85): pulihkan DILEWATI, factory reset aktif"
      : noBackups
        ? " — OTOMATIS pra-login (D85): repo belum punya cadangan, tanpa pemulihan"
        : restored
          ? " — OTOMATIS pra-login (D85): cadangan terakhir dipulihkan tanpa dialog"
          : " — OTOMATIS pra-login (D85): PEMULIHAN GAGAL, tunggu manual di layar bootstrap"
    : forceRestore && !businessEmpty
      ? " — pemilik memilih TETAP PULIHKAN di dialog (data lokal tidak kosong, D78)"
      : "";
  await db.auditLog.create({
    data: {
      action: "GITHUB_BOOTSTRAP",
      details: `GitHub tersambung PRA-LOGIN — repo ${info.fullName}${info.isPrivate ? " (privat)" : " (PUBLIK — disarankan ganti ke privat)"}, branch ${branch}, folder ${folder || "(root)"}, sumber token: ${useDefaultToken ? (defaults.source ?? "default") : "manual"}${restored ? `, database dipulihkan dari "${restoredFile}"` : restoreError ? `, PEMULIHAN GAGAL: ${restoreError}` : ", tidak ada cadangan yang dipulihkan"}${forcedNote}.`,
      performedBy: "Pra-login (pemilik perangkat)",
    },
  });

  return NextResponse.json({
    ok: true,
    repo: { fullName: info.fullName, isPrivate: info.isPrivate, emptyRepo: info.emptyRepo },
    restored,
    restoredFile,
    restoreError,
    noBackups, // D85 — repo valid tapi belum punya cadangan (bukan error)
    suppressedRestore, // D85 — pulihkan dilewati karena factory reset
    autoMode, // D85 — penanda untuk layar bootstrap
    autoBackupOnChange, // D86 — aturan: auto-backup per-perubahan diaktifkan otomatis saat koneksi
    autoRestore: after.autoRestore === true,
    status: credsSummary(after),
  });
}
