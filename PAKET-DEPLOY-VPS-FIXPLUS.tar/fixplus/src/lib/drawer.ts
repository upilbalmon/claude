import { db } from "@/lib/db";
import { dayKeyWIB } from "@/lib/format";

// D92 — Alur absensi otomatis + kas laci.
//
// Sebelumnya (D73) absen masuk/keluar dilakukan MANDIRI lewat tombol di
// halaman Absensi. Sejak D92 alurnya otomatis:
//   1. Login (termasuk ganti-PIN pertama & ganti akun via gerbang D41 — semua
//      memakai /api/auth/login|change-pin) → SERVER langsung mencatat absen
//      masuk (jam server WIB; klien tidak bisa memalsukan tanggal/jam).
//   2. Login PERTAMA dalam 1 hari → wajib mengisi "jumlah kas di laci"
//      (Sesi Kas Laci baru dibuka; dialog di UI tidak bisa ditutup).
//   3. Tombol "Tutup Laci" (topbar & halaman Absensi) → isi kas fisik →
//      server menutup laci, menutup absen (checkOut) — UI lalu logout.
//
// Helper di sini dipakai bersama oleh /api/auth/* dan /api/drawer.

// Status yang ditetapkan Admin — absen otomatis tidak boleh menimpanya
// (aturan yang sama dengan absen mandiri D73).
const DAY_OFF_STATUSES = new Set(["IZIN", "SAKIT", "ALPA", "LIBUR"]);

const WIB_OFFSET_MS = 7 * 60 * 60 * 1000;

/** "HH:mm" WIB dari sebuah instant */
function timeStrWIB(d: Date): string {
  return new Date(d.getTime() + WIB_OFFSET_MS).toISOString().slice(11, 16);
}

/**
 * Absen masuk otomatis saat login (server-side, jam server WIB).
 * - Belum ada catatan hari ini  → buat (checkIn = sekarang, HADIR).
 * - Ada tanpa checkIn & bukan hari-libur Admin → isi checkIn + HADIR.
 * - Sudah ada checkIn           → TIDAK disentuh (jam masuk pertama hari itu
 *   tetap dipakai walau user keluar-masuk aplikasi berkali-kali; baris yang
 *   sudah checkOut juga tidak dibuka lagi).
 * Kembalikan catatan absensi hari itu (tanpa menulis audit — LOGIN sudah
 * tercatat di audit log oleh endpoint auth-nya).
 */
export async function autoAbsenMasuk(user: { id: number; name: string }): Promise<void> {
  const date = dayKeyWIB(new Date());
  const existing = await db.attendance.findFirst({ where: { userId: user.id, date } });
  if (!existing) {
    await db.attendance.create({
      data: { userId: user.id, userName: user.name, date, checkIn: new Date(), status: "HADIR" },
    });
    return;
  }
  if (!existing.checkIn && !DAY_OFF_STATUSES.has(existing.status)) {
    await db.attendance.update({
      where: { id: existing.id },
      data: { checkIn: new Date(), status: "HADIR" },
    });
  }
}

/**
 * Σ penjualan TUNAI (net refund, tanpa void) dalam jendela [start, end).
 * Dipakai untuk menghitung "kas tercatat" saat tutup laci: satu laci fisik
 * di toko, sehingga SEMUA transaksi tunai pada jendela shift dihitung —
 * bukan hanya yang dibuat oleh pemakai tersebut.
 */
export async function sumTunaiBetween(start: Date, end: Date): Promise<number> {
  const txs = await db.transaction.findMany({
    where: { paymentMethod: "Tunai", isVoided: false, timestamp: { gte: start, lt: end } },
    select: { grandTotal: true, docType: true },
  });
  return txs.reduce((s, t) => {
    if (t.docType === "REFUND") return s - Math.abs(t.grandTotal);
    return s + t.grandTotal;
  }, 0);
}

/** Bentuk JSON sesi laci untuk klien (DateTime → ISO). */
export function serializeSession(s: {
  id: number;
  userId: number | null;
  userName: string;
  date: string;
  openingCash: number;
  closingCash: number | null;
  cashIn: number | null;
  expectedCash: number | null;
  selisih: number | null;
  openingAt: Date;
  closingAt: Date | null;
}) {
  return {
    id: s.id,
    userId: s.userId,
    userName: s.userName,
    date: s.date,
    openingCash: s.openingCash,
    closingCash: s.closingCash,
    cashIn: s.cashIn,
    expectedCash: s.expectedCash,
    selisih: s.selisih,
    openingAt: s.openingAt.toISOString(),
    closingAt: s.closingAt ? s.closingAt.toISOString() : null,
    isOpen: s.closingAt === null,
    jamBuka: timeStrWIB(s.openingAt),
    jamTutup: s.closingAt ? timeStrWIB(s.closingAt) : null,
  };
}
