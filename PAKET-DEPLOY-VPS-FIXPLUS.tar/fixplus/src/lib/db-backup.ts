import { db } from "@/lib/db";

// D40 — Mesin cadangan/pulihkan/reset database (parity "Database & Backup"
// referensi DatabaseSettings.kt). Dipakai oleh route /api/database/*.
//
// Semantik RESTORE = MERGE aman (persis importBackupJson referensi):
// - Pelanggan  : cocok berdasarkan telepon (bila terisi) atau nama → ada: lewati
// - Teknisi    : cocok berdasarkan nama (tanpa peduli huruf besar/kecil) → ada: lewati
// - Sparepart  : cocok berdasarkan SKU (bila terisi) atau nama → ada: lewati
// - Produk Jasa: cocok berdasarkan nama → ada: lewati
// - Tiket      : cocok berdasarkan ID lama bila masih ada → sisanya dibuat baru
//                (FK pelanggan/teknisi dipetakan ke ID baru; hilang → null)
// - Transaksi  : cocok berdasarkan nomor invoice (unik) → ada: lewati
// - Pengguna   : cocok berdasarkan username → ada: lewati (PIN & salt ikut
//                cadangan, sehingga akun bisa berpindah server)
//
// RESET = deleteMany per tabel terpilih; pengguna: akun yang sedang login
// (requester) selalu dipertahankan — persis resetDatabase referensi.

export type BackupEntity =
  | "customers"
  | "technicians"
  | "spare_parts"
  | "service_products"
  | "repair_records"
  | "transactions"
  | "users";

export const BACKUP_ENTITIES: { key: BackupEntity; label: string }[] = [
  { key: "customers", label: "Data Pelanggan" },
  { key: "technicians", label: "Data Teknisi" },
  { key: "spare_parts", label: "Data Sparepart" },
  { key: "service_products", label: "Data Produk Jasa" },
  { key: "repair_records", label: "Data Tiket Servis" },
  { key: "transactions", label: "Data Transaksi Kasir" },
  { key: "users", label: "Data Pengguna (Akun & PIN)" },
];

export const ENTITY_LABEL = (key: BackupEntity) =>
  BACKUP_ENTITIES.find((e) => e.key === key)?.label ?? key;

const iso = (d: Date | null | undefined) => (d ? new Date(d).toISOString() : null);

// ===== EXPORT =====
export async function exportBackup(entities: BackupEntity[]) {
  const pick = (k: BackupEntity) => entities.includes(k);
  const out: Record<string, unknown> = {
    meta: {
      app: "Servis HP & POS",
      format: "fixplus-backup-json",
      exportedAt: new Date().toISOString(),
      entities,
    },
  };
  if (pick("customers")) {
    out.customers = (await db.customer.findMany({ orderBy: { id: "asc" } })).map((c) => ({
      id: c.id,
      name: c.name,
      phone: c.phone,
      email: c.email,
      address: c.address,
      loyaltyPoints: c.loyaltyPoints,
      createdAt: iso(c.createdAt),
    }));
  }
  if (pick("technicians")) {
    out.technicians = (await db.technician.findMany({ orderBy: { id: "asc" } })).map((t) => ({
      id: t.id,
      name: t.name,
      phone: t.phone,
      isAvailable: t.isAvailable,
    }));
  }
  if (pick("spare_parts")) {
    out.spare_parts = (await db.sparePart.findMany({ orderBy: { id: "asc" } })).map((p) => ({
      id: p.id,
      name: p.name,
      alias: p.alias,
      sku: p.sku,
      stock: p.stock,
      minStock: p.minStock,
      costPrice: p.costPrice,
      sellPrice: p.sellPrice,
      location: p.location,
    }));
  }
  if (pick("service_products")) {
    out.service_products = (await db.serviceProduct.findMany({ orderBy: { id: "asc" } })).map((s) => ({
      id: s.id,
      name: s.name,
      basePrice: s.basePrice,
      points: s.points,
    }));
  }
  if (pick("repair_records")) {
    out.repair_records = (await db.repairRecord.findMany({ orderBy: { id: "asc" } })).map((r) => ({
      id: r.id,
      customerId: r.customerId,
      customerName: r.customerName,
      customerPhone: r.customerPhone,
      deviceModel: r.deviceModel,
      serialOrImei: r.serialOrImei,
      damageDescription: r.damageDescription,
      status: r.status,
      technicianId: r.technicianId,
      technicianName: r.technicianName,
      serviceFee: r.serviceFee,
      usedPartsJson: r.usedPartsJson,
      requestedPartsJson: r.requestedPartsJson,
      totalPrice: r.totalPrice,
      difficulty: r.difficulty,
      notes: r.notes,
      estimatedCost: r.estimatedCost,
      downPayment: r.downPayment,
      estimatedCompletionTime: r.estimatedCompletionTime,
      createdByUser: r.createdByUser,
      pointsReward: r.pointsReward,
      warrantyDays: r.warrantyDays,
      createdAt: iso(r.createdAt),
      updatedAt: iso(r.updatedAt),
      completedAt: iso(r.completedAt),
    }));
  }
  if (pick("transactions")) {
    out.transactions = (await db.transaction.findMany({ orderBy: { id: "asc" } })).map((t) => ({
      id: t.id,
      invoiceNumber: t.invoiceNumber,
      repairRecordId: t.repairRecordId,
      customerId: t.customerId,
      customerName: t.customerName,
      subtotal: t.subtotal,
      discount: t.discount,
      grandTotal: t.grandTotal,
      paymentMethod: t.paymentMethod,
      paymentStatus: t.paymentStatus,
      paidAmount: t.paidAmount,
      changeAmount: t.changeAmount,
      itemsJson: t.itemsJson,
      timestamp: iso(t.timestamp),
      isVoided: t.isVoided,
      voidedBy: t.voidedBy,
      voidedAt: iso(t.voidedAt),
      voidReason: t.voidReason,
      createdBy: t.createdBy,
      docType: t.docType,
      refundOfId: t.refundOfId,
      referenceNumber: t.referenceNumber,
    }));
  }
  if (pick("users")) {
    out.users = (await db.user.findMany({ orderBy: { id: "asc" } })).map((u) => ({
      id: u.id,
      name: u.name,
      username: u.username,
      role: u.role,
      pin: u.pin,
      salt: u.salt,
      mustChangePin: u.mustChangePin,
      permissionDashboard: u.permissionDashboard,
      permissionCashier: u.permissionCashier,
      permissionServices: u.permissionServices,
      permissionInventory: u.permissionInventory,
      permissionCustomers: u.permissionCustomers,
      permissionUsers: u.permissionUsers,
      permissionSettings: u.permissionSettings,
      createdAt: iso(u.createdAt),
    }));
  }
  return out;
}

// ===== IMPORT (merge aman) =====
// data: hasil exportBackup (JSON) ATAU satu entitas dari CSV (objek per baris).
// entities: entitas mana yang boleh diimpor dari payload.
export async function importBackup(
  data: Record<string, unknown>,
  entities: BackupEntity[]
): Promise<Record<string, { imported: number; skipped: number }>> {
  const result: Record<string, { imported: number; skipped: number }> = {};

  const arr = (k: BackupEntity): Record<string, unknown>[] => {
    if (!entities.includes(k)) return [];
    const v = data[k];
    return Array.isArray(v) ? (v as Record<string, unknown>[]) : [];
  };
  const track = (k: BackupEntity, imported: boolean) => {
    const r = (result[k] ??= { imported: 0, skipped: 0 });
    if (imported) r.imported++;
    else r.skipped++;
  };
  const dateOf = (v: unknown): Date | null => {
    if (!v) return null;
    const d = new Date(String(v));
    return Number.isNaN(d.getTime()) ? null : d;
  };
  const num = (v: unknown, dflt = 0) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : dflt;
  };
  const int = (v: unknown, dflt = 0) => Math.trunc(num(v, dflt));
  const str = (v: unknown, dflt = "") => (v === null || v === undefined ? dflt : String(v));
  const bool = (v: unknown, dflt = false) =>
    v === undefined || v === null ? dflt : v === true || v === "true" || v === 1 || v === "1";

  // Peta ID lama → ID baru untuk remap FK antar entitas
  const customerMap = new Map<number, number>();
  const techMap = new Map<number, number>();
  const repairMap = new Map<number, number>();
  const transactionMap = new Map<number, number>();
  const remap = (m: Map<number, number>, v: unknown): number | null => {
    const n = int(v, 0);
    if (n <= 0) return null;
    return m.get(n) ?? null; // tidak ditemukan → null (FK opsional)
  };

  // 1. Pelanggan
  {
    const rows = arr("customers");
    const existing = await db.customer.findMany();
    for (const r of rows) {
      const id = int(r.id, 0);
      const phone = str(r.phone).trim();
      const name = str(r.name).trim();
      if (!name) {
        track("customers", false);
        continue;
      }
      const match = phone
        ? existing.find((c) => c.phone.trim() === phone)
        : existing.find((c) => c.name.trim().toLowerCase() === name.toLowerCase());
      if (match) {
        customerMap.set(id, match.id);
        track("customers", false);
        continue;
      }
      const created = await db.customer.create({
        data: {
          name,
          phone,
          email: str(r.email),
          address: str(r.address),
          loyaltyPoints: int(r.loyaltyPoints),
          ...(dateOf(r.createdAt) ? { createdAt: dateOf(r.createdAt)! } : {}),
        },
      });
      existing.push(created);
      customerMap.set(id, created.id);
      track("customers", true);
    }
  }

  // 2. Teknisi
  {
    const rows = arr("technicians");
    const existing = await db.technician.findMany();
    for (const r of rows) {
      const name = str(r.name).trim();
      if (!name) {
        track("technicians", false);
        continue;
      }
      const match = existing.find((t) => t.name.trim().toLowerCase() === name.toLowerCase());
      if (match) {
        techMap.set(int(r.id, 0), match.id);
        track("technicians", false);
        continue;
      }
      const created = await db.technician.create({
        data: { name, phone: str(r.phone), isAvailable: bool(r.isAvailable, true) },
      });
      existing.push(created);
      techMap.set(int(r.id, 0), created.id);
      track("technicians", true);
    }
  }

  // 3. Sparepart
  {
    const rows = arr("spare_parts");
    const existing = await db.sparePart.findMany();
    for (const r of rows) {
      const name = str(r.name).trim();
      const sku = str(r.sku).trim();
      if (!name) {
        track("spare_parts", false);
        continue;
      }
      const match = sku
        ? existing.find((p) => p.sku.trim() === sku)
        : existing.find((p) => p.name.trim().toLowerCase() === name.toLowerCase());
      if (match) {
        track("spare_parts", false);
        continue;
      }
      await db.sparePart.create({
        data: {
          name,
          alias: str(r.alias).trim() ? str(r.alias).trim() : null,
          sku,
          stock: int(r.stock),
          minStock: int(r.minStock, 5),
          costPrice: num(r.costPrice),
          sellPrice: num(r.sellPrice),
          location: str(r.location),
        },
      });
      track("spare_parts", true);
    }
  }

  // 4. Produk jasa
  {
    const rows = arr("service_products");
    const existing = await db.serviceProduct.findMany();
    for (const r of rows) {
      const name = str(r.name).trim();
      if (!name) {
        track("service_products", false);
        continue;
      }
      if (existing.find((s) => s.name.trim().toLowerCase() === name.toLowerCase())) {
        track("service_products", false);
        continue;
      }
      await db.serviceProduct.create({
        data: { name, basePrice: num(r.basePrice), points: int(r.points) },
      });
      track("service_products", true);
    }
  }

  // 5. Tiket servis (ID lama masih ada → lewati; sisanya dibuat baru + remap FK)
  {
    const rows = arr("repair_records");
    const existingIds = new Set(
      (await db.repairRecord.findMany({ select: { id: true } })).map((r) => r.id)
    );
    for (const r of rows) {
      const oldId = int(r.id, 0);
      if (oldId > 0 && existingIds.has(oldId)) {
        repairMap.set(oldId, oldId);
        track("repair_records", false);
        continue;
      }
      const created = await db.repairRecord.create({
        data: {
          customerId: remap(customerMap, r.customerId),
          customerName: str(r.customerName, "Umum") || "Umum",
          customerPhone: str(r.customerPhone),
          deviceModel: str(r.deviceModel, "-") || "-",
          serialOrImei: str(r.serialOrImei),
          damageDescription: str(r.damageDescription),
          status: str(r.status, "ANTRI") || "ANTRI",
          technicianId: remap(techMap, r.technicianId),
          technicianName: str(r.technicianName).trim() ? str(r.technicianName) : null,
          serviceFee: num(r.serviceFee),
          usedPartsJson: str(r.usedPartsJson, "[]") || "[]",
          requestedPartsJson: str(r.requestedPartsJson, "[]") || "[]",
          totalPrice: num(r.totalPrice),
          difficulty: str(r.difficulty, "Sedang") || "Sedang",
          notes: str(r.notes),
          estimatedCost: r.estimatedCost === null || r.estimatedCost === "" ? null : num(r.estimatedCost),
          downPayment: r.downPayment === null || r.downPayment === "" ? null : num(r.downPayment),
          estimatedCompletionTime: str(r.estimatedCompletionTime),
          createdByUser: str(r.createdByUser),
          pointsReward: r.pointsReward === null || r.pointsReward === "" ? null : int(r.pointsReward),
          warrantyDays: int(r.warrantyDays),
          ...(dateOf(r.createdAt) ? { createdAt: dateOf(r.createdAt)! } : {}),
          ...(dateOf(r.completedAt) ? { completedAt: dateOf(r.completedAt)! } : {}),
        },
      });
      repairMap.set(oldId, created.id);
      track("repair_records", true);
    }
  }

  // 6. Transaksi kasir (nomor invoice unik → duplikat dilewati; refund dirantai)
  {
    const rows = arr("transactions");
    const existingInvoices = new Set(
      (await db.transaction.findMany({ select: { invoiceNumber: true } })).map((t) => t.invoiceNumber)
    );
    // Dua putaran: dokumen asli dulu, lalu refund — agar refundOf bisa diremap
    for (const onlyRefund of [false, true]) {
      for (const r of rows) {
        const isRefund = str(r.docType, "PENJUALAN") === "REFUND";
        if (isRefund !== onlyRefund) continue;
        const oldId = int(r.id, 0);
        const invoice = str(r.invoiceNumber).trim();
        if (!invoice) {
          track("transactions", false);
          continue;
        }
        if (existingInvoices.has(invoice)) {
          transactionMap.set(oldId, -1); // -1 = sudah ada di DB (abaikan remap)
          track("transactions", false);
          continue;
        }
        // refundOfId: petakan ke dokumen asli yang baru dibuat/diimpor pada putaran pertama
        const refundOfRaw = int(r.refundOfId, 0);
        const refundOfMapped = refundOfRaw > 0 ? transactionMap.get(refundOfRaw) : undefined;
        const refundOfId =
          refundOfMapped && refundOfMapped > 0
            ? refundOfMapped
            : refundOfRaw > 0 && (await db.transaction.findUnique({ where: { id: refundOfRaw } }))
              ? refundOfRaw
              : null;
        const created = await db.transaction.create({
          data: {
            invoiceNumber: invoice,
            repairRecordId: remap(repairMap, r.repairRecordId),
            customerId: remap(customerMap, r.customerId),
            customerName: str(r.customerName, "Umum") || "Umum",
            subtotal: num(r.subtotal),
            discount: num(r.discount),
            grandTotal: num(r.grandTotal),
            paymentMethod: str(r.paymentMethod, "Tunai") || "Tunai",
            paymentStatus: str(r.paymentStatus, "LUNAS") || "LUNAS",
            paidAmount: num(r.paidAmount),
            changeAmount: num(r.changeAmount),
            itemsJson: str(r.itemsJson, "[]") || "[]",
            timestamp: dateOf(r.timestamp) ?? new Date(),
            isVoided: bool(r.isVoided),
            voidedBy: str(r.voidedBy).trim() ? str(r.voidedBy) : null,
            voidedAt: dateOf(r.voidedAt),
            voidReason: str(r.voidReason).trim() ? str(r.voidReason) : null,
            createdBy: str(r.createdBy, "Admin") || "Admin",
            docType: isRefund ? "REFUND" : "PENJUALAN",
            refundOfId,
            referenceNumber: str(r.referenceNumber),
          },
        });
        existingInvoices.add(invoice);
        transactionMap.set(oldId, created.id);
        track("transactions", true);
      }
    }
  }

  // 7. Pengguna (username unik; PIN & salt ikut — akun dapat berpindah server)
  {
    const rows = arr("users");
    const existing = await db.user.findMany();
    for (const r of rows) {
      const username = str(r.username).trim();
      const name = str(r.name).trim();
      if (!username || !name) {
        track("users", false);
        continue;
      }
      if (existing.find((u) => u.username.toLowerCase() === username.toLowerCase())) {
        track("users", false);
        continue;
      }
      await db.user.create({
        data: {
          name,
          username,
          role: str(r.role, "Kasir") || "Kasir",
          ...(str(r.pin)
            ? { pin: str(r.pin), salt: str(r.salt) }
            : await defaultHashedPin()),
          mustChangePin: bool(r.mustChangePin, false),
          permissionDashboard: bool(r.permissionDashboard, true),
          permissionCashier: bool(r.permissionCashier, true),
          permissionServices: bool(r.permissionServices, true),
          permissionInventory: bool(r.permissionInventory, true),
          permissionCustomers: bool(r.permissionCustomers, true),
          permissionUsers: bool(r.permissionUsers, true),
          permissionSettings: bool(r.permissionSettings, true),
          ...(dateOf(r.createdAt) ? { createdAt: dateOf(r.createdAt)! } : {}),
        },
      });
      track("users", true);
    }
  }

  return result;
}

// PIN cadangan 4 digit "1234" bila data pengguna tidak membawa hash PIN
async function defaultHashedPin(): Promise<{ pin: string; salt: string }> {
  const { hashPin } = await import("@/lib/pin-hash");
  const salt = Math.random().toString(36).slice(2, 10);
  return { pin: hashPin("1234", salt), salt };
}

// ===== RESET (parity resetDatabase referensi) =====
export async function resetTables(entities: BackupEntity[], keepUserId: number) {
  const deleted: Record<string, number> = {};
  for (const e of entities) {
    switch (e) {
      case "repair_records":
        deleted.repair_records = (await db.repairRecord.deleteMany()).count;
        break;
      case "customers":
        deleted.customers = (await db.customer.deleteMany()).count;
        break;
      case "spare_parts":
        deleted.spare_parts = (await db.sparePart.deleteMany()).count;
        break;
      case "service_products":
        deleted.service_products = (await db.serviceProduct.deleteMany()).count;
        break;
      case "transactions":
        deleted.transactions = (await db.transaction.deleteMany()).count;
        break;
      case "technicians":
        deleted.technicians = (await db.technician.deleteMany()).count;
        break;
      case "users":
        deleted.users = (
          await db.user.deleteMany({ where: { id: { not: keepUserId } } })
        ).count;
        break;
    }
  }
  return deleted;
}

// ===== STATISTIK (parity "Statistik Data Database" referensi) =====
export async function backupStats() {
  const [
    customers,
    technicians,
    spare_parts,
    service_products,
    repair_records,
    transactions,
    users,
    audit_logs,
  ] = await Promise.all([
    db.customer.count(),
    db.technician.count(),
    db.sparePart.count(),
    db.serviceProduct.count(),
    db.repairRecord.count(),
    db.transaction.count(),
    db.user.count(),
    db.auditLog.count(),
  ]);
  return {
    customers,
    technicians,
    spare_parts,
    service_products,
    repair_records,
    transactions,
    users,
    audit_logs,
  };
}

// ===== CSV (parity bagian 4 "Ekspor & Impor CSV" referensi) =====
// Kolom mengikuti field aplikasi (round-trip aman dengan ekspornya sendiri).
export const CSV_COLUMNS: Record<BackupEntity, string[]> = {
  customers: ["id", "name", "phone", "email", "address", "loyaltyPoints", "createdAt"],
  technicians: ["id", "name", "phone", "isAvailable"],
  spare_parts: ["id", "name", "alias", "sku", "stock", "minStock", "costPrice", "sellPrice", "location"],
  service_products: ["id", "name", "basePrice", "points"],
  repair_records: [
    "id", "customerName", "customerPhone", "deviceModel", "serialOrImei",
    "damageDescription", "status", "technicianName", "serviceFee", "totalPrice",
    "difficulty", "notes", "estimatedCost", "downPayment", "estimatedCompletionTime",
    "createdByUser", "pointsReward", "warrantyDays", "createdAt", "completedAt",
    "usedPartsJson", "requestedPartsJson",
  ],
  transactions: [
    "invoiceNumber", "customerName", "subtotal", "discount", "grandTotal",
    "paymentMethod", "paymentStatus", "paidAmount", "changeAmount", "itemsJson",
    "isVoided", "voidedBy", "voidReason", "createdBy", "docType", "referenceNumber",
    "timestamp",
  ],
  users: [
    "id", "name", "username", "role", "mustChangePin",
    "permissionDashboard", "permissionCashier", "permissionServices",
    "permissionInventory", "permissionCustomers", "permissionUsers", "permissionSettings",
    "createdAt",
  ],
};

// nilai sensitif (hash PIN/salt) tidak pernah diekspor ke CSV
function csvEscape(v: unknown): string {
  const s = v === null || v === undefined ? "" : String(v);
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

export function entitiesToCsv(entity: BackupEntity, data: Record<string, unknown>): string {
  const rows = Array.isArray(data[entity]) ? (data[entity] as Record<string, unknown>[]) : [];
  const cols = CSV_COLUMNS[entity];
  const lines = [cols.join(",")];
  for (const r of rows) {
    lines.push(cols.map((c) => csvEscape(r[c])).join(","));
  }
  return "\uFEFF" + lines.join("\r\n"); // BOM agar Excel membaca UTF-8
}

// Parser CSV mini: dukung kutip, koma di dalam kutip, kutip ganda, \r\n
export function parseCsv(text: string): Record<string, string>[] {
  const clean = text.replace(/^\uFEFF/, "");
  const rows: string[][] = [];
  let cur: string[] = [];
  let field = "";
  let inQuotes = false;
  for (let i = 0; i < clean.length; i++) {
    const ch = clean[i];
    if (inQuotes) {
      if (ch === '"') {
        if (clean[i + 1] === '"') {
          field += '"';
          i++;
        } else inQuotes = false;
      } else field += ch;
    } else if (ch === '"') {
      inQuotes = true;
    } else if (ch === ",") {
      cur.push(field);
      field = "";
    } else if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && clean[i + 1] === "\n") i++;
      cur.push(field);
      field = "";
      if (cur.length > 1 || cur[0] !== "") rows.push(cur);
      cur = [];
    } else field += ch;
  }
  cur.push(field);
  if (cur.length > 1 || cur[0] !== "") rows.push(cur);

  if (!rows.length) return [];
  const headers = rows[0].map((h) => h.trim());
  return rows.slice(1).map((r) => {
    const obj: Record<string, string> = {};
    headers.forEach((h, i) => (obj[h] = r[i] ?? ""));
    return obj;
  });
}

// CSV → payload satu entitas (dipipakan ke importBackup dengan entitas tunggal)
export function csvRowsToPayload(entity: BackupEntity, rows: Record<string, string>[]) {
  const cols = CSV_COLUMNS[entity];
  const out: Record<string, unknown>[] = [];
  for (const row of rows) {
    const obj: Record<string, unknown> = {};
    for (const c of cols) {
      const raw = row[c];
      if (raw === undefined) continue;
      obj[c] = raw;
    }
    out.push(obj);
  }
  return { [entity]: out };
}
