"use client";

// D75 — layar BOOTSTRAP pra-login: bila token GitHub belum ada saat aplikasi
// dibuka, layar ini menggantikan LoginScreen. Pemilik toko memasukkan token &
// repo SEKALI di sini → server menguji koneksi, menyimpan kredensial, lalu
// langsung menjalankan sinkronisasi D74 (DB kosong + repo punya cadangan →
// pulih otomatis). Setelah itu login berjalan normal dengan akun asli yang
// kembali bersama database yang dipulihkan.
// "Lewati dulu" tersedia untuk toko yang memang belum pakai backup GitHub —
// ditandai per sesi (sessionStorage) agar tidak memaksa tiap buka aplikasi.
//
// D85 — OTOMATIS PENUH (permintaan pemilik): "dialog pra login dibuat auto.
// alurnya yaitu ambil token dari vercel setelah itu restore ke cadangan
// terakhir. dialog tidak perlu ditampilkan kecuali ada error". Urutan baru:
//   1. Saat layar muncul, server ditanya dulu (GET bootstrap): bila token
//      default + repo saran tersedia (env Vercel / file / jembatan) → POST
//      { auto: true } LANGSUNG dijalankan tanpa form — splash kecil
//      "menghubungkan otomatis" saja.
//   2. Sukses (dipulihkan / repo kosong / factory reset) → LANGSUNG ke halaman
//      login tanpa dialog dan tanpa layar sukses (cukup toast).
//   3. Gagal (token tidak ada / koneksi / pulihkan ditolak) → form manual
//      D85 (form D75) tampil dengan BANNER MERAH penjelas di atasnya — inilah
//      "dialog hanya saat error". Form tetap terisi default sehingga pemilik
//      cukup menekan tombol, atau memilih "Lewati dulu".
import { useEffect, useRef, useState } from "react";
import { CheckCircle2, CloudOff, Loader2, ShieldAlert, Wrench } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"; // D78 — dialog pilihan pulihkan/skip
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { SUGGESTED_REPO } from "@/lib/app-types"; // D75 — repo default (bisa diganti)

type BootstrapResponse = {
  ok?: boolean;
  error?: string;
  needsConfirm?: boolean; // D78 — data tidak kosong → tampilkan dialog pilihan
  repo?: { fullName: string; isPrivate: boolean; emptyRepo?: boolean };
  restored?: boolean;
  restoredFile?: string | null;
  restoreError?: string | null; // D78 — pesan gagal pulihkan paksa
  noBackups?: boolean; // D85 — repo valid tapi belum punya cadangan (bukan error)
  suppressedRestore?: boolean; // D85 — pulihkan dilewati (factory reset)
  autoMode?: boolean; // D85 — respons berasal dari mode otomatis
  autoRestore?: boolean;
  autoBackupOnChange?: boolean; // D86 — auto-backup per-perubahan diaktifkan otomatis saat koneksi
};

export function BootstrapScreen({
  shopName,
  onDone,
  onSkip,
}: {
  shopName: string;
  onDone: () => void;
  onSkip: () => void;
}) {
  const { toast } = useToast();
  const [token, setToken] = useState("");
  const [repo, setRepo] = useState(SUGGESTED_REPO); // D75 — terisi default, bebas diubah
  const [branch, setBranch] = useState("main");
  const [folder, setFolder] = useState("fixplus-backup");
  const [autoRestore, setAutoRestore] = useState(true);
  // D75 — token default di sisi server (db/deployment-defaults.json): nilai
  // token tidak pernah dikirim ke browser. Browser hanya tahu ADA/TIDAKNYA
  // (boolean) lewat GET bootstrap; server memakai tokennya saat submit.
  const [hasSuggestedToken, setHasSuggestedToken] = useState(false);
  const [useDefaultToken, setUseDefaultToken] = useState(false);
  const [busy, setBusy] = useState(false);
  const [success, setSuccess] = useState<BootstrapResponse | null>(null);
  // D78 — kondisi data lokal (null = belum diketahui) + dialog konfirmasi
  // "Tetap Pulihkan / Skip" saat data toko TIDAK kosong.
  const [businessEmpty, setBusinessEmpty] = useState<boolean | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  // D85 — fase layar: "auto" = splash penghubungan otomatis (tanpa form),
  // "form" = form manual (fallback saat otomatis tidak mungkin / gagal).
  const [phase, setPhase] = useState<"auto" | "form">("auto");
  const [autoStatus, setAutoStatus] = useState("Menyiapkan pemulihan otomatis…");
  const [autoError, setAutoError] = useState<string | null>(null);
  // D85 — pengaman StrictMode/double-effect: POST auto TIDAK boleh dua kali
  // (panggilan kedua akan ditolak 409 karena kredensial sudah tersimpan).
  const autoStarted = useRef(false);

  // D85 — pemulihan otomatis pra-login: POST { auto: true } → server mengambil
  // token + repo dari default server (Vercel env / file / jembatan) lalu
  // memulihkan cadangan terakhir. Sukses → langsung ke halaman login (tanpa
  // dialog, cukup toast). Gagal → kembali ke form manual dengan banner error.
  async function runAutoConnect() {
    try {
      const res = await fetch("/api/github/bootstrap", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ auto: true }),
      });
      const data = (await res.json()) as BootstrapResponse;
      if (res.ok && data.ok) {
        if (data.noBackups) {
          // Repo terhubung tapi belum punya cadangan — bukan error: lanjut
          // login, backup pertama nanti akan mengisi repo.
          toast({
            title: "GitHub terhubung otomatis",
            description:
              "Repo belum punya cadangan — data toko akan dibackup ke sana." +
              (data.autoBackupOnChange ? " Auto-backup aktif tiap ada perubahan data." : ""),
          });
          onDone();
          return;
        }
        if (data.restoreError) {
          // Koneksi berhasil tapi PEMULIHAN gagal — ini error → tampilkan form
          // manual dengan penjelasan (aturan pemilik: dialog hanya saat error).
          setAutoError(data.restoreError);
          setPhase("form");
          return;
        }
        toast(
          data.restored
            ? {
                title: "Cadangan terakhir dipulihkan otomatis",
                description:
                  [data.restoredFile, data.autoBackupOnChange ? "Auto-backup aktif tiap ada perubahan data." : ""]
                    .filter(Boolean)
                    .join(" · ") || undefined,
              }
            : {
                title: "GitHub terhubung otomatis",
                description:
                  (data.suppressedRestore
                    ? "Pemulihan dilewati — factory reset pernah berjalan di perangkat ini."
                    : "") +
                  (data.autoBackupOnChange ? " Auto-backup aktif tiap ada perubahan data." : "") ||
                  undefined,
              }
        );
        onDone();
        return;
      }
      setAutoError(data.error ?? "Gagal menghubungkan GitHub otomatis");
      setPhase("form");
    } catch {
      setAutoError("Tidak dapat terhubung ke server");
      setPhase("form");
    }
  }

  // Cek ketersediaan token default server sekali saat layar muncul.
  // D76 — sekaligus ambil saran repo/branch/folder (bukan rahasia) dari env
  // hosting (Vercel) atau db/deployment-defaults.json agar form terisi
  // otomatis dan cukup satu klik "HUBUNGKAN & PULIHKAN".
  // D85 — bila token default + repo saran ADA, jangan tampilkan form sama
  // sekali: langsung jalankan pemulihan otomatis (dialog hanya saat error).
  useEffect(() => {
    let cancelled = false;
    fetch("/api/github/bootstrap")
      .then((r) => (r.ok ? r.json() : null))
      .then(
        (
          d: {
            businessEmpty?: boolean;
            hasSuggestedToken?: boolean;
            suggestedRepo?: string | null;
            suggestedBranch?: string | null;
            suggestedFolder?: string | null;
          } | null
        ) => {
          if (cancelled || !d) {
            if (!cancelled) setPhase("form");
            return;
          }
          if (typeof d.businessEmpty === "boolean") setBusinessEmpty(d.businessEmpty);
          if (d.hasSuggestedToken === true) {
            setHasSuggestedToken(true);
            setUseDefaultToken(true);
          }
          if (d.suggestedRepo) setRepo(d.suggestedRepo);
          if (d.suggestedBranch) setBranch(d.suggestedBranch);
          if (d.suggestedFolder) setFolder(d.suggestedFolder);
          // D85 — jalur otomatis: server punya token default + repo saran.
          if (d.hasSuggestedToken === true && d.suggestedRepo) {
            if (!autoStarted.current) {
              autoStarted.current = true;
              setAutoStatus("Menghubungkan GitHub otomatis & memulihkan cadangan terakhir…");
              void runAutoConnect();
              return;
            }
          }
          setPhase("form");
        }
      )
      .catch(() => {
        if (!cancelled) setPhase("form");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // D85 — pengaman macet: bila koneksi otomatis tidak selesai juga dalam 60
  // detik (jaringan sangat lambat), tampilkan form manual agar pemilik tidak
  // terkurung di splash. Respons yang akhirnya datang tetap diproses (sukses
  // tetap langsung ke login).
  useEffect(() => {
    if (phase !== "auto") return;
    const t = setTimeout(() => {
      setAutoError((prev) => prev ?? "Waktu tunggu koneksi otomatis habis — hubungkan manual di bawah.");
      setPhase("form");
    }, 60_000);
    return () => clearTimeout(t);
  }, [phase]);

  // D78 — force=true dipakai saat pemilik memilih "Tetap Pulihkan" di dialog
  // setelah server menolak karena data lokal tidak kosong (needsConfirm).
  async function handleSubmit(force = false) {
    if (!repo.trim()) {
      toast({ title: "Repo wajib diisi!", variant: "destructive" });
      return;
    }
    if (!useDefaultToken && !token.trim()) {
      toast({
        title: "Token wajib diisi — atau nyalakan token default server!",
        variant: "destructive",
      });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/github/bootstrap", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          token: useDefaultToken ? undefined : token,
          useDefaultToken,
          repo,
          branch,
          folder,
          autoRestore,
          force, // D78
        }),
      });
      const data = (await res.json()) as BootstrapResponse;
      // D78 — data toko tidak kosong → JANGAN hanya toast error: buka dialog
      // pilihan "Tetap Pulihkan / Skip" sesuai permintaan pemilik.
      if (res.status === 403 && data.needsConfirm) {
        setConfirmOpen(true);
        return;
      }
      if (!res.ok || !data.ok) {
        toast({ title: data.error ?? "Gagal menghubungkan GitHub", variant: "destructive" });
        return;
      }
      setSuccess(data);
    } catch {
      toast({ title: "Tidak dapat terhubung ke server", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  if (success) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-accent/60 to-background p-6">
        <div className="w-full max-w-[450px] rounded-3xl bg-card p-8 shadow-lg">
          <div className="flex flex-col items-center gap-5">
            <div className="flex size-16 items-center justify-center rounded-full bg-emerald-500/10">
              <CheckCircle2 className="size-9 text-emerald-600" aria-hidden />
            </div>
            <div className="text-center">
              <p className="text-[22px] font-black">GitHub Terhubung</p>
              <p className="text-sm font-medium text-muted-foreground">
                Repo <span className="font-bold">{success.repo?.fullName}</span>
                {success.repo?.isPrivate ? " (privat)" : " (PUBLIK — disarankan ganti ke privat)"}
              </p>
            </div>
            <Separator />
            <div className="w-full rounded-xl bg-muted p-4 text-sm leading-relaxed">
              {success.restored ? (
                <>
                  <p className="font-bold text-emerald-700 dark:text-emerald-400">
                    Data toko berhasil dipulihkan
                  </p>
                  <p className="mt-1 text-muted-foreground">
                    Sumber: <span className="font-mono text-xs">{success.restoredFile}</span>
                  </p>
                  <p className="mt-2 text-muted-foreground">
                    Silakan masuk dengan akun &amp; PIN yang biasa Anda pakai.
                  </p>
                  {success.autoBackupOnChange && (
                    <p className="mt-1 text-muted-foreground">
                      Auto-backup per-perubahan data aktif — setiap perubahan dibackup sendiri ke
                      GitHub.
                    </p>
                  )}
                </>
              ) : (
                <>
                  <p className="font-bold">Belum ada data yang dipulihkan</p>
                  {success.restoreError ? (
                    <p className="mt-1 font-medium text-destructive">{success.restoreError}</p>
                  ) : (
                    <p className="mt-1 text-muted-foreground">
                      Repo mungkin masih kosong — mulai dari sini. Setiap perubahan data akan
                      otomatis dibackup{success.autoRestore === false ? " (Pulihkan Otomatis saat ini mati)" : ""}.
                    </p>
                  )}
                </>
              )}
            </div>
            <Button onClick={onDone} className="h-12 w-full rounded-xl text-sm font-bold tracking-widest">
              LANJUT KE MASUK
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (phase === "auto") {
    // D85 — splash penghubungan otomatis: bukan dialog, tidak butuh aksi.
    // Bila prosesnya gagal/tapal batas 60 detik, form manual tampil sendiri
    // dengan banner error (lihat fase "form" di bawah).
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-accent/60 to-background p-6">
        <div className="flex w-full max-w-[450px] flex-col items-center gap-5 rounded-3xl bg-card p-8 text-center shadow-lg">
          <div className="flex size-16 items-center justify-center rounded-full bg-primary/10">
            <Wrench className="size-9 text-primary" aria-hidden />
          </div>
          <p className="text-2xl font-black">{shopName}</p>
          <Loader2 className="size-8 animate-spin text-primary" aria-hidden />
          <p className="text-sm font-medium text-muted-foreground">{autoStatus}</p>
          <p className="text-xs text-muted-foreground">
            Token diambil otomatis dari server (Vercel), lalu cadangan terakhir
            dipulihkan. Layar ini tidak perlu Anda sentuh — bila terjadi
            kegagalan, layar hubungkan manual akan muncul dengan penjelasan.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-accent/60 to-background p-6">
      <div className="w-full max-w-[450px] rounded-3xl bg-card p-8 shadow-lg">
        <div className="flex flex-col items-center gap-5">
          <div className="flex size-16 items-center justify-center rounded-full bg-primary/10">
            <Wrench className="size-9 text-primary" aria-hidden />
          </div>
          <div className="text-center">
            <p className="text-2xl font-black">{shopName}</p>
            <p className="text-sm font-medium text-muted-foreground">
              Hubungkan Backup GitHub Sebelum Masuk
            </p>
          </div>
          {/* D85 — banner error: form manual hanya tampil saat pemulihan
              otomatis tidak mungkin/gagal, jadi penyebabnya WAJIB terlihat. */}
          {autoError ? (
            <div className="flex w-full items-start gap-3 rounded-xl border border-destructive/50 bg-destructive/10 p-3 text-xs leading-relaxed text-destructive">
              <ShieldAlert className="mt-0.5 size-4 shrink-0" aria-hidden />
              <p>
                <b>Pemulihan otomatis gagal.</b> {autoError} Kolom di bawah sudah
                terisi dari pengaturan server — periksa lalu tekan tombol
                hubungkan, atau pilih "Lewati dulu" untuk masuk tanpa GitHub.
              </p>
            </div>
          ) : null}
          <div className="flex w-full items-start gap-3 rounded-xl border border-amber-300 bg-amber-50 p-3 text-xs leading-relaxed text-amber-950 dark:border-amber-500/40 dark:bg-amber-950/40 dark:text-amber-100">
            <CloudOff className="mt-0.5 size-4 shrink-0" aria-hidden />
            {/* D78 — pesan menyesuaikan kondisi data lokal. */}
            {businessEmpty === false ? (
              <p>
                Perangkat ini <b>sudah memiliki data</b> &amp; GitHub belum terhubung. Setelah
                menekan tombol di bawah akan muncul pilihan: <b>Tetap Pulihkan</b> (data lokal
                diganti cadangan terbaru dari repo — salinan keamanan dibuat otomatis) atau
                <b> Skip</b>. Token tersimpan aman di perangkat.
              </p>
            ) : (
              <p>
                Data toko masih kosong &amp; GitHub belum terhubung. Masukkan token &amp; repo yang
                sama seperti sebelumnya — cadangan terakhir akan <b>dipulihkan otomatis</b> sebelum
                Anda masuk. Token tersimpan aman di perangkat dan tidak hilang saat reset.
              </p>
            )}
          </div>
          <Separator />
          <div className="flex w-full flex-col gap-4">
            {/* D75 — token default server: tidak dikirim ke browser, dipakai
                langsung di server saat submit. Matikan untuk menempel token
                lain secara manual. */}
            {hasSuggestedToken ? (
              <div className="flex items-center justify-between rounded-xl bg-muted p-3">
                <div className="pr-3">
                  <p className="text-sm font-bold">Gunakan token default server</p>
                  <p className="text-xs text-muted-foreground">
                    Token backup bawaan tersimpan di server ini (environment variable hosting,
                    jembatan token Vercel, atau file deployment-defaults) — nilai aslinya tidak
                    pernah dikirim ke browser.
                  </p>
                </div>
                <Switch
                  checked={useDefaultToken}
                  onCheckedChange={setUseDefaultToken}
                  aria-label="Gunakan token default server"
                />
              </div>
            ) : null}
            {!useDefaultToken ? (
              <div className="space-y-2">
                <Label htmlFor="gh-token">Token GitHub (Personal Access Token)</Label>
                <Input
                  id="gh-token"
                  type="password"
                  placeholder="ghp_... / github_pat_..."
                  value={token}
                  onChange={(e) => setToken(e.target.value)}
                  className="h-11 rounded-xl font-mono"
                  autoComplete="off"
                />
              </div>
            ) : null}
            <div className="space-y-2">
              <Label htmlFor="gh-repo">Repo Backup</Label>
              <Input
                id="gh-repo"
                placeholder="owner/repo — mis. budi/fixplus-backup"
                value={repo}
                onChange={(e) => setRepo(e.target.value)}
                className="h-11 rounded-xl"
                autoComplete="off"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="gh-branch">Branch</Label>
                <Input
                  id="gh-branch"
                  value={branch}
                  onChange={(e) => setBranch(e.target.value)}
                  className="h-11 rounded-xl"
                  autoComplete="off"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gh-folder">Folder di Repo</Label>
                <Input
                  id="gh-folder"
                  value={folder}
                  onChange={(e) => setFolder(e.target.value)}
                  className="h-11 rounded-xl"
                  autoComplete="off"
                />
              </div>
            </div>
            <div className="flex items-center justify-between rounded-xl bg-muted p-3">
              <div className="pr-3">
                <p className="text-sm font-bold">Pulihkan Otomatis</p>
                <p className="text-xs text-muted-foreground">
                  Database kosong / lebih tua dari repo → otomatis dipulihkan saat aplikasi dibuka.
                </p>
              </div>
              <Switch
                checked={autoRestore}
                onCheckedChange={setAutoRestore}
                aria-label="Pulihkan Otomatis"
              />
            </div>
            <Button
              onClick={() => void handleSubmit()}
              disabled={busy}
              className="h-12 w-full rounded-xl text-sm font-bold tracking-widest"
            >
              {busy ? (
                <>
                  <Loader2 className="size-4 animate-spin" aria-hidden />
                  MENGUJI &amp; MEMULIHKAN...
                </>
              ) : (
                "HUBUNGKAN & PULIHKAN"
              )}
            </Button>
            <button
              type="button"
              onClick={onSkip}
              disabled={busy}
              className="text-center text-xs font-semibold text-muted-foreground underline-offset-4 hover:text-foreground hover:underline"
            >
              Lewati dulu — masuk tanpa GitHub (bisa diatur nanti di Pengaturan)
            </button>
          </div>
        </div>
      </div>

      {/* ===== D78 — dialog pilihan saat data toko TIDAK kosong ===== */}
      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Data toko tidak kosong — tetap pulihkan?</AlertDialogTitle>
            <AlertDialogDescription>
              Perangkat ini sudah memiliki data. Melanjutkan akan MENGGANTI seluruh data lokal
              dengan cadangan terbaru dari repo GitHub (bukan digabung). Database saat ini otomatis
              disalin dulu sebagai berkas keamanan di server, dan keputusan ini tercatat di Log
              Aktivitas.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            {/* D78 — Skip = LEWATI SELURUH LANGKAH bootstrap dan langsung ke
                halaman login (permintaan pemilik) — bukan sekadar menutup
                dialog. onSkip menandai sessionStorage agar layar setup tidak
                muncul lagi sesi ini; koneksi GitHub bisa diatur nanti di
                Pengaturan setelah masuk sebagai Admin. */}
            <AlertDialogCancel
              disabled={busy}
              onClick={() => onSkip()}
              className="sm:flex-1 sm:justify-center"
            >
              Skip — langsung masuk ke aplikasi
            </AlertDialogCancel>
            <AlertDialogAction
              disabled={busy}
              onClick={(e) => {
                e.preventDefault();
                setConfirmOpen(false);
                void handleSubmit(true);
              }}
            >
              {busy ? "Memulihkan…" : "Tetap Pulihkan"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
