import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { dayKeyWIB } from "@/lib/format";
import { OPEN_REPAIR_STATUSES } from "@/lib/part-warning";
import { parseRange, resolveReporter } from "@/lib/report-utils";
import { serviceIdOf, difficultyPoints } from "@/lib/repair-utils";

// D48/5A.4 + 5A.5 — Kartu Servis & Kinerja Teknisi.
// GET /api/reports/services?from=YYYY-MM-DD&to=YYYY-MM-DD&requesterUsername=…
//  - aktif      : tiket berjalan (ANTRI→DIKERJAKAN) — jumlah per status + daftar;
//  - belumDiambil: status SELESAI (unit siap, menunggu bayar/diambil) + umur hari
//                 (sorot > 30 hari sesuai rencana 5A.4);
//  - garansi    : status DIAMBIL dengan warrantyDays > 0 yang MASIH berjalan
//                 (jawaban f: laporan masa garansi dulu — klaim garansi di 5D);
//  - kinerja    : per teknisi dalam rentang (tiket selesai: SELESAI/DIAMBIL dengan
//                 completedAt dalam rentang) — jumlah selesai, omzet jasa, poin.

const DAY_MS = 24 * 60 * 60 * 1000;

export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const reporter = await resolveReporter(sp.get("requesterUsername"));
    if (!reporter) {
      return NextResponse.json({ error: "Sesi tidak dikenal — masuk ulang" }, { status: 401 });
    }
    const today = dayKeyWIB(new Date());
    const { from, to, start, end } = parseRange(sp.get("from"), sp.get("to"), today);
    const now = Date.now();

    const repairs = await db.repairRecord.findMany({
      orderBy: { createdAt: "desc" },
      select: {
        id: true, createdAt: true, updatedAt: true, completedAt: true,
        customerName: true, customerPhone: true, deviceModel: true,
        status: true, technicianName: true, serviceFee: true,
        difficulty: true, pointsReward: true, warrantyDays: true,
        totalPrice: true, downPayment: true,
      },
    });

    const umurHari = (d: Date | null | undefined) =>
      d ? Math.max(0, Math.floor((now - new Date(d).getTime()) / DAY_MS)) : 0;

    // --- tiket aktif (berjalan) ---
    const aktif = repairs
      .filter((r) => OPEN_REPAIR_STATUSES.includes(r.status))
      .map((r) => ({
        id: r.id,
        serviceId: serviceIdOf(r.createdAt),
        customerName: r.customerName,
        deviceModel: r.deviceModel,
        status: r.status,
        teknisi: r.technicianName ?? null,
        umurHari: umurHari(r.createdAt),
        total: r.totalPrice,
      }));
    const aktifPerStatus = OPEN_REPAIR_STATUSES.map((s) => ({
      status: s,
      count: aktif.filter((a) => a.status === s).length,
    }));

    // --- SELESAI belum diambil ---
    const belumDiambil = repairs
      .filter((r) => r.status === "SELESAI")
      .map((r) => ({
        id: r.id,
        serviceId: serviceIdOf(r.createdAt),
        customerName: r.customerName,
        deviceModel: r.deviceModel,
        completedAt: r.completedAt ?? r.updatedAt,
        umurHari: umurHari(r.completedAt ?? r.updatedAt),
        total: r.totalPrice,
      }))
      .sort((a, b) => b.umurHari - a.umurHari)
      .slice(0, 50);

    // --- masih dalam masa garansi (status DIAMBIL, warrantyDays > 0) ---
    const garansi = repairs
      .filter((r) => r.status === "DIAMBIL" && r.warrantyDays > 0 && r.completedAt)
      .map((r) => {
        const selesai = new Date(r.completedAt!).getTime();
        const berakhir = selesai + r.warrantyDays * DAY_MS;
        return {
          id: r.id,
          serviceId: serviceIdOf(r.createdAt),
          customerName: r.customerName,
          deviceModel: r.deviceModel,
          completedAt: r.completedAt!,
          warrantyDays: r.warrantyDays,
          berakhirPada: new Date(berakhir),
          sisaHari: Math.ceil((berakhir - now) / DAY_MS),
        };
      })
      .filter((g) => g.sisaHari >= 0)
      .sort((a, b) => a.sisaHari - b.sisaHari)
      .slice(0, 50);

    // --- kinerja teknisi (rentang) ---
    const kinerjaMap = new Map<string, { teknisi: string; selesai: number; omzetJasa: number; poin: number; sulit: number }>();
    for (const r of repairs) {
      if (!(r.status === "SELESAI" || r.status === "DIAMBIL")) continue;
      if (!r.completedAt) continue;
      const c = new Date(r.completedAt);
      if (c < start || c >= end) continue;
      const nama = r.technicianName?.trim() || "Tanpa Teknisi";
      const row = kinerjaMap.get(nama) ?? { teknisi: nama, selesai: 0, omzetJasa: 0, poin: 0, sulit: 0 };
      row.selesai += 1;
      row.omzetJasa += Math.max(0, r.serviceFee || 0);
      // D58 — poin kini dihitung lewat resolver: override pointsReward bila diisi,
      // selain itu otomatis dari kesulitan (Rendah 10 / Sedang 25 / Tinggi 50).
      // Sebelumnya memakai pointsReward mentah sehingga tiket tanpa override
      // (pointsReward = null, mayoritas kasus) selalu terhitung 0 poin.
      row.poin += difficultyPoints(r.difficulty, r.pointsReward);
      if (r.difficulty === "Tinggi") row.sulit += 1;
      kinerjaMap.set(nama, row);
    }

    return NextResponse.json({
      from,
      to,
      aktifTotal: aktif.length,
      aktifPerStatus,
      aktif: aktif.slice(0, 50),
      belumDiambilTotal: repairs.filter((r) => r.status === "SELESAI").length,
      belumDiambil,
      garansi,
      kinerja: [...kinerjaMap.values()].sort((a, b) => b.omzetJasa - a.omzetJasa),
    });
  } catch (e) {
    console.error("reports services GET error", e);
    return NextResponse.json({ error: "Gagal memuat laporan servis" }, { status: 500 });
  }
}
