import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { db } from "@/lib/db";
import { loadCreds, saveCreds, type AutoSettings } from "@/lib/gdrive";

// D67 — POST /api/gdrive/auto — simpan pengaturan backup otomatis harian:
// { requesterUsername, auto: { enabled, hour (0-23 Jakarta), method, keepLast } }
export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as {
    requesterUsername?: unknown;
    auto?: Partial<AutoSettings>;
  };
  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const a = body.auto ?? {};
  const hour = Math.trunc(Number(a.hour));
  if (!Number.isInteger(hour) || hour < 0 || hour > 23) {
    return errAction("Jam backup harus 0-23 (waktu Jakarta)", 400);
  }
  const keepLast = Math.trunc(Number(a.keepLast));
  if (!Number.isInteger(keepLast) || keepLast < 1 || keepLast > 90) {
    return errAction("Jumlah cadangan disimpan harus 1-90", 400);
  }
  const method = a.method === "oauth" || a.method === "sa" ? a.method : "auto";
  const current = (await loadCreds()).auto;
  const auto: AutoSettings = {
    enabled: Boolean(a.enabled ?? current?.enabled ?? false),
    hour,
    method,
    keepLast,
  };
  await saveCreds({ auto });
  await db.auditLog.create({
    data: {
      action: "GDRIVE_AUTO_SETTINGS",
      details: `Auto-backup ${auto.enabled ? "DIAKTIFKAN" : "DIMATIKAN"} — jam ${String(hour).padStart(2, "0")}:00 WIB, jalur ${method === "auto" ? "otomatis (OAuth dahulu)" : method === "oauth" ? "OAuth" : "Service Account"}, simpan ${keepLast} cadangan terakhir`,
      performedBy: actor.name,
    },
  });
  return NextResponse.json({ ok: true, auto });
}
