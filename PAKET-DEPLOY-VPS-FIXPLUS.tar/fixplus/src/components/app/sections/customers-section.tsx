"use client";

// CustomerSection.kt + CustomerViewModel.kt + AppViewModel(saveTechnician/deleteTechnician) → versi web (Tahap 2)
// Sub-tab 1: Pelanggan & Loyalitas (setia referensi: cari nama/telepon, urut Nama/Poin ▲▼,
// kartu poin, dialog detail + tombol Blast WA Promosi, form tambah/edit, konfirmasi hapus)
// Sub-tab 2: Manajemen Teknisi (referensi Android tidak punya layar CRUD teknisi —
// dibuatkan sub-tab mengikuti preseden D2 Tahap 1, lihat catatan D5)
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  CheckCircle2,
  Inbox,
  Megaphone,
  Plus,
  Search,
  X,
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableHeader } from "@/components/ui/table";
import {
  FinCountChip,
  FinFootTd,
  FinIndexTd,
  FinRow,
  FinSortTh,
  FinTd,
  FinTh,
  FinTfoot,
} from "@/components/app/fin-table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { isValidPhone } from "@/lib/phone"; // T3 revisi Tahap 2: validasi nomor WA 9–15 digit
import type { SafeUser } from "@/lib/app-types";

// Entity Customer.kt: name, phone (nomor WA), email="", address="", loyaltyPoints=0
type Customer = {
  id: number;
  name: string;
  phone: string;
  email: string;
  address: string;
  loyaltyPoints: number;
};

// Entity Technician.kt: name, phone="", isAvailable=true
type Technician = {
  id: number;
  name: string;
  phone: string;
  isAvailable: boolean;
  // D71 — tautan akun Pengguna (role Teknisi); null = profil tanpa akun
  userId?: number | null;
  accountUsername?: string | null;
};

type CustomerSortKey = "NAMA" | "POIN";

const CUSTOMER_SORT_OPTIONS: { key: CustomerSortKey; label: string }[] = [
  { key: "NAMA", label: "Nama" },
  { key: "POIN", label: "Poin" },
];

async function apiJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string }).error ?? "Terjadi kesalahan");
  return data as T;
}

export function CustomersSection({ user }: { user: SafeUser }) {
  return (
    <div className="space-y-4">
      <Tabs defaultValue="PELANGGAN">
        <TabsList className="rounded-xl">
          <TabsTrigger value="PELANGGAN" className="rounded-lg">Pelanggan</TabsTrigger>
          <TabsTrigger value="TEKNISI" className="rounded-lg">Teknisi</TabsTrigger>
        </TabsList>
        <TabsContent value="PELANGGAN" className="mt-4">
          <CustomersTab user={user} />
        </TabsContent>
        <TabsContent value="TEKNISI" className="mt-4">
          <TechniciansTab user={user} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ============================================================
// Sub-tab 1: Pelanggan & Loyalitas (CustomerSection.kt)
// ============================================================
function CustomersTab({ user }: { user: SafeUser }) {
  const { toast } = useToast();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortKey, setSortKey] = useState<CustomerSortKey>("NAMA");
  const [sortAscending, setSortAscending] = useState(true);

  // Dialog states (nama persis CustomerSection.kt)
  const [formOpen, setFormOpen] = useState(false);
  const [editCustomerId, setEditCustomerId] = useState(0);
  const [inputName, setInputName] = useState("");
  const [inputPhone, setInputPhone] = useState("");
  const [inputEmail, setInputEmail] = useState("");
  const [inputAddress, setInputAddress] = useState("");
  const [inputPoints, setInputPoints] = useState("0");
  const [saving, setSaving] = useState(false);

  const [detailCust, setDetailCust] = useState<Customer | null>(null);
  const [deleteCust, setDeleteCust] = useState<Customer | null>(null);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      const data = await apiJson<Customer[]>("/api/customers");
      setCustomers(data);
    } catch (e) {
      toast({ title: "Gagal memuat pelanggan", description: String(e instanceof Error ? e.message : e), variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    void load();
  }, [load]);

  // filter: nama (abaikan huruf besar/kecil) ATAU telepon — persis CustomerSection.kt
  const filteredCustomers = useMemo(() => {
    const filtered = customers.filter(
      (c) =>
        c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.phone.includes(searchQuery)
    );
    const sorted = [...filtered].sort((a, b) => {
      if (sortKey === "NAMA") return a.name.toLowerCase().localeCompare(b.name.toLowerCase());
      return a.loyaltyPoints - b.loyaltyPoints;
    });
    return sortAscending ? sorted : sorted.reverse();
  }, [customers, searchQuery, sortKey, sortAscending]);

  function sortBy(k: CustomerSortKey) {
    if (k === sortKey) setSortAscending((v) => !v);
    else {
      setSortKey(k);
      setSortAscending(true);
    }
  }

  // Footer total poin loyalitas (D10) — dari daftar yang tampil (ikut filter)
  const totalLoyaltyPoints = filteredCustomers.reduce((s, c) => s + c.loyaltyPoints, 0);

  function openAddDialog() {
    setEditCustomerId(0);
    setInputName("");
    setInputPhone("");
    setInputEmail("");
    setInputAddress("");
    setInputPoints("0");
    setFormOpen(true);
  }

  function openEditDialog(cust: Customer) {
    setEditCustomerId(cust.id);
    setInputName(cust.name);
    setInputPhone(cust.phone);
    setInputEmail(cust.email);
    setInputAddress(cust.address);
    setInputPoints(String(cust.loyaltyPoints));
    setFormOpen(true);
  }

  async function saveCustomer() {
    // D52: nama wajib, nomor WhatsApp OPSIONAL — divalidasi hanya bila diisi.
    if (inputName.trim() === "") return;
    // T3 (revisi Tahap 2): tolak nomor salah ketik pendek sebelum kirim ke server.
    if (inputPhone.trim() !== "" && !isValidPhone(inputPhone)) {
      toast({
        title: "Nomor WhatsApp tidak valid!",
        description: "Masukkan 9–15 digit angka, contoh: 08123456789.",
        variant: "destructive",
      });
      return;
    }
    try {
      setSaving(true);
      const payload = {
        name: inputName,
        phone: inputPhone,
        email: inputEmail,
        address: inputAddress,
        loyaltyPoints: Number.parseInt(inputPoints, 10) || 0, // toIntOrNull() ?: 0
        performedBy: user.name,
      };
      if (editCustomerId === 0) {
        await apiJson("/api/customers", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      } else {
        await apiJson(`/api/customers/${editCustomerId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      }
      toast({ title: editCustomerId === 0 ? "Pelanggan ditambahkan" : "Pelanggan diperbarui" });
      setFormOpen(false);
      await load();
    } catch (e) {
      toast({ title: "Gagal menyimpan pelanggan", description: String(e instanceof Error ? e.message : e), variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  async function confirmDeleteCustomer() {
    if (!deleteCust) return;
    try {
      await apiJson(`/api/customers/${deleteCust.id}?requesterUsername=${encodeURIComponent(user.username)}`, {
        method: "DELETE",
      });
      toast({ title: "Pelanggan dihapus" });
      await load();
    } catch (e) {
      toast({ title: "Gagal menghapus pelanggan", description: String(e instanceof Error ? e.message : e), variant: "destructive" });
    } finally {
      setDeleteCust(null);
    }
  }

  return (
    <div className="space-y-4">
      {/* Toolbar: judul + jumlah data + cari + urutkan (persis baris atas CustomerSection.kt) */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="me-auto flex items-center gap-2">
          <h2 className="text-base font-extrabold text-primary">Pelanggan &amp; Loyalitas</h2>
          <FinCountChip count={filteredCustomers.length} unit="pelanggan" />
        </div>
        <div className="relative w-full sm:w-64">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari pelanggan..."
            className="h-9 rounded-xl pl-8 pr-8"
            aria-label="Cari pelanggan"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery("")}
              aria-label="Bersihkan pencarian"
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-muted-foreground hover:text-foreground"
            >
              <X className="size-4" aria-hidden />
            </button>
          )}
        </div>
        <div className="flex gap-2 md:hidden">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="h-9 rounded-xl">
                Urut: {CUSTOMER_SORT_OPTIONS.find((o) => o.key === sortKey)?.label}
                <span aria-hidden>{sortAscending ? " ▲" : " ▼"}</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              {CUSTOMER_SORT_OPTIONS.map((o) => (
                <DropdownMenuItem key={o.key} onClick={() => sortBy(o.key)}>
                  {o.label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <Button
            variant="outline"
            size="icon"
            className="size-9 rounded-xl"
            onClick={() => setSortAscending((v) => !v)}
            aria-label={sortAscending ? "Urutan menaik" : "Urutan menurun"}
            title={sortAscending ? "Menaik" : "Menurun"}
          >
            {sortAscending ? <ArrowUp className="size-4" aria-hidden /> : <ArrowDown className="size-4" aria-hidden />}
          </Button>
        </div>
        <Button size="sm" className="h-9 rounded-xl" onClick={openAddDialog}>
          <Plus className="size-4" aria-hidden />
          Tambah Pelanggan
        </Button>
      </div>

      {loading ? (
        <p className="py-10 text-center text-sm text-muted-foreground">Memuat pelanggan…</p>
      ) : filteredCustomers.length === 0 ? (
        <EmptyState
          message={searchQuery ? "Tidak ada pelanggan cocok." : "Belum ada pelanggan terdaftar."}
          hint="Tekan “Tambah Pelanggan” untuk mendaftarkan pelanggan baru."
        />
      ) : (
        <>
          {/* Desktop: tabel standar industri keuangan (D10) — zebra, No. urut, header sticky
              bisa diurutkan, nomor WA mono, baris total poin di footer */}
          <div className="hidden overflow-x-auto rounded-2xl border bg-card shadow-sm md:block xl:overflow-x-visible">
            <Table>
              <TableHeader className="[&_tr]:border-b-0">
                <tr>
                  <FinTh corner="first" align="center" className="w-10">#</FinTh>
                  <FinSortTh label="Nama" k="NAMA" sortKey={sortKey} asc={sortAscending} onSort={sortBy} />
                  <FinTh>No. WhatsApp</FinTh>
                  <FinTh>Alamat</FinTh>
                  <FinSortTh label="Poin" k="POIN" sortKey={sortKey} asc={sortAscending} onSort={sortBy} align="right" />
                  <FinTh align="center" corner="last">Status</FinTh>
                </tr>
              </TableHeader>
              <TableBody>
                {filteredCustomers.map((cust, i) => (
                  <FinRow key={cust.id} zebra={i % 2 === 1} onClick={() => setDetailCust(cust)}>
                    <FinIndexTd>{i + 1}</FinIndexTd>
                    <FinTd>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setDetailCust(cust);
                        }}
                        className="text-left font-bold hover:text-primary hover:underline"
                      >
                        {cust.name}
                      </button>
                    </FinTd>
                    <FinTd className="font-mono text-[12px] text-muted-foreground">{cust.phone || "—"}</FinTd>
                    <FinTd className="max-w-[220px] truncate text-muted-foreground">{cust.address || "—"}</FinTd>
                    <FinTd className="text-right font-bold tabular-nums text-primary">{cust.loyaltyPoints}</FinTd>
                    <FinTd className="text-center">
                      <Badge className="gap-1 rounded-lg bg-success/15 text-success hover:bg-success/20">
                        <CheckCircle2 className="size-3" aria-hidden />
                        Aktif
                      </Badge>
                    </FinTd>
                  </FinRow>
                ))}
              </TableBody>
              <FinTfoot>
                <tr>
                  <FinFootTd colSpan={4}>Total {filteredCustomers.length} pelanggan</FinFootTd>
                  <FinFootTd className="text-right text-[12px] normal-case tracking-normal tabular-nums text-primary">
                    {totalLoyaltyPoints.toLocaleString("id-ID")} poin
                  </FinFootTd>
                  <FinFootTd aria-hidden />
                </tr>
              </FinTfoot>
            </Table>
          </div>

          {/* Mobile: kartu persis CustomerSection.kt */}
          <div className="grid gap-3 sm:grid-cols-2 md:hidden">
            {filteredCustomers.map((cust) => (
              <button
                key={cust.id}
                type="button"
                onClick={() => setDetailCust(cust)}
                className="rounded-2xl border bg-card p-4 text-left shadow-sm transition-shadow hover:shadow-md"
              >
                <p className="font-bold">{cust.name}</p>
                <div className="mt-2 flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-[13px] text-muted-foreground">Telp: {cust.phone || "—"}</p>
                    {cust.address && (
                      <p className="mt-0.5 text-xs text-muted-foreground">Alamat: {cust.address}</p>
                    )}
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <Badge className="rounded-full bg-primary-container text-on-primary-container">
                      {cust.loyaltyPoints} Poin
                    </Badge>
                    <CheckCircle2 className="size-5 text-success" aria-label="Status Aktif" />
                  </div>
                </div>
              </button>
            ))}
          </div>
        </>
      )}

      {/* Dialog tambah/edit (judul & label persis CustomerSection.kt) */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-h-[85dvh] overflow-y-auto rounded-2xl sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editCustomerId === 0 ? "Tambah Pelanggan Baru" : "Edit Detail Pelanggan"}</DialogTitle>
            <DialogDescription>
              {editCustomerId === 0
                ? "Daftarkan pelanggan baru beserta poin loyalitasnya."
                : "Perbarui data pelanggan yang sudah terdaftar."}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="cust-nama">Nama Pelanggan</Label>
              <Input id="cust-nama" value={inputName} onChange={(e) => setInputName(e.target.value)} placeholder="Contoh: Andi Wijaya" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="cust-wa">No WhatsApp (Opsional — Contoh: 08123456789)</Label>
              <Input id="cust-wa" value={inputPhone} onChange={(e) => setInputPhone(e.target.value)} inputMode="tel" placeholder="Boleh dikosongkan — contoh: 08123456789" />
              {/* T3: umpan balik langsung saat nomor terisi tapi tidak valid */}
              {inputPhone.trim() !== "" && !isValidPhone(inputPhone) && (
                <p className="text-[11px] font-medium text-destructive">
                  Nomor tidak valid — masukkan 9–15 digit angka (contoh: 08123456789).
                </p>
              )}
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="cust-email">Email (Opsional)</Label>
              <Input id="cust-email" type="email" value={inputEmail} onChange={(e) => setInputEmail(e.target.value)} placeholder="nama@email.com" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="cust-alamat">Alamat</Label>
              <Input id="cust-alamat" value={inputAddress} onChange={(e) => setInputAddress(e.target.value)} placeholder="Jl. Merdeka No. 10" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="cust-poin">Poin Loyalitas</Label>
              <Input id="cust-poin" value={inputPoints} onChange={(e) => setInputPoints(e.target.value)} inputMode="numeric" />
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setFormOpen(false)}>
              Batal
            </Button>
            {/* T3: Simpan nonaktif bila nomor DIISI tapi tidak valid (pola D5e — umpan balik jelas);
                D52: nomor kosong dibolehkan */}
            <Button
              onClick={saveCustomer}
              disabled={saving || inputName.trim() === "" || (inputPhone.trim() !== "" && !isValidPhone(inputPhone))}
            >
              Simpan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog detail pelanggan (persis CustomerDetailDialog.kt) */}
      <Dialog open={detailCust !== null} onOpenChange={(open) => !open && setDetailCust(null)}>
        <DialogContent className="rounded-2xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Detail Pelanggan</DialogTitle>
            <DialogDescription className="sr-only">Rincian data pelanggan.</DialogDescription>
          </DialogHeader>
          {detailCust && (
            <div className="space-y-3">
              <div>
                <p className="text-[11px] text-muted-foreground">Nama Pelanggan</p>
                <p className="text-base font-bold">{detailCust.name}</p>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-[11px] text-muted-foreground">No. WhatsApp / HP</p>
                  <p className="text-sm font-medium">{detailCust.phone || "—"}</p>
                </div>
                <div>
                  <p className="text-[11px] text-muted-foreground">Email</p>
                  <p className="text-sm font-medium">{detailCust.email || "-"}</p>
                </div>
              </div>
              <Separator />
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-[11px] text-muted-foreground">Alamat</p>
                  <p className="text-sm font-medium">{detailCust.address || "-"}</p>
                </div>
                <div>
                  <p className="text-[11px] text-muted-foreground">Poin Loyalitas</p>
                  <p className="text-sm font-bold text-primary">{detailCust.loyaltyPoints} Poin</p>
                </div>
              </div>
              <Separator />
              <Button
                className="w-full gap-2 rounded-lg bg-[#00796B] text-white hover:bg-[#00695F]"
                onClick={() => {
                  // template & konversi nomor persis CustomerSection.kt (adaptasi web: wa.me)
                  const templateMsg = `Halo *${detailCust.name}*, terima kasih telah menjadi pelanggan setia FixPlus! Anda memiliki *${detailCust.loyaltyPoints} poin loyalitas* aktif. Tukarkan poin Anda dengan potongan diskon servis HP menarik hari ini! Hubungi kami untuk info lebih lanjut.`;
                  let formattedPhone = detailCust.phone.trim();
                  if (formattedPhone.startsWith("0")) formattedPhone = "62" + formattedPhone.substring(1);
                  if (!formattedPhone.startsWith("62") && !formattedPhone.startsWith("+")) formattedPhone = "62" + formattedPhone;
                  window.open(`https://wa.me/${formattedPhone}?text=${encodeURIComponent(templateMsg)}`, "_blank", "noopener,noreferrer");
                }}
              >
                <Megaphone className="size-4" aria-hidden />
                Blast WA Promosi
              </Button>
            </div>
          )}
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              className="flex-1 border-destructive text-destructive hover:bg-destructive/10 hover:text-destructive"
              onClick={() => {
                setDeleteCust(detailCust);
                setDetailCust(null);
              }}
            >
              Hapus
            </Button>
            <Button
              className="flex-1"
              onClick={() => {
                if (detailCust) openEditDialog(detailCust);
                setDetailCust(null);
              }}
            >
              Edit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Konfirmasi hapus (teks persis CustomerSection.kt) */}
      <AlertDialog open={deleteCust !== null} onOpenChange={(open) => !open && setDeleteCust(null)}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Pelanggan</AlertDialogTitle>
            <AlertDialogDescription>
              Apakah Anda yakin ingin menghapus pelanggan &quot;{deleteCust?.name}&quot;? Tindakan ini tidak
              dapat dibatalkan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={confirmDeleteCustomer}
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ============================================================
// Sub-tab 2: Manajemen Teknisi (tanpa layar di referensi — keputusan D5)
// Entity + logika: Technician.kt, saveTechnician/deleteTechnician AppViewModel.kt
// ============================================================
function TechniciansTab({ user }: { user: SafeUser }) {
  const { toast } = useToast();
  // D71 — kelola teknisi (tambah/edit/hapus) khusus Admin; kasir & teknisi
  // hanya melihat daftar untuk penugasan tiket.
  const isAdmin = user.role === "Admin";
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [tSortAscending, setTSortAscending] = useState(true);

  const [formOpen, setFormOpen] = useState(false);
  const [editTechId, setEditTechId] = useState(0);
  const [editTechLinked, setEditTechLinked] = useState(false);
  const [inputName, setInputName] = useState("");
  const [inputPhone, setInputPhone] = useState("");
  const [inputAvailable, setInputAvailable] = useState(true);
  const [saving, setSaving] = useState(false);

  const [deleteTech, setDeleteTech] = useState<Technician | null>(null);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      const data = await apiJson<Technician[]>("/api/technicians");
      setTechnicians(data);
    } catch (e) {
      toast({ title: "Gagal memuat teknisi", description: String(e instanceof Error ? e.message : e), variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    void load();
  }, [load]);

  const filteredTechs = useMemo(() => {
    const list = technicians.filter((t) => t.name.toLowerCase().includes(searchQuery.toLowerCase()));
    const sorted = [...list].sort((a, b) => a.name.toLowerCase().localeCompare(b.name.toLowerCase()));
    return tSortAscending ? sorted : sorted.reverse();
  }, [technicians, searchQuery, tSortAscending]);

  // Header Nama bisa diklik untuk urutkan ▲▼ (D10)
  function sortTechBy() {
    setTSortAscending((v) => !v);
  }

  const availableCount = filteredTechs.filter((t) => t.isAvailable).length;
  const linkedCount = filteredTechs.filter((t) => t.accountUsername).length;

  function openAddDialog() {
    setEditTechId(0);
    setInputName("");
    setInputPhone("");
    setInputAvailable(true); // default Entities.kt: isAvailable = true
    setFormOpen(true);
  }

  function openEditDialog(tech: Technician) {
    setEditTechId(tech.id);
    setEditTechLinked(Boolean(tech.userId));
    setInputName(tech.name);
    setInputPhone(tech.phone);
    setInputAvailable(tech.isAvailable);
    setFormOpen(true);
  }

  async function saveTechnician() {
    if (inputName.trim() === "") return;
    // T3 (revisi Tahap 2): telepon teknisi tetap opsional, tapi bila diisi harus valid.
    if (inputPhone.trim() !== "" && !isValidPhone(inputPhone)) {
      toast({
        title: "Nomor telepon teknisi tidak valid!",
        description: "Kosongkan, atau masukkan 9–15 digit angka (contoh: 0812334455).",
        variant: "destructive",
      });
      return;
    }
    try {
      setSaving(true);
      const payload = {
        name: inputName,
        phone: inputPhone,
        isAvailable: inputAvailable,
        performedBy: user.name,
        requesterUsername: user.username, // D71 — server memverifikasi Admin
      };
      if (editTechId === 0) {
        await apiJson("/api/technicians", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      } else {
        await apiJson(`/api/technicians/${editTechId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      }
      toast({ title: editTechId === 0 ? "Teknisi ditambahkan" : "Teknisi diperbarui" });
      setFormOpen(false);
      await load();
    } catch (e) {
      toast({ title: "Gagal menyimpan teknisi", description: String(e instanceof Error ? e.message : e), variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  async function confirmDeleteTechnician() {
    if (!deleteTech) return;
    try {
      await apiJson(`/api/technicians/${deleteTech.id}?requesterUsername=${encodeURIComponent(user.username)}`, {
        method: "DELETE",
      });
      toast({ title: "Teknisi dihapus" });
      await load();
    } catch (e) {
      toast({ title: "Gagal menghapus teknisi", description: String(e instanceof Error ? e.message : e), variant: "destructive" });
    } finally {
      setDeleteTech(null);
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="me-auto flex items-center gap-2">
          <h2 className="text-base font-extrabold text-primary">Manajemen Teknisi</h2>
          <FinCountChip count={filteredTechs.length} unit="teknisi" />
        </div>
        <div className="relative w-full sm:w-64">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari nama teknisi..."
            className="h-9 rounded-xl pl-8 pr-8"
            aria-label="Cari nama teknisi"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery("")}
              aria-label="Bersihkan pencarian"
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-muted-foreground hover:text-foreground"
            >
              <X className="size-4" aria-hidden />
            </button>
          )}
        </div>
        {isAdmin && (
          <Button size="sm" className="h-9 rounded-xl" onClick={openAddDialog}>
            <Plus className="size-4" aria-hidden />
            Tambah Teknisi
          </Button>
        )}
      </div>
      <p className="text-[11px] leading-relaxed text-muted-foreground">
        {isAdmin
          ? "Tambah/edit/hapus teknisi khusus Admin. Teknisi berakun dibuat lewat Setting → Pengguna (role Teknisi) dan otomatis muncul di sini dengan nama yang selalu sinkron dengan akunnya."
          : "Daftar teknisi dikelola Admin. Akun role Teknisi otomatis muncul di sini untuk ditugaskan pada tiket servis."}
      </p>

      {loading ? (
        <p className="py-10 text-center text-sm text-muted-foreground">Memuat teknisi…</p>
      ) : filteredTechs.length === 0 ? (
        <EmptyState
          icon={<Inbox className="size-7 text-muted-foreground/50" aria-hidden />}
          message={searchQuery ? "Tidak ada teknisi cocok." : "Belum ada teknisi."}
          hint={
            searchQuery
              ? undefined
              : isAdmin
                ? "Tekan “Tambah Teknisi” untuk mendaftarkan teknisi (nama, telepon, status ketersediaan), atau buat akun role Teknisi di Setting → Pengguna — profilnya muncul otomatis di sini."
                : "Teknisi dikelola Admin — akun role Teknisi otomatis muncul di sini."
          }
        />
      ) : (
        <>
          {/* Desktop: tabel standar industri keuangan (D10) */}
          <div className="hidden overflow-x-auto rounded-2xl border bg-card shadow-sm md:block xl:overflow-x-visible">
            <Table>
              <TableHeader className="[&_tr]:border-b-0">
                <tr>
                  <FinTh corner="first" align="center" className="w-10">#</FinTh>
                  <FinSortTh label="Nama Teknisi" k="NAMA" sortKey="NAMA" asc={tSortAscending} onSort={() => sortTechBy()} />
                  <FinTh>Telepon</FinTh>
                  <FinTh align="center">Status Ketersediaan</FinTh>
                  <FinTh align="center">Akun</FinTh>
                  <FinTh align="center" corner="last">Aksi</FinTh>
                </tr>
              </TableHeader>
              <TableBody>
                {filteredTechs.map((t, i) => (
                  <FinRow key={t.id} zebra={i % 2 === 1}>
                    <FinIndexTd>{i + 1}</FinIndexTd>
                    <FinTd className="font-bold">{t.name}</FinTd>
                    <FinTd className="font-mono text-[12px] text-muted-foreground">{t.phone || "—"}</FinTd>
                    <FinTd className="text-center">
                      {t.isAvailable ? (
                        <Badge className="gap-1 rounded-lg bg-success/15 text-success hover:bg-success/20">
                          <CheckCircle2 className="size-3" aria-hidden />
                          Tersedia
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="rounded-lg text-muted-foreground">
                          Tidak Tersedia
                        </Badge>
                      )}
                    </FinTd>
                    <FinTd className="text-center">
                      {t.accountUsername ? (
                        <Badge variant="outline" className="gap-1 rounded-lg font-mono text-[11px]">
                          @{t.accountUsername}
                        </Badge>
                      ) : (
                        <span className="text-[11px] text-muted-foreground">Tanpa akun</span>
                      )}
                    </FinTd>
                    <FinTd className="text-center">
                      <div className="flex justify-center gap-1">
                        {isAdmin && (
                          <Button variant="outline" size="icon" className="size-8 rounded-lg" onClick={() => openEditDialog(t)} aria-label={`Edit ${t.name}`}>
                            <svg className="size-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
                          </Button>
                        )}
                        {isAdmin && (
                          <Button variant="outline" size="icon" className="size-8 rounded-lg text-destructive hover:text-destructive" onClick={() => setDeleteTech(t)} aria-label={`Hapus ${t.name}`}>
                            <svg className="size-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
                          </Button>
                        )}
                        {!isAdmin && <span className="text-[11px] text-muted-foreground">—</span>}
                      </div>
                    </FinTd>
                  </FinRow>
                ))}
              </TableBody>
              <FinTfoot>
                <tr>
                  <FinFootTd colSpan={4}>Total {filteredTechs.length} teknisi</FinFootTd>
                  <FinFootTd className="text-center text-[12px] normal-case tracking-normal tabular-nums">
                    {availableCount} tersedia · {linkedCount} tertaut akun
                  </FinFootTd>
                  <FinFootTd aria-hidden />
                </tr>
              </FinTfoot>
            </Table>
          </div>

          {/* Mobile: kartu dengan tombol aksi (pola kartu produk jasa) */}
          <div className="grid gap-3 sm:grid-cols-2 md:hidden">
            {filteredTechs.map((t) => (
              <div key={t.id} className="flex items-center gap-3 rounded-2xl border bg-card p-4 shadow-sm">
                <div className="min-w-0 flex-1">
                  <p className="font-bold">{t.name}</p>
                  <p className="mt-0.5 text-[13px] text-muted-foreground">{t.phone || "-"}</p>
                  <p className="mt-0.5 text-[11px] text-muted-foreground">
                    {t.accountUsername ? `Tertaut akun @${t.accountUsername}` : "Tanpa akun"}
                  </p>
                </div>
                {t.isAvailable ? (
                  <Badge className="gap-1 rounded-lg bg-success/15 text-success hover:bg-success/20">
                    <CheckCircle2 className="size-3" aria-hidden />
                    Tersedia
                  </Badge>
                ) : (
                  <Badge variant="outline" className="rounded-lg text-muted-foreground">
                    Tidak Tersedia
                  </Badge>
                )}
                {isAdmin && (
                  <div className="flex shrink-0 gap-1">
                    <Button variant="outline" size="icon" className="size-8 rounded-lg" onClick={() => openEditDialog(t)} aria-label={`Edit ${t.name}`}>
                      <svg className="size-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
                    </Button>
                    <Button variant="outline" size="icon" className="size-8 rounded-lg text-destructive hover:text-destructive" onClick={() => setDeleteTech(t)} aria-label={`Hapus ${t.name}`}>
                      <svg className="size-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      )}

      {/* Dialog tambah/edit teknisi */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-h-[85dvh] overflow-y-auto rounded-2xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editTechId === 0 ? "Tambah Teknisi Baru" : "Edit Teknisi"}</DialogTitle>
            <DialogDescription>
              {editTechId === 0
                ? "Daftarkan teknisi tanpa akun (mis. teknisi lepas) agar bisa ditugaskan pada tiket servis. Untuk teknisi berakun, buat akun role Teknisi di Setting → Pengguna — profilnya muncul otomatis di sini."
                : editTechLinked
                  ? "Teknisi ini tertaut akun pengguna — nama mengikuti akun. Telepon & status ketersediaan boleh diubah di sini."
                  : "Perbarui data teknisi yang sudah terdaftar."}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="tech-nama">Nama Teknisi</Label>
              <Input
                id="tech-nama"
                value={inputName}
                onChange={(e) => setInputName(e.target.value)}
                placeholder="Contoh: Rian Hidayat"
                disabled={editTechId !== 0 && editTechLinked}
              />
              {editTechId !== 0 && editTechLinked && (
                <p className="text-[11px] text-muted-foreground">
                  Nama tertaut akun — ubah lewat Setting → Pengguna agar selalu sinkron.
                </p>
              )}
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="tech-telp">No. Telepon</Label>
              <Input id="tech-telp" value={inputPhone} onChange={(e) => setInputPhone(e.target.value)} inputMode="tel" placeholder="0812334455" />
              {/* T3: telepon opsional — peringatan hanya bila diisi tapi tidak valid */}
              {inputPhone.trim() !== "" && !isValidPhone(inputPhone) && (
                <p className="text-[11px] font-medium text-destructive">
                  Nomor tidak valid — kosongkan atau isi 9–15 digit angka.
                </p>
              )}
            </div>
            <div className="flex items-center justify-between gap-3 rounded-xl border p-3">
              <div className="min-w-0">
                <Label htmlFor="tech-avail">Tersedia untuk ditugaskan</Label>
                <p className="mt-0.5 text-xs text-muted-foreground">Teknisi aktif menerima tiket servis baru.</p>
              </div>
              <Switch id="tech-avail" checked={inputAvailable} onCheckedChange={setInputAvailable} />
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setFormOpen(false)}>
              Batal
            </Button>
            {/* T3: blokir simpan hanya saat nomor diisi tapi tidak valid */}
            <Button
              onClick={saveTechnician}
              disabled={saving || inputName.trim() === "" || (inputPhone.trim() !== "" && !isValidPhone(inputPhone))}
            >
              Simpan
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Konfirmasi hapus teknisi (pola teks hapus pelanggan) */}
      <AlertDialog open={deleteTech !== null} onOpenChange={(open) => !open && setDeleteTech(null)}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Teknisi</AlertDialogTitle>
            <AlertDialogDescription>
              Apakah Anda yakin ingin menghapus teknisi &quot;{deleteTech?.name}&quot;? Tindakan ini tidak
              dapat dibatalkan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={confirmDeleteTechnician}
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function EmptyState({ message, hint, icon }: { message: string; hint?: string; icon?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed bg-card/60 px-6 py-14 text-center">
      <div className="mb-3 flex size-14 items-center justify-center rounded-2xl bg-muted">
        {icon ?? <Inbox className="size-7 text-muted-foreground/50" aria-hidden />}
      </div>
      <p className="text-sm font-semibold">{message}</p>
      {hint && <p className="mt-1 max-w-sm text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}
