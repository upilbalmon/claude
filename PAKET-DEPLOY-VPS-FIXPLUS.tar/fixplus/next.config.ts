import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // D86 — perkecil paket deploy (target: debian glibc + SQLite).
  // 1) Mesin kueri WASM Prisma untuk database lain (cockroachdb/postgresql/
  //    mysql/sqlserver) tidak pernah dimuat — aplikasi memakai SQLite dengan
  //    library engine (libquery_engine-debian-*.so.node). Varian sqlite
  //    SEMUA DIPERTAHANKAN.
  // 2) libvips varian musl dari sharp tidak pernah dimuat di debian glibc —
  //    varian linux-x64 (gnu) dipertahankan untuk optimasi gambar Next.
  // Keduanya dibawa node file tracing padahal mustahil terpakai; memangkasnya
  // memangkas ~62 MB isi mentah paket deploy tanpa efek fungsional apa pun.
  outputFileTracingExcludes: {
    "*": [
      "**/@prisma/client/runtime/query_engine_bg.cockroachdb*",
      "**/@prisma/client/runtime/query_compiler_bg.cockroachdb*",
      "**/@prisma/client/runtime/query_engine_bg.postgresql*",
      "**/@prisma/client/runtime/query_compiler_bg.postgresql*",
      "**/@prisma/client/runtime/query_engine_bg.mysql*",
      "**/@prisma/client/runtime/query_compiler_bg.mysql*",
      "**/@prisma/client/runtime/query_engine_bg.sqlserver*",
      "**/@prisma/client/runtime/query_compiler_bg.sqlserver*",
      "**/@img/sharp-libvips-linuxmusl-x64/**",
      // D87 — salinan kredensial token polos tidak dibawa ke artefak deploy
      // (runtime produksi membaca dari dirname(DATABASE_URL) + jembatan token;
      // salinan traced di standalone tidak pernah terbaca). Pemangkasan
      // definitif di scripts/prune-standalone.mjs karena Next tidak menerapkan
      // eksklusi pada trace instrumentation/next-server.
      "**/db/deployment-defaults.json",
      "**/db/github-credentials.json",
    ],
  },
};

export default nextConfig;
