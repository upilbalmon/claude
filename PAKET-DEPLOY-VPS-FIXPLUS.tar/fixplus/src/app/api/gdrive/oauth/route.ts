import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { loadCreds, saveCreds, requestOrigin } from "@/lib/gdrive";

// D67 — Kredensial OAuth Client (jalur A "Hubungkan Google").
// POST: simpan Client ID + Client Secret (klien), balas redirect URI yang
// WAJIB didaftarkan di Google Cloud Console → Authorized redirect URIs.
// DELETE: putuskan koneksi (hapus refresh token & folder) — Client ID/Secret
// tetap tersimpan agar bisa langsung tersambung ulang.
function originOf(req: NextRequest): string {
  return requestOrigin(req.nextUrl.toString(), req.headers);
}

export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as {
    requesterUsername?: unknown;
    clientId?: unknown;
    clientSecret?: unknown;
  };
  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const clientId = String(body.clientId ?? "").trim();
  const clientSecret = String(body.clientSecret ?? "").trim();
  if (!clientId || !clientSecret) {
    return errAction("Client ID dan Client Secret wajib diisi", 400);
  }
  if (!clientId.endsWith(".apps.googleusercontent.com")) {
    return errAction(
      "Client ID tidak valid — biasanya diakhiri .apps.googleusercontent.com (salin dari Google Cloud Console → Credentials → OAuth 2.0 Client ID)",
      400
    );
  }

  await saveCreds({
    oauth: {
      clientId,
      clientSecret,
      // reset koneksi lama bila kredensial diganti
      refreshToken: undefined,
      accessToken: undefined,
      accessTokenExpiry: undefined,
      email: undefined,
      folderId: undefined,
    },
  });
  return NextResponse.json({
    ok: true,
    redirectUri: `${originOf(req)}/api/gdrive/oauth/callback`,
  });
}

export async function DELETE(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as { requesterUsername?: unknown };
  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const c = await loadCreds();
  if (!c.oauth?.refreshToken) {
    return errAction("OAuth belum terhubung", 400);
  }
  await saveCreds({
    oauth: {
      clientId: c.oauth.clientId,
      clientSecret: c.oauth.clientSecret,
      refreshToken: undefined,
      accessToken: undefined,
      accessTokenExpiry: undefined,
      email: undefined,
      folderId: undefined,
    },
  });
  return NextResponse.json({ ok: true });
}
