// D18 — Saran alias struk (instan, offline, 0 biaya).
// Pola bengkel: alias = jenis part + nama unit — "LCD IPHONE 7G ORI QUALITY" → "lcd iphone 7",
// "Tempered Glass UniversalTG" → "tg universal", "Baterai Oppo A37 Original 2000mah" → "batre oppo a37".
// Hasil saran SELALU bisa diedit di form (alias = preferensi tiap bengkel); nama yang terlalu ribet
// dirapikan lewat tombol AI (POST /api/ai/alias).
// Catatan: file dipakai juga oleh skrip Node (type-stripping Node 24) → hanya sintaks TS erasable,
// tanpa import apa pun.

// Kata yang DILEWATI di posisi mana pun (penanda kualitas, warna, spek) — bukan penghenti.
const NOISE = new Set([
  // kualitas / asal
  "original", "ori", "orginal", "quality", "kwalitas", "kualitas", "new", "baru", "copy", "oem",
  "high", "replacement", "grade", "premium", "super", "plus-ori", "kw", "kw1", "kw2", "kw3",
  "bnib", "second", "bekas", "refurbish", " refurbished",
  // spek tak penting di struk
  "mah", "inch", "inc", "in", "volt", "ampere", "amper",
  // warna / finish
  "hitam", "putih", "black", "white", "gold", "silver", "merah", "biru", "blue", "red", "green",
  "hijau", "kuning", "yellow", "pink", "ungu", "purple", "abu", "gray", "grey", "rose", "transparent",
  "transparan", "clear",
  // kata sambung / pengisi
  "untuk", "buat", "dari", "type", "tipe", "model", "unit", "hp", "phone", "handphone",
  "sparepart", "spare", "part", "retail",
  // keterangan part lcd/ts
  "on", "off", "touch", "ts",
]);

// Kata yang MENGHENTI pengambilan nama unit (kata jualan/opsional di ekor nama).
const STOP = new Set(["murah", "bagus", "best", "good", "ready", "stock", "promo", "garansi", "gratis", "harga", "sale", "diskon"]);

// Kata pertama → singkatan ala bengkel. Token di luar peta dipakai apa adanya.
const PART_HEAD: Record<string, string> = {
  tempered: "tg", temperedglass: "tg", tg: "tg",
  lcd: "lcd",
  touchscreen: "ts", ts: "ts",
  baterai: "batre", batrai: "batre", batre: "batre", battery: "batre", battrai: "batre",
  flexible: "flex", flexibel: "flex", flexy: "flex", flex: "flex",
  ic: "ic",
  kamera: "kamera", camera: "kamera", cam: "kamera",
  speaker: "speaker", buzzer: "speaker", earphone: "speaker",
  mic: "mic", mick: "mic", microphone: "mic",
  konektor: "konektor",
  charger: "charger",
  housing: "casing", casing: "casing", backdoor: "backdoor", backglass: "kaca belakang",
  sarung: "sarung", softcase: "softcase", pouch: "sarung",
  sim: "sim", tray: "sim tray",
  antenna: "antena", antena: "antena",
  kaca: "kaca",
  anti: "anti",
  waterproof: "anti air",
  glassonly: "kaca lcd", glasslayar: "kaca lcd",
};

// Pasangan token 1+2 → frasa part khusus (konsumsi 2 token).
const PART_PAIR: Record<string, Record<string, string>> = {
  tempered: { glass: "tg" },
  lcd: { ts: "lcd ts", touchscreen: "lcd ts", touch: "lcd ts" },
  kaca: { belakang: "kaca belakang", back: "kaca belakang" },
  anti: { gores: "anti gores" },
  sim: { tray: "sim tray" },
  konektor: { charger: "konektor charger", cas: "konektor charger", charging: "konektor charger" },
  kabel: { flex: "flex", charger: "flex charger", data: "kabel data" },
};

// Sinonim part dipakai lagi di belakang nama → buang (mis. "Tempered Glass UniversalTG").
const PART_SYNONYMS: Record<string, Set<string>> = {
  tg: new Set(["tg", "tempered", "glass", "temperedglass"]),
  lcd: new Set(["lcd", "fullset"]),
  ts: new Set(["ts", "touch", "touchscreen"]),
  batre: new Set(["batre", "baterai", "batrai", "battery"]),
  flex: new Set(["flex", "flexible", "flexibel", "flexy"]),
  "flex charger": new Set(["flex", "charger", "kabel"]),
  "kabel data": new Set(["kabel", "data"]),
};

function tokenize(nama: string): string[] {
  return nama
    // lindungi merek Apple agar tidak dipecah camelCase ("iPhone" → bukan "i phone")
    .replace(/(iphone|ipad|ipod)/gi, (m) => m.toLowerCase())
    // pisah camelCase huruf→huruf besar agar "UniversalTG" → "universal tg";
    // digit TIDAK dipisah agar kode model "7G"/"5A" tetap satu token
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .toLowerCase()
    .split(/[^a-z0-9+]+/)
    .filter(Boolean);
}

function potongPerKata(s: string, maks: number): string {
  if (s.length <= maks) return s;
  const potong = s.slice(0, maks);
  const spasiTerakhir = potong.lastIndexOf(" ");
  return (spasiTerakhir > 8 ? potong.slice(0, spasiTerakhir) : potong).trim();
}

/**
 * Saran alias dari nama lengkap barang. Bila pola tidak dikenali, hasil bisa kosong —
 * pengguna tinggal mengetik sendiri atau menekan tombol AI.
 */
export function saranAlias(nama: string): string {
  const tokens = tokenize(nama);
  if (tokens.length === 0) return "";

  // lewati kata kualitas di depan ("ORI LCD IPHONE 7")
  let start = 0;
  while (start < tokens.length && NOISE.has(tokens[start])) start++;
  if (start >= tokens.length) return "";

  const head = tokens[start];
  let part = PART_HEAD[head] ?? head;
  let i = start + 1;
  const pair = PART_PAIR[head]?.[tokens[i]];
  if (pair) {
    part = pair;
    i++;
  }

  const sinonim = PART_SYNONYMS[part];
  const unit: string[] = [];
  for (; i < tokens.length; i++) {
    const t = tokens[i];
    if (STOP.has(t)) break;
    if (NOISE.has(t)) continue;
    if (sinonim && sinonim.has(t)) continue;
    // kapasitas baterai/layar: "2000mah", "6.1inch" — tidak berguna di struk
    if (/^\d+(mah|ma)$/.test(t) || /^\d+(\.\d+)?(inch|inc)$/.test(t)) continue;
    if (unit.length >= 5) break;
    unit.push(t);
  }

  const alias = potongPerKata([part, ...unit].join(" "), 30);
  return alias.trim();
}

/** Alias yang dipakai struk: alias non-kosong, selain itu nama asli. */
export function aliasAtauNama(alias: string, nama: string): string {
  const a = (alias ?? "").trim();
  return a === "" ? nama : a;
}
