// ============================================================================
// D50 — Konteks data toko untuk Asisten AI (server-side saja)
// Snapshot ringkas dari database nyata (SQLite) yang disisipkan ke system
// prompt model. Role-aware sesuai D48 (g): angka LABA KOTOR, HPP, dan NILAI
// STOK hanya disertakan untuk Admin — untuk Kasir data itu tidak pernah
// dikirim ke model, sehingga mustahil bocor lewat jawaban.
// Asisten bersifat READ-ONLY: tidak ada penulisan data di sini.
// ============================================================================
import { db } from "@/lib/db";
import { dayKeyWIB, formatCurrency, formatDate, wibDayRange } from "@/lib/format";
import { serviceIdOf } from "@/lib/repair-utils";
import { REPAIR_STATUS_LABEL } from "@/lib/app-types";
import type { Reporter } from "@/lib/report-utils";

type ItemJson = { name?: string; alias?: string | null; qty?: number; price?: number };
type TxRow = {
  grandTotal: number; discount: number; paymentMethod: string; docType: string; isVoided: boolean;
  itemsJson?: string;
};

function sisaOf(t: { grandTotal: number; paidAmount: number }): number {
  return Math.max(0, t.grandTotal - t.paidAmount);
}

function rekap(rows: TxRow[]) {
  let omzet = 0, diskon = 0, count = 0;
  const perMetode = new Map<string, { penjualan: number; count: number }>();
  for (const t of rows) {
    if (t.docType !== "PENJUALAN" || t.isVoided) continue;
    omzet += t.grandTotal;
    diskon += t.discount;
    count++;
    const m = perMetode.get(t.paymentMethod) ?? { penjualan: 0, count: 0 };
    m.penjualan += t.grandTotal; m.count++;
    perMetode.set(t.paymentMethod, m);
  }
  let refund = 0, refundCount = 0;
  for (const t of rows) {
    if (t.docType !== "REFUND" || t.isVoided) continue;
    refund += Math.abs(t.grandTotal); refundCount++;
  }
  return { omzet, diskon, count, refund, refundCount, perMetode };
}

export async function buildShopContext(reporter: Reporter): Promise<string> {
  const admin = reporter.role === "Admin";
  const now = new Date();
  const today = dayKeyWIB(now);
  const yesterday = dayKeyWIB(new Date(now.getTime() - 86400000));
  const sixDaysAgo = dayKeyWIB(new Date(now.getTime() - 6 * 86400000));
  const monthStart = `${today.slice(0, 8)}01`;

  const [rowsToday, rowsYesterday, rowsWeek, rowsMonth, piutang, parts, repairs, customerCount] =
    await Promise.all([
      db.transaction.findMany({
        where: { timestamp: { gte: wibDayRange(today).start, lt: wibDayRange(today).end } },
        select: { grandTotal: true, discount: true, paymentMethod: true, docType: true, isVoided: true },
      }),
      db.transaction.findMany({
        where: { timestamp: { gte: wibDayRange(yesterday).start, lt: wibDayRange(yesterday).end } },
        select: { grandTotal: true, discount: true, paymentMethod: true, docType: true, isVoided: true },
      }),
      db.transaction.findMany({
        where: { timestamp: { gte: wibDayRange(sixDaysAgo).start, lt: wibDayRange(today).end } },
        select: { grandTotal: true, discount: true, paymentMethod: true, docType: true, isVoided: true },
      }),
      db.transaction.findMany({
        where: { timestamp: { gte: wibDayRange(monthStart).start, lt: wibDayRange(today).end } },
        select: { grandTotal: true, docType: true, isVoided: true, itemsJson: true },
      }),
      db.transaction.findMany({
        where: { paymentStatus: { in: ["BON_PIUTANG", "DP_SEBAGIAN"] }, isVoided: false, docType: "PENJUALAN" },
        select: { invoiceNumber: true, customerName: true, grandTotal: true, paidAmount: true, timestamp: true },
        orderBy: { timestamp: "asc" },
      }),
      db.sparePart.findMany({ select: { name: true, stock: true, minStock: true, costPrice: true, sellPrice: true } }),
      db.repairRecord.findMany({ orderBy: { createdAt: "asc" }, select: { id: true, customerName: true, deviceModel: true, status: true, technicianName: true, createdAt: true } }),
      db.customer.count(),
    ]);

  const rToday = rekap(rowsToday);
  const rYesterday = rekap(rowsYesterday);
  const rWeek = rekap(rowsWeek);

  // omzet net = omzet kotor − refund (D36)
  const netToday = rToday.omzet - rToday.refund;
  const netYesterday = rYesterday.omzet - rYesterday.refund;
  const netWeek = rWeek.omzet - rWeek.refund;

  // piutang
  const totalSisa = piutang.reduce((s, t) => s + sisaOf(t), 0);
  const piutangLines = piutang.slice(0, 5).map((t) => {
    const umur = Math.floor((now.getTime() - t.timestamp.getTime()) / 86400000);
    return `  - ${t.invoiceNumber} · ${t.customerName} · sisa ${formatCurrency(sisaOf(t))} · umur ${umur} hari`;
  });

  // servis aktif (belum final)
  const FINAL = new Set(["DIAMBIL", "DIBATALKAN", "TIDAK_BISA"]);
  const aktif = repairs.filter((r) => !FINAL.has(r.status));
  const perStatus = new Map<string, number>();
  for (const r of aktif) perStatus.set(r.status, (perStatus.get(r.status) ?? 0) + 1);
  const statusLine = [...perStatus.entries()]
    .map(([s, c]) => `${REPAIR_STATUS_LABEL[s] ?? s}: ${c}`)
    .join(", ");
  const belumDiambil = repairs.filter((r) => r.status === "SELESAI");
  const belumLines = belumDiambil.slice(0, 5).map((r) => {
    const umur = Math.floor((now.getTime() - r.createdAt.getTime()) / 86400000);
    return `  - ${serviceIdOf(r.createdAt)} · ${r.customerName} · ${r.deviceModel} · selesai ${umur} hari lalu${r.technicianName ? ` · teknisi ${r.technicianName}` : ""}`;
  });

  // stok
  const menipis = parts.filter((p) => p.stock <= p.minStock);
  const menipisLines = menipis.slice(0, 6).map((p) => `  - ${p.name}: stok ${p.stock} (min ${p.minStock})`);

  // top item bulan ini (dari itemsJson)
  const itemMap = new Map<string, { qty: number; omzet: number }>();
  for (const t of rowsMonth) {
    if (t.docType !== "PENJUALAN" || t.isVoided) continue;
    let items: ItemJson[] = [];
    try { items = JSON.parse(t.itemsJson) as ItemJson[]; } catch { items = []; }
    for (const it of items) {
      const nm = String(it.name ?? "?");
      const qty = Number(it.qty ?? 0);
      const omz = Number(it.price ?? 0) * qty;
      const cur = itemMap.get(nm) ?? { qty: 0, omzet: 0 };
      cur.qty += qty; cur.omzet += omz;
      itemMap.set(nm, cur);
    }
  }
  const topItems = [...itemMap.entries()].sort((a, b) => b[1].qty - a[1].qty).slice(0, 5);
  const topLines = topItems.map(([nm, v]) => `  - ${nm}: ${v.qty}x · ${formatCurrency(v.omzet)}`);

  // teknisi aktif
  const perTeknisi = new Map<string, number>();
  for (const r of aktif) {
    const nm = r.technicianName ?? "(tanpa teknisi)";
    perTeknisi.set(nm, (perTeknisi.get(nm) ?? 0) + 1);
  }
  const teknisiLine = [...perTeknisi.entries()].map(([nm, c]) => `${nm}: ${c} tiket`).join(", ") || "-";

  // admin saja (D48 jawaban g)
  let adminBlock = "";
  if (admin) {
    const nilaiBeli = parts.reduce((s, p) => s + p.costPrice * p.stock, 0);
    const nilaiJual = parts.reduce((s, p) => s + p.sellPrice * p.stock, 0);
    adminBlock = [
      "",
      "DATA KHUSUS ADMIN (boleh dibahas):",
      `- Nilai stok (harga beli): ${formatCurrency(nilaiBeli)}; (harga jual): ${formatCurrency(nilaiJual)}`,
    ].join("\n");
  } else {
    adminBlock = [
      "",
      "BATASAN PERAN: pengguna ini BUKAN Admin. Angka LABA KOTOR, HPP, dan NILAI STOK tidak disertakan.",
      "Jika ditanya hal itu, jawab sopan bahwa laba/nilai stok hanya bisa dilihat Admin (lihat menu Laporan sebagai Admin).",
    ].join("\n");
  }

  const metodeLine =
    [...rToday.perMetode.entries()].map(([m, v]) => `${m} ${formatCurrency(v.penjualan)} (${v.count} nota)`).join(", ") || "-";

  return [
    `DATA TOKO TERKINI (snapshot ${formatDate(now)} WIB — sumber: database aplikasi):`,
    "",
    "PENJUALAN HARI INI:",
    `- Omzet kotor ${formatCurrency(rToday.omzet)} dari ${rToday.count} nota; diskon ${formatCurrency(rToday.diskon)}`,
    `- Refund ${formatCurrency(rToday.refund)} (${rToday.refundCount} dokumen); omzet net ${formatCurrency(netToday)}`,
    `- Metode bayar: ${metodeLine}`,
    "",
    "KEMARIN:",
    `- Omzet kotor ${formatCurrency(rYesterday.omzet)} dari ${rYesterday.count} nota; net ${formatCurrency(netYesterday)}`,
    "",
    "7 HARI TERAKHIR:",
    `- Omzet kotor ${formatCurrency(rWeek.omzet)}; refund ${formatCurrency(rWeek.refund)}; net ${formatCurrency(netWeek)}`,
    "",
    "PIUTANG (BON + DP SEBAGIAN, aktif):",
    `- ${piutang.length} nota · total sisa ${formatCurrency(totalSisa)}`,
    ...(piutang.length ? ["  Terlama:"] : []),
    ...piutangLines,
    "",
    `SERVIS: ${aktif.length} tiket aktif (${statusLine || "-"})`,
    `- Selesai belum diambil: ${belumDiambil.length}`,
    ...(belumDiambil.length ? ["  Terlama:"] : []),
    ...belumLines,
    `- Beban teknisi aktif: ${teknisiLine}`,
    "",
    `STOK: ${parts.length} item sparepart/aksesoris; ${menipis.length} item menipis (≤ stok minimum)`,
    ...(menipis.length ? ["  Yang menipis:"] : []),
    ...menipisLines,
    "",
    `ITEM TERLARIS BULAN INI (per ${monthStart.slice(0, 7)}):`,
    ...(topItems.length ? topLines : ["  - (belum ada penjualan bulan ini)"]),
    "",
    `LAINNYA: ${customerCount} pelanggan terdaftar.`,
    adminBlock,
  ].join("\n");
}
