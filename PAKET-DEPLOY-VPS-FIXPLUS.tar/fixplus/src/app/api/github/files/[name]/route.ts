import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { db } from "@/lib/db";
import {
  loadCreds,
  downloadFile,
  deleteFile,
  listBackupFiles,
  DEFAULT_BRANCH,
  DEFAULT_FOLDER,
  BACKUP_FILE_PREFIX,
} from "@/lib/github-backup";

type Params = { params: Promise<{ name: string }> };

// Validasi nama file cadangan: hanya karakter aman + harus pola nama backup
// aplikasi ini (mencegah pembacaan file lain di repo lewat endpoint ini).
function namaValid(name: string): boolean {
  return /^[\w.\-]+$/.test(name) && name.startsWith(BACKUP_FILE_PREFIX) && name.endsWith(".db");
}

// D68 — GET /api/github/files/[name]?requesterUsername=&download=1
// download=1 → proxy unduhan file cadangan dari repo (untuk disimpan lokal).
export async function GET(req: NextRequest, { params }: Params) {
  const sp = req.nextUrl.searchParams;
  const actor = await resolveActor(sp.get("requesterUsername"));
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const name = String((await params).name ?? "").trim();
  if (!namaValid(name)) return errAction("Nama file cadangan tidak valid", 400);

  try {
    const c = await loadCreds();
    if (!c.token || !c.repo) return errAction("GitHub belum terhubung", 400);
    const branch = c.branch ?? DEFAULT_BRANCH;
    const folder = (c.folder ?? DEFAULT_FOLDER).replace(/^\/+|\/+$/g, "");
    const path = folder ? `${folder}/${name}` : name;
    const buf = await downloadFile(c.token, c.repo, branch, path);
    const safeName = name.replace(/[^\w.\-]/g, "_");
    return new NextResponse(new Uint8Array(buf), {
      headers: {
        "Content-Type": "application/octet-stream",
        "Content-Disposition": `attachment; filename="${safeName}"`,
      },
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("github file download error", e);
    return errAction(msg, 400);
  }
}

// D68 — DELETE /api/github/files/[name] — hapus satu file cadangan di repo.
export async function DELETE(req: NextRequest, { params }: Params) {
  const body = (await req.json().catch(() => ({}))) as { requesterUsername?: unknown };
  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const name = String((await params).name ?? "").trim();
  if (!namaValid(name)) return errAction("Nama file cadangan tidak valid", 400);

  try {
    const c = await loadCreds();
    if (!c.token || !c.repo) return errAction("GitHub belum terhubung", 400);
    const branch = c.branch ?? DEFAULT_BRANCH;
    const folder = (c.folder ?? DEFAULT_FOLDER).replace(/^\/+|\/+$/g, "");
    const path = folder ? `${folder}/${name}` : name;
    // sha diambil dari daftar (juga memastikan file benar-benar ada)
    const files = await listBackupFiles(c.token, c.repo, branch, folder);
    const target = files.find((f) => f.name === name);
    if (!target) return errAction("File cadangan tidak ditemukan di repo", 404);
    await deleteFile(c.token, c.repo, branch, path, target.sha);
    await db.auditLog.create({
      data: {
        action: "GITHUB_DELETE_FILE",
        details: `Cadangan "${name}" dihapus dari GitHub ${c.repo}@${branch}${folder ? `/${folder}` : ""}`,
        performedBy: actor.name,
      },
    });
    return NextResponse.json({ ok: true });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("github file delete error", e);
    return errAction(msg, 400);
  }
}
