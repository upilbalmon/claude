import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { resolveActor } from "@/lib/action-guard";
import { MAX_IGNORE_DAYS } from "@/lib/belanja-utils";

type Params = { params: Promise<{ id: string }> };

// D61 — Tahap 6.3: pilihan daftar belanja & tunda saran restock untuk
// SparePart (parity InventoryViewModel.kt: isShoppingSelected &
// shoppingIgnoredUntil). Dipakai tab "Rekomendasi Belanja" (modul Belanja).
//
// PATCH body:
//  { isShoppingSelected?: boolean, ignoreDays?: number, requesterUsername, performedBy }
//  - ignoreDays > 0  → saran restock item ini diabaikan sampai N hari lagi (maks 90)
//  - ignoreDays = 0  → hapus tundaan (saran restock aktif kembali)

export async function PATCH(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return NextResponse.json({ error: "ID tidak valid" }, { status: 400 });
    }
    const part = await db.sparePart.findUnique({ where: { id } });
    if (!part) {
      return NextResponse.json({ error: "Sparepart tidak ditemukan" }, { status: 404 });
    }

    const body = await req.json();
    const actor = await resolveActor(body.requesterUsername, false);
    const performedBy = actor?.name ?? String(body.performedBy ?? "Tidak diketahui");

    const data: { isShoppingSelected?: boolean; shoppingIgnoredUntil?: Date | null } = {};
    if (body.isShoppingSelected !== undefined) {
      data.isShoppingSelected = Boolean(body.isShoppingSelected);
    }
    if (body.ignoreDays !== undefined) {
      const days = Math.trunc(Number(body.ignoreDays));
      if (!Number.isFinite(days) || days < 0 || days > MAX_IGNORE_DAYS) {
        return NextResponse.json(
          { error: `Abaikan saran hanya 0–${MAX_IGNORE_DAYS} hari` },
          { status: 400 }
        );
      }
      data.shoppingIgnoredUntil =
        days > 0 ? new Date(Date.now() + days * 24 * 60 * 60 * 1000) : null;
    }
    if (Object.keys(data).length === 0) {
      return NextResponse.json({ error: "Tidak ada perubahan yang dikirim" }, { status: 400 });
    }

    const updated = await db.sparePart.update({ where: { id }, data });

    const parts: string[] = [];
    if (data.isShoppingSelected !== undefined) {
      parts.push(`pilihan belanja: ${data.isShoppingSelected ? "YA" : "TIDAK"}`);
    }
    if (data.shoppingIgnoredUntil !== undefined) {
      parts.push(
        data.shoppingIgnoredUntil
          ? `abaikan saran restock s.d. ${data.shoppingIgnoredUntil.toLocaleDateString("id-ID")}`
          : "abaikan saran restock dihapus"
      );
    }
    await db.auditLog.create({
      data: {
        action: "DAFTAR_BELANJA_SPAREPART",
        details: `${part.name} (stok ${updated.stock}) — ${parts.join("; ")}`,
        performedBy,
      },
    });

    return NextResponse.json(updated);
  } catch (e) {
    console.error("spare-parts shopping PATCH error", e);
    return NextResponse.json({ error: "Gagal memperbarui pilihan belanja" }, { status: 500 });
  }
}
