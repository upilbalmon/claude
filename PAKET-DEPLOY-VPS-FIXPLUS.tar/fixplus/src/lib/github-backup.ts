// D68/D69 — Integrasi GitHub sebagai lokasi backup database (alternatif Google
// Drive D67 yang TANPA Google Cloud sama sekali): cukup akun GitHub gratis +
// Personal Access Token (PAT) + satu repositori privat. Semua panggilan memakai
// GitHub REST API v3 lewat fetch bawaan — tanpa dependensi baru.
//
// D69 — mode auto-backup baru "per-perubahan": hook tulisan Prisma (db.ts)
// menandai perubahan lewat lib/data-dirty.ts; penjadwal di bawah menjalankan
// backup ±2 menit setelah perubahan TERAKHIR (perubahan beruntun digabung satu
// commit), dengan batas tunggu maksimum 30 menit bila data terus berubah.
//
// Cara kerja (parity jalur Google Drive):
//   · Backup   = unggah snapshot file .db penuh (WAL di-checkpoint dulu)
//     sebagai commit baru ke folder <folder>/ pada branch terpilih, dengan
//     nama bertanggal waktu-Jakarta (database-fixplus-YYYY-MM-DD-HHMM.db).
//   · Pulihkan = unduh file cadangan → prosedur GANTI DATABASE yang persis
//     sama dengan unggahan manual (performRestoreDb di db-restore.ts).
//   · Auto     = penjadwal harian dipasang dari instrumentation.ts
//     (startGithubAutoBackup) — cek tiap 10 menit; bila jam Jakarta >= jam
//     target dan hari ini belum dibackup → commit + pangkas di atas keepLast.
//
// Kredensial disimpan di berkas JSON di samping database
// (<dir db>/github-credentials.json) — tidak ikut ter-backup di file .db
// (token tidak boleh bercampur data bisnis), persis pola gdrive-credentials.
//
// D74 — SINKRONISASI AWAL BERBASIS NOMOR URUT (seq): tiap tulisan data bisnis
// menaikkan seq di tabel AppMeta (lihat db.ts). Setiap backup menulis
// manifest.json (seq + deviceId + nama file) ke folder repo. Saat server
// menyala ATAU aplikasi dibuka (splash-screen parity), tickAutoSync membandingkan:
//   · DB lokal kosong, GitHub ada cadangan  → pulihkan otomatis (D70)
//   · seq lokal < seq GitHub (perangkat sama) → pulihkan otomatis (data lokal mundur)
//   · seq lokal > seq GitHub                → UNGGAH (backup belum terkirim), jangan restore
//   · seq sama tapi deviceId beda           → KONFLIK — dicatat & ditampilkan, tunggu pemilik
// Setelah pulihkan: seq lokal disamakan dengan manifest (langkah 4 alur restore).
import { readFile, writeFile } from "fs/promises";
import { randomUUID } from "crypto";
import { dirname, join } from "path";
import { db, getDataVersion, setDataVersion } from "@/lib/db";
import { pushNotification } from "@/lib/notifications"; // D81 — pusat notifikasi
import { dbPathFromEnv, performRestoreDb, isRestoreBusy } from "@/lib/db-restore";
import { peekDirty, clearDirty, suppressDirty, markDataChange } from "@/lib/data-dirty";
// Snapshot .db penuh (checkpoint WAL + nama bertanggal WIB) satu sumber dari
// D67 — dipakai ulang agar isi file backup GitHub identik dengan backup Drive.
import { BACKUP_FILE_PREFIX, makeDbBackupBuffer } from "@/lib/gdrive";
// Re-export untuk route /api/github/* (validasi nama file cadangan).
export { BACKUP_FILE_PREFIX };

const JAKARTA_OFFSET_MS = 7 * 3600 * 1000;
const API = "https://api.github.com";
export const DEFAULT_BRANCH = "main";
export const DEFAULT_FOLDER = "fixplus-backup";
const MAX_FILE_BYTES = 90 * 1024 * 1024; // batas aman Contents API GitHub

export type GithubAutoMode = "off" | "daily" | "onchange";
export type GithubAuto = {
  enabled: boolean;
  mode?: GithubAutoMode; // D69 — "daily" = jadwal jam; "onchange" = tiap ada perubahan data
  hour: number;
  keepLast: number;
};

// D74 — konflik sinkronisasi: repo & lokal sama-sama punya data tapi ditulis
// perangkat berbeda — tidak boleh diputuskan otomatis, ditunggu keputusan pemilik.
export type GithubSyncConflict = {
  detectedAt: string;
  detail: string;
  manifestDeviceId: string | null;
  localSeq: number;
  manifestSeq: number;
};

// D74 — manifest.json di folder repo: kartu nama cadangan terbaru berisi nomor
// urut data (seq) + identitas perangkat penulisnya.
export type GithubManifest = {
  app: "fixplus";
  seq: number;
  deviceId: string;
  lastBackupFile: string;
  lastBackupAt: string;
  savedAt: string;
};

// Jeda setelah perubahan terakhir sebelum backup dianggap waktunya (debounce
// trailing), dan batas tunggu maksimum sejak perubahan PERTAMA bila data
// terus-menerus berubah (mencegah backup tidak pernah jalan).
const ONCHANGE_DEBOUNCE_MS = 2 * 60_000;
const ONCHANGE_MAX_WAIT_MS = 30 * 60_000;

// Normalisasi pengaturan auto: kredensial lama (D68) tanpa "mode" diturunkan
// dari enabled (aktif = harian, mati = off) supaya tidak ada yang rusak.
function resolveAuto(a?: GithubAuto): Required<Pick<GithubAuto, "enabled" | "hour" | "keepLast">> & { mode: GithubAutoMode } {
  const merged = { ...DEFAULT_AUTO, ...(a ?? {}) };
  const mode: GithubAutoMode = a?.mode ?? (a?.enabled ? "daily" : "off");
  return { ...merged, enabled: mode !== "off", mode };
}
export type GithubCreds = {
  token?: string;
  repo?: string; // "owner/repo"
  branch?: string;
  folder?: string;
  auto?: GithubAuto;
  autoRestore?: boolean; // D70/D74 — pulihkan otomatis saat DB kosong ATAU lokal lebih tua (seq)
  deviceId?: string; // D74 — identitas perangkat/instansi ini, ditulis ke manifest.json
  conflict?: GithubSyncConflict | null; // D74 — konflik perangkat menunggu keputusan pemilik
  lastBackupAt?: string | null;
  lastAutoBackupDate?: string | null; // YYYY-MM-DD Jakarta
  lastBackupFile?: string | null;
  lastAutoRestoreAt?: string | null;
  lastAutoRestoreFile?: string | null;
};

const DEFAULT_AUTO: GithubAuto = { enabled: false, hour: 21, keepLast: 7 };

// Validasi input (dipakai route + UI)
export const REPO_RE = /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/;
export const BRANCH_RE = /^[A-Za-z0-9._\-/]+$/; // boleh "release/v1"
export const FOLDER_RE = /^[A-Za-z0-9._\-/ ]+$/; // boleh bersarang "a/b c"

function credPath(): string {
  const dbPath = dbPathFromEnv();
  return dbPath ? join(dirname(dbPath), "github-credentials.json") : "";
}

export async function loadCreds(): Promise<GithubCreds> {
  const p = credPath();
  if (!p) return {};
  try {
    const raw = await readFile(p, "utf8");
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? (parsed as GithubCreds) : {};
  } catch {
    return {}; // belum ada / rusak — mulai kosong
  }
}

export async function saveCreds(patch: Partial<GithubCreds>): Promise<GithubCreds> {
  const merged = { ...(await loadCreds()), ...patch };
  const p = credPath();
  if (!p) throw new Error("Lokasi penyimpanan kredensial tidak diketahui (DATABASE_URL kosong)");
  await writeFile(p, JSON.stringify(merged, null, 2), "utf8");
  return merged;
}

export async function updateCreds(
  fn: (c: GithubCreds) => GithubCreds
): Promise<GithubCreds> {
  return saveCreds(fn(await loadCreds()));
}

// D76 — JEMBATAN TOKEN (opsional). URL + kunci jembatan boleh lewat env
// (menang) atau konstanta di bawah — konstanta sengaja DI KODE agar ikut
// bertahan walau workspace hilang total dan proyek dibangun ulang dari zip.
//
//   TOKEN_BRIDGE_KEY_DEFAULT — SUDAH DIISI (kunci rahasia jembatan). Nilai
//   yang sama harus dipasang sebagai BRIDGE_KEY di Vercel (lihat panduan).
//
//   TOKEN_BRIDGE_URL_DEFAULT — SUDAH DIISI (D79, 16 Nov 2026): URL jembatan
//   hasil deploy pemilik ke Vercel (TANPA /api/token — koneksi hanya cocok
//   kunci benar; kunci salah dijawab 404 oleh jembatan).
const TOKEN_BRIDGE_URL_DEFAULT = "https://fixplus-token-bridge.vercel.app";
const TOKEN_BRIDGE_KEY_DEFAULT = "0qw_E_b19bqc0QyeVaiL1I3gFPO10NCMUqVBUXm2";

// Ambil token default dari jembatan (server-side — nilai tidak pernah
// menyentuh browser). Gagal/timeout → null, aplikasi lanjut tanpa jembatan.
async function fetchBridgeDefaults(
  url: string,
  key: string
): Promise<DeploymentDefaults | null> {
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 6000);
    const res = await fetch(
      `${url.replace(/\/+$/, "")}/api/token?key=${encodeURIComponent(key)}`,
      { signal: ctrl.signal, headers: { "User-Agent": "fixplus-app" }, cache: "no-store" }
    );
    clearTimeout(timer);
    if (!res.ok) return null;
    const j = (await res.json()) as Partial<DeploymentDefaults> & { ok?: boolean };
    return j && typeof j === "object" && typeof j.token === "string" && j.token.trim()
      ? (j as DeploymentDefaults)
      : null;
  } catch {
    return null; // jembatan mati/lambat — abaikan saja
  }
}

export type DeploymentDefaults = {
  token?: string;
  repo?: string;
  branch?: string;
  folder?: string;
  source: "env" | "file" | "bridge" | null;
};

// D75 — DEFAULT KONEKSI BACKUP UNTUK PEMULIHAN PRA-LOGIN.
// Tiga sumber berurutan (D76):
//   1. Environment variable hosting — GITHUB_BACKUP_TOKEN (+ GITHUB_BACKUP_REPO,
//      GITHUB_BACKUP_BRANCH, GITHUB_BACKUP_FOLDER opsional). Ini cara bawaan
//      Vercel saat aplikasi itu sendiri di-host di Vercel: token terenkripsi
//      di sisi server, tidak pernah masuk kode/git/browser, dan bertahan
//      saat redeploy.
//   2. db/deployment-defaults.json — berisi token + repo cadangan bawaan
//      pemilik (dibuat sekali dari kredensial yang sedang hidup) untuk
//      hosting yang tidak punya panel environment variable.
//   3. JEMBATAN TOKEN di Vercel (lihat TOKEN_BRIDGE_* di atas) — dipakai
//      HANYA bila sumber 1 & 2 kosong (workspace baru yang benar-benar
//      bersih): aplikasi mengambil token dari jembatan sekali, lalu
//      menyimpannya sebagai kredensial perangkat.
// Dipakai layar bootstrap saat token belum ada: pemilik cukup menyalakan
// "Gunakan token default server" — nilai token TIDAK PERNAH dikirim ke
// browser, hanya dibaca di server untuk uji koneksi & simpan kredensial.
// Kalau token sudah dirotasi di GitHub, uji koneksi akan gagal → pemilik
// tinggal menempel token baru manual.
export async function loadDeploymentDefaults(): Promise<DeploymentDefaults> {
  const env = {
    token: (process.env.GITHUB_BACKUP_TOKEN ?? "").trim(),
    repo: (process.env.GITHUB_BACKUP_REPO ?? "").trim(),
    branch: (process.env.GITHUB_BACKUP_BRANCH ?? "").trim(),
    folder: (process.env.GITHUB_BACKUP_FOLDER ?? "").trim(),
  };
  let file: Partial<Record<"token" | "repo" | "branch" | "folder", string>> = {};
  const p = credPath();
  if (p) {
    try {
      const raw = await readFile(join(dirname(p), "deployment-defaults.json"), "utf8");
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === "object") file = parsed;
    } catch {
      // belum dibuat — biarkan file kosong
    }
  }

  // 1) ENV menang di atas semuanya (Vercel dsb.).
  if (env.token) {
    return {
      token: env.token,
      repo: env.repo || file.repo || undefined,
      branch: env.branch || file.branch || undefined,
      folder: env.folder || file.folder || undefined,
      source: "env",
    };
  }
  // 2) File default lokal (perangkat pernah terhubung sebelumnya).
  if (file.token) {
    return {
      token: file.token,
      repo: file.repo || env.repo || undefined,
      branch: file.branch || env.branch || undefined,
      folder: file.folder || env.folder || undefined,
      source: "file",
    };
  }
  // 3) Jembatan token (Vercel) — hanya bila workspace benar-benar bersih.
  const bridgeUrl = (process.env.TOKEN_BRIDGE_URL ?? TOKEN_BRIDGE_URL_DEFAULT).trim();
  const bridgeKey = (process.env.TOKEN_BRIDGE_KEY ?? TOKEN_BRIDGE_KEY_DEFAULT).trim();
  if (bridgeUrl && bridgeKey) {
    const bridge = await fetchBridgeDefaults(bridgeUrl, bridgeKey);
    if (bridge?.token) {
      return {
        token: bridge.token.trim(),
        repo: bridge.repo?.trim() || undefined,
        branch: bridge.branch?.trim() || undefined,
        folder: bridge.folder?.trim() || undefined,
        source: "bridge",
      };
    }
  }
  return { source: null }; // tidak ada sumber — layar bootstrap minta manual
}

export function credsSummary(c: GithubCreds) {
  const token = c.token ?? "";
  return {
    configured: Boolean(token && c.repo),
    repo: c.repo ?? null,
    branch: c.branch ?? DEFAULT_BRANCH,
    folder: c.folder ?? DEFAULT_FOLDER,
    tokenHint: token ? `••••${token.slice(-4)}` : null,
    auto: resolveAuto(c.auto),
    autoRestore: c.autoRestore === true,
    deviceId: c.deviceId ?? null, // D74
    conflict: c.conflict ?? null, // D74
    lastBackupAt: c.lastBackupAt ?? null,
    lastAutoBackupDate: c.lastAutoBackupDate ?? null,
    lastBackupFile: c.lastBackupFile ?? null,
    lastAutoRestoreAt: c.lastAutoRestoreAt ?? null,
    lastAutoRestoreFile: c.lastAutoRestoreFile ?? null,
  };
}

// D86 — ATURAN PEMILIK: "saat berhasil terhubung ke github langsung set auto
// backup aktif ke setiap ada perubahan data". Dipanggil dari KEDUA pintu
// koneksi GitHub (layar bootstrap pra-login & Pengaturan Admin) SETELAH
// koneksi lulus uji ke api.github.com dan kredensial tersimpan: mode
// auto-backup langsung diset "per-perubahan data" (onchange, D69) — backup
// berjalan sendiri ±2 menit setelah tiap perubahan data terakhir, tanpa
// perlu Admin membuka Pengaturan. Jam harian & keepLast yang sudah ada tidak
// diubah; Admin tetap bebas mengubah/mematikan setelahnya — aturan ini hanya
// menyala pada MOMEN koneksi berhasil (terhubung ulang = menyala lagi).
// Tulisan audit & notifikasi di sini dikecualikan dari penanda perubahan data
// (lihat db.ts) sehingga TIDAK memicu backup tanpa perubahan data bisnis.
// Return true bila pengaturan benar-benar diubah (sudah onchange → false,
// tanpa audit duplikat).
export async function enableAutoBackupOnChangeAfterConnect(
  actor: string
): Promise<boolean> {
  const c = await loadCreds();
  const cur = resolveAuto(c.auto);
  if (cur.mode === "onchange") return false; // sudah aktif — jangan catat ulang
  const auto: GithubAuto = { enabled: true, mode: "onchange", hour: cur.hour, keepLast: cur.keepLast };
  await saveCreds({ auto });
  await db.auditLog.create({
    data: {
      action: "GITHUB_AUTO_SETTINGS",
      details: `Auto-backup GitHub per-perubahan data DIAKTIFKAN OTOMATIS (aturan D86: GitHub berhasil terhubung → backup tiap ada perubahan data) — simpan ${cur.keepLast} cadangan terakhir`,
      performedBy: actor,
    },
  });
  await pushNotification({
    type: "SYSTEM",
    title: "Auto-backup per-perubahan diaktifkan otomatis",
    message: `GitHub berhasil terhubung (${c.repo ?? "-"}) — setiap perubahan data akan otomatis dibackup ke GitHub ±2 menit setelah perubahan terakhir (aturan D86). Mode/jadwal tetap bisa diubah di Pengaturan → Backup GitHub.`,
    meta: { mode: "onchange", aturan: "D86", actor },
  });
  console.log(`[github] aturan D86: auto-backup per-perubahan DIAKTIFKAN otomatis setelah koneksi (${actor})`);
  return true;
}

// ===== Waktu Jakarta (parity gdrive.ts) =====
function jakartaNow() {
  const d = new Date(Date.now() + JAKARTA_OFFSET_MS);
  const iso = d.toISOString();
  return {
    dateStr: iso.slice(0, 10),
    hour: d.getUTCHours(),
    minuteStr: `${iso.slice(11, 13)}.${iso.slice(14, 16)}`,
  };
}

// ===== HTTP dasar GitHub =====
function ghHeaders(token: string, extra?: Record<string, string>) {
  return {
    Authorization: `Bearer ${token}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "User-Agent": "fixplus-backup",
    ...(extra ?? {}),
  };
}

// Terjemahkan kode HTTP GitHub jadi pesan Indonesia yang bisa ditindaklanjuti.
function pesanGithub(status: number, msg: string): string {
  const detail = msg ? ` — ${msg}` : "";
  if (status === 401) {
    return `Token GitHub ditolak (401${detail}). Token mungkin kedaluwarsa/dicabut — buat token baru lalu simpan ulang.`;
  }
  if (status === 404) {
    return `Repo/branch/folder tidak ditemukan (404${detail}). Pastikan owner/repo & branch benar dan token punya akses ke repo tersebut.`;
  }
  if (status === 403) {
    return `Akses ditolak GitHub (403${detail}). Token fine-grained wajib izin Contents: Read and write pada repo backup.`;
  }
  if (status === 422) {
    return `GitHub menolak perubahan (422${detail}).`;
  }
  return `GitHub: HTTP ${status}${detail}`;
}

async function ghJson(
  token: string,
  url: string,
  init?: RequestInit
): Promise<Record<string, unknown>> {
  const res = await fetch(url, {
    ...init,
    headers: ghHeaders(token, init?.headers as Record<string, string> | undefined),
  });
  const json = (await res.json().catch(() => ({}))) as Record<string, unknown>;
  if (!res.ok) {
    const msg = String(json.message ?? res.statusText);
    throw new Error(pesanGithub(res.status, msg));
  }
  return json;
}

// Path aman: encode tiap segmen (folder bisa bersarang "a/b").
function encodePath(path: string): string {
  return path.split("/").filter(Boolean).map(encodeURIComponent).join("/");
}

export function normalizeFolder(folder: string): string {
  return folder.trim().replace(/^\/+|\/+$/g, "").replace(/\/{2,}/g, "/");
}

// Repo kosong (belum pernah ada commit) → daftar branch-nya kosong [].
// Repo baru yang dibuat tanpa README berada dalam kondisi ini: belum punya
// branch apa pun, TAPI tetap valid sebagai lokasi backup — commit backup
// pertama akan membuat branch-nya sekaligus (initEmptyRepoBranch).
async function isRepoEmpty(token: string, repo: string): Promise<boolean> {
  try {
    const json = await ghJson(token, `${API}/repos/${encodePath(repo)}/branches`);
    return Array.isArray(json) && (json as unknown[]).length === 0;
  } catch {
    return false; // tidak yakin → perlakukan sebagai repo berisi
  }
}

// ===== Uji koneksi =====
export type RepoInfo = {
  fullName: string;
  isPrivate: boolean;
  defaultBranch: string;
  emptyRepo: boolean; // true = repo masih kosong, backup pertama menginisialisasi branch
};

export async function testConnection(
  token: string,
  repo: string,
  branch: string
): Promise<RepoInfo> {
  const info = await ghJson(token, `${API}/repos/${encodePath(repo)}`);
  const perms = info.permissions as { push?: boolean } | undefined;
  if (perms && perms.push === false) {
    throw new Error("Token tidak punya izin menulis (push) ke repo ini — perbaiki izin token (Contents: Read and write).");
  }
  const defaultBranch = String(info.default_branch ?? DEFAULT_BRANCH);
  let emptyRepo = false;
  try {
    await ghJson(token, `${API}/repos/${encodePath(repo)}/git/ref/heads/${encodePath(branch)}`);
  } catch {
    // Branch belum ada. Boleh terjadi pada repo yang masih KOSONG (dibuat
    // tanpa README) — itu kondisi valid dan akan diinisialisasi otomatis.
    // Repo yang sudah berisi commit tetap ditolak agar salah ketik branch
    // terdeteksi di sini, bukan saat backup.
    if (await isRepoEmpty(token, repo)) {
      emptyRepo = true;
    } else {
      throw new Error(`Branch "${branch}" tidak ada di ${repo}. Branch bawaan repo: ${defaultBranch}.`);
    }
  }
  return { fullName: String(info.full_name ?? repo), isPrivate: Boolean(info.private), defaultBranch, emptyRepo };
}

// ===== Operasi Contents API =====
export type GithubFile = { name: string; sha: string; size: number };

// Daftar file cadangan di folder repo (terbaru dulu — nama memuat stempel waktu).
// Folder yang belum ada dianggap kosong (bukan error).
export async function listBackupFiles(
  token: string,
  repo: string,
  branch: string,
  folder: string
): Promise<GithubFile[]> {
  const path = normalizeFolder(folder);
  const url = `${API}/repos/${encodePath(repo)}/contents/${encodePath(path)}?ref=${encodeURIComponent(branch)}`;
  let json: Record<string, unknown>;
  try {
    json = await ghJson(token, url);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    if (msg.includes("404")) return [];
    throw e;
  }
  if (!Array.isArray(json)) {
    throw new Error('Path tujuan bukan folder — periksa pengaturan "Folder di repo".');
  }
  return (json as Record<string, unknown>[])
    .filter(
      (f) =>
        f.type === "file" &&
        String(f.name ?? "").startsWith(BACKUP_FILE_PREFIX) &&
        String(f.name ?? "").endsWith(".db")
    )
    .map((f) => ({
      name: String(f.name),
      sha: String(f.sha),
      size: Number(f.size ?? 0),
    }))
    .sort((a, b) => b.name.localeCompare(a.name));
}

async function getFileSha(
  token: string,
  repo: string,
  branch: string,
  path: string
): Promise<string | null> {
  try {
    const json = await ghJson(
      token,
      `${API}/repos/${encodePath(repo)}/contents/${encodePath(path)}?ref=${encodeURIComponent(branch)}`
    );
    return json.sha ? String(json.sha) : null;
  } catch {
    return null; // belum ada
  }
}

// Inisialisasi repo KOSONG: commit pertama sekaligus membuat branch. Contents
// API tidak bisa menulis ke branch yang belum ada, jadi dipakai alur Git Data
// API: blob → tree → commit (tanpa induk) → refs/heads/<branch>.
async function initEmptyRepoBranch(
  token: string,
  repo: string,
  branch: string,
  path: string,
  contentB64: string,
  message: string
): Promise<{ sha: string; commitUrl: string }> {
  const gitUrl = `${API}/repos/${encodePath(repo)}/git`;
  const blob = await ghJson(token, `${gitUrl}/blobs`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ content: contentB64, encoding: "base64" }),
  });
  const tree = await ghJson(token, `${gitUrl}/trees`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      tree: [{ path, mode: "100644", type: "blob", sha: String(blob.sha) }],
    }),
  });
  const commit = await ghJson(token, `${gitUrl}/commits`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message, tree: String(tree.sha), parents: [] }),
  });
  await ghJson(token, `${gitUrl}/refs`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ref: `refs/heads/${branch}`, sha: String(commit.sha) }),
  });
  return { sha: String(commit.sha ?? ""), commitUrl: String(commit.html_url ?? "") };
}

// Commit satu file (base64). Bila nama sama sudah ada → timpa dengan sha.
// Bila repo masih kosong (branch belum ada) → commit pertama membuat branch.
export async function putFile(
  token: string,
  repo: string,
  branch: string,
  path: string,
  contentB64: string,
  message: string
): Promise<{ sha: string; commitUrl: string }> {
  const body = {
    message,
    content: contentB64,
    branch,
  };
  const doPut = async (sha?: string) =>
    ghJson(token, `${API}/repos/${encodePath(repo)}/contents/${encodePath(path)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...body, ...(sha ? { sha } : {}) }),
    });
  let json: Record<string, unknown>;
  try {
    json = await doPut();
  } catch (e) {
    // 422 = file dengan nama sama sudah ada → ambil sha lama lalu timpa sekali
    const sha = await getFileSha(token, repo, branch, path);
    if (!sha) {
      // File memang belum ada; bila repo masih kosong, commit pertama
      // sekaligus membuat branch-nya.
      if (await isRepoEmpty(token, repo)) {
        return initEmptyRepoBranch(token, repo, branch, path, contentB64, message);
      }
      throw e;
    }
    json = await doPut(sha);
  }
  const content = json.commit as { html_url?: string; sha?: string } | undefined;
  return {
    sha: String((json.content as { sha?: string } | undefined)?.sha ?? content?.sha ?? ""),
    commitUrl: String(content?.html_url ?? ""),
  };
}

// Unduh isi file cadangan (raw).
export async function downloadFile(
  token: string,
  repo: string,
  branch: string,
  path: string
): Promise<Buffer> {
  const res = await fetch(
    `${API}/repos/${encodePath(repo)}/contents/${encodePath(path)}?ref=${encodeURIComponent(branch)}`,
    { headers: ghHeaders(token, { Accept: "application/vnd.github.raw" }) }
  );
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    let msg = "";
    try {
      msg = String((JSON.parse(text) as { message?: string }).message ?? "");
    } catch {
      msg = text;
    }
    throw new Error(pesanGithub(res.status, msg.slice(0, 200)));
  }
  return Buffer.from(await res.arrayBuffer());
}

// Hapus satu file cadangan (butuh sha dari daftar).
export async function deleteFile(
  token: string,
  repo: string,
  branch: string,
  path: string,
  sha: string
): Promise<void> {
  await ghJson(token, `${API}/repos/${encodePath(repo)}/contents/${encodePath(path)}`, {
    method: "DELETE",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message: `Hapus cadangan ${path} (Fixplus)`, sha, branch }),
  });
}

// ===== D74 — manifest.json + identitas perangkat =====
const MANIFEST_NAME = "manifest.json";

function manifestPath(folder: string): string {
  return folder ? `${folder}/${MANIFEST_NAME}` : MANIFEST_NAME;
}

// Baca manifest.json dari folder repo. Belum ada (cadangan pra-D74 / repo
// kosong) → null — pemeriksaan seq dilewati, perilaku lama dipakai.
export async function readGithubManifest(
  token: string,
  repo: string,
  branch: string,
  folder: string
): Promise<GithubManifest | null> {
  try {
    const buf = await downloadFile(token, repo, branch, manifestPath(folder));
    const m = JSON.parse(buf.toString("utf8")) as GithubManifest;
    if (m && m.app === "fixplus" && Number.isFinite(m.seq)) {
      return { ...m, seq: Math.trunc(m.seq) };
    }
    return null;
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    if (!msg.includes("404")) {
      console.error("[github] manifest.json tidak terbaca — diabaikan:", msg);
    }
    return null; // 404 = belum ada; rusak = jangan blokir backup/restore
  }
}

// Identitas perangkat/instansi: dibuat sekali, disimpan di kredensial (file
// samping — bukan data bisnis) sehingga bertahan walau database dipulihkan.
async function ensureDeviceId(): Promise<string> {
  const c = await loadCreds();
  if (c.deviceId) return c.deviceId;
  const id = `fx-${randomUUID().slice(0, 8)}`;
  await saveCreds({ deviceId: id });
  console.log(`[github] deviceId perangkat ini: ${id}`);
  return id;
}

// ===== Backup penuh (.db) → GitHub =====
export type BackupOutcome = {
  repo: string;
  branch: string;
  path: string;
  fileName: string;
  sha: string;
  commitUrl: string;
  size: number;
  pruned: number;
};

export async function performGithubBackup(actorName: string): Promise<BackupOutcome> {
  // Tulisan jejak audit oleh backup ini sendiri TIDAK boleh memicu auto-backup
  // per-perubahan berikutnya (lingkaran backup→audit→backup).
  suppressDirty(true);
  try {
    return await doPerformGithubBackup(actorName);
  } finally {
    suppressDirty(false);
  }
}

// D81 — sumber backup untuk pesan notifikasi: "Sistem (…)" = otomatis/penjadwal
// (harian D70, per-perubahan D69, sinkron-awal D74); nama lain = aktor Admin.
function sumberBackup(actorName: string): "MANUAL" | "AUTO" {
  return actorName.startsWith("Sistem") ? "AUTO" : "MANUAL";
}

async function doPerformGithubBackup(actorName: string): Promise<BackupOutcome> {
  const c = await loadCreds();
  if (!c.token || !c.repo) {
    throw new Error("GitHub belum terhubung — isi Token & Repo di Pengaturan → Data & Backup dulu");
  }
  const repo = c.repo;
  const branch = c.branch ?? DEFAULT_BRANCH;
  const folder = normalizeFolder(c.folder ?? DEFAULT_FOLDER);
  // D74 — baca seq SEBELUM snapshot dibuat: nilai inilah yang tertanam di file
  // .db yang diunggah. Dibaca lebih awal (bukan sesudah) supaya manifest.seq
  // TIDAK pernah melebihi seq di dalam file — mencegah lingkaran
  // restore→“lokal lebih tua”→restore bila file itu nanti dipulihkan kembali.
  let seqAtSnapshot = 0;
  try {
    seqAtSnapshot = await getDataVersion();
  } catch (e) {
    console.error("[github] gagal membaca seq (dianggap 0):", e);
  }
  const { buf, fileName } = await makeDbBackupBuffer();
  if (buf.length > MAX_FILE_BYTES) {
    throw new Error(`File database ${Math.ceil(buf.length / 1024 / 1024)} MB melebihi batas unggah GitHub (90 MB)`);
  }
  const now = jakartaNow();
  const path = folder ? `${folder}/${fileName}` : fileName;
  const message = `Backup Fixplus ${now.dateStr} ${now.minuteStr} WIB`;
  const up = await putFile(c.token, repo, branch, path, buf.toString("base64"), message);

  // Pangkas cadangan lama di atas keepLast (list sudah terbaru dulu)
  const keepLast = Math.max(1, Math.min(90, c.auto?.keepLast ?? DEFAULT_AUTO.keepLast));
  let pruned = 0;
  try {
    const files = await listBackupFiles(c.token, repo, branch, folder);
    for (const f of files.slice(keepLast)) {
      try {
        await deleteFile(c.token, repo, branch, folder ? `${folder}/${f.name}` : f.name, f.sha);
        pruned++;
      } catch (e) {
        console.error("[github] gagal menghapus cadangan lama:", f.name, e);
      }
    }
  } catch (e) {
    console.error("[github] pemangkasan dilewati:", e);
  }

  await updateCreds((cr) => ({
    ...cr,
    lastBackupAt: new Date().toISOString(),
    lastBackupFile: fileName,
  }));

  // D74 — tulis manifest.json ke folder repo (seq + deviceId + file terakhir)
  // supaya pemeriksaan sinkron di sisi mana pun tahu seberapa baru data repo.
  // Gagal menulis manifest TIDAK menggagalkan backup yang sudah sukses.
  try {
    const deviceId = await ensureDeviceId();
    const manifest: GithubManifest = {
      app: "fixplus",
      seq: seqAtSnapshot,
      deviceId,
      lastBackupFile: fileName,
      lastBackupAt: new Date().toISOString(),
      savedAt: new Date().toISOString(),
    };
    await putFile(
      c.token,
      repo,
      branch,
      manifestPath(folder),
      Buffer.from(JSON.stringify(manifest, null, 2), "utf8").toString("base64"),
      `Manifest Fixplus (seq ${seqAtSnapshot})`
    );
  } catch (e) {
    console.error("[github] gagal menulis manifest.json (backup tetap sukses):", e);
  }

  // D77 — backup sukses berarti repo kini ditulis perangkat INI; penanda
  // konflik lama tidak lagi relevan → bersihkan.
  if (c.conflict) await clearConflict(c);

  await db.auditLog.create({
    data: {
      action: "BACKUP_GITHUB",
      details: `Cadangan "${fileName}" (${Math.ceil(buf.length / 1024)} KB) di-commit ke GitHub ${repo}@${branch}${folder ? `/${folder}` : ""}${pruned ? `, ${pruned} cadangan lama dihapus` : ""}`,
      performedBy: actorName,
    },
  });

  // D81 — simpan notifikasi permanen (panel lonceng header): toast di layar
  // hanya sebentar, riwayat ini yang bisa dibuka kapan saja. Tulisan di sini
  // masih DI DALAM jendela suppressDirty dan tabelnya dikecualikan di db.ts —
  // tidak memicu backup baru.
  const sumber = sumberBackup(actorName);
  await pushNotification({
    type: "BACKUP_SUCCESS",
    title: "Backup GitHub berhasil",
    message:
      (sumber === "AUTO" ? "Backup otomatis" : `Backup manual oleh ${actorName}`) +
      ` — cadangan "${fileName}" (${Math.ceil(buf.length / 1024)} KB) tersimpan di ${repo}@${branch}${folder ? `/${folder}` : ""}${pruned ? `, ${pruned} cadangan lama dihapus` : ""}.`,
    meta: { fileName, repo, branch, folder, size: buf.length, pruned, actor: actorName, sumber },
  });
  return {
    repo,
    branch,
    path,
    fileName,
    sha: up.sha,
    commitUrl: up.commitUrl,
    size: buf.length,
    pruned,
  };
}

// ===== D70/D74 — Auto-pulihkan + sinkronisasi awal berbasis nomor urut =====
//
// Kebalikan auto-backup: bila server menyala ATAU aplikasi dibuka, database
// LOKAL dibandingkan dengan repo GitHub:
//
//   1. DB lokal KOSONG (belum ada data bisnis — mis. file .db hilang/terganti
//      setelah redeploy) dan repo punya cadangan → cadangan TERBARU otomatis
//      diunduh lalu dipulihkan lewat prosedur GANTI DATABASE standar
//      (performRestoreDb): validasi SQLite, salinan keamanan, rollback
//      otomatis, penyembuhan kolom usang.  [D70]
//
//   2. seq lokal < seq manifest GitHub dan perangkat sama → data lokal
//      mundur/rusak (mis. file .db diganti salinan lama) → pulihkan otomatis.
//      [D74 — baris 2 tabel keputusan]
//
//   3. seq lokal > seq manifest → ada backup yang belum terkirim → UNGGAH,
//      JANGAN restore. [D74 — baris 4 tabel keputusan; hanya saat auto-backup
//      aktif, dan pada mode harian hanya saat aplikasi dibuka agar cadangan
//      harian tetap satu commit per hari]
//
//   4. seq sama tapi deviceId repo berbeda (kedua sisi punya data) → KONFLIK
//      — tidak ada aksi otomatis; dicatat di kredensial + audit + banner di
//      Pengaturan, menunggu keputusan pemilik (pulihkan manual / unggah
//      manual). [D74 — baris 5 tabel keputusan]
//
// Keamanan: pulihkan hanya jalan bila Admin menyalakan autoRestore, dan (kecuali
// DB kosong) hanya bila perangkat penulis repo sama dengan perangkat ini —
// sehingga data yang lebih baru TIDAK PERNAH ditimpa otomatis. Akun pabrik
// (admin/1234) & profil toko tidak dihitung karena selalu ada di database baru
// hasil seed.
//
// Pemicu: 20 detik setelah server hidup, saat aplikasi dibuka dari sisi
// klien (POST /api/github/sync-check), lalu ikut dicek pada siklus 10 menit.
// Factory reset mematikan pengaturan ini otomatis (suppressAutoRestore +
// simpan autoRestore=false) agar data lama tidak "bangkit kembali" setelah
// reset yang disengaja.
const gRestore = globalThis as unknown as {
  __fixplusGithubRestore?: { running: boolean; suppressed: boolean };
};
const rst = (gRestore.__fixplusGithubRestore ??= { running: false, suppressed: false });

// Dipanggil factory reset SEBELUM data dihapus: database sengaja dikosongkan →
// auto-pulihkan tidak boleh memulihkan cadangan lama di sisa hidup proses ini.
// Pengaturan permanennya dinonaktifkan oleh route factory-reset (saveCreds).
export function suppressAutoRestore(): void {
  rst.suppressed = true;
}

// D85 — dibaca route bootstrap pra-login otomatis: setelah factory reset
// pemilik sengaja memulai dari kosong, mode auto TIDAK boleh menghidupkan
// kembali data lama (parity cek rst.suppressed di tickAutoSync).
export function isAutoRestoreSuppressed(): boolean {
  return rst.suppressed;
}

// D75 — diekspor untuk /api/github/bootstrap (cek pra-login) & banner pemulihan:
// "DB kosong" = keenam tabel bisnis nol (lihat penjelasan di atas).
export async function isDbBusinessEmpty(): Promise<boolean> {
  const [transactions, customers, repairs, spareParts, serviceProducts, preOrders] =
    await Promise.all([
      db.transaction.count(),
      db.customer.count(),
      db.repairRecord.count(),
      db.sparePart.count(),
      db.serviceProduct.count(),
      db.preOrder.count(),
    ]);
  return (
    transactions === 0 &&
    customers === 0 &&
    repairs === 0 &&
    spareParts === 0 &&
    serviceProducts === 0 &&
    preOrders === 0
  );
}

// Pulihkan cadangan TERBARU dari daftar file repo (terbaru dulu). Return true
// bila sukses. Alasan hanya untuk pesan log/audit.
async function autoRestoreLatest(
  c: GithubCreds,
  files: GithubFile[],
  branch: string,
  folder: string,
  alasan: string,
  actorName = "Sistem (Auto-Pulihkan)"
): Promise<boolean> {
  if (!files.length || !c.token || !c.repo) return false;
  const latest = files[0];
  console.log(`[github] auto-pulihkan (${alasan}) — "${latest.name}" dari ${c.repo}@${branch}`);
  const buf = await downloadFile(
    c.token,
    c.repo,
    branch,
    folder ? `${folder}/${latest.name}` : latest.name
  );
  const result = await performRestoreDb(buf, latest.name, actorName, "sistem");
  if (!result.ok) {
    console.error(`[github] auto-pulihkan ditolak: ${result.error}`);
    // D85 — kegagalan pulihkan otomatis tidak boleh BISU: pemilik melaporkan
    // kasus restore ditolak tanpa ada tanda apa pun di aplikasi. Sekarang
    // penolakan masuk panel notifikasi (dedupe 1 jam agar siklus 10 menit
    // tidak menumpuk) — terlihat jelas setelah login.
    await pushNotification({
      type: "RESTORE",
      title: "Pemulihan otomatis ditolak",
      message: `Cadangan "${latest.name}" tidak bisa dipulihkan: ${result.error} Dicoba ulang otomatis pada cek berikutnya; pulihkan manual tersedia di Pengaturan → Backup GitHub.`,
      meta: { fileName: latest.name, error: result.error, repo: c.repo },
      dedupeMs: 60 * 60 * 1000,
    });
    return false;
  }
  await updateCreds((cr) => ({
    ...cr,
    lastAutoRestoreAt: new Date().toISOString(),
    lastAutoRestoreFile: latest.name,
  }));
  // D81 — notifikasi permanen pemulihan database (kejadian besar: seluruh isi
  // database diganti dari cadangan — wajib terlihat di panel notifikasi).
  await pushNotification({
    type: "RESTORE",
    title: "Database dipulihkan dari GitHub",
    message: `Cadangan "${latest.name}" dipulihkan ke server (${alasan}). Pelaksana: ${actorName}.`,
    meta: { fileName: latest.name, alasan, actor: actorName, repo: c.repo },
  });
  console.log(`[github] auto-pulihkan selesai: ${result.summary}`);
  return true;
}

// D78 — PEMULIHAN PAKSA permintaan pemilik lewat layar bootstrap pra-login:
// data lokal TIDAK kosong tapi pemilik sudah mengonfirmasi "Tetap Pulihkan"
// di dialog → unduh cadangan rujukan manifest (atau file terbaru) dan GANTI
// database lokal TANPA memandang seq/perangkat penulis repo (tabel keputusan
// D74 bisa saja berakhir "konflik/tanpa aksi" — di sini pemilik sudah
// memutuskan). Salinan keamanan data lama tetap dibuat otomatis oleh
// performRestoreDb (<db>.pra-restore-*.bak) dan penanda konflik sinkronisasi
// lama dianggap selesai.
export async function forceRestoreLatestFromGithub(label?: {
  alasan?: string; // D85 — keterangan khusus mode otomatis untuk log/notifikasi
  actor?: string;
}): Promise<{
  ok: boolean;
  file?: string;
  error?: string;
  noBackups?: boolean; // D85 — repo valid tapi belum punya file cadangan (bukan error)
}> {
  const c = await loadCreds();
  if (!c.token || !c.repo) return { ok: false, error: "GitHub belum terhubung" };
  if (isRestoreBusy()) {
    return { ok: false, error: "Sedang ada proses pulihkan database berjalan" };
  }
  const branch = c.branch ?? DEFAULT_BRANCH;
  const folder = normalizeFolder(c.folder ?? DEFAULT_FOLDER);
  const files = await listBackupFiles(c.token, c.repo, branch, folder);
  if (!files.length) {
    return {
      ok: false,
      error: "Repo belum punya file cadangan — tidak ada yang bisa dipulihkan",
      noBackups: true,
    };
  }
  const m = await readGithubManifest(c.token, c.repo, branch, folder);
  let source = files[0];
  if (m?.lastBackupFile) {
    const hit = files.find((f) => f.name === m.lastBackupFile);
    // Rujukan manifest hilang di repo → pakai file terbaru (pemilik minta
    // paksa, jadi jangan menolak — berbeda dengan auto-restore yang menahan).
    if (hit) source = hit;
  }
  const restored = await autoRestoreLatest(
    c,
    [source],
    branch,
    folder,
    label?.alasan ?? "permintaan pemilik — pra-login, data lokal tidak kosong (D78)",
    label?.actor ?? "Pemilik (Pulihkan Paksa Pra-Login)"
  );
  if (!restored) {
    return { ok: false, error: "Pemulihan gagal — lihat Log Aktivitas / log server" };
  }
  if (m) await setDataVersion(m.seq); // seq lokal disamakan repo (lihat tickAutoSync)
  await saveCreds({ conflict: null }); // keputusan pemilik → konflik lama selesai
  return { ok: true, file: source.name };
}

// Catat konflik perangkat (sekali per keadaan — bukan spam tiap 10 menit):
// disimpan di kredensial untuk banner Pengaturan + satu baris audit.
async function recordConflict(
  c: GithubCreds,
  detail: string,
  manifest: GithubManifest,
  localSeq: number
): Promise<void> {
  const next: GithubSyncConflict = {
    detectedAt: new Date().toISOString(),
    detail,
    manifestDeviceId: manifest.deviceId ?? null,
    localSeq,
    manifestSeq: manifest.seq,
  };
  const cur = c.conflict;
  if (
    cur &&
    cur.detail === next.detail &&
    cur.localSeq === next.localSeq &&
    cur.manifestSeq === next.manifestSeq
  ) {
    return; // keadaan sama — jangan catat ulang
  }
  await saveCreds({ conflict: next });
  console.warn(`[github] KONFLIK SINKRONISASI — ${detail} Tunggu keputusan pemilik.`);
  await db.auditLog.create({
    data: {
      action: "GITHUB_SYNC_CONFLICT",
      details: `Konflik sinkronisasi GitHub: ${detail} Tidak ada aksi otomatis — selesaikan lewat Pulihkan/Unggah manual di Pengaturan.`,
      performedBy: "Sistem",
    },
  });
  // D81 — konflik butuh KEPUTUSAN pemilik → wajib masuk panel notifikasi
  // (recordConflict sudah anti-duplikat: keadaan sama tidak dicatat ulang).
  await pushNotification({
    type: "SYNC_CONFLICT",
    title: "Konflik sinkronisasi terdeteksi",
    message: `${detail} Tidak ada aksi otomatis — putuskan lewat tombol Pulihkan/Unggah di Pengaturan → Backup GitHub.`,
    meta: {
      manifestDeviceId: next.manifestDeviceId,
      localSeq: next.localSeq,
      manifestSeq: next.manifestSeq,
    },
  });
}

// Konflik selesai (seq sama & perangkat sama) → hapus penandanya.
async function clearConflict(c: GithubCreds): Promise<void> {
  if (!c.conflict) return;
  await saveCreds({ conflict: null });
  console.log("[github] konflik sinkronisasi selesai — penanda dihapus");
}

async function tickAutoSync(onOpen: boolean) {
  if (rst.running || rst.suppressed) return;
  rst.running = true;
  try {
    const c = await loadCreds();
    if (!c.token || !c.repo) return; // belum terhubung
    if (isRestoreBusy()) return; // pulihkan manual sedang berjalan
    const branch = c.branch ?? DEFAULT_BRANCH;
    const folder = normalizeFolder(c.folder ?? DEFAULT_FOLDER);
    const files = await listBackupFiles(c.token, c.repo, branch, folder);

    // ---- (1) DB kosong + repo ada cadangan → pulihkan (D70) ----
    if (await isDbBusinessEmpty()) {
      if (c.autoRestore !== true) return; // fitur dimatikan Admin
      if (!files.length) return; // belum ada cadangan → biarkan kosong
      // D76 — sumber pemulihan mengikuti MANIFEST (file yang terikat seq &
      // deviceId), bukan sekadar file terbaru di daftar. Bila file rujukan
      // manifest sudah tidak ada di repo (dihapus manual / aktor luar),
      // JANGAN mundur ke cadangan lebih lama — itu bisa menghidupkan kembali
      // data yang sengaja dihapus pemilik lewat factory reset. Catat konflik
      // agar pemilik memutuskan lewat Pengaturan.
      const m = await readGithubManifest(c.token, c.repo, branch, folder);
      let source: GithubFile | undefined = files[0];
      if (m?.lastBackupFile) {
        const hit = files.find((f) => f.name === m.lastBackupFile);
        if (!hit) {
          await recordConflict(
            c,
            `Manifest menunjuk cadangan "${m.lastBackupFile}" (seq ${m.seq}) tapi file itu sudah tidak ada di repo — pemulihan otomatis DITAHAN agar data lama tidak terhidupkan kembali. Buat backup baru atau pulihkan manual di Pengaturan.`,
            m,
            0
          );
          return;
        }
        source = hit;
      }
      // D74 — pengaman lingkaran: file cadangan yang SAMA tidak dipulihkan dua
      // kali. Tanpa ini, bila isi cadangan repo juga kosong (mis. cadangan
      // toko baru buka), tiap cek akan memulihkan ulang file yang sama —
      // menimpa seq lokal dan menumpuk salinan .pra-restore setiap siklus.
      // Cadangan LEBIH BARU (nama berbeda) tetap langsung dipulihkan.
      if (c.lastAutoRestoreFile === source.name) return;
      const restored = await autoRestoreLatest(c, [source], branch, folder, "database kosong");
      if (restored) {
        // D74 langkah 4 alur restore — seq lokal disamakan dengan GitHub:
        // file cadangan lama (pra-D74) tidak membawa AppMeta; tanpa ini lokal
        // akan dianggap "lebih tua" terus dan dipulihkan berulang-ulang.
        if (m) await setDataVersion(m.seq);
      }
      return;
    }

    // ---- (2) Ada data lokal → bandingkan nomor urut (D74) ----
    const manifest = await readGithubManifest(c.token, c.repo, branch, folder);
    if (!manifest) return; // repo belum punya manifest (cadangan pra-D74) → perilaku lama
    const localSeq = await getDataVersion();
    const sameDevice =
      !manifest.deviceId || !c.deviceId || manifest.deviceId === c.deviceId;

    if (localSeq < manifest.seq) {
      // GitHub lebih baru → data lokal mundur/rusak → pulihkan otomatis,
      // KECUALI penulis repo perangkat lain → konflik, tanya pemilik.
      if (c.autoRestore !== true) return;
      if (!sameDevice) {
        await recordConflict(
          c,
          `Repo lebih baru (seq ${manifest.seq}) tapi terakhir ditulis perangkat lain (${manifest.deviceId ?? "?"}), lokal seq ${localSeq}.`,
          manifest,
          localSeq
        );
        return;
      }
      // D76 — sumber pemulihan mengikuti manifest (lihat cabang DB kosong).
      // File rujukan hilang → jangan mundur ke cadangan lebih lama.
      const hit = manifest.lastBackupFile
        ? files.find((f) => f.name === manifest.lastBackupFile)
        : undefined;
      if (manifest.lastBackupFile && !hit) {
        await recordConflict(
          c,
          `Manifest menunjuk cadangan "${manifest.lastBackupFile}" (seq ${manifest.seq}) tapi file itu sudah tidak ada di repo — pemulihan otomatis DITAHAN agar data lama tidak terhidupkan kembali. Buat backup baru atau pulihkan manual di Pengaturan.`,
          manifest,
          localSeq
        );
        return;
      }
      const source = hit ?? files[0];
      // D74 — pengaman lingkaran (lihat cabang DB kosong): file yang sama
      // tidak dipulihkan dua kali berturut-turut.
      if (source.name === c.lastAutoRestoreFile) return;
      const restored = await autoRestoreLatest(
        c,
        [source],
        branch,
        folder,
        `lokal lebih tua (seq ${localSeq} < repo ${manifest.seq})`
      );
      if (restored) await setDataVersion(manifest.seq);
      return;
    }

    if (localSeq > manifest.seq) {
      // Ada backup yang belum terkirim → UNGGAH, jangan restore. Mode harian
      // hanya saat aplikasi dibuka (bukan tiap 10 menit) agar tetap 1 commit/hari.
      const auto = resolveAuto(c.auto);
      if (!auto.enabled) return;
      if (!onOpen && auto.mode !== "onchange") return;
      if (sched.running) return;
      sched.running = true;
      try {
        clearDirty(); // snapshot penuh mencakup SEMUA perubahan — penanda lama tak relevan
        const out = await performGithubBackup("Sistem (Sinkron-Awal)");
        console.log(
          `[github] sinkron-awal: backup belum terkirim diunggah "${out.fileName}" (seq lokal ${localSeq} > repo ${manifest.seq})`
        );
      } catch (e) {
        markDataChange(); // gagal → tandai lagi, dicoba ulang siklus berikutnya
        throw e;
      } finally {
        sched.running = false;
      }
      return;
    }

    // seq sama:
    if (!sameDevice) {
      await recordConflict(
        c,
        `Versi data sama (seq ${manifest.seq}) tapi repo terakhir ditulis perangkat lain (${manifest.deviceId ?? "?"}).`,
        manifest,
        localSeq
      );
      return; // tanya pemilik — jangan sentuh data
    }
    await clearConflict(c); // normal — bersihkan penanda konflik lama bila ada
  } catch (e) {
    console.error("[github] sinkronisasi awal gagal — dicoba ulang pada cek berikutnya:", e);
    // D81 — kegagalan berulang tiap 10 menit (mis. token kedaluwarsa, jaringan
    // mati) diberitahu sekali per jam lewat panel notifikasi (anti-spam).
    const msg = e instanceof Error ? e.message : String(e);
    await pushNotification({
      type: "SYNC_ERROR",
      title: "Pemeriksaan sinkronisasi GitHub gagal",
      message: `${msg} — dicoba ulang pada cek berikutnya (tiap 10 menit).`,
      meta: { error: msg },
      dedupeMs: 60 * 60 * 1000,
    });
  } finally {
    rst.running = false;
  }
}

// D74 — dipanggil route /api/github/sync-check saat aplikasi DIBUKA (parity
// "pengecekan di splash screen sebelum UI kasir tampil"): jalankan pemeriksaan
// di luar siklus 10 menit.
export function triggerAutoSync(): Promise<void> {
  return tickAutoSync(true);
}

// ===== Auto-backup harian + per-perubahan (dipanggil penjadwal di instrumentation) =====
// Status penjadwal di globalThis agar semua salinan instansi modul berbagi
// satu penjadwal — tidak ada interval ganda maupun balapan antar-salinan.
const gSched = globalThis as unknown as {
  __fixplusGithubSched?: { started: boolean; running: boolean };
};
const sched = (gSched.__fixplusGithubSched ??= { started: false, running: false });

export function startGithubAutoBackup() {
  if (sched.started) return;
  sched.started = true;
  console.log("[github] penjadwal auto-backup + sinkronisasi awal terpasang");
  const tick = async () => {
    try {
      await autoBackupTick();
    } catch (e) {
      console.error("[github] auto-backup gagal:", e);
    }
    // D70/D74 — sinkronisasi awal dicek pada siklus yang sama (tiap 10 menit).
    // onOpen=false: mode harian TIDAK mengunggah di sini (hanya saat dibuka).
    try {
      await tickAutoSync(false);
    } catch (e) {
      console.error("[github] sinkronisasi awal gagal:", e);
    }
  };
  setTimeout(tick, 45_000); // cek pertama 45 detik setelah server hidup
  setInterval(tick, 10 * 60_000); // lalu tiap 10 menit
  // D70/D74 — percobaan sinkronisasi lebih awal: 20 detik setelah server hidup
  // (ensureSchema di instrumentation sudah selesai sebelum penjadwal ini dipasang).
  // onOpen=true: sama dengan kondisi "aplikasi dibuka" — unggah backup pending.
  setTimeout(() => void tickAutoSync(true), 20_000);
  // D69 — penjadwal mode "per-perubahan": cek penanda perubahan tiap 30 detik.
  setTimeout(() => void tickOnChange(), 60_000);
  setInterval(() => void tickOnChange(), 30_000);
}

async function autoBackupTick() {
  if (sched.running) return;
  sched.running = true;
  try {
    const c = await loadCreds();
    const auto = resolveAuto(c.auto);
    if (auto.mode !== "daily") return; // off / per-perubahan → bukan jalur jadwal ini
    if (!c.token || !c.repo) return;
    if (c.conflict) return; // D77 — konflik menunggu keputusan pemilik, jangan unggah
    const now = jakartaNow();
    if (auto.hour > now.hour) return; // belum jamnya hari ini
    if (c.lastAutoBackupDate === now.dateStr) return; // sudah dibackup hari ini
    try {
      const out = await performGithubBackup("Sistem (Auto-Backup)");
      await updateCreds((cr) => ({ ...cr, lastAutoBackupDate: now.dateStr }));
      console.log(`[github] auto-backup selesai: ${out.fileName} → ${out.repo}@${out.branch}`);
    } catch (e) {
      // D81 — backup harian otomatis gagal → notifikasi permanen (maks sekali
      // per jam agar siklus 10 menit yang gagal terus tidak menumpuk).
      const msg = e instanceof Error ? e.message : String(e);
      await pushNotification({
        type: "BACKUP_FAILED",
        title: "Backup otomatis harian GAGAL",
        message: `${msg} — dicoba ulang pada siklus berikutnya.`,
        meta: { mode: "daily", error: msg },
        dedupeMs: 60 * 60 * 1000,
      });
      throw e;
    }
  } finally {
    sched.running = false;
  }
}

// Mode "per-perubahan" (D69): backup ketika data sudah tenang DEBOUNCE sejak
// perubahan terakhir, ATAU saat MAX_WAIT sejak perubahan pertama terlampaui
// (data terus berubah tanpa henti). Bila backup gagal, penanda perubahan
// dipasang ulang dengan batas waktu baru agar dicoba lagi — bukan spam tiap 30 detik.
async function tickOnChange() {
  if (sched.running) return;
  try {
    const c = await loadCreds();
    if (resolveAuto(c.auto).mode !== "onchange") return;
    if (!c.token || !c.repo) return;
    if (c.conflict) return; // D77 — konflik menunggu keputusan pemilik, jangan unggah
    const s = peekDirty();
    if (!s.dirty || s.firstDirtyAt === null) return;
    const now = Date.now();
    const quiet = now - s.lastChangeAt >= ONCHANGE_DEBOUNCE_MS;
    const waited = now - s.firstDirtyAt >= ONCHANGE_MAX_WAIT_MS;
    if (!quiet && !waited) return;
    sched.running = true;
    try {
      clearDirty();
      const out = await performGithubBackup("Sistem (Auto-Backup)");
      await updateCreds((cr) => ({ ...cr, lastAutoBackupDate: jakartaNow().dateStr }));
      console.log(`[github] auto-backup perubahan selesai: ${out.fileName} → ${out.repo}@${out.branch}`);
    } catch (e) {
      markDataChange(); // coba lagi nanti (jeda baru), bukan tiap 30 detik
      throw e;
    } finally {
      sched.running = false;
    }
  } catch (e) {
    console.error("[github] auto-backup perubahan gagal:", e);
    // D81 — backup per-perubahan otomatis gagal → notifikasi permanen
    // (maks sekali per jam; kegagalan beruntun tidak menumpuk panel).
    const msg = e instanceof Error ? e.message : String(e);
    await pushNotification({
      type: "BACKUP_FAILED",
      title: "Backup otomatis per-perubahan GAGAL",
      message: `${msg} — penanda perubahan dipasang ulang, dicoba lagi setelah data tenang.`,
      meta: { mode: "onchange", error: msg },
      dedupeMs: 60 * 60 * 1000,
    });
  }
}

// Jaring pengaman: pastikan penjadwal terpasang juga bila modul ini dimuat
// lewat route (instrumentation terlewat / dev belum menjalankan ulangnya).
// schedStarted mencegah pemasangan ganda pada instance modul yang sama.
if (typeof window === "undefined") {
  startGithubAutoBackup();
}
