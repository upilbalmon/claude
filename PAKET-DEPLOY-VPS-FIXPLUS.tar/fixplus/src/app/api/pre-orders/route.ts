import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { spareCategoryOf } from "@/lib/spare-category";
import { PREORDER_STATUS_ORDER } from "@/lib/belanja-utils";

// D61 — Tahap 6.1: Pre-Order pelanggan dengan DP.
// GET /api/pre-orders — daftar + statistik; POST — buat pre-order baru
// (status awal Pending). Kaitan pelanggan & tiket servis opsional (item 6.4).

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = req.nextUrl;
    const status = String(searchParams.get("status") ?? "").trim();
    const q = String(searchParams.get("q") ?? "").trim();

    const where: Record<string, unknown> = {};
    if (status && (PREORDER_STATUS_ORDER as readonly string[]).includes(status)) {
      where.status = status;
    }
    if (q) {
      where.OR = [
        { customerName: { contains: q } },
        { customerPhone: { contains: q } },
        { itemName: { contains: q } },
        { notes: { contains: q } },
      ];
    }

    const rows = await db.preOrder.findMany({
      where,
      orderBy: { createdAt: "desc" },
      include: {
        customer: { select: { id: true, name: true, phone: true, loyaltyPoints: true } },
        // D63: createdAt tiket ikut — kode SRV-<epoch> di UI/struk memakai tanggal
        // tiket yang SEBENARNYA (sebelumnya dipakai approximasi createdAt pre-order).
        repairRecord: { select: { id: true, deviceModel: true, status: true, customerName: true, createdAt: true } },
        transaction: { select: { id: true, invoiceNumber: true, grandTotal: true, paymentStatus: true, timestamp: true } },
      },
    });

    // Statistik untuk kartu ringkasan (dihitung dari seluruh data, bukan hanya
    // hasil filter — angka kartu tetap stabil saat pengguna mencari/menyaring)
    const all = await db.preOrder.findMany({ select: { status: true, dp: true, qty: true, estPrice: true } });
    const aktif = all.filter((r) => ["Pending", "Dipesan", "Tiba"].includes(r.status));
    const stats = {
      total: all.length,
      perStatus: Object.fromEntries(
        PREORDER_STATUS_ORDER.map((s) => [s, all.filter((r) => r.status === s).length])
      ) as Record<string, number>,
      aktif: aktif.length,
      dpTertahan: aktif.reduce((n, r) => n + r.dp, 0), // DP sudah diterima, pesanan belum selesai
      nilaiAktif: aktif.reduce((n, r) => n + r.estPrice * r.qty, 0),
    };

    return NextResponse.json({ rows, stats });
  } catch (e) {
    console.error("pre-orders GET error", e);
    return NextResponse.json({ error: "Gagal memuat pre-order" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const itemName = String(body.itemName ?? "").trim();
    if (!itemName) {
      return NextResponse.json({ error: "Nama barang wajib diisi" }, { status: 400 });
    }

    const qty = clampInt(body.qty, 1, 1, 999);
    const estPrice = clampNum(body.estPrice, 0, 0);
    const dp = clampNum(body.dp, 0, 0);
    const estTotal = estPrice * qty;
    if (estTotal > 0 && dp > estTotal) {
      return NextResponse.json(
        { error: `DP (${fmtRp(dp)}) tidak boleh melebihi estimasi total (${fmtRp(estTotal)})` },
        { status: 400 }
      );
    }

    // Kaitan pelanggan (6.4): pelanggan terdaftar mengisi nama/telepon otomatis;
    // tanpa pelanggan → nama manual wajib (pembeli umum).
    let customerId: number | null = null;
    let customerName = String(body.customerName ?? "").trim();
    let customerPhone = String(body.customerPhone ?? "").trim();
    if (body.customerId !== undefined && body.customerId !== null && String(body.customerId).trim() !== "") {
      const cid = Number(body.customerId);
      if (!Number.isInteger(cid)) {
        return NextResponse.json({ error: "ID pelanggan tidak valid" }, { status: 400 });
      }
      const cust = await db.customer.findUnique({ where: { id: cid } });
      if (!cust) {
        return NextResponse.json({ error: "Pelanggan tidak ditemukan" }, { status: 404 });
      }
      customerId = cid;
      if (!customerName) customerName = cust.name;
      if (!customerPhone) customerPhone = cust.phone;
    }
    if (!customerName) {
      return NextResponse.json({ error: "Nama pelanggan wajib diisi" }, { status: 400 });
    }

    // Kaitan tiket servis (6.4): opsional, tiket harus ada.
    let repairRecordId: number | null = null;
    if (body.repairRecordId !== undefined && body.repairRecordId !== null && String(body.repairRecordId).trim() !== "") {
      const rid = Number(body.repairRecordId);
      if (!Number.isInteger(rid)) {
        return NextResponse.json({ error: "ID tiket servis tidak valid" }, { status: 400 });
      }
      const repair = await db.repairRecord.findUnique({ where: { id: rid } });
      if (!repair) {
        return NextResponse.json({ error: "Tiket servis tidak ditemukan" }, { status: 404 });
      }
      repairRecordId = rid;
    }

    // D63: include relasi agar respons lengkap — struk tanda terima langsung
    // bisa ditampilkan UI setelah pre-order dicatat.
    const row = await db.preOrder.create({
      data: {
        customerId,
        repairRecordId,
        customerName,
        customerPhone,
        itemName,
        category: spareCategoryOf(body.category),
        qty,
        estPrice,
        dp,
        notes: String(body.notes ?? "").trim(),
        status: "Pending",
      },
      include: {
        customer: { select: { id: true, name: true, phone: true, loyaltyPoints: true } },
        repairRecord: { select: { id: true, deviceModel: true, status: true, customerName: true, createdAt: true } },
        transaction: { select: { id: true, invoiceNumber: true, grandTotal: true, paymentStatus: true, timestamp: true } },
      },
    });

    const performedBy = String(body.performedBy ?? "Tidak diketahui");
    await db.auditLog.create({
      data: {
        action: "TAMBAH_PREORDER",
        details: `${row.itemName} ×${row.qty} — ${row.customerName} (DP Rp ${Math.trunc(row.dp).toLocaleString("id-ID")})`,
        performedBy,
      },
    });

    return NextResponse.json(row, { status: 201 });
  } catch (e) {
    console.error("pre-orders POST error", e);
    return NextResponse.json({ error: "Gagal menyimpan pre-order" }, { status: 500 });
  }
}

function clampInt(v: unknown, fallback: number, min: number, max: number): number {
  const n = Math.trunc(Number(v));
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
}

function clampNum(v: unknown, fallback: number, min: number): number {
  const n = Number(v);
  return Number.isFinite(n) && n >= min ? n : fallback;
}

function fmtRp(n: number): string {
  return `Rp ${Math.trunc(n).toLocaleString("id-ID")}`;
}
