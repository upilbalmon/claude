import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { db } from "@/lib/db";
import {
  loadCreds,
  resolveMethod,
  tokenAndFolder,
  downloadDriveFile,
  deleteDriveFile,
  getDriveFileInfo,
} from "@/lib/gdrive";

type Params = { params: Promise<{ id: string }> };

// D67 — GET /api/gdrive/files/[id]?requesterUsername=&method=&download=1
// download=1 → proxy unduhan file cadangan dari Drive (untuk disimpan lokal).
// Tanpa download → metadata (dipakai validasi sebelum restore).
export async function GET(req: NextRequest, { params }: Params) {
  const sp = req.nextUrl.searchParams;
  const actor = await resolveActor(sp.get("requesterUsername"));
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const id = String((await params).id ?? "").trim();
  if (!/^[\w-]+$/.test(id)) return errAction("ID file tidak valid", 400);

  const methodRaw = sp.get("method") ?? "auto";
  const method = methodRaw === "oauth" || methodRaw === "sa" ? methodRaw : "auto";
  try {
    const c = await loadCreds();
    const kind = await resolveMethod(c, method);
    const { token } = await tokenAndFolder(kind, c);
    if (sp.get("download") === "1") {
      const buf = await downloadDriveFile(token, id);
      let fileName = `${id}.db`;
      try {
        fileName = (await getDriveFileInfo(token, id)).name;
      } catch { /* pakai id */ }
      const safeName = fileName.replace(/[^\w.\-]/g, "_");
      return new NextResponse(new Uint8Array(buf), {
        headers: {
          "Content-Type": "application/octet-stream",
          "Content-Disposition": `attachment; filename="${safeName}"`,
        },
      });
    }
    return NextResponse.json({ ok: true, file: await getDriveFileInfo(token, id) });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("gdrive file detail error", e);
    return errAction(msg, 400);
  }
}

// D67 — DELETE /api/gdrive/files/[id] — hapus satu file cadangan di Drive.
export async function DELETE(req: NextRequest, { params }: Params) {
  const body = (await req.json().catch(() => ({}))) as { requesterUsername?: unknown };
  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const id = String((await params).id ?? "").trim();
  if (!/^[\w-]+$/.test(id)) return errAction("ID file tidak valid", 400);

  const sp = req.nextUrl.searchParams;
  const methodRaw = sp.get("method") ?? "auto";
  const method = methodRaw === "oauth" || methodRaw === "sa" ? methodRaw : "auto";
  try {
    const c = await loadCreds();
    const kind = await resolveMethod(c, method);
    const { token } = await tokenAndFolder(kind, c);
    const info = await getDriveFileInfo(token, id);
    await deleteDriveFile(token, id);
    await db.auditLog.create({
      data: {
        action: "GDRIVE_DELETE_FILE",
        details: `Cadangan "${info.name}" dihapus dari Google Drive (${kind === "oauth" ? "OAuth" : "Service Account"})`,
        performedBy: actor.name,
      },
    });
    return NextResponse.json({ ok: true });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("gdrive file delete error", e);
    return errAction(msg, 400);
  }
}
