"use client";

// PinUnlockScreen.kt — layar buka-kunci sesi, kini memakai PinInput Adaptif (Keputusan D1):
// desktop cukup ketik 4 angka di keyboard (auto-buka), keypad grafis hanya untuk layar sentuh.
import { useState } from "react";
import { Lock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { PinInput } from "@/components/app/pin-input";
import type { SafeUser } from "@/lib/app-types";

export function PinUnlockScreen({
  user,
  onUnlocked,
  onLogout,
}: {
  user: SafeUser;
  onUnlocked: (user: SafeUser) => void;
  onLogout: () => void;
}) {
  const { toast } = useToast();
  const [pinValue, setPinValue] = useState("");
  const [errorTick, setErrorTick] = useState(0);
  const [busy, setBusy] = useState(false);

  async function submitPin(pin: string) {
    if (busy || pin.length < 4) return;
    setBusy(true);
    try {
      const res = await fetch("/api/auth/unlock", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id, pin }),
      });
      const data = await res.json();
      if (data.status === "SUCCESS") {
        onUnlocked(data.user as SafeUser);
      } else {
        toast({ title: data.message ?? "PIN salah!", variant: "destructive" });
        setPinValue("");
        setErrorTick((t) => t + 1);
      }
    } catch {
      toast({ title: "Tidak dapat terhubung ke server", variant: "destructive" });
      setPinValue("");
      setErrorTick((t) => t + 1);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-accent/60 to-background p-6">
      <div className="flex w-full max-w-[400px] flex-col items-center">
        <div className="flex size-16 items-center justify-center rounded-full bg-primary/10">
          <Lock className="size-8 text-primary" aria-hidden />
        </div>
        <p className="mt-6 text-[22px] font-bold">Sesi Terkunci</p>
        <p className="mt-2 text-center text-sm text-muted-foreground">
          Silakan masukkan PIN untuk {user.name}
        </p>
        <div className="mt-10 w-full">
          <PinInput
            value={pinValue}
            onChange={setPinValue}
            onComplete={(pin) => void submitPin(pin)}
            errorTick={errorTick}
            disabled={busy}
            variant="bare"
            ariaLabel={`PIN untuk ${user.name}`}
          />
        </div>
        <button
          type="button"
          onClick={onLogout}
          className="mt-10 text-sm font-semibold text-destructive underline-offset-4 hover:underline"
        >
          Keluar &amp; Ganti Akun
        </button>
      </div>
    </div>
  );
}
