import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { resolveActor } from "@/lib/action-guard"; // D34/D39

// GET /api/settings — profil toko (dipakai LoginScreen: judul = nama toko)
export async function GET() {
  try {
    let settings = await db.shopSettings.findUnique({ where: { id: 1 } });
    if (!settings) {
      settings = await db.shopSettings.create({ data: { id: 1 } });
    }
    return NextResponse.json(settings);
  } catch (e) {
    console.error("settings error", e);
    return NextResponse.json({ error: "Gagal memuat pengaturan" }, { status: 500 });
  }
}

// PUT /api/settings — simpan profil toko & template WhatsApp per status servis
// (Tahap 4: editor WA menyimpan template ke DB ShopSettings.waTemplates agar
// berlaku untuk semua perangkat; UI pemusatannya dibangun di Tahap 7).
// Tahap 7.1: perubahan profil toko dicatat ke audit log (EDIT_PROFIL_TOKO).
// D39: menerima editTransactionDate (ThemeSettings referensi) + requesterUsername
// — server memverifikasi identitas aktor (D34) sebelum mengubah pengaturan.
export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    // D34: identitas dari requesterUsername yang diverifikasi server (bukan string bebas)
    const actor = await resolveActor(body.requesterUsername, false);
    if (!actor) {
      return NextResponse.json(
        { error: "Akses ditolak — akun tidak dikenali" },
        { status: 403 }
      );
    }
    const performedBy = actor.name;
    const current = (await db.shopSettings.findUnique({ where: { id: 1 } })) ??
      (await db.shopSettings.create({ data: { id: 1 } }));

    const shopName = String(body.shopName ?? current.shopName).trim() || current.shopName;
    const address = String(body.address ?? current.address);
    const phone = String(body.phone ?? current.phone);
    const receiptFooter = String(body.receiptFooter ?? current.receiptFooter);
    // waTemplates divalidasi JSON object sebelum disimpan
    let waTemplates = current.waTemplates;
    if (body.waTemplates !== undefined) {
      try {
        const parsed = JSON.parse(String(body.waTemplates));
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          waTemplates = JSON.stringify(parsed);
        }
      } catch {
        return NextResponse.json({ error: "Format template WhatsApp tidak valid" }, { status: 400 });
      }
    }

    // D39: toggle "Edit Tanggal Transaksi" (ThemeSettings referensi) — hanya
    // Admin yang boleh mengubahnya; perubahan dicatat ke audit log.
    let editTransactionDate = current.editTransactionDate;
    if (body.editTransactionDate !== undefined) {
      if (actor.role !== "Admin") {
        return NextResponse.json(
          { error: "Akses ditolak — hanya Admin yang boleh mengubah pengaturan operasional" },
          { status: 403 }
        );
      }
      editTransactionDate = Boolean(body.editTransactionDate);
    }

    const updated = await db.shopSettings.update({
      where: { id: 1 },
      data: { shopName, address, phone, receiptFooter, waTemplates, editTransactionDate },
    });

    // Tahap 7.1: audit hanya bila profil toko (bukan template WA) yang berubah
    if (body.shopName !== undefined || body.address !== undefined || body.phone !== undefined || body.receiptFooter !== undefined) {
      await db.auditLog.create({
        data: {
          action: "EDIT_PROFIL_TOKO",
          details: `${updated.shopName} (Telp: ${updated.phone || "-"})`,
          performedBy,
        },
      });
    }

    // D39: audit perubahan pengaturan operasional (Edit Tanggal Transaksi)
    if (body.editTransactionDate !== undefined && editTransactionDate !== current.editTransactionDate) {
      await db.auditLog.create({
        data: {
          action: "EDIT_PENGATURAN_OPERASIONAL",
          details: `Edit Tanggal Transaksi ${editTransactionDate ? "DIAKTIFKAN" : "DIMATIKAN"} (kasir ${editTransactionDate ? "boleh" : "tidak boleh"} mengubah tanggal/waktu saat pembayaran)`,
          performedBy,
        },
      });
    }

    return NextResponse.json(updated);
  } catch (e) {
    console.error("settings PUT error", e);
    return NextResponse.json({ error: "Gagal menyimpan pengaturan" }, { status: 500 });
  }
}
