"use client";

// Tahap 6 (D61): modul BELANJA kini lengkap — placeholder dihapus.
import { Hammer } from "lucide-react";
import { InventorySection } from "@/components/app/sections/inventory-section";
import { CustomersSection } from "@/components/app/sections/customers-section";
import { CashierSection } from "@/components/app/sections/kasir-section"; // Tahap 3
import { ServisSection } from "@/components/app/sections/servis-section"; // Tahap 4
import { SettingSection } from "@/components/app/sections/settings-section"; // Tahap 7
import { LaporanSection } from "@/components/app/sections/laporan-section"; // Tahap 5A (D48)
import { BelanjaSection } from "@/components/app/sections/belanja-section"; // Tahap 6 (D61)
import { AttendanceSection } from "@/components/app/sections/attendance-section"; // D73 — absensi karyawan
import type { Repair } from "@/components/app/sections/servis-receipt";
import type { ShopTab, SafeUser } from "@/lib/app-types";

export function SectionBody({
  tab,
  user,
  pendingRepair,
  onCheckoutRepair,
  onClearPendingRepair,
  onShopUpdated,
  onSwitchUser,
  onOpenServiceForm,
  serviceFormRequest,
  onServiceFormRequestConsumed,
  onLogout,
}: {
  tab: ShopTab;
  user: SafeUser;
  // Tahap 4.6: tiket servis "Bayar (POS)" diteruskan ke tab Kasir (ala
  // selectedRepairForCheckout MainLayout.kt)
  pendingRepair: Repair | null;
  onCheckoutRepair: (r: Repair) => void;
  onClearPendingRepair: () => void;
  // Tahap 7.1: profil toko tersimpan → top bar/login ikut memperbarui nama
  onShopUpdated: (shopName: string) => void;
  // D41: gerbang "Akses Terbatas" Setting — pilih Admin + PIN → sesi berpindah
  onSwitchUser: (u: SafeUser) => void;
  // D72: "Tambah Transaksi → Terima Servis" dari halaman Kasir — pindah tab
  // Servis + form tiket langsung terbuka (ala FAB referensi CashierSection)
  onOpenServiceForm: () => void;
  serviceFormRequest: boolean;
  onServiceFormRequestConsumed: () => void;
  // D92: halaman Absensi — tombol "Tutup Laci" menutup absen lalu logout
  onLogout: () => void;
}) {
  switch (tab) {
    case "LAPORAN":
      // Tahap 5A (D48): laporan dari data yang sudah ada — ringkasan keuangan,
      // penjualan per kategori/metode/kasir/teknisi, kartu servis & garansi,
      // piutang, stok (Admin), grafik harian, rekap UMKM + CSV, kartu D37.
      return <LaporanSection user={user} />;
    case "SERVIS":
      // Tahap 4: modul lengkap (tiket, alur status, nota A5, WA, estimator)
      // D72: + pemicu "Terima Servis" dari halaman Kasir
      return (
        <ServisSection
          user={user}
          onCheckoutRepair={onCheckoutRepair}
          openServiceForm={serviceFormRequest}
          onOpenServiceFormConsumed={onServiceFormRequestConsumed}
        />
      );
    case "KASIR":
      // Tahap 3: modul lengkap (POS + riwayat + struk 58mm); Tahap 4: tiket servis dibawa ke sini
      // D72: + menu Tambah Transaksi (Kasir/Servis) di Riwayat
      return (
        <CashierSection
          user={user}
          pendingRepair={pendingRepair}
          onClearPendingRepair={onClearPendingRepair}
          onOpenServiceForm={onOpenServiceForm}
        />
      );
    case "INVENTARIS":
      // Tahap 1: modul lengkap (sparepart + produk jasa)
      return <InventorySection user={user} />;
    case "BELANJA":
      // Tahap 6 (D61): modul lengkap — Pre-Order + DP, Barang Pesanan,
      // Rekomendasi Belanja (saran restock & daftar belanja).
      return <BelanjaSection user={user} />;
    case "PELANGGAN":
      // Tahap 2: modul lengkap (pelanggan & loyalitas + teknisi)
      return <CustomersSection user={user} />;
    case "ABSENSI":
      // D73 — Absensi Karyawan. D92 — absen otomatis saat login + kas laci:
      // rekap semua karyawan + catat manual/edit/hapus hanya Admin;
      // "Tutup Laci" dari halaman ini menutup absen lalu logout.
      return <AttendanceSection user={user} onLogout={onLogout} />;
    case "SETTING":
      // Tahap 7: modul lengkap (Profil Toko, Tampilan, Data & Backup, Pengguna & izin,
      // Log Aktivitas). Ganti PIN sendiri ada di dropdown akun topbar (semua role).
      // D41: halaman digate izin Setting — tanpa izin tampil gerbang "pilih Admin + PIN".
      return (
        <SettingSection user={user} onShopUpdated={onShopUpdated} onSwitchUser={onSwitchUser} />
      );
    default:
      return <Hammer className="size-6" aria-hidden />;
  }
}
