import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { exportBackup, BACKUP_ENTITIES, type BackupEntity } from "@/lib/db-backup";
import { db } from "@/lib/db";

// D40 — GET /api/database/backup?entities=customers,users&download=1&requesterUsername=...
// Cadangan JSON granular (parity "Cadangkan / Impor Granular (Format JSON)" referensi).
// ?download=1 → file .json terunduh; tanpa itu → JSON mentah (untuk tombol "Salin").
// Admin-only karena payload memuat hash PIN pengguna.
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const actor = await resolveActor(sp.get("requesterUsername"));
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const valid = new Set(BACKUP_ENTITIES.map((e) => e.key));
  const requested = (sp.get("entities") ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter((s): s is BackupEntity => valid.has(s as BackupEntity));
  const entities = requested.length ? requested : BACKUP_ENTITIES.map((e) => e.key);

  try {
    const payload = await exportBackup(entities);
    await db.auditLog.create({
      data: {
        action: "BACKUP_DATABASE",
        details: `Cadangan JSON: ${entities.join(", ")}`,
        performedBy: actor.name,
      },
    });
    if (sp.get("download") === "1") {
      const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
      return new NextResponse(JSON.stringify(payload, null, 2), {
        headers: {
          "Content-Type": "application/json; charset=utf-8",
          "Content-Disposition": `attachment; filename="cadangan-fixplus-${stamp}.json"`,
        },
      });
    }
    return NextResponse.json(payload);
  } catch (e) {
    console.error("database backup error", e);
    return NextResponse.json({ error: "Gagal membuat cadangan" }, { status: 500 });
  }
}
