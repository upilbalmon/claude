import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { performRestoreDb } from "@/lib/db-restore";

// D43 — POST /api/database/restore-db (multipart/form-data)
// Lanjutan D40 "Ekspor File .db": file .db bisa DIPULIHKAN (parity
// "Impor File .db" pada aplikasi referensi yang menyalin file database).
//
// Semantik = GANTI SELURUH DATABASE dengan isi file (bukan merge seperti
// /api/database/restore JSON/CSV). Seluruh prosedur aman (validasi SQLite,
// checkpoint WAL, salinan keamanan, rollback otomatis, verifikasi skema,
// penyembuhan kolom usang) kini hidup di src/lib/db-restore.ts agar persis
// sama dipakai juga oleh "Pulihkan dari Google Drive" (/api/gdrive/restore).
export async function POST(req: NextRequest) {
  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return errAction("Formulir tidak valid", 400);
  }
  const actor = await resolveActor(String(form.get("requesterUsername") ?? ""));
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const file = form.get("file");
  if (!(file instanceof File) || file.size === 0) {
    return errAction("File database (.db) tidak ditemukan dalam formulir", 400);
  }
  const buf = Buffer.from(await file.arrayBuffer());
  const result = await performRestoreDb(buf, file.name, actor.name, actor.username, file.size);
  if (!result.ok) return errAction(result.error, result.status);
  return NextResponse.json(result);
}
