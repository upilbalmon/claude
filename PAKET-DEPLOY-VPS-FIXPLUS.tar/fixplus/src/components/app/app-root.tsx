"use client";

// AppRoot — mesin status: bootstrap GitHub → login → shell → kunci sesi (idle 5 menit, MainLayout.kt)
import { useCallback, useEffect, useRef, useState } from "react";
import { LoginScreen } from "@/components/app/login-screen";
import { PinUnlockScreen } from "@/components/app/pin-unlock";
import { AppShell } from "@/components/app/app-shell";
import { BootstrapScreen } from "@/components/app/bootstrap-screen"; // D75 — setup token pra-login
import { KasAwalDialog } from "@/components/app/kas-laci"; // D92 — kas awal wajib
import type { SafeUser } from "@/lib/app-types";

const SESSION_KEY = "sphp_user";
const IDLE_LOCK_MS = 5 * 60 * 1000; // 5 menit idle → kunci sesi (MainLayout.kt)
const BOOTSTRAP_SKIP_KEY = "sphp_bootstrap_skip"; // D75 — "lewat dulu" per sesi

export function AppRoot() {
  const [user, setUser] = useState<SafeUser | null>(null);
  const [ready, setReady] = useState(false);
  const [locked, setLocked] = useState(false);
  const [shopName, setShopName] = useState("Servis HP & POS");
  // D92 — kas awal wajib: bila pemakai BELUM punya sesi kas laci hari ini
  // (login pertama dalam 1 hari), dialog "Isi Kas Awal" ditampilkan di atas
  // aplikasi dan tidak bisa ditutup sebelum diisi.
  const [needKasAwal, setNeedKasAwal] = useState(false);
  const [jamMasuk, setJamMasuk] = useState<string | null>(null);
  // D75 — pra-login: cek apakah token GitHub sudah ada. Bila belum, layar
  // setup pemulihan ditampilkan SEBELUM login (aturan pemilik: buka aplikasi
  // → cek token → kosong → minta token → pulihkan → baru login).
  const [stage, setStage] = useState<"checking" | "setup" | "login">("checking");
  const lastInteraction = useRef<number>(Date.now());

  // Nama toko (ditampilkan di login & topbar) — dipanggil ulang setelah
  // bootstrap karena database bisa terganti hasil pemulihan.
  const fetchShopName = useCallback(() => {
    fetch("/api/settings")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d?.shopName) setShopName(d.shopName);
      })
      .catch(() => undefined);
  }, []);

  // Pulihkan sesi dari sessionStorage
  useEffect(() => {
    try {
      const raw = sessionStorage.getItem(SESSION_KEY);
      if (raw) setUser(JSON.parse(raw) as SafeUser);
    } catch {
      // abaikan sesi rusak
    }
    setReady(true);
  }, []);

  useEffect(() => {
    fetchShopName();
  }, [fetchShopName]);

  // D75 — cek token pra-login saat aplikasi dibuka.
  useEffect(() => {
    let cancelled = false;
    const decide = async () => {
      try {
        const res = await fetch("/api/github/bootstrap");
        const d = (await res.json()) as { configured?: boolean };
        if (cancelled) return;
        if (!d.configured) {
          try {
            if (sessionStorage.getItem(BOOTSTRAP_SKIP_KEY) === "1") {
              setStage("login");
              return;
            }
          } catch {
            // storage tidak tersedia — tetap tawarkan setup
          }
          setStage("setup");
          return;
        }
        setStage("login");
      } catch {
        if (!cancelled) setStage("login"); // server belum siap — jangan blokir login
      }
    };
    void decide();
    return () => {
      cancelled = true;
    };
  }, []);

  // D74 — cek sinkronisasi backup SAAT APLIKASI DIBUKA (parity pengecekan di
  // splash screen sebelum UI kasir tampil): server membandingkan nomor urut
  // data lokal dengan manifest GitHub — database kosong/lebih tua → pulihkan
  // otomatis; ada backup belum terkirim → unggah. Hanya berlaku bila Admin
  // menyalakan fitur di Pengaturan → Data & Backup.
  useEffect(() => {
    fetch("/api/github/sync-check", { method: "POST" }).catch(() => undefined);
  }, []);

  // D92 — cek kas laci setiap kali sesi berpindah (login/ganti akun): belum
  // ada sesi hari ini → wajib isi kas awal. Gagal jaringan TIDAK mengunci
  // aplikasi (dialog hanya muncul bila status benar-benar diketahui).
  const userId = user?.id ?? null;
  const username = user?.username ?? "";
  useEffect(() => {
    setNeedKasAwal(false);
    setJamMasuk(null);
    if (!userId || !username) return;
    let cancelled = false;
    fetch(`/api/drawer?requesterUsername=${encodeURIComponent(username)}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d: { today: unknown; attendance: { checkIn: string | null } | null } | null) => {
        if (cancelled || !d) return;
        if (!d.today) setNeedKasAwal(true);
        else if (d.attendance?.checkIn) {
          setJamMasuk(
            new Intl.DateTimeFormat("id-ID", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Jakarta" }).format(
              new Date(d.attendance.checkIn)
            )
          );
        }
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [userId, username]);

  // Lacak interaksi untuk kunci sesi otomatis
  useEffect(() => {
    const mark = () => {
      lastInteraction.current = Date.now();
    };
    const events: (keyof WindowEventMap)[] = ["pointerdown", "keydown", "mousemove", "touchstart"];
    events.forEach((ev) => window.addEventListener(ev, mark, { passive: true }));
    return () => events.forEach((ev) => window.removeEventListener(ev, mark));
  }, []);

  // Pemeriksa idle tiap 5 detik — persis LaunchedEffect di MainLayout.kt
  useEffect(() => {
    if (!user || locked) return;
    const interval = setInterval(() => {
      if (Date.now() - lastInteraction.current >= IDLE_LOCK_MS) {
        setLocked(true);
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [user, locked]);

  const handleLogin = useCallback((u: SafeUser) => {
    setUser(u);
    setLocked(false);
    try {
      sessionStorage.setItem(SESSION_KEY, JSON.stringify(u));
    } catch {
      // storage penuh — biarkan sesi hanya di memori
    }
  }, []);

  const handleLogout = useCallback(() => {
    setUser(null);
    setLocked(false);
    try {
      sessionStorage.removeItem(SESSION_KEY);
    } catch {
      // abaikan
    }
  }, []);

  const handleUnlocked = useCallback((u: SafeUser) => {
    setLocked(false);
    lastInteraction.current = Date.now();
    try {
      sessionStorage.setItem(SESSION_KEY, JSON.stringify(u));
    } catch {
      // abaikan
    }
    void u;
  }, []);

  if (!ready || stage === "checking") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="size-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  if (!user) {
    // D75 — token GitHub belum ada → tawarkan setup pemulihan pra-login dulu.
    if (stage === "setup") {
      return (
        <BootstrapScreen
          shopName={shopName}
          onDone={() => {
            fetchShopName(); // nama toko bisa berubah setelah pemulihan
            setStage("login");
          }}
          onSkip={() => {
            try {
              sessionStorage.setItem(BOOTSTRAP_SKIP_KEY, "1");
            } catch {
              // abaikan
            }
            setStage("login");
          }}
        />
      );
    }
    return <LoginScreen shopName={shopName} onLogin={handleLogin} />;
  }

  if (locked) {
    return (
      <PinUnlockScreen user={user} onUnlocked={handleUnlocked} onLogout={handleLogout} />
    );
  }

  // D92 — dialog kas awal wajib ditampilkan DI ATAS aplikasi (tidak bisa
  // ditutup/didolimi) sampai pemakai mengisi jumlah kas di laci.
  return (
    <>
      <AppShell
        user={user}
        shopName={shopName}
        onLogout={handleLogout}
        onShopNameChange={setShopName}
        onSwitchUser={handleLogin} // D41: gerbang Setting "pilih Admin + PIN"
      />
      {needKasAwal && (
        <KasAwalDialog user={user} jamMasuk={jamMasuk} onDone={() => setNeedKasAwal(false)} />
      )}
    </>
  );
}
