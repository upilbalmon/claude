"use client";

// LoginScreen.kt — username + PIN, 5 status respon, form ganti PIN default
// Kolom PIN memakai PinInput Adaptif (D1): desktop ketik keyboard (auto-masuk 4 digit),
// HP dapat keypad 3×4 otomatis. Form ganti PIN = entri berurutan 2 langkah.
import { useState } from "react";
import { Lock, User, Wrench } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { PinInput } from "@/components/app/pin-input";
import type { SafeUser } from "@/lib/app-types";

type LoginResponse = {
  status: "SUCCESS" | "LOCKED" | "MUST_CHANGE_PIN" | "WRONG_PIN" | "NOT_FOUND" | "ERROR";
  user?: SafeUser;
  message?: string;
  attemptsLeft?: number;
  lockSeconds?: number;
};

export function LoginScreen({
  shopName,
  onLogin,
}: {
  shopName: string;
  onLogin: (user: SafeUser) => void;
}) {
  const { toast } = useToast();
  const [usernameInput, setUsernameInput] = useState("");
  const [passwordInput, setPasswordInput] = useState("");
  const [loginErrorTick, setLoginErrorTick] = useState(0);
  const [busy, setBusy] = useState(false);

  // form ganti PIN default — entri berurutan 2 langkah dengan satu PinInput
  const [showChangePinForm, setShowChangePinForm] = useState(false);
  const [userToChangePin, setUserToChangePin] = useState<SafeUser | null>(null);
  const [changeStep, setChangeStep] = useState<1 | 2>(1);
  const [newPinInput, setNewPinInput] = useState("");
  const [confirmPinInput, setConfirmPinInput] = useState("");
  const [changeErrorTick, setChangeErrorTick] = useState(0);

  async function handleLogin(pinOverride?: string) {
    const pin = pinOverride ?? passwordInput;
    if (!usernameInput.trim() || !pin.trim()) {
      toast({ title: "Username dan password wajib diisi!", variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: usernameInput, pin }),
      });
      const data = (await res.json()) as LoginResponse;
      switch (data.status) {
        case "SUCCESS":
          toast({ title: `Selamat datang kembali, ${data.user?.name}!` });
          onLogin(data.user!);
          break;
        case "LOCKED":
          toast({ title: data.message ?? "Akun terkunci sementara!", variant: "destructive" });
          // T1 (revisi Tahap 2): samakan dengan jalur WRONG_PIN — kolom PIN dibersihkan
          // + animasi goyang, agar PIN sisa tidak tertinggal di layar saat terkunci.
          setPasswordInput("");
          setLoginErrorTick((t) => t + 1);
          break;
        case "MUST_CHANGE_PIN":
          setUserToChangePin(data.user ?? null);
          setShowChangePinForm(true);
          break;
        case "WRONG_PIN":
          toast({ title: data.message ?? "PIN salah!", variant: "destructive" });
          setPasswordInput("");
          setLoginErrorTick((t) => t + 1);
          break;
        case "NOT_FOUND":
          toast({ title: "Username tidak terdaftar!", variant: "destructive" });
          break;
        default:
          toast({ title: data.message ?? "Terjadi kesalahan", variant: "destructive" });
      }
    } catch {
      toast({ title: "Tidak dapat terhubung ke server", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  // Langkah entri PIN: langkah 1 = PIN baru (tolak PIN default), langkah 2 = konfirmasi → simpan
  function handlePinStepComplete(pin: string) {
    if (changeStep === 1) {
      if (pin === "1234" || pin === "1111") {
        toast({ title: "Jangan gunakan PIN default! Gunakan kombinasi lain.", variant: "destructive" });
        setNewPinInput("");
        setChangeErrorTick((t) => t + 1);
        return;
      }
      setChangeStep(2);
      return;
    }
    if (pin !== newPinInput) {
      toast({ title: "Konfirmasi PIN tidak cocok!", variant: "destructive" });
      setConfirmPinInput("");
      setChangeErrorTick((t) => t + 1);
      return;
    }
    void handleChangePin(pin);
  }

  async function handleChangePin(confirmPin: string) {
    if (newPinInput.length !== 4 || !/^\d{4}$/.test(newPinInput)) {
      toast({ title: "PIN baru wajib berupa 4 angka!", variant: "destructive" });
      setChangeStep(1);
      setConfirmPinInput("");
      return;
    }
    if (confirmPin !== newPinInput) {
      toast({ title: "Konfirmasi PIN tidak cocok!", variant: "destructive" });
      setConfirmPinInput("");
      setChangeErrorTick((t) => t + 1);
      return;
    }
    if (newPinInput === "1234" || newPinInput === "1111") {
      toast({ title: "Jangan gunakan PIN default! Gunakan kombinasi lain.", variant: "destructive" });
      setChangeStep(1);
      setNewPinInput("");
      setConfirmPinInput("");
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/auth/change-pin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: userToChangePin?.id, newPin: newPinInput }),
      });
      const data = (await res.json()) as LoginResponse;
      if (data.status === "SUCCESS" && data.user) {
        toast({ title: "PIN berhasil diperbarui. Selamat datang!" });
        onLogin(data.user);
      } else {
        toast({ title: data.message ?? "Gagal mengganti PIN", variant: "destructive" });
      }
    } catch {
      toast({ title: "Tidak dapat terhubung ke server", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  function resetChangePinForm() {
    setShowChangePinForm(false);
    setUserToChangePin(null);
    setChangeStep(1);
    setNewPinInput("");
    setConfirmPinInput("");
    setChangeErrorTick(0);
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-accent/60 to-background p-6">
      <div className="w-full max-w-[450px] rounded-3xl bg-card p-8 shadow-lg">
        {showChangePinForm ? (
          <div className="flex flex-col items-center gap-5">
            <div className="flex size-16 items-center justify-center rounded-full bg-destructive/10">
              <Lock className="size-9 text-destructive" aria-hidden />
            </div>
            <div className="text-center">
              <p className="text-[22px] font-black">Ganti PIN Default</p>
              <p className="text-xs font-medium text-muted-foreground">
                Demi keamanan, Anda wajib mengganti PIN default pada login pertama.
              </p>
            </div>
            <Separator />
            <div className="flex w-full flex-col items-center gap-3">
              <Label htmlFor="pin-change" className="self-start">
                {changeStep === 1 ? "PIN Baru (4 Angka)" : "Konfirmasi PIN Baru"}
              </Label>
              <PinInput
                id="pin-change"
                variant="field"
                value={changeStep === 1 ? newPinInput : confirmPinInput}
                onChange={(v) => (changeStep === 1 ? setNewPinInput(v) : setConfirmPinInput(v))}
                onComplete={handlePinStepComplete}
                errorTick={changeErrorTick}
                disabled={busy}
                ariaLabel={changeStep === 1 ? "PIN baru" : "Konfirmasi PIN baru"}
              />
              <p className="text-center text-xs text-muted-foreground">
                {changeStep === 1
                  ? "Langkah 1 dari 2 — ketik 4 angka, otomatis lanjut ke konfirmasi."
                  : "Langkah 2 dari 2 — ulangi PIN baru yang sama."}
              </p>
              <div className="flex w-full gap-3 pt-1">
                <Button
                  variant="outline"
                  onClick={resetChangePinForm}
                  className="h-11 flex-1 rounded-xl"
                  disabled={busy}
                >
                  Batal
                </Button>
                <Button
                  onClick={() => void handleChangePin(confirmPinInput)}
                  className="h-11 flex-1 rounded-xl"
                  disabled={busy || changeStep !== 2 || confirmPinInput.length < 4}
                >
                  {busy ? "Menyimpan..." : "Simpan"}
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-5">
            <div className="flex size-16 items-center justify-center rounded-full bg-primary/10">
              <Wrench className="size-9 text-primary" aria-hidden />
            </div>
            <div className="text-center">
              <p className="text-2xl font-black">{shopName}</p>
              <p className="text-sm font-medium text-muted-foreground">Masuk ke Sistem Servis</p>
            </div>
            <Separator />
            <div className="flex w-full flex-col gap-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  placeholder="Masukkan username"
                  value={usernameInput}
                  onChange={(e) => setUsernameInput(e.target.value)}
                  className="h-11 rounded-xl"
                  autoComplete="username"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pin-login">Password (PIN)</Label>
                <PinInput
                  id="pin-login"
                  variant="field"
                  autoFocus={false}
                  value={passwordInput}
                  onChange={setPasswordInput}
                  onComplete={(pin) => {
                    if (!usernameInput.trim()) {
                      toast({ title: "Isi username terlebih dahulu!", variant: "destructive" });
                      return;
                    }
                    void handleLogin(pin);
                  }}
                  onSubmit={() => void handleLogin()}
                  errorTick={loginErrorTick}
                  disabled={busy}
                  ariaLabel="Password (PIN)"
                />
              </div>
              <Button
                onClick={() => void handleLogin()}
                disabled={busy}
                className="h-12 w-full rounded-xl text-sm font-bold tracking-widest"
              >
                {busy ? "MEMPROSES..." : "MASUK"}
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
