import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { dayKeyWIB, wibDayRange } from "@/lib/format";

// D37 — laporan void/refund per kasir (aturan 8 dokumen "Pembatalan transaksi":
// "Pantau pola mencurigakan lewat laporan void harian per kasir, untuk mencegah fraud").
// GET /api/reports/void?from=YYYY-MM-DD&to=YYYY-MM-DD (tanggal kalender WIB, inklusif;
// default: hari ini). Mengembalikan:
//   voids    — dokumen yang DI-VOID pada rentang (voidedAt), dikelompokkan per voidedBy;
//   refunds  — dokumen REFUND yang DIBUAT pada rentang (timestamp), dikelompokkan per createdBy.
// Kasir yang membatalkan dilihat dari voidedBy (aktor terverifikasi D34), bukan string klien.

type Row = { name: string; count: number; total: number };

export async function GET(req: NextRequest) {
  try {
    const sp = req.nextUrl.searchParams;
    const today = dayKeyWIB(new Date());
    const fromDay = /^\d{4}-\d{2}-\d{2}$/.test(sp.get("from") ?? "") ? sp.get("from")! : today;
    const toDay = /^\d{4}-\d{2}-\d{2}$/.test(sp.get("to") ?? "") ? sp.get("to")! : today;
    const from = fromDay <= toDay ? fromDay : toDay;
    const to = fromDay <= toDay ? toDay : fromDay;

    const { start } = wibDayRange(from);
    const { end } = wibDayRange(to); // eksklusif → rentang inklusif multi-hari

    const [voidedDocs, refundDocs] = await Promise.all([
      db.transaction.findMany({
        where: { isVoided: true, voidedAt: { gte: start, lt: end } },
        orderBy: { voidedAt: "desc" },
      }),
      db.transaction.findMany({
        where: { docType: "REFUND", isVoided: false, timestamp: { gte: start, lt: end } },
        orderBy: { timestamp: "desc" },
      }),
    ]);

    type VoidRowDoc = { grandTotal: number; voidedBy: string | null };
    type RefundRowDoc = { grandTotal: number; createdBy: string };

    function groupBy(docs: (VoidRowDoc | RefundRowDoc)[], key: "voidedBy" | "createdBy"): Row[] {
      const m = new Map<string, Row>();
      for (const d of docs) {
        const name = ((d[key] as string | null) || "Tidak diketahui");
        const row = m.get(name) ?? { name, count: 0, total: 0 };
        row.count += 1;
        row.total += Math.abs(d.grandTotal);
        m.set(name, row);
      }
      return [...m.values()].sort((a, b) => b.total - a.total);
    }

    type DetailDoc = {
      id: number; invoiceNumber: string; customerName: string; grandTotal: number;
      createdBy: string; isVoided: boolean; voidedBy: string | null; voidedAt: Date | null;
      voidReason: string | null; docType: string; referenceNumber: string; refundOfId: number | null;
      timestamp: Date;
    };
    function detailOf(d: DetailDoc) {
      return {
        id: d.id,
        invoiceNumber: d.invoiceNumber,
        customerName: d.customerName,
        grandTotal: d.grandTotal,
        createdBy: d.createdBy,
        voidedBy: d.voidedBy,
        voidedAt: d.voidedAt,
        voidReason: d.voidReason,
        docType: d.docType,
        referenceNumber: d.referenceNumber,
        refundOfId: d.refundOfId,
        timestamp: d.timestamp,
      };
    }

    return NextResponse.json({
      from,
      to,
      voids: {
        rows: groupBy(voidedDocs, "voidedBy"),
        details: voidedDocs.map(detailOf),
      },
      refunds: {
        rows: groupBy(refundDocs, "createdBy"),
        details: refundDocs.map(detailOf),
      },
    });
  } catch (e) {
    console.error("reports void GET error", e);
    return NextResponse.json({ error: "Gagal memuat laporan pembatalan" }, { status: 500 });
  }
}
