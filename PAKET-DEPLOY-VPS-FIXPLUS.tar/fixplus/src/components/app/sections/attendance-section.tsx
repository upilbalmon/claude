"use client";

// D73 — Absensi Karyawan. D92 — ALUR OTOMATIS:
//  - Absen masuk dicatat otomatis SERVER saat login (tidak ada lagi tombol
//    Absen Masuk/Absen Keluar mandiri).
//  - Kas laci hari ini ditampilkan (KasLaciPanel): kas awal diisi wajib saat
//    login pertama hari itu; tombol "Tutup Laci" mencatat kas fisik,
//    menutup absen, lalu keluar dari aplikasi.
//  - Rekap Absensi tetap: Admin melihat SEMUA karyawan + Catat Manual / Edit
//    / Hapus (dijaga ulang server-side di /api/attendance). Non-admin otomatis
//    hanya melihat catatannya sendiri (API yang memisahkan — UI bukan penjaga).
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  CalendarDays,
  Clock,
  Pencil,
  Plus,
  Trash2,
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Table, TableBody, TableHeader } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import {
  FinCountChip,
  FinIndexTd,
  FinRow,
  FinTd,
  FinTh,
} from "@/components/app/fin-table";
import { useToast } from "@/hooks/use-toast";
import { KasLaciPanel } from "@/components/app/kas-laci"; // D92 — status kas laci + Tutup Laci
import type { SafeUser } from "@/lib/app-types";

const WIB_OFFSET_MS = 7 * 60 * 60 * 1000;
const TZ_WIB = "Asia/Jakarta";

type AttendanceRecord = {
  id: number;
  userId: number | null;
  userName: string;
  date: string; // "YYYY-MM-DD"
  checkIn: string | null;
  checkOut: string | null;
  status: string;
  notes: string;
  recordedBy: string;
  createdAt: string;
  updatedAt: string;
};

type UserLite = { id: number; name: string; username: string; role: string };

type AttendancePayload = {
  month: string;
  today: string;
  isAdmin: boolean;
  records: AttendanceRecord[];
  users: UserLite[] | null;
  myToday: AttendanceRecord | null;
};

const STATUS_LIST = ["HADIR", "TERLAMBAT", "IZIN", "SAKIT", "ALPA", "LIBUR"] as const;
type StatusKey = (typeof STATUS_LIST)[number];

const STATUS_LABEL: Record<StatusKey, string> = {
  HADIR: "Hadir",
  TERLAMBAT: "Terlambat",
  IZIN: "Izin",
  SAKIT: "Sakit",
  ALPA: "Alpa",
  LIBUR: "Libur",
};

// Warna badge status — selaras gaya badge transaksi kasir (D10)
const STATUS_BADGE: Record<StatusKey, string> = {
  HADIR: "bg-green-100 text-green-800",
  TERLAMBAT: "bg-amber-100 text-amber-800",
  IZIN: "bg-blue-100 text-blue-800",
  SAKIT: "bg-violet-100 text-violet-800",
  ALPA: "bg-red-100 text-red-800",
  LIBUR: "bg-slate-100 text-slate-600",
};

function statusKey(s: string): StatusKey {
  return (STATUS_LIST as readonly string[]).includes(s) ? (s as StatusKey) : "HADIR";
}

async function apiJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string }).error || "Terjadi kesalahan");
  return data as T;
}

/** ISO → "HH:mm" WIB */
function fmtTime(iso: string | null): string {
  if (!iso) return "—";
  return new Intl.DateTimeFormat("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: TZ_WIB,
  }).format(new Date(iso));
}

/** "YYYY-MM-DD" → "14 Nov 2026" (WIB) */
function fmtDateKey(key: string): string {
  const d = new Date(`${key}T00:00:00+07:00`);
  if (Number.isNaN(d.getTime())) return key;
  return new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    timeZone: TZ_WIB,
  }).format(d);
}

/** "YYYY-MM-DD" → "Jumat, 14 November 2026" (WIB) — untuk kartu Absensi Saya */
function fmtDateKeyLong(key: string): string {
  const d = new Date(`${key}T00:00:00+07:00`);
  if (Number.isNaN(d.getTime())) return key;
  return new Intl.DateTimeFormat("id-ID", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: TZ_WIB,
  }).format(d);
}

/** Durasi kerja menit → "7j 30m" */
function fmtDurasi(fromIso: string | null, toIso: string | null): string {
  if (!fromIso || !toIso) return "—";
  const mins = Math.round((new Date(toIso).getTime() - new Date(fromIso).getTime()) / 60000);
  if (mins < 0) return "—";
  return `${Math.floor(mins / 60)}j ${mins % 60}m`;
}

/** ISO → "HH:mm" untuk <input type="time"> */
function isoToTimeInput(iso: string | null): string {
  if (!iso) return "";
  return new Intl.DateTimeFormat("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    timeZone: TZ_WIB,
  }).format(new Date(iso));
}

function StatusBadge({ status }: { status: string }) {
  const key = statusKey(status);
  return (
    <span className={"inline-block rounded px-1.5 py-0.5 text-[10px] font-black " + STATUS_BADGE[key]}>
      {STATUS_LABEL[key]}
    </span>
  );
}

export function AttendanceSection({ user, onLogout }: { user: SafeUser; onLogout: () => void }) {
  const { toast } = useToast();

  // Bulan rekap default = bulan berjalan (WIB); komponen hanya dirender client
  // (setelah login) sehingga aman dari hydration mismatch.
  const [month, setMonth] = useState(() =>
    new Date(Date.now() + WIB_OFFSET_MS).toISOString().slice(0, 7)
  );
  const [data, setData] = useState<AttendancePayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [userFilter, setUserFilter] = useState<string>("all");

  // Jam berjalan (WIB) — mulai diisi setelah mount agar aman hydration
  const [clockNow, setClockNow] = useState<string | null>(null);
  useEffect(() => {
    const tick = () =>
      setClockNow(
        new Intl.DateTimeFormat("id-ID", {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          timeZone: TZ_WIB,
        }).format(new Date())
      );
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, []);

  const load = useCallback(async () => {
    try {
      const payload = await apiJson<AttendancePayload>(
        `/api/attendance?requesterUsername=${encodeURIComponent(user.username)}&month=${encodeURIComponent(month)}`
      );
      setData(payload);
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Gagal memuat absensi", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [user.username, month, toast]);

  useEffect(() => {
    void load();
  }, [load]);

  // ===== Rekap: ringkasan per status =====
  const filteredRecords = useMemo(() => {
    if (!data) return [];
    if (userFilter === "all") return data.records;
    const uid = Number(userFilter);
    return data.records.filter((r) => r.userId === uid);
  }, [data, userFilter]);

  const statusCounts = useMemo(() => {
    const counts = new Map<StatusKey, number>();
    for (const r of filteredRecords) {
      const key = statusKey(r.status);
      counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    return counts;
  }, [filteredRecords]);

  const roleOf = useMemo(() => {
    const map = new Map<number, string>();
    for (const u of data?.users ?? []) map.set(u.id, u.role);
    return map;
  }, [data]);

  // ===== Dialog catat manual / edit (Admin) =====
  const [formOpen, setFormOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null); // null = catat baru
  const [fUserId, setFUserId] = useState("");
  const [fDate, setFDate] = useState(() =>
    new Date(Date.now() + WIB_OFFSET_MS).toISOString().slice(0, 10)
  );
  const [fStatus, setFStatus] = useState<string>("HADIR");
  const [fCheckIn, setFCheckIn] = useState("");
  const [fCheckOut, setFCheckOut] = useState("");
  const [fNotes, setFNotes] = useState("");
  const [savingForm, setSavingForm] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<AttendanceRecord | null>(null);
  const [deleting, setDeleting] = useState(false);

  const isAdmin = data?.isAdmin ?? false;

  function openCreate() {
    setEditId(null);
    setFUserId("");
    setFDate(data?.today ?? new Date(Date.now() + WIB_OFFSET_MS).toISOString().slice(0, 10));
    setFStatus("HADIR");
    setFCheckIn("");
    setFCheckOut("");
    setFNotes("");
    setFormOpen(true);
  }

  function openEdit(r: AttendanceRecord) {
    setEditId(r.id);
    setFUserId(String(r.userId ?? ""));
    setFDate(r.date);
    setFStatus(r.status);
    setFCheckIn(isoToTimeInput(r.checkIn));
    setFCheckOut(isoToTimeInput(r.checkOut));
    setFNotes(r.notes);
    setFormOpen(true);
  }

  async function saveForm() {
    setSavingForm(true);
    try {
      if (editId === null) {
        await apiJson<AttendanceRecord>("/api/attendance", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            requesterUsername: user.username,
            userId: fUserId,
            date: fDate,
            status: fStatus,
            checkIn: fCheckIn,
            checkOut: fCheckOut,
            notes: fNotes,
          }),
        });
        toast({ title: "Catatan absensi ditambahkan" });
      } else {
        await apiJson<AttendanceRecord>("/api/attendance", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            requesterUsername: user.username,
            id: editId,
            status: fStatus,
            checkIn: fCheckIn,
            checkOut: fCheckOut,
            notes: fNotes,
          }),
        });
        toast({ title: "Catatan absensi diperbarui" });
      }
      setFormOpen(false);
      await load();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Gagal menyimpan absensi", variant: "destructive" });
    } finally {
      setSavingForm(false);
    }
  }

  async function deleteRecord() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await apiJson(
        `/api/attendance?requesterUsername=${encodeURIComponent(user.username)}&id=${deleteTarget.id}`,
        { method: "DELETE" }
      );
      toast({ title: "Catatan absensi dihapus" });
      setDeleteTarget(null);
      await load();
    } catch (e) {
      toast({ title: e instanceof Error ? e.message : "Gagal menghapus absensi", variant: "destructive" });
    } finally {
      setDeleting(false);
    }
  }

  const my = data?.myToday ?? null;

  return (
    <div className="flex flex-col gap-4">
      {/* ===== Header ===== */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="min-w-0 flex-1">
          <h1 className="text-lg font-black tracking-tight">Absensi</h1>
          <p className="text-xs text-muted-foreground">
            Absen otomatis saat login · tutup absen lewat "Tutup Laci" — jam dari server (WIB, UTC+7)
          </p>
        </div>
        <FinCountChip count={filteredRecords.length} unit="catatan" />
        {isAdmin && (
          <Button onClick={openCreate} className="h-9 rounded-xl">
            <Plus className="size-4" aria-hidden /> Catat Manual
          </Button>
        )}
      </div>

      {/* ===== Kartu Absensi Saya (semua role) ===== */}
      <Card className="rounded-2xl">
        <CardContent className="flex flex-col gap-4 p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <CalendarDays className="size-5 text-primary" aria-hidden />
              <div>
                <p className="text-sm font-bold">Absensi Saya — {user.name}</p>
                <p className="text-xs text-muted-foreground">
                  {data ? fmtDateKeyLong(data.today) : "Memuat..."}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 rounded-xl bg-muted px-3 py-1.5" aria-label="Jam server WIB">
              <Clock className="size-4 text-primary" aria-hidden />
              <span className="font-mono text-sm font-bold tabular-nums">{clockNow ?? "--:--:--"}</span>
              <span className="text-[10px] font-bold text-muted-foreground">WIB</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 rounded-xl border bg-muted/40 p-4">
            <div className="min-w-[120px]">
              <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">Masuk</p>
              <p className="font-mono text-xl font-black tabular-nums">{my ? fmtTime(my.checkIn) : "—"}</p>
            </div>
            <div className="min-w-[120px]">
              <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">Keluar</p>
              <p className="font-mono text-xl font-black tabular-nums">{my ? fmtTime(my.checkOut) : "—"}</p>
            </div>
            <div className="min-w-[120px]">
              <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">Durasi</p>
              <p className="font-mono text-xl font-black tabular-nums">
                {my ? fmtDurasi(my.checkIn, my.checkOut) : "—"}
              </p>
            </div>
            <div className="min-w-[100px]">
              <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">Status</p>
              <p className="pt-1">{my ? <StatusBadge status={my.status} /> : <span className="text-xs text-muted-foreground">Belum absen</span>}</p>
            </div>

            <div className="ml-auto max-w-[260px] text-right text-[11px] font-semibold text-muted-foreground">
              {my?.checkIn ? (
                <>
                  Absen masuk otomatis saat login pukul {fmtTime(my.checkIn)} WIB.
                  {!my.checkOut && " Tutup absen lewat tombol \u201cTutup Laci\u201d."}
                </>
              ) : (
                <>Absen masuk tercatat otomatis saat Anda login ke aplikasi.</>
              )}
              {my?.recordedBy ? ` (disesuaikan ${my.recordedBy})` : ""}
            </div>
          </div>
          {my && my.notes && (
            <p className="text-xs text-muted-foreground">
              <span className="font-bold">Catatan Admin:</span> {my.notes}
            </p>
          )}
        </CardContent>
      </Card>

      {/* ===== D92 — Kas Laci hari ini (semua role) ===== */}
      <KasLaciPanel user={user} onAfterClose={onLogout} />

      {/* ===== Rekap Absensi ===== */}
      <div className="flex flex-wrap items-center gap-2">
        <h2 className="text-sm font-bold">
          {isAdmin ? "Rekap Absensi Karyawan" : "Riwayat Absensi Saya"}
        </h2>
        <span className="text-xs text-muted-foreground">·</span>
        <Label htmlFor="absensi-bulan" className="text-xs text-muted-foreground">Bulan</Label>
        <Input
          id="absensi-bulan"
          type="month"
          value={month}
          onChange={(e) => e.target.value && setMonth(e.target.value)}
          className="h-9 w-[150px] rounded-xl"
        />
        {isAdmin && data?.users && (
          <Select value={userFilter} onValueChange={setUserFilter}>
            <SelectTrigger className="h-9 w-[190px] rounded-xl" aria-label="Filter karyawan">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Karyawan</SelectItem>
              {data.users.map((u) => (
                <SelectItem key={u.id} value={String(u.id)}>
                  {u.name} ({u.role})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {/* Ringkasan per status */}
      <div className="flex flex-wrap gap-2">
        {STATUS_LIST.map((s) => (
          <span
            key={s}
            className={
              "inline-flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-[11px] font-bold " +
              STATUS_BADGE[s]
            }
          >
            {STATUS_LABEL[s]}
            <span className="tabular-nums opacity-80">{statusCounts.get(s) ?? 0}</span>
          </span>
        ))}
      </div>

      <div className="overflow-x-auto rounded-2xl border bg-card shadow-sm xl:overflow-x-visible">
        <Table>
          <TableHeader className="[&_tr]:border-b-0">
            <tr>
              <FinTh corner="first" align="center" className="w-10">#</FinTh>
              <FinTh>Tanggal</FinTh>
              <FinTh>Karyawan</FinTh>
              <FinTh>Role</FinTh>
              <FinTh align="center">Masuk</FinTh>
              <FinTh align="center">Keluar</FinTh>
              <FinTh align="center">Durasi</FinTh>
              <FinTh align="center">Status</FinTh>
              <FinTh>Catatan</FinTh>
              {isAdmin && <FinTh align="center" corner="last">Aksi</FinTh>}
              {!isAdmin && <FinTh corner="last">Pencatat</FinTh>}
            </tr>
          </TableHeader>
          <TableBody>
            {loading ? (
              <tr>
                <FinTd colSpan={isAdmin ? 10 : 9} className="py-10 text-center text-muted-foreground">
                  Memuat absensi...
                </FinTd>
              </tr>
            ) : filteredRecords.length === 0 ? (
              <tr>
                <FinTd colSpan={isAdmin ? 10 : 9} className="py-10 text-center text-muted-foreground">
                  Belum ada catatan absensi pada bulan ini.
                </FinTd>
              </tr>
            ) : (
              filteredRecords.map((r, i) => (
                <FinRow key={r.id} zebra={i % 2 === 1}>
                  <FinIndexTd>{i + 1}</FinIndexTd>
                  <FinTd className="font-semibold">{fmtDateKey(r.date)}</FinTd>
                  <FinTd className="max-w-[160px] truncate font-semibold">{r.userName}</FinTd>
                  <FinTd className="text-muted-foreground">
                    {r.userId !== null ? roleOf.get(r.userId) ?? "—" : "—"}
                  </FinTd>
                  <FinTd className="text-center font-mono tabular-nums">{fmtTime(r.checkIn)}</FinTd>
                  <FinTd className="text-center font-mono tabular-nums">{fmtTime(r.checkOut)}</FinTd>
                  <FinTd className="text-center font-mono tabular-nums">{fmtDurasi(r.checkIn, r.checkOut)}</FinTd>
                  <FinTd className="text-center"><StatusBadge status={r.status} /></FinTd>
                  <FinTd className="max-w-[200px] truncate text-muted-foreground">{r.notes || "—"}</FinTd>
                  {isAdmin ? (
                    <FinTd className="text-center">
                      <span className="inline-flex items-center justify-center gap-1">
                        <Button variant="ghost" size="icon" className="size-8" onClick={() => openEdit(r)} aria-label={`Edit absensi ${r.userName} ${r.date}`}>
                          <Pencil className="size-4" aria-hidden />
                        </Button>
                        <Button variant="ghost" size="icon" className="size-8 text-destructive hover:text-destructive" onClick={() => setDeleteTarget(r)} aria-label={`Hapus absensi ${r.userName} ${r.date}`}>
                          <Trash2 className="size-4" aria-hidden />
                        </Button>
                      </span>
                    </FinTd>
                  ) : (
                    <FinTd className="text-muted-foreground">{r.recordedBy || "Otomatis (login)"}</FinTd>
                  )}
                </FinRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* ===== Dialog Catat Manual / Edit (Admin) ===== */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="rounded-2xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editId === null ? "Catat Absensi Manual" : "Edit Absensi"}</DialogTitle>
            <DialogDescription>
              {editId === null
                ? "Untuk karyawan yang lupa absen, izin, sakit, atau hari libur."
                : "Koreksi status, jam masuk/keluar, atau catatan."}
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="abs-karyawan">Karyawan</Label>
              {editId === null ? (
                <Select value={fUserId} onValueChange={setFUserId}>
                  <SelectTrigger id="abs-karyawan" className="rounded-xl">
                    <SelectValue placeholder="Pilih karyawan" />
                  </SelectTrigger>
                  <SelectContent>
                    {(data?.users ?? []).map((u) => (
                      <SelectItem key={u.id} value={String(u.id)}>
                        {u.name} ({u.role})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <Input id="abs-karyawan" value={fUserId ? (data?.users ?? []).find((u) => String(u.id) === fUserId)?.name ?? "—" : "—"} disabled />
              )}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="abs-tanggal">Tanggal</Label>
                <Input
                  id="abs-tanggal"
                  type="date"
                  value={fDate}
                  onChange={(e) => e.target.value && setFDate(e.target.value)}
                  disabled={editId !== null}
                  className="rounded-xl"
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="abs-status">Status</Label>
                <Select value={fStatus} onValueChange={setFStatus}>
                  <SelectTrigger id="abs-status" className="rounded-xl">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUS_LIST.map((s) => (
                      <SelectItem key={s} value={s}>{STATUS_LABEL[s]}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="abs-masuk">Jam Masuk (WIB)</Label>
                <Input
                  id="abs-masuk"
                  type="time"
                  value={fCheckIn}
                  onChange={(e) => setFCheckIn(e.target.value)}
                  className="rounded-xl"
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="abs-keluar">Jam Keluar (WIB)</Label>
                <Input
                  id="abs-keluar"
                  type="time"
                  value={fCheckOut}
                  onChange={(e) => setFCheckOut(e.target.value)}
                  className="rounded-xl"
                />
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="abs-catatan">Catatan</Label>
              <Textarea
                id="abs-catatan"
                value={fNotes}
                onChange={(e) => setFNotes(e.target.value)}
                placeholder="Misal: izin ke RS, dinas luar, lembur..."
                className="rounded-xl"
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFormOpen(false)} disabled={savingForm}>
              Batal
            </Button>
            <Button onClick={saveForm} disabled={savingForm || (editId === null && !fUserId)}>
              {savingForm ? "Menyimpan..." : editId === null ? "Simpan" : "Perbarui"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== Konfirmasi Hapus (Admin) ===== */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus catatan absensi?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget &&
                `Absensi ${deleteTarget.userName} tanggal ${fmtDateKey(deleteTarget.date)} (${STATUS_LABEL[statusKey(deleteTarget.status)]}) akan dihapus permanen dan dicatat di Log Aktivitas.`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                void deleteRecord();
              }}
              disabled={deleting}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              {deleting ? "Menghapus..." : "Hapus"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
