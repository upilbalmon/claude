// D86 — Pemangkas berkas mati dari .next/standalone sebelum paket deploy dibungkus.
//
// Latar: outputFileTracingExcludes di next.config.ts hanya diterapkan Next pada
// trace per-halaman/app. Trace server utama (next-server.js.nft.json, ditulis
// di pass pertama collect-build-traces) dan instrumentation.js.nft.json TIDAK
// difilter, sehingga paket deploy tetap membawa:
//   1) mesin kueri WASM Prisma untuk database lain (cockroachdb/postgresql/
//      mysql/sqlserver) ~44 MB — aplikasi hanya memakai SQLite library engine
//      (libquery_engine-debian-*.so.node, TIDAK disentuh);
//   2) biner sharp/libvips varian musl ~17,3 MB — target deploy debian glibc,
//      varian linux-x64 (gnu) tetap dipertahankan untuk optimasi gambar.
// Prune di sini memastikan paket kecil apa pun hasil tracing Next, dan aman
// karena berkas yang dihapus mustahil dimuat pada runtime produksi ini.
//
// Idempoten: berkas yang sudah tidak ada diabaikan; tanpa kecocokan → exit 0.
import { existsSync, statSync, rmSync, readdirSync } from "node:fs";
import { join } from "node:path";

const STANDALONE = join(process.cwd(), ".next", "standalone", "node_modules");
const STANDALONE_ROOT = join(process.cwd(), ".next", "standalone");

const PRISMA_DEAD_ENGINES = ["cockroachdb", "postgresql", "mysql", "sqlserver"];
const targets = [];
for (const engine of PRISMA_DEAD_ENGINES) {
  for (const prefix of ["query_engine_bg", "query_compiler_bg"]) {
    for (const suffix of ["", ".wasm-base64"]) {
      for (const ext of ["js", "mjs"]) {
        targets.push(
          join(
            STANDALONE,
            "@prisma",
            "client",
            "runtime",
            `${prefix}.${engine}${suffix}.${ext}`
          )
        );
      }
    }
  }
}
// folder biner varian musl (seluruh isi)
targets.push(join(STANDALONE, "@img", "sharp-libvips-linuxmusl-x64"));
targets.push(join(STANDALONE, "@img", "sharp-linuxmusl-x64"));

// D87 — salinan kredensial token polos hasil tracing TIDAK dibawa paket.
// Runtime produksi TIDAK PERNAH membaca salinan ini: path kredensial dihitung
// dari dirname(DATABASE_URL) (lihat credPath() di github-backup.ts) — di FC
// menjadi /app/db/*, dan bila berkas tidak ada di sana, token diambil dari
// jembatan token (sumber ke-3 D76, teruji hidup). Salinan traced di
// standalone hanya menggandakan token ghp_… ke dalam artefak deploy tanpa
// pernah terpakai — risiko ditolak validator/kebocoran tanpa manfaat.
targets.push(join(STANDALONE_ROOT, "db", "deployment-defaults.json"));
targets.push(join(STANDALONE_ROOT, "db", "github-credentials.json"));

// D87 — folder yang ter-tracing tanpa referensi runtime apa pun:
// scripts/  = skrip diagnostik/uji workspace (d53…d85, fake-bridge, dsb.)
// skills/   = berkas skill platform yang diekstrak platform saat boot sandbox
// Tidak ada satu pun import/fs-read dari kode aplikasi ke dua folder ini
// (diverifikasi rg seluruh src/), jadi dihapus dari artefak deploy.
targets.push(join(STANDALONE_ROOT, "scripts"));
targets.push(join(STANDALONE_ROOT, "skills"));

function duDir(dir) {
  let total = 0;
  const stack = [dir];
  while (stack.length) {
    const cur = stack.pop();
    let entries = [];
    try {
      entries = readdirSync(cur);
    } catch {
      continue;
    }
    for (const e of entries) {
      const p = join(cur, e);
      try {
        const st = statSync(p);
        if (st.isDirectory()) stack.push(p);
        else total += st.size;
      } catch {
        // berkas hilang di antara waktu — abaikan
      }
    }
  }
  return total;
}

let removedTargets = 0;
let removedBytes = 0;

for (const target of targets) {
  if (!existsSync(target)) continue;
  let bytes = 0;
  try {
    const st = statSync(target);
    bytes = st.isDirectory() ? duDir(target) : st.size;
  } catch {
    bytes = 0;
  }
  rmSync(target, { recursive: true, force: true });
  removedTargets += 1;
  removedBytes += bytes;
  console.log(
    `[prune-standalone] dihapus: ${target.slice(process.cwd().length + 1)} (~${(bytes / 1e6).toFixed(1)} MB)`
  );
}

console.log(
  `[prune-standalone] selesai: ${removedTargets} target dihapus, ~${(removedBytes / 1e6).toFixed(1)} MB dibebaskan dari paket deploy`
);
