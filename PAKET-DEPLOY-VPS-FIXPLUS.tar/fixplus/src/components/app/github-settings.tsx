"use client";

// D68 — Kartu "Backup GitHub" di Pengaturan → Data & Backup.
// Alternatif Google Drive yang TANPA Google Cloud / berlangganan: cukup akun
// GitHub gratis + Personal Access Token (PAT) + satu repositori privat.
// Fitur: uji & simpan koneksi (token, repo, branch, folder), putuskan koneksi,
// backup manual sekarang, auto-backup harian (jam Jakarta + keep-last),
// daftar cadangan di repo dengan aksi Pulihkan (ganti database) / Unduh /
// Hapus, plus panduan setup ringkas. Semua route /api/github/* wajib Admin
// (server penjaga utama); token hanya disimpan di server aplikasi.
import { useCallback, useEffect, useRef, useState } from "react";
import {
  CheckCircle2,
  ChevronDown,
  CloudUpload,
  Download,
  ExternalLink,
  Github,
  HelpCircle,
  Info,
  KeyRound,
  RefreshCw,
  Trash2,
  Undo2,
  Unplug,
  XCircle,
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import type { SafeUser } from "@/lib/app-types";
import { SUGGESTED_REPO } from "@/lib/app-types"; // D75 — repo default (bisa diganti)

type GhFile = {
  name: string;
  sha: string;
  size: number;
};
type Status = {
  configured: boolean;
  repo: string | null;
  branch: string | null;
  folder: string | null;
  tokenHint: string | null;
  auto: { enabled: boolean; mode?: "off" | "daily" | "onchange"; hour: number; keepLast: number };
  autoRestore: boolean;
  deviceId: string | null; // D74 — identitas perangkat ini di manifest
  conflict: {
    detectedAt: string;
    detail: string;
    manifestDeviceId: string | null;
    localSeq: number;
    manifestSeq: number;
  } | null; // D74 — konflik sinkronisasi menunggu keputusan pemilik
  dataVersion: number | null; // D74 — nomor urut (seq) data lokal
  lastBackupAt: string | null;
  lastAutoBackupDate: string | null;
  lastBackupFile: string | null;
  lastAutoRestoreAt: string | null;
  lastAutoRestoreFile: string | null;
};

async function apiJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init);
  const data = (await res.json().catch(() => ({}))) as T & { error?: string };
  if (!res.ok) throw new Error(data.error ?? "Terjadi kesalahan");
  return data as T;
}

const fmtBytes = (n: number) =>
  n >= 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(1)} MB` : `${Math.ceil(n / 1024)} KB`;
const fmtDate = (iso: string) => {
  if (!iso) return "-";
  try {
    return new Intl.DateTimeFormat("id-ID", {
      dateStyle: "medium",
      timeStyle: "short",
      timeZone: "Asia/Jakarta",
    }).format(new Date(iso));
  } catch {
    return iso;
  }
};
// database-fixplus-2026-11-14-0930.db → "14 Nov 2026 09.30"
function tglDariNama(name: string): string {
  const m = name.match(/^database-fixplus-(\d{4})-(\d{2})-(\d{2})-(\d{2})(\d{2})\.db$/);
  if (!m) return "-";
  try {
    const d = new Date(
      Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4]), Number(m[5]))
    );
    return new Intl.DateTimeFormat("id-ID", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "Asia/Jakarta",
    }).format(d);
  } catch {
    return "-";
  }
}

export function GithubCard({ user }: { user: SafeUser }) {
  const { toast } = useToast();
  const isAdmin = user.role === "Admin";
  const uname = encodeURIComponent(user.username);

  const [status, setStatus] = useState<Status | null>(null);
  const [loading, setLoading] = useState(true);

  // Kredensial
  const [token, setToken] = useState("");
  const [repo, setRepo] = useState(SUGGESTED_REPO); // D75 — terisi default, bebas diubah
  const [branch, setBranch] = useState("main");
  const [folder, setFolder] = useState("fixplus-backup");
  const [credBusy, setCredBusy] = useState(false);
  const [editOpen, setEditOpen] = useState(false);

  // Backup & auto
  const [backupBusy, setBackupBusy] = useState(false);
  const [autoMode, setAutoMode] = useState<"off" | "daily" | "onchange">("off");
  const [autoHour, setAutoHour] = useState("21");
  const [autoKeep, setAutoKeep] = useState("7");
  const [autoBusy, setAutoBusy] = useState(false);
  const [autoRestore, setAutoRestore] = useState(false);

  // Daftar cadangan + aksi
  const [files, setFiles] = useState<GhFile[] | null>(null);
  const [filesBusy, setFilesBusy] = useState(false);
  const [restoreTarget, setRestoreTarget] = useState<GhFile | null>(null);
  const [restoreBusy, setRestoreBusy] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<GhFile | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const [guideOpen, setGuideOpen] = useState(false);
  const refreshTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const loadStatus = useCallback(async () => {
    try {
      const s = await apiJson<Status>(`/api/github/status?requesterUsername=${uname}`);
      setStatus(s);
      setAutoMode(s.auto.mode ?? (s.auto.enabled ? "daily" : "off"));
      setAutoHour(String(s.auto.hour));
      setAutoKeep(String(s.auto.keepLast));
      setAutoRestore(s.autoRestore === true);
      if (s.repo) {
        setRepo(s.repo);
        setBranch(s.branch ?? "main");
        setFolder(s.folder ?? "fixplus-backup");
        setEditOpen(false);
      } else {
        setEditOpen(true);
      }
    } catch (e) {
      toast({
        title: "Gagal memuat status GitHub",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [uname]);

  const loadFiles = useCallback(async () => {
    setFilesBusy(true);
    try {
      const r = await apiJson<{ files: GhFile[] }>(`/api/github/files?requesterUsername=${uname}`);
      setFiles(r.files);
    } catch (e) {
      setFiles(null);
      // Bila belum terhubung, jangan berisik — cukup kosongkan daftar
      const msg = e instanceof Error ? e.message : "";
      if (!msg.includes("belum terhubung")) {
        toast({
          title: "Gagal memuat daftar cadangan",
          description: msg || undefined,
          variant: "destructive",
        });
      }
    } finally {
      setFilesBusy(false);
    }
  }, [uname]);

  useEffect(() => {
    void loadStatus();
    void loadFiles();
    return () => {
      if (refreshTimer.current) clearTimeout(refreshTimer.current);
    };
  }, [loadStatus, loadFiles]);

  // ===== Aksi =====
  async function simpanKredensial() {
    setCredBusy(true);
    try {
      const r = await apiJson<{ repo: { fullName: string; isPrivate: boolean; emptyRepo?: boolean } }>(
        "/api/github/credentials",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            requesterUsername: user.username,
            token,
            repo,
            branch,
            folder,
          }),
        }
      );
      toast({
        title: "GitHub tersambung",
        description: `Repo ${r.repo.fullName} siap dipakai${r.repo.isPrivate ? "" : " — ingat, repo publik bisa dibaca siapa saja!"}${r.repo.emptyRepo ? " (repo masih kosong — backup pertama akan mengisi commit awal)" : ""}`,
      });
      setEditOpen(false);
      setLoading(true);
      await loadStatus();
      void loadFiles();
    } catch (e) {
      toast({
        title: "Gagal menghubungkan GitHub",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setCredBusy(false);
    }
  }

  async function putuskan() {
    setCredBusy(true);
    try {
      await apiJson("/api/github/credentials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requesterUsername: user.username, clearToken: true }),
      });
      toast({ title: "GitHub diputuskan", description: "Token dihapus dari server." });
      setToken("");
      setLoading(true);
      setEditOpen(true);
      await loadStatus();
      setFiles(null);
    } catch (e) {
      toast({
        title: "Gagal memutus koneksi",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setCredBusy(false);
    }
  }

  async function backupSekarang() {
    setBackupBusy(true);
    try {
      const r = await apiJson<{
        fileName: string;
        size: number;
        pruned: number;
        commitUrl: string;
      }>("/api/github/backup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requesterUsername: user.username }),
      });
      toast({
        title: "Backup ter-commit ke GitHub",
        description: `${r.fileName} (${fmtBytes(r.size)})${r.pruned ? ` · ${r.pruned} cadangan lama dihapus` : ""}`,
      });
      // beri jeda kecil agar commit terlihat di daftar
      refreshTimer.current = setTimeout(() => void loadFiles(), 1200);
      await loadStatus();
    } catch (e) {
      toast({
        title: "Gagal backup ke GitHub",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setBackupBusy(false);
    }
  }

  async function simpanAuto() {
    setAutoBusy(true);
    try {
      await apiJson("/api/github/auto", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requesterUsername: user.username,
          auto: { mode: autoMode, hour: Number(autoHour), keepLast: Number(autoKeep) },
          autoRestore,
        }),
      });
      toast({
        title: "Pengaturan otomatis disimpan",
        description:
          autoMode === "daily"
            ? `Backup otomatis tiap hari jam ${String(autoHour).padStart(2, "0")}:00 WIB${autoRestore ? " · auto-pulihkan aktif" : ""}.`
            : autoMode === "onchange"
              ? `Backup otomatis ±2 menit setelah setiap perubahan data${autoRestore ? " · auto-pulihkan aktif" : ""}.`
              : autoRestore
                ? "Backup mati · auto-pulihkan tetap aktif saat database kosong."
                : "Auto-backup dimatikan.",
      });
      await loadStatus();
    } catch (e) {
      toast({
        title: "Gagal menyimpan pengaturan otomatis",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setAutoBusy(false);
    }
  }

  async function pulihkan() {
    if (!restoreTarget) return;
    setRestoreBusy(true);
    try {
      const r = await apiJson<{ summary: string; sessionInvalid: boolean }>("/api/github/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requesterUsername: user.username, name: restoreTarget.name }),
      });
      if (r.sessionInvalid) {
        toast({
          title: "Database dipulihkan",
          description: "Akun Anda tidak ada di file cadangan — silakan login ulang dengan akun dari file tersebut.",
          variant: "destructive",
        });
      } else {
        toast({ title: "Database dipulihkan", description: r.summary });
      }
      setRestoreTarget(null);
      // Halaman penuh data lama → muat ulang agar seluruh section membaca db baru
      setTimeout(() => window.location.reload(), 1800);
    } catch (e) {
      toast({
        title: "Gagal memulihkan database",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setRestoreBusy(false);
    }
  }

  async function hapusFile() {
    if (!deleteTarget) return;
    setDeleteBusy(true);
    try {
      await apiJson(`/api/github/files/${encodeURIComponent(deleteTarget.name)}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ requesterUsername: user.username }),
      });
      toast({ title: "Cadangan dihapus dari GitHub", description: deleteTarget.name });
      setDeleteTarget(null);
      void loadFiles();
    } catch (e) {
      toast({
        title: "Gagal menghapus cadangan",
        description: e instanceof Error ? e.message : undefined,
        variant: "destructive",
      });
    } finally {
      setDeleteBusy(false);
    }
  }

  function unduh(f: GhFile) {
    const a = document.createElement("a");
    a.href = `/api/github/files/${encodeURIComponent(f.name)}?requesterUsername=${uname}&download=1`;
    a.download = f.name;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  const ready = Boolean(status?.configured);

  return (
    <div className="space-y-4 rounded-2xl border bg-card p-5">
      <div className="flex flex-wrap items-center gap-2">
        <Github className="size-4 text-primary" aria-hidden />
        <h2 className="text-sm font-bold uppercase tracking-wide">Backup ke GitHub</h2>
        <Badge variant="outline" className="rounded-lg bg-emerald-50 text-[10px] font-semibold text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
          Gratis · tanpa Google Cloud
        </Badge>
        <span className="flex-1" />
        <Button
          variant="ghost"
          size="sm"
          className="h-8 gap-1.5 rounded-lg px-2 text-[11px]"
          onClick={() => {
            setLoading(true);
            void loadStatus();
            void loadFiles();
          }}
          disabled={loading || filesBusy}
        >
          <RefreshCw className={`size-3.5 ${loading || filesBusy ? "animate-spin" : ""}`} aria-hidden />
          Segarkan
        </Button>
      </div>
      <p className="text-xs text-muted-foreground">
        Simpan cadangan database ke repositori GitHub privat — commit file .db bertanggal WIB,
        auto-backup harian/per-perubahan, dan pulihkan kembali dari daftar cadangan atau otomatis
        saat database kosong.
      </p>

      {!isAdmin ? (
        <p className="rounded-xl bg-muted/40 px-3 py-2.5 text-xs font-semibold">
          Hanya Admin yang dapat mengatur GitHub.
        </p>
      ) : (
        <>
          {/* ===== Status badge ===== */}
          <div className="flex flex-wrap items-center gap-2">
            {loading ? (
              <span className="text-xs text-muted-foreground">Memuat status…</span>
            ) : (
              <>
                <Badge
                  variant="outline"
                  className={`gap-1.5 rounded-lg ${ready ? "border-emerald-300 bg-emerald-50 text-emerald-800" : "bg-muted/40 text-muted-foreground"}`}
                >
                  {ready ? (
                    <CheckCircle2 className="size-3.5" aria-hidden />
                  ) : (
                    <XCircle className="size-3.5" aria-hidden />
                  )}
                  {ready
                    ? `${status?.repo ?? "-"} @ ${status?.branch ?? "main"}${status?.tokenHint ? ` · token ${status.tokenHint}` : ""}`
                    : "Belum terhubung"}
                </Badge>
                {status?.lastBackupAt && (
                  <span className="text-[11px] text-muted-foreground">
                    Backup terakhir: {fmtDate(status.lastBackupAt)}
                    {status.lastBackupFile ? ` (${status.lastBackupFile})` : ""}
                  </span>
                )}
              </>
            )}
          </div>

          {/* ===== Kredensial ===== */}
          <div className="rounded-xl border p-4">
            <div className="mb-1 flex flex-wrap items-center gap-2">
              <KeyRound className="size-4 text-primary" aria-hidden />
              <h3 className="text-[13px] font-bold">Koneksi GitHub (Token + Repo)</h3>
              {ready && (
                <div className="ml-auto flex gap-1.5">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 gap-1 rounded-lg px-2 text-[11px]"
                    onClick={() => setEditOpen((v) => !v)}
                    disabled={credBusy}
                  >
                    Ubah
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-8 gap-1 rounded-lg px-2 text-[11px]"
                    onClick={() => void putuskan()}
                    disabled={credBusy}
                  >
                    <Unplug className="size-3.5" aria-hidden /> Putuskan
                  </Button>
                </div>
              )}
            </div>
            <p className="mb-3 text-xs text-muted-foreground">
              Server meng-commit cadangan langsung ke repo Anda. Gunakan repo <b>privat</b>; token
              hanya tersimpan di server aplikasi ini.
            </p>

            {ready && !editOpen ? (
              <p className="text-xs">
                <b>Tersambung</b> — repo <code className="font-mono text-[10px]">{status?.repo}</code>,
                branch <code className="font-mono text-[10px]">{status?.branch}</code>, folder{" "}
                <code className="font-mono text-[10px]">{status?.folder || "(root)"}</code>
                {status?.tokenHint ? `, token ${status.tokenHint}` : ""}.
              </p>
            ) : (
              <div className="space-y-2">
                <div className="space-y-1">
                  <Label htmlFor="github-token" className="text-[11px]">
                    Personal Access Token (fine-grained / classic)
                  </Label>
                  <Input
                    id="github-token"
                    type="password"
                    value={token}
                    onChange={(e) => setToken(e.target.value)}
                    placeholder="github_pat_… atau ghp_…"
                    className="h-9 rounded-lg text-xs"
                    autoComplete="off"
                  />
                </div>
                <div className="grid gap-2 sm:grid-cols-3">
                  <div className="space-y-1 sm:col-span-2">
                    <Label htmlFor="github-repo" className="text-[11px]">
                      Repositori (owner/repo)
                    </Label>
                    <Input
                      id="github-repo"
                      value={repo}
                      onChange={(e) => setRepo(e.target.value)}
                      placeholder="mis. budi/fixplus-backup"
                      className="h-9 rounded-lg text-xs"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="github-branch" className="text-[11px]">
                      Branch
                    </Label>
                    <Input
                      id="github-branch"
                      value={branch}
                      onChange={(e) => setBranch(e.target.value)}
                      placeholder="main"
                      className="h-9 rounded-lg text-xs"
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <Label htmlFor="github-folder" className="text-[11px]">
                    Folder di repo (opsional)
                  </Label>
                  <Input
                    id="github-folder"
                    value={folder}
                    onChange={(e) => setFolder(e.target.value)}
                    placeholder="fixplus-backup"
                    className="h-9 rounded-lg text-xs"
                  />
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <Button
                    size="sm"
                    className="h-9 gap-1.5 rounded-lg"
                    onClick={() => void simpanKredensial()}
                    disabled={credBusy || !token.trim() || !repo.trim()}
                  >
                    <KeyRound className="size-3.5" aria-hidden />
                    {credBusy ? "Menguji koneksi…" : "Uji & Simpan"}
                  </Button>
                  <a
                    href="https://github.com/new"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex h-9 items-center gap-1.5 rounded-lg border px-3 text-xs font-medium hover:bg-muted/50"
                  >
                    <ExternalLink className="size-3.5" aria-hidden /> Buat repo privat baru
                  </a>
                </div>
              </div>
            )}
          </div>

          {/* ===== Panduan setup ===== */}
          <Collapsible open={guideOpen} onOpenChange={setGuideOpen}>
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 gap-1.5 rounded-lg px-2 text-[12px]">
                <HelpCircle className="size-3.5" aria-hidden />
                Panduan singkat setup GitHub (±5 menit, sekali saja)
                <ChevronDown className={`size-3.5 transition-transform ${guideOpen ? "rotate-180" : ""}`} aria-hidden />
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent>
              <div className="mt-2 space-y-3 rounded-xl border border-dashed bg-muted/30 p-4 text-xs leading-relaxed">
                <div>
                  <p className="font-bold">1. Siapkan repositori</p>
                  <ol className="mt-1 list-decimal space-y-0.5 pl-5 text-muted-foreground">
                    <li>
                      Buka <b>github.com/new</b> (perlu akun GitHub gratis) → nama{" "}
                      <i>fixplus-backup</i> → centang <b>Private</b> → <b>Create repository</b>.
                    </li>
                    <li>Repo baru boleh kosong — folder cadangan dibuat otomatis saat backup pertama.</li>
                  </ol>
                </div>
                <div>
                  <p className="font-bold">2. Buat Personal Access Token</p>
                  <ol className="mt-1 list-decimal space-y-0.5 pl-5 text-muted-foreground">
                    <li>
                      GitHub → <b>Settings → Developer settings → Personal access tokens →
                      Fine-grained tokens → Generate new token</b>.
                    </li>
                    <li>
                      <b>Repository access</b>: <i>Only select repositories</i> → pilih{" "}
                      <i>fixplus-backup</i> saja (least-privilege).
                    </li>
                    <li>
                      <b>Permissions → Repository permissions → Contents</b>: pilih{" "}
                      <b>Read and write</b>. Metadata otomatis ikut terbaca.
                    </li>
                    <li>
                      <b>Generate token</b> → salin (mulai <i>github_pat_…</i>) → tempel ke kolom
                      Token di atas. Kedaluwarsa bebas; bila kedaluwarsa, buat token baru dan simpan ulang.
                    </li>
                  </ol>
                </div>
                <div>
                  <p className="font-bold">3. Hubungkan aplikasi</p>
                  <ol className="mt-1 list-decimal space-y-0.5 pl-5 text-muted-foreground">
                    <li>
                      Isi Token + Repositori di atas → <b>Uji &amp; Simpan</b> (koneksi diuji langsung
                      ke GitHub sebelum disimpan).
                    </li>
                    <li>
                      Klik <b>Backup ke GitHub Sekarang</b> untuk cadangan pertama, lalu aktifkan{" "}
                      auto-backup bila ingin otomatis — mode <b>tiap ada perubahan data</b> atau
                      jadwal <b>harian</b>.
                    </li>
                    <li>
                      (Opsional) Nyalakan <b>Pulihkan Otomatis &amp; Sinkron Awal</b> — bila server
                      menyala / aplikasi dibuka dengan database kosong atau lebih tua dari cadangan
                      GitHub, cadangan terakhir dipulihkan sendiri; backup yang belum terkirim
                      diunggah dulu.
                    </li>
                  </ol>
                </div>
                <p className="text-muted-foreground">
                  Catatan: pakai token classic (ghp_…)? Centang scope <i>repo</i>. Repo privat +
                  token fine-grained satu repo = akses paling kecil.
                </p>
              </div>
            </CollapsibleContent>
          </Collapsible>

          {/* ===== Backup & auto-backup ===== */}
          <div className="rounded-xl border p-4">
            <h3 className="mb-1 text-[13px] font-bold">Backup ke GitHub &amp; Auto-Backup</h3>
            <div className="mb-3 flex flex-wrap items-end gap-2">
              <Button
                className="h-9 gap-1.5 rounded-lg"
                onClick={() => void backupSekarang()}
                disabled={backupBusy || !ready || loading}
              >
                <CloudUpload className="size-4" aria-hidden />
                {backupBusy ? "Meng-commit…" : "Backup ke GitHub Sekarang"}
              </Button>
              <span className="text-[11px] text-muted-foreground">
                File .db penuh (semua data) dengan nama bertanggal WIB.
              </span>
            </div>
            <div className="h-px bg-border" aria-hidden />
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <div className="space-y-1 sm:col-span-2">
                <Label className="text-[13px] font-semibold">Mode auto-backup</Label>
                <Select
                  value={autoMode}
                  onValueChange={(v) => setAutoMode(v as "off" | "daily" | "onchange")}
                  disabled={!ready}
                >
                  <SelectTrigger className="h-9 w-full rounded-lg text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="off">Tidak aktif</SelectItem>
                    <SelectItem value="daily">Setiap hari (jam tertentu)</SelectItem>
                    <SelectItem value="onchange">Setiap ada perubahan data</SelectItem>
                  </SelectContent>
                </Select>
                <span className="block text-[11px] text-muted-foreground">
                  {autoMode === "onchange"
                    ? status?.lastBackupAt
                      ? `Terakhir otomatis: ${fmtDate(status.lastBackupAt)}`
                      : "Belum pernah jalan"
                    : status?.lastAutoBackupDate
                      ? `Terakhir otomatis: ${status.lastAutoBackupDate}`
                      : "Belum pernah jalan"}
                </span>
              </div>
              {autoMode === "daily" && (
                <div className="space-y-1">
                  <Label className="text-[11px]">Jam (WIB)</Label>
                  <Select value={autoHour} onValueChange={setAutoHour} disabled={!ready}>
                    <SelectTrigger className="h-9 w-full rounded-lg text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="max-h-56">
                      {Array.from({ length: 24 }, (_, h) => (
                        <SelectItem key={h} value={String(h)}>
                          {String(h).padStart(2, "0")}:00
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <div className="space-y-1">
                <Label className="text-[11px]">Simpan cadangan terakhir (biji)</Label>
                <Input
                  type="number"
                  min={1}
                  max={90}
                  value={autoKeep}
                  onChange={(e) => setAutoKeep(e.target.value)}
                  disabled={!ready}
                  className="h-9 rounded-lg text-xs"
                />
              </div>
              <div className="flex items-end sm:col-span-2">
                <Button
                  variant="outline"
                  className="h-9 rounded-lg"
                  onClick={() => void simpanAuto()}
                  disabled={autoBusy || !ready}
                >
                  {autoBusy ? "Menyimpan…" : "Simpan Pengaturan Otomatis"}
                </Button>
              </div>
            </div>
            {autoMode === "onchange" ? (
              <p className="mt-2 rounded-lg bg-muted/40 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
                Setiap perubahan data — transaksi kasir, tiket servis, pelanggan, inventaris,
                pengguna, dll. — otomatis di-backup ±2 menit setelah perubahan TERAKHIR; perubahan
                beruntun digabung jadi satu commit. Bila data terus berubah tanpa henti, backup
                tetap jalan paling lambat 30 menit setelah perubahan pertama. Catatan log aktivitas
                (login, dsb.) tidak dihitung sebagai perubahan.
              </p>
            ) : (
              <p className="mt-2 text-[11px] text-muted-foreground">
                Jadwal berjalan di server — komputer/HP boleh dimatikan. Cadangan melebihi jumlah di
                atas otomatis dihapus dari repo (riwayat commit tetap ada di GitHub, tapi hanya
                &quot;empty tree&quot; kecil — repo tetap ramping).
              </p>
            )}

            {/* D70/D74 — Pulihkan otomatis + sinkronisasi awal berbasis seq */}
            <div className="mt-3 h-px bg-border" aria-hidden />
            <div className="mt-3 flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0 flex-1 space-y-1">
                <h4 className="text-[13px] font-bold">Pulihkan Otomatis &amp; Sinkron Awal</h4>
                <p className="text-xs leading-relaxed text-muted-foreground">
                  Setiap backup menulis nomor urut data (seq) ke <i>manifest.json</i> di repo. Saat
                  server menyala / aplikasi dibuka, seq lokal dibandingkan dengan GitHub: database
                  <b> kosong</b> atau <b>lebih tua</b> dari cadangan terbaru → cadangan otomatis
                  dipulihkan; ada <b>backup yang belum terkirim</b> (lokal lebih baru) → langsung
                  diunggah, tidak di-restore. Repo ditulis perangkat lain → ditandai konflik dan
                  ditunggu keputusan pemilik — data yang lebih baru tidak pernah ditimpa otomatis.
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-2 pt-0.5">
                <span
                  className={`text-[11px] font-semibold ${autoRestore ? "text-emerald-700 dark:text-emerald-300" : "text-muted-foreground"}`}
                >
                  {autoRestore ? "Aktif" : "Mati"}
                </span>
                <Switch
                  checked={autoRestore}
                  onCheckedChange={setAutoRestore}
                  disabled={!ready || autoBusy}
                  aria-label="Aktifkan pulihkan otomatis dan sinkronisasi awal"
                />
              </div>
            </div>
            <p className="mt-1.5 text-[11px] text-muted-foreground">
              {autoRestore
                ? `Dicek 20 detik setelah server menyala, saat aplikasi dibuka, lalu tiap 10 menit. ${status?.dataVersion != null ? `Seq lokal: ${status.dataVersion}${status.deviceId ? ` · perangkat: ${status.deviceId}` : ""}. ` : ""}${status?.lastAutoRestoreAt ? `Terakhir auto-pulihkan: ${fmtDate(status.lastAutoRestoreAt)}${status.lastAutoRestoreFile ? ` (${status.lastAutoRestoreFile})` : ""}.` : "Belum pernah pulihkan otomatis."}`
                : "Nyalakan saklar lalu klik “Simpan Pengaturan Otomatis” di atas."}
            </p>
            {autoRestore && status?.conflict && (
              <p className="mt-1.5 rounded-lg bg-red-50 px-3 py-2 text-[11px] leading-relaxed text-red-900 dark:bg-red-950 dark:text-red-200">
                <b>Konflik sinkronisasi</b> (terdeteksi {fmtDate(status.conflict.detectedAt)}):{" "}
                {status.conflict.detail} — tidak ada aksi otomatis. Putuskan sendiri lewat tombol{" "}
                <b>Backup ke GitHub Sekarang</b> (pakai data lokal) atau pulihkan cadangan terbaru di
                daftar di bawah (pakai data repo).
              </p>
            )}
            {autoRestore && (
              <p className="mt-1.5 rounded-lg bg-amber-50 px-3 py-2 text-[11px] leading-relaxed text-amber-900 dark:bg-amber-950 dark:text-amber-200">
                Catatan: bila aplikasi sengaja dikosongkan lewat Factory Reset, fitur ini dimatikan
                otomatis agar data lama tidak kembali sendiri.
              </p>
            )}
          </div>

          {/* ===== Daftar cadangan di repo ===== */}
          <div className="rounded-xl border p-4">
            <div className="mb-2 flex flex-wrap items-center gap-2">
              <h3 className="text-[13px] font-bold">Cadangan Tersimpan di GitHub</h3>
              <span className="flex-1" />
              <Button
                variant="outline"
                size="sm"
                className="h-8 gap-1 rounded-lg px-2 text-[11px]"
                onClick={() => void loadFiles()}
                disabled={filesBusy || !ready}
              >
                <RefreshCw className={`size-3.5 ${filesBusy ? "animate-spin" : ""}`} aria-hidden /> Muat daftar
              </Button>
            </div>
            {!ready ? (
              <p className="rounded-lg bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
                Hubungkan GitHub di atas untuk melihat cadangan di repo.
              </p>
            ) : files === null ? (
              <p className="text-xs text-muted-foreground">Klik “Muat daftar” untuk melihat cadangan.</p>
            ) : files.length === 0 ? (
              <p className="text-xs text-muted-foreground">
                Belum ada cadangan. Klik “Backup ke GitHub Sekarang” untuk membuat yang pertama.
              </p>
            ) : (
              <div className="divide-y rounded-lg border">
                {files.map((f) => (
                  <div key={f.sha} className="flex flex-wrap items-center gap-x-3 gap-y-1 px-3 py-2">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[12px] font-semibold">{f.name}</p>
                      <p className="text-[10px] text-muted-foreground">
                        {tglDariNama(f.name)}
                        {f.size ? ` · ${fmtBytes(f.size)}` : ""}
                      </p>
                    </div>
                    <div className="flex shrink-0 gap-1.5">
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 gap-1 rounded-md px-2 text-[10px]"
                        onClick={() => setRestoreTarget(f)}
                      >
                        <Undo2 className="size-3" aria-hidden /> Pulihkan
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 gap-1 rounded-md px-2 text-[10px]"
                        onClick={() => unduh(f)}
                      >
                        <Download className="size-3" aria-hidden /> Unduh
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 gap-1 rounded-md px-2 text-[10px] text-destructive"
                        onClick={() => setDeleteTarget(f)}
                      >
                        <Trash2 className="size-3" aria-hidden /> Hapus
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <p className="flex items-start gap-2 rounded-xl border border-dashed bg-muted/30 px-3 py-2.5 text-[11px] leading-relaxed text-muted-foreground">
            <Info className="mt-0.5 size-3.5 shrink-0" aria-hidden />
            Semua transfer ditangani server aplikasi (token tidak pernah tersimpan di perangkat
            klien), dan setiap aksi backup/pulihkan tercatat di Log Aktivitas.
          </p>
        </>
      )}

      {/* ===== Dialog konfirmasi Pulihkan ===== */}
      <AlertDialog
        open={!!restoreTarget}
        onOpenChange={(v) => {
          if (!restoreBusy) setRestoreTarget(v ? restoreTarget : null);
        }}
      >
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Pulihkan dari GitHub — Ganti Seluruh Database?</AlertDialogTitle>
            <AlertDialogDescription>
              Isi database akan DIGANTI dengan &quot;{restoreTarget?.name}&quot; (bukan digabung).
              Database saat ini otomatis disalin dulu sebagai berkas keamanan di server. Bila akun
              Anda tidak ada di file tersebut, sesi berakhir dan Anda login ulang dengan akun dari
              file cadangan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={restoreBusy}>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                void pulihkan();
              }}
              disabled={restoreBusy}
            >
              {restoreBusy ? "Memulihkan…" : "Ya, Pulihkan"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ===== Dialog konfirmasi Hapus cadangan ===== */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(v) => {
          if (!deleteBusy) setDeleteTarget(v ? deleteTarget : null);
        }}
      >
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Cadangan dari GitHub?</AlertDialogTitle>
            <AlertDialogDescription>
              &quot;{deleteTarget?.name}&quot; akan dihapus permanen dari repositori{" "}
              {status?.repo ?? "-"}. Cadangan lain tidak terpengaruh.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteBusy}>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                void hapusFile();
              }}
              disabled={deleteBusy}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteBusy ? "Menghapus…" : "Hapus"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
