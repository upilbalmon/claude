import { NextRequest } from "next/server";
import { loadCreds, updateCreds, findOrCreateFolder, GDRIVE_FOLDER_NAME } from "@/lib/gdrive";
import { db } from "@/lib/db";

// D67 — GET /api/gdrive/oauth/callback?code=...&state=...
// Google mengembalikan pengguna ke sini setelah menyetujui izin. Tukar code
// dengan refresh token, simpan, buat/temukan folder "Fixplus Backup", lalu
// sajikan halaman kecil yang memberi tahu jendela utama (postMessage) dan
// menutup popup sendiri. Semua hasil (sukses/gagal) lewat satu halaman HTML.
function page(status: "ok" | "error", message: string): Response {
  const safe = message.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const html = `<!doctype html>
<html lang="id"><head><meta charset="utf-8"><title>Fixplus — Google Drive</title>
<style>body{font-family:system-ui,sans-serif;display:grid;place-items:center;height:100vh;margin:0;background:#0b1220;color:#e6edf7}
.kartu{max-width:420px;padding:28px;border-radius:16px;background:#151d2e;text-align:center}
h1{font-size:17px;margin:0 0 8px}p{font-size:13px;line-height:1.6;color:#9fb0c8;margin:0}
button{margin-top:16px;padding:8px 16px;border-radius:10px;border:0;background:#2f81f7;color:#fff;font-size:13px}</style></head>
<body><div class="kartu"><h1>${status === "ok" ? "Google Drive Tersambung" : "Koneksi Gagal"}</h1>
<p>${safe}</p><button onclick="window.close()">Tutup</button></div>
<script>
try { window.opener && window.opener.postMessage({ type: "fixplus-gdrive", status: "${status}", message: ${JSON.stringify(message)} }, "*"); } catch (e) {}
setTimeout(function(){ try { window.close(); } catch (e) {} }, 1200);
</script></body></html>`;
  return new Response(html, { headers: { "Content-Type": "text/html; charset=utf-8" } });
}

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const errorDesc = sp.get("error_description") ?? sp.get("error");
  if (errorDesc) {
    return page("error", `Google menolak: ${decodeURIComponent(errorDesc)}`);
  }
  const code = sp.get("code");
  const state = sp.get("state");
  if (!code || !state) {
    return page("error", "Respons Google tidak lengkap (code/state kosong)");
  }

  const c = await loadCreds();
  const pending = c.pendingOauth;
  if (!pending || pending.state !== state) {
    return page("error", "Kode state tidak cocok — buka ulang popup koneksi dari halaman Pengaturan");
  }
  if (new Date(pending.expiry).getTime() < Date.now()) {
    return page("error", "Sesi koneksi kedaluwarsa (lebih dari 15 menit) — coba hubungkan lagi");
  }
  if (!c.oauth?.clientId || !c.oauth?.clientSecret) {
    return page("error", "Kredensial OAuth hilang — simpan ulang Client ID/Secret");
  }

  try {
    // Tukar authorization code → refresh token
    const res = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: c.oauth.clientId,
        client_secret: c.oauth.clientSecret,
        redirect_uri: pending.redirectUri,
        grant_type: "authorization_code",
      }),
    });
    const tok = (await res.json().catch(() => ({}))) as Record<string, unknown>;
    if (!res.ok || typeof tok.access_token !== "string") {
      const desc = String(tok.error_description ?? tok.error ?? `HTTP ${res.status}`);
      throw new Error(desc);
    }
    const refreshToken = typeof tok.refresh_token === "string" ? tok.refresh_token : c.oauth.refreshToken;
    if (!refreshToken) {
      throw new Error(
        "Google tidak menerbitkan refresh token — coba putuskan lalu hubungkan ulang (prompt=consent sudah aktif)"
      );
    }

    // Nama akun Google (userinfo.email — hanya untuk ditampilkan)
    let email = "";
    try {
      const ui = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
        headers: { Authorization: `Bearer ${tok.access_token}` },
      });
      if (ui.ok) {
        const u = (await ui.json()) as { email?: string };
        email = String(u.email ?? "");
      }
    } catch { /* email opsional */ }

    // Siapkan folder cadangan
    const folderId = await findOrCreateFolder(tok.access_token, GDRIVE_FOLDER_NAME, null);

    await updateCreds((cr) => ({
      ...cr,
      pendingOauth: undefined,
      oauth: {
        clientId: c.oauth!.clientId,
        clientSecret: c.oauth!.clientSecret,
        refreshToken,
        accessToken: tok.access_token as string,
        accessTokenExpiry: new Date(Date.now() + Number(tok.expires_in ?? 3600) * 1000).toISOString(),
        email,
        folderId,
      },
    }));
    await db.auditLog.create({
      data: {
        action: "GDRIVE_OAUTH_CONNECT",
        details: `Google Drive terhubung (OAuth)${email ? ` — akun ${email}` : ""}; folder "${GDRIVE_FOLDER_NAME}" siap`,
        performedBy: email || "Admin",
      },
    });
    return page(
      "ok",
      `Akun ${email || "Google"} terhubung. Cadangan akan disimpan di folder "${GDRIVE_FOLDER_NAME}" di Drive Anda. Jendela ini bisa ditutup.`
    );
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return page("error", `Gagal menyelesaikan koneksi: ${msg}`);
  }
}
