import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { generateSalt, hashPin, sanitizeUser } from "@/lib/pin-hash";
import { autoAbsenMasuk } from "@/lib/drawer";

// POST /api/auth/change-pin — changePinAndLogin() AppViewModel.kt
// Validasi persis LoginScreen.kt: 4 angka, bukan PIN default 1234/1111
// Tahap 7.3 (ganti PIN sendiri dari aplikasi): selain jalur wajib-ganti-PIN
// pertama login, pengguna kini WAJIB mengirim currentPin — diverifikasi server
// (hash) sebelum PIN boleh diganti.
export async function POST(req: NextRequest) {
  try {
    const { userId, newPin, currentPin } = (await req.json()) as {
      userId?: number;
      newPin?: string;
      currentPin?: string;
    };

    if (!userId || !newPin) {
      return NextResponse.json({ status: "ERROR", message: "Data tidak lengkap" }, { status: 400 });
    }
    if (newPin.length !== 4 || !/^\d{4}$/.test(newPin)) {
      return NextResponse.json(
        { status: "ERROR", message: "PIN baru wajib berupa 4 angka!" },
        { status: 400 }
      );
    }
    if (newPin === "1234" || newPin === "1111") {
      return NextResponse.json(
        { status: "ERROR", message: "Jangan gunakan PIN default! Gunakan kombinasi lain." },
        { status: 400 }
      );
    }

    const user = await db.user.findUnique({ where: { id: userId } });
    if (!user) {
      return NextResponse.json({ status: "ERROR", message: "Pengguna tidak ditemukan" }, { status: 404 });
    }

    // Tahap 7.3: pengguna yang sudah melewati wajib-ganti-PIN pertama harus
    // membuktikan PIN lama. Tanpa ini siapa pun bisa mengganti PIN siapa pun.
    if (!user.mustChangePin) {
      if (!currentPin) {
        return NextResponse.json(
          { status: "ERROR", message: "PIN saat ini wajib diisi" },
          { status: 400 }
        );
      }
      if (hashPin(currentPin, user.salt) !== user.pin) {
        return NextResponse.json(
          { status: "ERROR", message: "PIN saat ini salah!" },
          { status: 403 }
        );
      }
    }

    const salt = generateSalt();
    const updated = await db.user.update({
      where: { id: userId },
      data: { pin: hashPin(newPin, salt), salt, mustChangePin: false },
    });

    await db.auditLog.create({
      data: {
        action: "CHANGE_PIN",
        details: user.mustChangePin ? "Ganti PIN default (login pertama)" : "Ganti PIN sendiri dari aplikasi",
        performedBy: updated.name,
      },
    });

    // D92 — jaring pengaman: bila absen masuk otomatis saat login belum
    // tercatat (mis. DB dipulihkan di antara dua langkah), catat sekarang.
    // Idempoten — absen yang sudah ada tidak diubah.
    await autoAbsenMasuk({ id: updated.id, name: updated.name });

    return NextResponse.json({
      status: "SUCCESS",
      user: sanitizeUser(updated),
      message: "PIN berhasil diperbarui. Selamat datang!",
    });
  } catch (e) {
    console.error("change-pin error", e);
    return NextResponse.json({ status: "ERROR", message: "Terjadi kesalahan server" }, { status: 500 });
  }
}
