"use client";

// Dialog pendukung modul Servis (Tahap 4) — port dari RepairSection.kt & SettingsSection.kt:
// CustomerSelectionDialog, SparePartSelectionDialog, WhatsAppEditorDialog,
// RepairReceiptDialog (struk terima barang/tanda terima, cetak A5 + JPG unduh/bagikan;
//   D21: mode Nota Pelunasan dihapus — struk pelunasan hanya dibuat di Kasir),
// DiagnosaSentWaDialog (D21: diagnosa tersimpan → konfirmasi + kirim WA otomatis;
//   D24: dipakai juga untuk VOID diagnosa — status TIDAK_BISA),
// PriceEstimationDialog.
import { useEffect, useMemo, useState } from "react";
import QRCode from "qrcode";
import { toJpeg } from "html-to-image";
import {
  Calculator,
  Check,
  Copy,
  Download,
  Printer,
  Save,
  Search,
  Send,
  Share2,
  UserRound,
  X,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableHeader } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import {
  FinIndexTd,
  FinRow,
  FinSortTh,
  FinTd,
  FinTh,
} from "@/components/app/fin-table";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { formatCurrency, formatDate } from "@/lib/format";
import { parseRequestedParts, pendingRequestedParts, serviceIdOf } from "@/lib/repair-utils";
import { cetakNode } from "@/lib/print-helper";
import {
  buildRepairReceiptText,
  notaSisaBayar,
  notaTotalPelunasan,
  partsSumOf,
  type Repair,
} from "@/components/app/sections/servis-receipt";
import {
  REPAIR_STATUS_LABEL,
} from "@/lib/app-types";
import {
  STANDARD_BRANDS,
  STANDARD_CASES,
  formatWaMessage,
  getWaTemplate,
  parseUsedParts,
  waLink,
} from "@/lib/repair-utils";

type CustomerLite = { id: number; name: string; phone: string; loyaltyPoints: number };
type SparePartLite = {
  id: number; name: string; sku: string; stock: number;
  costPrice: number; sellPrice: number;
};

async function apiJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string }).error ?? "Terjadi kesalahan");
  return data as T;
}

// Konversi data URL (base64) → File agar bisa dibagikan via navigator.share (ala kasir D14)
function dataUrlToFile(dataUrl: string, filename: string): File | null {
  try {
    const [meta, b64] = dataUrl.split(",");
    const mime = meta?.match(/:(.*?);/)?.[1] ?? "image/jpeg";
    const bin = atob(b64 ?? "");
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new File([bytes], filename, { type: mime });
  } catch {
    return null;
  }
}

function unduhDataUrl(dataUrl: string, namaFile: string) {
  const link = document.createElement("a");
  link.href = dataUrl;
  link.download = namaFile;
  link.click();
}

// ============================================================
// CustomerSelectionDialog.kt — pilih/cari pelanggan + tambah baru
// ============================================================
export function CustomerPickerDialog({
  customers,
  onSelect,
  onAddNew,
  onUmum,
  open,
  onOpenChange,
}: {
  customers: CustomerLite[];
  onSelect: (c: CustomerLite) => void;
  onAddNew: (name: string, phone: string) => void;
  // D72: pilihan Pelanggan Umum (walk-in) — tidak dicatat ke daftar pelanggan,
  // persis "Umum / Guest" pada transaksi kasir
  onUmum?: () => void;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [q, setQ] = useState("");
  const [showNew, setShowNew] = useState(false);
  const [newName, setNewName] = useState("");
  const [newPhone, setNewPhone] = useState("");

  const filtered = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(q.toLowerCase()) ||
      c.phone.toLowerCase().includes(q.toLowerCase())
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-2xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Pilih Pelanggan</DialogTitle>
          <DialogDescription>Cari nama atau nomor WhatsApp pelanggan terdaftar.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          {/* D72: pilihan Umum / Guest selalu paling atas — pelanggan langganan
              yang tidak mau dicatat datanya cukup pilih ini */}
          {onUmum && (
            <button
              type="button"
              onClick={() => {
                onUmum();
                onOpenChange(false);
              }}
              className="flex w-full items-center gap-3 rounded-xl border border-primary/30 bg-primary/5 px-3 py-2.5 text-left text-sm transition-colors hover:bg-primary/10"
            >
              <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                <UserRound className="size-4 text-primary" aria-hidden />
              </span>
              <span className="min-w-0">
                <span className="block font-bold text-primary">Umum / Guest</span>
                <span className="block text-xs text-muted-foreground">
                  Pelanggan tidak dicatat — tanpa nomor WA &amp; poin loyalitas
                </span>
              </span>
            </button>
          )}
          <div className="relative">
            <Search className="absolute left-3 top-2.5 size-4 text-muted-foreground" aria-hidden />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Cari nama / No. WA..."
              className="pl-9"
            />
          </div>
          <div className="max-h-64 overflow-y-auto rounded-xl border">
            {filtered.length === 0 && (
              <p className="p-4 text-center text-sm text-muted-foreground">Tidak ada pelanggan cocok.</p>
            )}
            {filtered.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => {
                  onSelect(c);
                  onOpenChange(false);
                }}
                className="flex w-full items-center justify-between gap-2 border-b px-3 py-2.5 text-left text-sm transition-colors last:border-b-0 hover:bg-primary/5"
              >
                <span className="min-w-0">
                  <span className="block truncate font-bold">{c.name}</span>
                  <span className="block font-mono text-xs text-muted-foreground">{c.phone || "—"}</span>
                </span>
                <Badge variant="secondary" className="shrink-0 tabular-nums">{c.loyaltyPoints} poin</Badge>
              </button>
            ))}
          </div>
          {!showNew ? (
            <Button type="button" variant="outline" className="w-full" onClick={() => setShowNew(true)}>
              + Pelanggan Baru
            </Button>
          ) : (
            <div className="space-y-2 rounded-xl border bg-muted/40 p-3">
              <div className="space-y-1">
                <Label htmlFor="wa-nama-baru">Nama Pelanggan</Label>
                <Input
                  id="wa-nama-baru"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="Contoh: Budi Santoso"
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="wa-telp-baru">No. WhatsApp</Label>
                <Input
                  id="wa-telp-baru"
                  value={newPhone}
                  onChange={(e) => setNewPhone(e.target.value)}
                  placeholder="08xxxxxxxxxx (boleh dikosongkan)"
                  inputMode="tel"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  type="button"
                  className="flex-1"
                  disabled={!newName.trim()}
                  onClick={() => {
                    onAddNew(newName.trim(), newPhone.trim());
                    setShowNew(false);
                    setNewName("");
                    setNewPhone("");
                    onOpenChange(false);
                  }}
                >
                  Simpan &amp; Pilih
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowNew(false)}>
                  Batal
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================
// SparePartSelectionDialog.kt — pilih sparepart internal (cari + sortir)
// ============================================================
type PartSortKey = "NAMA" | "HARGA" | "STOK";
export function SparePartPickerDialog({
  parts,
  onSelect,
  open,
  onOpenChange,
}: {
  parts: SparePartLite[];
  onSelect: (p: SparePartLite) => void;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [q, setQ] = useState("");
  const [sortKey, setSortKey] = useState<PartSortKey>("NAMA");
  const [asc, setAsc] = useState(true);

  const filtered = useMemo(() => {
    const list = parts.filter(
      (p) =>
        p.name.toLowerCase().includes(q.toLowerCase()) ||
        p.sku.toLowerCase().includes(q.toLowerCase())
    );
    const sorted = [...list].sort((a, b) => {
      if (sortKey === "NAMA") return a.name.localeCompare(b.name, "id");
      if (sortKey === "HARGA") return a.sellPrice - b.sellPrice;
      return a.stock - b.stock;
    });
    return asc ? sorted : sorted.reverse();
  }, [parts, q, sortKey, asc]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-2xl sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Pilih Sparepart</DialogTitle>
          <DialogDescription>
            Sparepart internal dari inventaris — stok baru dipotong saat tiket dibayar (checkout).
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative min-w-0 flex-1">
              <Search className="absolute left-3 top-2.5 size-4 text-muted-foreground" aria-hidden />
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Cari Sparepart atau SKU..."
                className="pl-9"
              />
            </div>
            {(["NAMA", "HARGA", "STOK"] as PartSortKey[]).map((k) => (
              <button
                key={k}
                type="button"
                onClick={() => {
                  if (sortKey === k) setAsc((v) => !v);
                  else {
                    setSortKey(k);
                    setAsc(true);
                  }
                }}
                aria-label={`Urutkan berdasarkan ${k}`}
                className={cn(
                  "rounded-lg border px-2.5 py-1.5 text-[11px] font-bold uppercase tracking-wide transition-colors",
                  sortKey === k
                    ? "border-primary bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-muted"
                )}
              >
                {k} {sortKey === k ? (asc ? "▲" : "▼") : ""}
              </button>
            ))}
          </div>
          <div className="max-h-80 overflow-y-auto rounded-xl border">
            <Table>
              <TableHeader>
                <tr>
                  <FinTh corner="first" sticky={false} className="w-10 text-center">#</FinTh>
                  <FinSortTh
                    label="Nama Sparepart"
                    k="NAMA"
                    sortKey={sortKey}
                    asc={asc}
                    onSort={(k) => { setSortKey(k); setAsc(k === sortKey ? !asc : true); }}
                    sticky={false}
                  />
                  <FinTh sticky={false} align="right">Stok</FinTh>
                  <FinTh sticky={false} align="right" corner="last">Harga Jual</FinTh>
                </tr>
              </TableHeader>
              <TableBody>
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={4} className="p-6 text-center text-sm text-muted-foreground">
                      Tidak ada sparepart cocok.
                    </td>
                  </tr>
                )}
                {filtered.map((p, i) => (
                  <FinRow key={p.id} zebra={i % 2 === 1} onClick={() => { onSelect(p); onOpenChange(false); }}>
                    <FinIndexTd>{i + 1}</FinIndexTd>
                    <FinTd>
                      <span className="block font-bold">{p.name}</span>
                      <span className="font-mono text-[11px] text-muted-foreground">{p.sku}</span>
                    </FinTd>
                    <FinTd align="right" className={cn("tabular-nums", p.stock <= 0 && "font-bold text-red-600")}>
                      {p.stock <= 0 ? "Habis" : p.stock}
                    </FinTd>
                    <FinTd align="right" className="font-bold tabular-nums">{formatCurrency(p.sellPrice)}</FinTd>
                  </FinRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================
// WhatsAppEditorDialog.kt — template per status + preview + kirim via wa.me
// ============================================================
export function WhatsAppEditorDialog({
  repair,
  waMap,
  onSaved,
  open,
  onOpenChange,
  shop,
}: {
  repair: Repair;
  waMap: Record<string, string>;
  onSaved: (map: Record<string, string>) => void;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  // Tahap 7.1: profil toko untuk placeholder {toko}/{telepon_toko}
  shop?: { name: string; phone: string };
}) {
  const { toast } = useToast();
  const statusLabel = REPAIR_STATUS_LABEL[repair.status] ?? repair.status;
  const [template, setTemplate] = useState(() => getWaTemplate(repair.status, waMap));
  const [saving, setSaving] = useState(false);

  const preview = formatWaMessage(
    repair.status,
    { [repair.status]: template },
    {
      customerName: repair.customerName,
      deviceModel: repair.deviceModel,
      damageDescription: repair.damageDescription,
      status: repair.status,
      notes: repair.notes,
      serviceFee: repair.serviceFee,
      totalPrice: repair.totalPrice,
      usedPartsJson: repair.usedPartsJson,
    },
    statusLabel,
    formatCurrency,
    undefined,
    shop
  );

  const simpanTemplate = async () => {
    try {
      setSaving(true);
      const merged = { ...waMap, [repair.status]: template };
      const updated = await apiJson<Record<string, unknown>>("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ waTemplates: JSON.stringify(merged) }),
      });
      onSaved(parseWaTemplatesSafe(String(updated.waTemplates ?? "{}")));
      toast({ title: "Template tersimpan", description: `Template WhatsApp status ${statusLabel} diperbarui.` });
    } catch (e) {
      toast({
        title: "Gagal menyimpan template",
        description: String(e instanceof Error ? e.message : e),
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-2xl sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>WhatsApp Editor &amp; Preview</DialogTitle>
          <DialogDescription>
            Template status <b>{statusLabel}</b> — placeholder {"{nama} {hp} {kerusakan} {diagnosa} {biaya_jasa} {total} {suku_cadang} {status} {toko} {telepon_toko}"} diganti otomatis.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <Label htmlFor="wa-template">Template Pesan</Label>
            <Textarea
              id="wa-template"
              value={template}
              onChange={(e) => setTemplate(e.target.value)}
              rows={5}
              className="text-[13px]"
            />
          </div>
          <div className="space-y-1">
            <Label>Preview Pesan</Label>
            <div className="max-h-44 overflow-y-auto whitespace-pre-wrap rounded-xl border bg-[#dcf8c6] p-3 text-[13px] leading-relaxed">
              {preview}
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {repair.customerPhone.trim() ? (
              <Button type="button" className="flex-1 bg-[#25D366] text-white hover:bg-[#1eb856]" asChild>
                <a href={waLink(repair.customerPhone, preview)} target="_blank" rel="noopener noreferrer">
                  <Send className="size-4" aria-hidden /> Kirim WhatsApp
                </a>
              </Button>
            ) : (
              // D52: pelanggan tanpa nomor WA — kirim dinonaktifkan (wa.me tanpa nomor rusak)
              <Button type="button" variant="outline" disabled className="flex-1">
                <Send className="size-4" aria-hidden /> Nomor WA belum diisi
              </Button>
            )}
            <Button type="button" variant="outline" onClick={simpanTemplate} disabled={saving}>
              <Save className="size-4" aria-hidden /> Simpan Template
            </Button>
            <Button
              type="button"
              variant="ghost"
              onClick={() => setTemplate(getWaTemplate(repair.status, null))}
            >
              Reset Default
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function parseWaTemplatesSafe(json: string): Record<string, string> {
  try {
    const parsed = JSON.parse(json);
    return parsed && typeof parsed === "object" ? (parsed as Record<string, string>) : {};
  } catch {
    return {};
  }
}

// ============================================================
// DiagnosaSentWaDialog (D21) — alur DIAGNOSA → KONFIRMASI: setelah tombol "Simpan"
// pada dialog diagnosa sukses, dialog ini muncul otomatis — konfirmasi hasil
// diagnosa & estimasi biaya + tombol Kirim WhatsApp ke pelanggan (template
// status KONFIRMASI; pesan bisa diedit per pengiriman tanpa mengubah template).
// D24: dipakai juga untuk VOID diagnosa — bila tiket berstatus TIDAK_BISA,
// template & judul beradaptasi ("Servis Di-void") agar pelanggan diinformasikan.
// ============================================================
export function DiagnosaSentWaDialog({
  repair,
  waMap,
  open,
  onOpenChange,
  shop,
}: {
  repair: Repair;
  waMap: Record<string, string>;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  // Tahap 7.1: profil toko untuk placeholder {toko}/{telepon_toko}
  shop?: { name: string; phone: string };
}) {
  const { toast } = useToast();
  const parts = parseUsedParts(repair.usedPartsJson);
  // D28: part pesanan (belum tersedia) — masuk pesan WA & ringkasan estimasi
  const reqPending = pendingRequestedParts(repair.requestedPartsJson);
  // D24: KONFIRMASI (simpan diagnosa) atau TIDAK_BISA (void diagnosa)
  const statusKey = repair.status === "TIDAK_BISA" ? "TIDAK_BISA" : "KONFIRMASI";
  const isVoid = statusKey === "TIDAK_BISA";

  // Pesan awal dari template status terkait (placeholder diganti otomatis)
  const [pesan, setPesan] = useState(() =>
    formatWaMessage(
      statusKey,
      waMap,
      {
        customerName: repair.customerName,
        deviceModel: repair.deviceModel,
        damageDescription: repair.damageDescription,
        status: statusKey,
        notes: repair.notes,
        serviceFee: repair.serviceFee,
        totalPrice: repair.totalPrice,
        usedPartsJson: repair.usedPartsJson,
      },
      REPAIR_STATUS_LABEL[statusKey],
      formatCurrency,
      parseRequestedParts(repair.requestedPartsJson), // D28: daftar part akan dipesan
      shop
    )
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-2xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {isVoid ? "Servis Di-void — Kirim WA ke Pelanggan" : "Diagnosa Tersimpan — Kirim WA ke Pelanggan"}
          </DialogTitle>
          <DialogDescription>
            {isVoid
              ? "Tiket berstatus Tidak Bisa (void). Beri tahu pelanggan bahwa unit tidak dapat dilanjutkan via WhatsApp."
              : "Tiket lanjut ke status Konfirmasi. Periksa ringkasan lalu kirim estimasi biaya via WhatsApp."}
          </DialogDescription>
        </DialogHeader>

        {/* Konfirmasi ringkasan hasil diagnosa yang baru disimpan */}
        <div className="space-y-1 rounded-xl border p-3 text-[13px]">
          <div className="flex justify-between gap-3">
            <span className="shrink-0 text-muted-foreground">Pelanggan</span>
            <b className="min-w-0 truncate text-right">{repair.customerName}</b>
          </div>
          <div className="flex justify-between gap-3">
            <span className="shrink-0 text-muted-foreground">No. WhatsApp</span>
            <b className="font-mono">{repair.customerPhone || "—"}</b>
          </div>
          <div className="flex justify-between gap-3">
            <span className="shrink-0 text-muted-foreground">Hasil Diagnosa</span>
            <b className="min-w-0 truncate text-right" title={repair.notes}>
              {repair.notes || "-"}
            </b>
          </div>
          <div className="flex justify-between gap-3">
            <span className="shrink-0 text-muted-foreground">Biaya Jasa</span>
            <span className="tabular-nums">{formatCurrency(repair.serviceFee)}</span>
          </div>
          {parts.length > 0 && (
            <div className="flex justify-between gap-3">
              <span className="shrink-0 text-muted-foreground">Sparepart</span>
              <span className="tabular-nums">{parts.length} item</span>
            </div>
          )}
          {reqPending.length > 0 && (
            <div className="flex justify-between gap-3">
              <span className="shrink-0 text-muted-foreground">Part Dipesan</span>
              <span className="tabular-nums">{reqPending.length} item (akan dipesan)</span>
            </div>
          )}
          <div className="flex justify-between gap-3 border-t pt-1 font-bold">
            <span>{isVoid ? "Biaya Jasa / Cek" : "Estimasi Total Biaya"}</span>
            <span className="tabular-nums text-primary">{formatCurrency(repair.totalPrice)}</span>
          </div>
        </div>

        <div className="space-y-1">
          <Label htmlFor="wa-diag-pesan">Pesan WhatsApp (dapat diedit sebelum kirim)</Label>
          <Textarea
            id="wa-diag-pesan"
            value={pesan}
            onChange={(e) => setPesan(e.target.value)}
            rows={6}
            className="text-[13px]"
          />
        </div>

        <div className="flex gap-2">
          <Button type="button" variant="ghost" className="flex-1" onClick={() => onOpenChange(false)}>
            Lewati
          </Button>
          {repair.customerPhone.trim() ? (
            <Button type="button" className="flex-[2] bg-[#25D366] text-white hover:bg-[#1eb856]" asChild>
              <a
                href={waLink(repair.customerPhone, pesan)}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  toast({
                    title: "WhatsApp dibuka di tab baru",
                    description: `Pesan estimasi untuk ${repair.customerName} siap dikirim.`,
                  });
                  onOpenChange(false);
                }}
              >
                <Send className="size-4" aria-hidden /> Kirim WhatsApp
              </a>
            </Button>
          ) : (
            // D52: pelanggan tanpa nomor WA — kirim dinonaktifkan
            <Button type="button" variant="outline" disabled className="flex-[2]">
              <Send className="size-4" aria-hidden /> Nomor WA belum diisi
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================
// RepairReceiptDialog.kt — STRUK TERIMA BARANG / TANDA TERIMA SERVIS (cetak A5)
// D21: mode "Nota Pelunasan" DIHAPUS — pelunasan hanya bisa dibuat di Kasir
// (struk transaksi 58mm saat checkout). Tombol Unduh JPG & Bagikan ditambah
// (sama dengan struk kasir D13/D14; JPG dirender dari node #nota-servis-print).
// ============================================================
export function RepairReceiptDialog({
  repair,
  settings,
  cashierName,
  waMap,
  open,
  onOpenChange,
}: {
  repair: Repair;
  settings: { shopName: string; address: string; phone: string; receiptFooter: string };
  cashierName: string;
  waMap: Record<string, string>;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const { toast } = useToast();
  const mode = "tanda_terima" as const;
  const [sharingJpg, setSharingJpg] = useState(false);
  // D14: tombol Bagikan hanya tampil bila browser mendukung share FILE (umumnya HP);
  // deteksi sekali saat mount agar tidak terjadi hydration mismatch.
  const [canShareFiles, setCanShareFiles] = useState(false);
  useEffect(() => {
    try {
      const probe = new File([new Blob([""])], "probe.jpg", { type: "image/jpeg" });
      setCanShareFiles(typeof navigator.share === "function" && !!navigator.canShare?.({ files: [probe] }));
    } catch {
      setCanShareFiles(false);
    }
  }, []);

  // D26: tautan lacak servis online + QR-nya — dicetak di struk terima barang.
  // Origin dihitung di client (useEffect) agar tidak terjadi hydration mismatch;
  // QR dirender lokal via paket qrcode (tanpa layanan eksternal, tetap jalan offline).
  const [trackingUrl, setTrackingUrl] = useState("");
  const [qrDataUrl, setQrDataUrl] = useState("");
  useEffect(() => {
    const url = `${window.location.origin}/track?id=${serviceIdOf(repair.createdAt)}`;
    setTrackingUrl(url);
    let alive = true;
    QRCode.toDataURL(url, { margin: 1, width: 216 })
      .then((d) => {
        if (alive) setQrDataUrl(d);
      })
      .catch(() => {
        if (alive) setQrDataUrl("");
      });
    return () => {
      alive = false;
    };
  }, [repair.createdAt]);

  const textMsg = buildRepairReceiptText(repair, mode, settings, cashierName, trackingUrl);

  async function renderNotaJpg(): Promise<string> {
    const node = document.getElementById("nota-servis-print");
    if (!node) throw new Error("Lembar nota tidak ditemukan");
    return toJpeg(node, {
      quality: 0.95,
      backgroundColor: "#ffffff",
      pixelRatio: 3,
      width: node.clientWidth + 24,
      style: { padding: "0 12px" },
    });
  }

  const salinTeks = async () => {
    try {
      await navigator.clipboard.writeText(textMsg);
      toast({ title: "Teks nota disalin", description: "Tempel di WhatsApp/SMS bila perlu." });
    } catch {
      toast({ title: "Gagal menyalin teks", variant: "destructive" });
    }
  };

  async function handleUnduhNotaJpg() {
    if (sharingJpg) return;
    setSharingJpg(true);
    const namaFile = `tanda-terima-servis-${repair.id}.jpg`;
    try {
      unduhDataUrl(await renderNotaJpg(), namaFile);
      toast({
        title: "Tanda terima JPG diunduh",
        description: "Bagikan file dari folder Unduhan/Galeri ke pelanggan (WhatsApp, dsb.).",
      });
    } catch (e) {
      console.error("gagal render nota jpg:", e);
      toast({ title: e instanceof Error ? e.message : "Gagal membuat JPG nota", variant: "destructive" });
    } finally {
      setSharingJpg(false);
    }
  }

  async function handleBagikanNotaJpg() {
    if (sharingJpg) return;
    setSharingJpg(true);
    const namaFile = `tanda-terima-servis-${repair.id}.jpg`;
    try {
      const dataUrl = await renderNotaJpg();
      const file = dataUrlToFile(dataUrl, namaFile);
      if (file && typeof navigator.share === "function" && navigator.canShare?.({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: `Tanda Terima Servis #${repair.id}`,
          text: `Tanda terima servis ${repair.customerName} - ${settings.shopName}`,
        });
        toast({ title: "Tanda terima dibagikan" });
      } else {
        // Tidak mendukung share file → jatuh ke unduh supaya aksi tetap berhasil
        unduhDataUrl(dataUrl, namaFile);
        toast({
          title: "Bagikan tidak tersedia — JPG diunduh",
          description: "Bagikan file dari folder Unduhan/Galeri ke pelanggan (WhatsApp, dsb.).",
        });
      }
    } catch (e) {
      // User menutup lembar bagikan bawaan → bukan error
      if (e instanceof DOMException && e.name === "AbortError") return;
      console.error("gagal membagikan nota jpg:", e);
      toast({ title: "Gagal membagikan nota", variant: "destructive" });
    } finally {
      setSharingJpg(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-2xl sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Tanda Terima Servis (A5)</DialogTitle>
          <DialogDescription>
            Struk terima barang saat unit diterima. Struk pelunasan hanya dibuat di Kasir saat pembayaran.
          </DialogDescription>
        </DialogHeader>

        {/* Preview lembar A5 — node ini yang dicetak (#nota-servis-print) */}
        <NotaSheet
          repair={repair}
          mode={mode}
          settings={settings}
          cashierName={cashierName}
          trackingUrl={trackingUrl}
          qrDataUrl={qrDataUrl}
        />

        <div className="grid grid-cols-2 gap-2">
          <Button
            type="button"
            onClick={() => cetakNode("nota-servis-print", "print-nota")}
            disabled={sharingJpg}
          >
            <Printer className="size-4" aria-hidden /> Cetak A5
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => void handleUnduhNotaJpg()}
            disabled={sharingJpg}
          >
            <Download className="size-4" aria-hidden /> {sharingJpg ? "Menyiapkan..." : "Unduh JPG"}
          </Button>
          {canShareFiles && (
            <Button
              type="button"
              variant="outline"
              onClick={() => void handleBagikanNotaJpg()}
              disabled={sharingJpg}
            >
              <Share2 className="size-4" aria-hidden /> Bagikan
            </Button>
          )}
          <Button type="button" variant="outline" onClick={salinTeks}>
            <Copy className="size-4" aria-hidden /> Salin Teks
          </Button>
          {repair.customerPhone.trim() ? (
            <Button type="button" variant="outline" className="bg-[#25D366] text-white hover:bg-[#1eb856]" asChild>
              <a href={waLink(repair.customerPhone, textMsg)} target="_blank" rel="noopener noreferrer">
                <Send className="size-4" aria-hidden /> Teks WA
              </a>
            </Button>
          ) : (
            // D52: pelanggan tanpa nomor WA — kirim dinonaktifkan
            <Button type="button" variant="outline" disabled>
              <Send className="size-4" aria-hidden /> Nomor WA belum diisi
            </Button>
          )}
          <Button type="button" variant="secondary" onClick={() => onOpenChange(false)}>
            <X className="size-4" aria-hidden /> Tutup
          </Button>
        </div>
        {/* info template WA tersimpan di DB — status label untuk editor */}
        <p className="sr-only">{getWaTemplate(repair.status, waMap).slice(0, 0)}</p>
      </DialogContent>
    </Dialog>
  );
}

// Lembar A5 visual — layout dokumen servis profesional
function NotaSheet({
  repair,
  mode,
  settings,
  cashierName,
  trackingUrl,
  qrDataUrl,
}: {
  repair: Repair;
  mode: "tanda_terima" | "nota";
  settings: { shopName: string; address: string; phone: string; receiptFooter: string };
  cashierName: string;
  trackingUrl: string; // D26: link lacak online (dicetak di struk terima barang)
  qrDataUrl: string; // D26: QR code dari link lacak
}) {
  const parts = parseUsedParts(repair.usedPartsJson);
  const partsSum = partsSumOf(parts);
  return (
    <div
      id="nota-servis-print"
      className="mx-auto w-full max-w-[148mm] rounded-lg border bg-white p-5 text-[12px] leading-relaxed text-black shadow-sm print:max-w-none print:rounded-none print:border-0 print:shadow-none"
    >
      <div className="text-center">
        <p className="text-base font-black uppercase tracking-wide">{settings.shopName}</p>
        {settings.address && <p className="text-[11px] text-gray-700">{settings.address}</p>}
        <p className="text-[11px] text-gray-700">Telp/WA: {settings.phone || "-"}</p>
      </div>
      <div className="my-2.5 border-t-2 border-dashed border-gray-400" />
      <p className="text-center text-[13px] font-black underline underline-offset-2">
        {mode === "tanda_terima" ? "TANDA TERIMA SERVIS" : "NOTA PELUNASAN SERVIS"}
      </p>
      <div className="mt-2 grid grid-cols-2 gap-x-4 gap-y-0.5">
        <p>No Servis: <b>#{repair.id}</b></p>
        {mode === "tanda_terima" ? (
          <p className="text-right">Tgl Masuk: {formatDate(repair.createdAt)}</p>
        ) : (
          <>
            <p>Tgl Masuk: {formatDate(repair.createdAt)}</p>
            <p className="text-right">Tgl Keluar: {formatDate(repair.updatedAt)}</p>
          </>
        )}
        <p>Dibuat Oleh: {cashierName}</p>
        <p className="text-right">Teknisi: {repair.technicianName ?? "-"}</p>
      </div>

      <div className="my-2.5 border-t-2 border-dashed border-gray-400" />
      <p className="text-[11px] font-black">PELANGGAN</p>
      <div className="mt-1 grid grid-cols-2 gap-x-4">
        <p>Nama: <b>{repair.customerName}</b></p>
        <p className="text-right">Telp/WA: <span className="font-mono">{repair.customerPhone}</span></p>
      </div>

      <div className="my-2.5 border-t-2 border-dashed border-gray-400" />
      <p className="text-[11px] font-black">{mode === "tanda_terima" ? "PERANGKAT & KELUHAN" : "PERANGKAT"}</p>
      <div className="mt-1 grid grid-cols-2 gap-x-4">
        <p>Model HP: <b>{repair.deviceModel}</b></p>
        <p className="text-right">S/N / IMEI: {repair.serialOrImei || "-"}</p>
      </div>
      {mode === "tanda_terima" && (
        <p className="mt-0.5">Kerusakan: {repair.damageDescription}</p>
      )}

      {mode === "tanda_terima" ? (
        <>
          <div className="my-2.5 border-t-2 border-dashed border-gray-400" />
          <p className="text-[11px] font-black">ESTIMASI BIAYA &amp; DP</p>
          <div className="mt-1 space-y-0.5">
            <div className="flex justify-between"><span>Est. Biaya:</span><span>{formatCurrency(repair.estimatedCost ?? 0)}</span></div>
            <div className="flex justify-between"><span>Uang Muka (DP):</span><span>{formatCurrency(repair.downPayment ?? 0)}</span></div>
            <div className="flex justify-between text-[13px] font-black">
              <span>Sisa Bayar:</span>
              <span className="text-emerald-700">{formatCurrency(notaSisaBayar(repair))}</span>
            </div>
          </div>
          {/* D26: blok lacak servis online — QR + tautan (pelanggan scan untuk pantau progres) */}
          <div className="my-2.5 border-t-2 border-dashed border-gray-400" />
          <p className="text-[11px] font-black">LACAK SERVIS ONLINE</p>
          <div className="mt-1 flex items-center gap-3">
            {qrDataUrl && (
              <img src={qrDataUrl} alt="QR Lacak Servis" className="h-[72px] w-[72px] shrink-0" />
            )}
            <div className="min-w-0 text-[10.5px] leading-snug text-gray-700">
              <p>Pantau progres perbaikan secara online — scan QR di samping atau buka tautan berikut:</p>
              <p className="mt-0.5 break-all font-mono text-black">{trackingUrl}</p>
              <p className="mt-0.5 text-gray-600">Kode: {trackingUrl.split("id=")[1] ?? ""}</p>
            </div>
          </div>
          <div className="my-2.5 border-t-2 border-dashed border-gray-400" />
          <div className="mt-6 grid grid-cols-2 gap-8 text-center">
            <div>
              <p className="border-b border-gray-500" />
              <p className="mt-1 text-[11px] text-gray-600">( Pelanggan )</p>
            </div>
            <div>
              <p className="border-b border-gray-500" />
              <p className="mt-1 text-[11px] text-gray-600">( {cashierName} )</p>
            </div>
          </div>
          <p className="mt-4 text-center text-[11px] font-bold">Harap bawa tanda terima ini saat mengambil HP.</p>
        </>
      ) : (
        <>
          <div className="my-2.5 border-t-2 border-dashed border-gray-400" />
          <p className="text-[11px] font-black">RINCIAN BIAYA</p>
          <div className="mt-1 space-y-0.5">
            <div className="flex justify-between"><span>- Jasa Servis:</span><span>{formatCurrency(repair.serviceFee)}</span></div>
            {parts.map((p, i) => (
              <div key={i} className="flex justify-between">
                {/* D23 (D18/D19): nota memakai Nama di Struk (alias) bila diisi */}
                <span>- {p.alias?.trim() || p.name} ({p.qty}x):</span>
                <span>{formatCurrency(p.sellPrice * p.qty)}</span>
              </div>
            ))}
            <div className="flex justify-between border-t border-gray-300 pt-1"><span>Subtotal:</span><span>{formatCurrency(repair.serviceFee + partsSum)}</span></div>
            <div className="flex justify-between"><span>DP / Uang Muka:</span><span>- {formatCurrency(repair.downPayment ?? 0)}</span></div>
            <div className="flex justify-between text-[13px] font-black">
              <span>TOTAL PELUNASAN:</span>
              <span>{formatCurrency(notaTotalPelunasan(repair))}</span>
            </div>
            <div className="flex justify-between"><span>Status:</span><b>LUNAS</b></div>
          </div>
          <p className="mt-3 text-center text-[11px]">{settings.receiptFooter}</p>
          <p className="text-center text-[11px] font-bold">
            {repair.warrantyDays === 0 ? "Tanpa Garansi." : `Garansi servis ${repair.warrantyDays} hari.`}
          </p>
        </>
      )}
    </div>
  );
}

// ============================================================
// PriceEstimationDialog.kt — "Cek Estimasi" (estimator harga FixMaster)
// ============================================================
export function PriceEstimationDialog({
  repairs,
  parts,
  open,
  onOpenChange,
}: {
  repairs: Repair[];
  parts: SparePartLite[];
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [brand, setBrand] = useState("");
  const [kasus, setKasus] = useState("Ganti LCD");
  const [manualHpp, setManualHpp] = useState("");
  const [selectedLcdPrice, setSelectedLcdPrice] = useState<number | null>(null);

  const modelOptions = useMemo(() => {
    const fromDb = repairs.map((r) => r.deviceModel).filter((m) => m.trim() !== "");
    return Array.from(new Set([...fromDb, ...STANDARD_BRANDS]));
  }, [repairs]);
  const kasusOptions = useMemo(() => {
    const fromDb = repairs.map((r) => r.damageDescription).filter((d) => d.trim() !== "");
    return Array.from(new Set([...fromDb, ...STANDARD_CASES]));
  }, [repairs]);

  const isLcd = kasus.toLowerCase().includes("lcd");

  // LCD di stok: cocokkan kata pada nama part (abaikan kata umum, persis referensi)
  const matchingLcdParts = useMemo(() => {
    if (!isLcd || !brand.trim()) return [];
    const tokens = brand
      .toLowerCase()
      .split(/\s+/)
      .filter((t) => t.length > 1 && !["hp", "ganti", "service", "servis"].includes(t));
    return parts.filter((p) => {
      const name = `${p.name} ${p.sku}`.toLowerCase();
      return tokens.some((t) => name.includes(t));
    });
  }, [brand, isLcd, parts]);

  const hppManual = Number(manualHpp) || 0;
  const hargaJualLcd = selectedLcdPrice ?? (hppManual > 0 ? hppManual * 1.8 : 0); // markup toko 80%
  const JASA_PASANG = 75000; // persis referensi (jasaPasang)
  const totalLcd = hargaJualLcd > 0 ? hargaJualLcd + JASA_PASANG : 0;

  // Referensi history kasus serupa: tiket lama dengan kerusakan mengandung kata kunci
  const matchingHistory = useMemo(() => {
    if (!kasus.trim()) return [];
    const kata = kasus.toLowerCase().split(/\s+/).filter((t) => t.length > 3);
    return repairs.filter((r) => {
      const d = r.damageDescription.toLowerCase();
      return kata.some((t) => d.includes(t));
    });
  }, [kasus, repairs]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto rounded-2xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calculator className="size-5 text-primary" aria-hidden /> Estimator Harga Servis
          </DialogTitle>
          <DialogDescription>
            Perkiraan biaya berdasarkan stok, kasus serupa, dan tingkat kesulitan.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1">
            <Label htmlFor="est-model">Tipe HP</Label>
            <Input
              id="est-model"
              value={brand}
              onChange={(e) => setBrand(e.target.value)}
              placeholder="Ketik tipe HP..."
              list="est-model-options"
            />
            <datalist id="est-model-options">
              {modelOptions.slice(0, 20).map((m) => (
                <option key={m} value={m} />
              ))}
            </datalist>
          </div>
          <div className="space-y-1">
            <Label htmlFor="est-kasus">Kasus / Kerusakan</Label>
            <Input
              id="est-kasus"
              value={kasus}
              onChange={(e) => setKasus(e.target.value)}
              placeholder="Ketik kerusakan..."
              list="est-kasus-options"
            />
            <datalist id="est-kasus-options">
              {kasusOptions.slice(0, 20).map((m) => (
                <option key={m} value={m} />
              ))}
            </datalist>
          </div>

          {isLcd && (
            <div className="space-y-2 rounded-xl border bg-muted/40 p-3">
              <p className="text-[12px] font-black text-primary">Estimator Khusus Ganti LCD</p>
              {matchingLcdParts.length > 0 ? (
                <>
                  <p className="text-[11px] text-muted-foreground">
                    Ditemukan {matchingLcdParts.length} sparepart LCD di stok untuk &quot;{brand}&quot;:
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    {matchingLcdParts.slice(0, 4).map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => setSelectedLcdPrice(p.sellPrice)}
                        className={cn(
                          "rounded-lg border p-2 text-left text-[11px] transition-colors",
                          selectedLcdPrice === p.sellPrice
                            ? "border-primary bg-primary/10"
                            : "hover:bg-background"
                        )}
                      >
                        {selectedLcdPrice === p.sellPrice && (
                          <Check className="mb-0.5 size-3 text-primary" aria-hidden />
                        )}
                        <span className="block truncate font-bold">{p.name}</span>
                        <span className="font-bold tabular-nums text-primary">{formatCurrency(p.sellPrice)}</span>
                      </button>
                    ))}
                  </div>
                </>
              ) : (
                <p className="text-[11px] text-amber-700">
                  Sparepart LCD untuk &quot;{brand || "-"}&quot; tidak ditemukan di stok. Ketik HPP manual:
                </p>
              )}
              <div className="space-y-1">
                <Label htmlFor="est-hpp">HPP LCD Manual (Rp)</Label>
                <Input
                  id="est-hpp"
                  value={manualHpp}
                  onChange={(e) => setManualHpp(e.target.value.replace(/\D/g, ""))}
                  placeholder="Misal: 150000"
                  inputMode="numeric"
                />
              </div>
              {totalLcd > 0 && (
                <div className="space-y-1 rounded-lg bg-primary p-3 text-white">
                  <p className="text-[11px] opacity-80">Total Estimasi Biaya Servis — {brand || "-"}</p>
                  <p className="text-xl font-black tabular-nums">{formatCurrency(totalLcd)}</p>
                </div>
              )}
            </div>
          )}

          <div className="space-y-2 rounded-xl border p-3">
            <p className="text-[12px] font-black">Referensi History Kasus Serupa</p>
            {matchingHistory.length === 0 ? (
              <div className="space-y-1 text-[11px] text-muted-foreground">
                <p>Belum ada rekam kasus serupa di database. Perkiraan standar per tingkat kesulitan:</p>
                <div className="flex justify-between"><span>Kesulitan Rendah (Baterai/Charger):</span><b>Rp 50.000 - Rp 150.000</b></div>
                <div className="flex justify-between"><span>Kesulitan Sedang (LCD/Backglass):</span><b>Rp 150.000 - Rp 350.000</b></div>
                <div className="flex justify-between"><span>Kesulitan Tinggi (Mati Total/IC):</span><b>Rp 350.000 - Rp 750.000+</b></div>
              </div>
            ) : (
              <div className="max-h-40 space-y-1 overflow-y-auto">
                {matchingHistory.slice(0, 6).map((r) => (
                  <div key={r.id} className="flex items-center justify-between gap-2 text-[11px]">
                    <span className="min-w-0 truncate">{r.deviceModel} — {r.damageDescription}</span>
                    <b className="shrink-0 tabular-nums">{formatCurrency(r.totalPrice)}</b>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
