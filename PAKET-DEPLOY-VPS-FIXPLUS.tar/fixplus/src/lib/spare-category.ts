// D48/5C-1 — kategori barang & penurunan kategori item untuk laporan 4 jalur
// pendapatan (referensi "Karakteristik bisnis konter servis HP").
// Kategori disimpan di SparePart.category dan DISNAPSHOT ke itemsJson saat
// checkout (5C-1.3) agar laporan tidak berubah saat katalog diedit belakangan.
// Item lama tanpa snapshot kategori diturunkan otomatis oleh deriveItemCategory()
// (server, saat laporan dibaca) — laporan tetap benar untuk data lama.

export const SPARE_CATEGORIES = ["SPAREPART", "AKSESORIS", "PERANGKAT", "LAINNYA"] as const;
export type SpareCategory = (typeof SPARE_CATEGORIES)[number];

export const SPARE_CATEGORY_LABEL: Record<string, string> = {
  SPAREPART: "Sparepart",
  AKSESORIS: "Aksesoris",
  PERANGKAT: "Perangkat",
  LAINNYA: "Lainnya",
  // kategori item (bukan kategori katalog) — dipakai di laporan penjualan
  JASA_SERVIS: "Jasa Servis",
};

/** Kategori katalog valid? (kategori luar duga → SPAREPART) */
export function spareCategoryOf(v: unknown): SpareCategory {
  const s = String(v ?? "").trim();
  return (SPARE_CATEGORIES as readonly string[]).includes(s) ? (s as SpareCategory) : "SPAREPART";
}

type ItemLite = {
  itemType?: string;
  category?: string;
  partId?: number;
  name?: string;
  alias?: string | null;
};

type PartLite = { id: number; name: string; alias: string | null; category: string };

/**
 * Turunkan kategori sebuah item struk (itemsJson) untuk laporan penjualan.
 * - snapshot `category` (data baru) langsung dipakai;
 * - jasa → JASA_SERVIS; biaya lain → LAINNYA;
 * - part tiket lama tanpa snapshot → cocokkan katalog lewat partId, lalu
 *   name/alias (strip prefiks "Sparepart: "); ambigu/kosong → SPAREPART;
 * - part toko lain (external) → SPAREPART (jalur pendapatan sparepart).
 */
export function deriveItemCategory(
  item: ItemLite,
  partById?: Map<number, PartLite>,
  partByKey?: Map<string, PartLite>
): string {
  const t = String(item.itemType ?? "");
  if (item.category && item.category !== "SPAREPART") return item.category;
  if (t === "service") return "JASA_SERVIS";
  if (t === "other") return "LAINNYA";
  if (t === "external_sparepart") return "SPAREPART";
  // snapshot SPAREPART (default) tetap boleh dipertajam lewat katalog (data lama)
  if (item.partId && partById?.get(item.partId)) return partById.get(item.partId)!.category;
  if (partByKey) {
    const rawName = String(item.name ?? "");
    const bare = rawName.replace(/^Sparepart:\s*/i, "").trim().toLowerCase();
    const alias = String(item.alias ?? "").trim().toLowerCase();
    const keys = [alias, bare].filter((k) => k !== "");
    const matches = new Set<string>();
    for (const k of keys) {
      const p = partByKey.get(k);
      if (p) matches.add(p.category);
    }
    if (matches.size === 1) return [...matches][0];
  }
  return item.category && item.category !== "" ? item.category : "SPAREPART";
}
