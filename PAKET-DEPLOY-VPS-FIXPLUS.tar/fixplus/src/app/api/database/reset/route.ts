import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { resetTables, BACKUP_ENTITIES, ENTITY_LABEL, type BackupEntity } from "@/lib/db-backup";
import { db } from "@/lib/db";

// D40 — POST /api/database/reset (parity "3. Reset Database" referensi)
// Body: { requesterUsername, tables: [...] } — hapus permanen seluruh baris
// tabel terpilih. Akun yang mengeksekusi SELALU dipertahankan (persis referensi:
// "Reset Semua Pengguna (Kecuali Admin saat ini)").
// Admin-only (D34) + wajib audit — tindakan destruktif dicatat siapa & kapan.
export async function POST(req: NextRequest) {
  let body: { requesterUsername?: string; tables?: string[] };
  try {
    body = await req.json();
  } catch {
    return errAction("Body JSON tidak valid", 400);
  }

  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const valid = new Set(BACKUP_ENTITIES.map((e) => e.key));
  const tables = Array.isArray(body.tables)
    ? (body.tables.filter((t): t is BackupEntity => valid.has(t as BackupEntity)))
    : [];
  if (!tables.length) {
    return errAction("Pilih minimal satu tabel yang akan direset", 400);
  }

  try {
    const deleted = await resetTables(tables, actor.id);
    const summary = tables
      .map((t) => `${ENTITY_LABEL(t)}: ${deleted[t] ?? 0} baris dihapus`)
      .join("; ");
    await db.auditLog.create({
      data: {
        action: "RESET_DATABASE",
        details: `Reset tabel — ${summary}`,
        performedBy: actor.name,
      },
    });
    return NextResponse.json({ deleted, summary });
  } catch (e) {
    console.error("database reset error", e);
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Gagal mereset database" },
      { status: 500 }
    );
  }
}
