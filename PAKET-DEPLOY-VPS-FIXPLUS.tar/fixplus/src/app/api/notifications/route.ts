import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { db } from "@/lib/db";

// D81 — PUSAT NOTIFIKASI APLIKASI (panel lonceng di header).
//
// GET  /api/notifications?requesterUsername=... — daftar notifikasi terbaru
//      (maks 50) + jumlah belum dibaca.
// POST /api/notifications — aksi kelola riwayat:
//      { action: "read", ids: [1,2,...] }  — tandai sudah dibaca
//      { action: "readAll" }               — tandai SEMUA dibaca
//      { action: "delete", ids: [1,2,...] } — hapus notifikasi terpilih (D83)
//      { action: "deleteAll" }              — hapus SEMUA riwayat (D83)
//
// Hanya Admin: seluruh notifikasi saat ini menyangkut backup/pulihkan GitHub
// (aksi Admin) — guardnya server-side (UI bukan satu-satunya penjaga).
// Struktur dirancang ekstensibel: fitur lain cukup push type baru lewat
// pushNotification() (src/lib/notifications.ts) dan panel sudah menampilkannya.

const LIMIT = 50;

function safeParseMeta(s: string): Record<string, unknown> {
  try {
    const v = JSON.parse(s);
    return v && typeof v === "object" && !Array.isArray(v) ? v : {};
  } catch {
    return {};
  }
}

async function unreadCount(): Promise<number> {
  return db.appNotification.count({ where: { readAt: null } });
}

export async function GET(req: NextRequest) {
  const actor = await resolveActor(req.nextUrl.searchParams.get("requesterUsername"));
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);
  try {
    const [items, unread] = await Promise.all([
      db.appNotification.findMany({
        orderBy: [{ createdAt: "desc" }, { id: "desc" }],
        take: LIMIT,
      }),
      unreadCount(),
    ]);
    return NextResponse.json({
      items: items.map((n) => ({
        id: n.id,
        type: n.type,
        title: n.title,
        message: n.message,
        meta: safeParseMeta(n.metaJson),
        readAt: n.readAt,
        createdAt: n.createdAt,
      })),
      unreadCount: unread,
    });
  } catch (e) {
    console.error("notifications GET error", e);
    return NextResponse.json({ error: "Gagal membaca notifikasi" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as {
    requesterUsername?: unknown;
    action?: unknown;
    ids?: unknown;
  };
  const actor = await resolveActor(body.requesterUsername);
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);
  const action = String(body.action ?? "");
  // D83 — penerimaan ids yang aman dipakai read & delete sekaligus.
  const idsList = (): number[] =>
    Array.isArray(body.ids)
      ? body.ids.map(Number).filter((n) => Number.isInteger(n) && n > 0)
      : [];
  try {
    if (action === "read") {
      const ids = idsList();
      if (ids.length) {
        await db.appNotification.updateMany({
          where: { id: { in: ids }, readAt: null },
          data: { readAt: new Date() },
        });
      }
    } else if (action === "readAll") {
      await db.appNotification.updateMany({
        where: { readAt: null },
        data: { readAt: new Date() },
      });
    } else if (action === "delete") {
      // D83 — hapus notifikasi terpilih (mendukung beberapa id sekaligus).
      const ids = idsList();
      if (!ids.length) return errAction("Tidak ada notifikasi yang dipilih untuk dihapus", 400);
      const del = await db.appNotification.deleteMany({ where: { id: { in: ids } } });
      return NextResponse.json({ ok: true, deleted: del.count, unreadCount: await unreadCount() });
    } else if (action === "deleteAll") {
      // D83 — kosongkan seluruh riwayat (dipakai tombol "Hapus semua" di panel;
      // UI meminta konfirmasi dua-langkah sebelum mengirim aksi ini).
      const del = await db.appNotification.deleteMany({});
      return NextResponse.json({ ok: true, deleted: del.count, unreadCount: 0 });
    } else {
      return errAction(
        "Aksi tidak dikenal — gunakan 'read', 'readAll', 'delete', atau 'deleteAll'",
        400
      );
    }
    return NextResponse.json({ ok: true, unreadCount: await unreadCount() });
  } catch (e) {
    console.error("notifications POST error", e);
    return NextResponse.json({ error: "Gagal memperbarui notifikasi" }, { status: 500 });
  }
}
