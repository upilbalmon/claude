// D43/D53/D55 — Mesin pulihkan database SQLite (GANTI SELURUH DATABASE).
// Diekstrak dari route /api/database/restore-db agar bisa dipakai dua sumber
// dengan prosedur yang PERSIS sama: (1) unggahan file .db manual, (2) pulihkan
// dari Google Drive (/api/gdrive/restore). Route asli kini hanya pembungkus.
//
// Prosedur aman (runtime-agnostic — dev Node & produksi bun sama-sama aman,
// tanpa driver sqlite eksternal):
//   1. Validasi: ukuran + magic bytes "SQLite format 3\0"
//   2. wal_checkpoint(TRUNCATE) — WAL dituangkan ke file utama
//   3. db.$disconnect() — tutup semua koneksi Prisma
//   4. DB lama dipindah jadi salinan keamanan  <db>.pra-restore-<stamp>.bak
//   5. -wal/-shm lama dibuang (mencegah recovery menulis isi lama ke file baru)
//   6. File ditulis ke tmp lalu direname atomik ke posisi db
//   7. Verifikasi struktur via Prisma (koneksi baru ke file baru): tabel wajib ada
//   8. Gagal di langkah mana pun setelah pindah → ROLLBACK otomatis
//   9. Sukses → audit RESTORE_DATABASE_DB di database baru + cek akun sesi
//
// D55 — kebijakan: kolom hilang = TERIMA lalu DISEMBUHKAN otomatis (ensureSchema)
// sehingga file versi lama bisa dipulihkan.
// D82 — REVISI untuk TABEL: dulu "tabel hilang = TOLAK" (kecuali daftar
// HEALABLE) — akibatnya cadangan lama pranambah-tabel baru DITOLAK saat
// dipulihkan (laporan pemilik: file database-fixplus-2026-11-16-1553.db
// tak bisa dipulihkan karena tabel AppNotification baru ada di D81).
// Kini dibalik: cukup TABEL WAJIB yang harus ada di file; tabel DI LUAR daftar
// (AppMeta D74, AppNotification D81, dan tabel teknis/tabel baru masa depan)
// dibuat otomatis oleh ensureSchema({force:true}) setelah file terpasang —
// cadangan dari versi aplikasi MANAPUN tetap bisa dipulihkan tanpa harus
// menaikkan daftar healable setiap ada fitur baru.
//
// D84 — REVISI KEDUA: daftar wajib D82 masih 12 tabel, termasuk tabel yang
// BARU ada belakangan (ServiceProduct/PreOrder/RequestedItem era awal,
// Attendance D73 14-15 Nov) — akibatnya cadangan SANGAT lama (contoh nyata:
// file database-fixplus-2026-11-12.db yang hanya punya 11 tabel, tanpa
// Attendance) DITOLAK LAGI dengan pesan 'tabel "Attendance" tidak ada di file'
// (laporan pemilik: "masalah pemulihan terulang lagi ... periksa kecocokan
// tabel"). Kini daftar wajib dipersempit ke 6 TABEL INTI BISNIS yang ada
// sejak hari pertama aplikasi: Customer, Technician, SparePart, RepairRecord,
// Transaction, User — sidik jari database FixPlus yang pasti ada di file
// cadangan dari TANGGAL MANAPUN. Semua tabel lain yang belum ada di file
// dibuat otomatis KOSONG oleh ensureSchema({force:true}) dan ringkasan hasil
// pulihkan menyebutkan tabel apa saja yang dibuat agar transparan.
// Validasi "file mungkin bukan database aplikasi ini" tetap terjaga oleh
// magic bytes SQLite + 6 tabel inti tersebut.
import { db } from "@/lib/db";
import { ensureSchema } from "@/lib/db-migrate";
import { rename, writeFile, rm } from "fs/promises";
import { dirname, join } from "path";

let busy = false;
export const isRestoreBusy = () => busy;

class SchemaMismatch extends Error {}
export class RestoreRejected extends Error {}

// Peta skema (tabel → himpunan kolom) dari database yang sedang terhubung.
async function captureSchema(): Promise<Map<string, Set<string>>> {
  const tables = (
    (await db.$queryRawUnsafe<{ name: string }[]>(
      "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    )) ?? []
  ).map((r) => String(r.name));
  const map = new Map<string, Set<string>>();
  for (const t of tables) {
    const cols = (await db.$queryRawUnsafe<{ name: string }[]>(
      `PRAGMA table_info(${JSON.stringify(t)})`
    )) ?? [];
    map.set(t, new Set(cols.map((c) => String(c.name))));
  }
  return map;
}

function diffSchema(expected: Map<string, Set<string>>, actual: Map<string, Set<string>>): {
  tableProblems: string[];
  missingColumns: string[];
} {
  // D84 — tabel WAJIB yang harus ada di file cadangan agar dianggap database
  // FixPlus: 6 tabel inti bisnis yang ada sejak HARI PERTAMA aplikasi. D82
  // sempat mewajibkan 12 tabel termasuk yang baru ada belakangan (Attendance
  // D73, ServiceProduct/PreOrder/RequestedItem era awal) — cadangan pra-D73
  // jadi ditolak lagi (laporan pemilik 16 Nov). Tabel DI LUAR daftar ini
  // (ServiceProduct, PreOrder, RequestedItem, Attendance D73, AuditLog,
  // ShopSettings, AppMeta D74, AppNotification D81, dst. yang datang nanti)
  // hilang di file lama = NORMAL: dibuat otomatis KOSONG oleh
  // ensureSchema({force:true}) segera setelah file terpasang.
  const REQUIRED_TABLES = new Set([
    "Customer",
    "Technician",
    "SparePart",
    "RepairRecord",
    "Transaction",
    "User",
  ]);
  const tableProblems: string[] = [];
  const missingColumns: string[] = [];
  // D82 — hanya tabel WAJIB yang hilang dianggap masalah. Tabel lain yang
  // belum ada di file lama dibiarkan: ensureSchema({force:true}) membuatnya
  // segera setelah file terpasang (lihat performRestoreDb).
  for (const [t, cols] of expected) {
    const a = actual.get(t);
    if (!a) {
      if (REQUIRED_TABLES.has(t)) {
        tableProblems.push(`tabel "${t}" tidak ada di file`);
      }
      continue;
    }
    const missing = [...cols].filter((c) => !a.has(c));
    if (missing.length) missingColumns.push(`${t}: ${missing.join(", ")}`);
  }
  return { tableProblems, missingColumns };
}

export function dbPathFromEnv(): string {
  const url = process.env.DATABASE_URL ?? "";
  return url.startsWith("file:") ? url.slice(5).trim() : "";
}

export function isValidSqliteBuffer(buf: Buffer): boolean {
  const MAGIC = "SQLite format 3\u0000";
  return buf.length >= 512 && buf.subarray(0, 16).equals(Buffer.from(MAGIC, "latin1"));
}

export type RestoreResult =
  | {
      ok: true;
      summary: string;
      counts: { users: number; customers: number; repairs: number; transactions: number };
      healedColumns: string[];
      safetyCopy: string;
      sessionInvalid: boolean;
    }
  | { ok: false; status: number; error: string };

// Jalankan seluruh prosedur pulihkan. fileName hanya untuk pesan/audit.
export async function performRestoreDb(
  buf: Buffer,
  fileName: string,
  actorName: string,
  actorUsername: string,
  fileByteSize?: number
): Promise<RestoreResult> {
  if (busy) {
    return { ok: false, status: 409, error: "Sedang ada proses pulihkan database berjalan. Coba lagi sesaat." };
  }
  busy = true;
  try {
    const size = fileByteSize ?? buf.length;
    if (size === 0 || buf.length === 0) {
      return { ok: false, status: 400, error: "File database (.db) kosong" };
    }
    if (size > 100 * 1024 * 1024) {
      return { ok: false, status: 400, error: "File terlalu besar (maksimal 100 MB)" };
    }
    if (!isValidSqliteBuffer(buf)) {
      return {
        ok: false,
        status: 400,
        error:
          "File bukan database SQLite — header tidak cocok. Pastikan mengunggah file .db hasil ekspor aplikasi ini.",
      };
    }

    const dbPath = dbPathFromEnv();
    if (!dbPath) return { ok: false, status: 500, error: "Lokasi file database tidak diketahui" };
    const dir = dirname(dbPath);
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const safetyPath = `${dbPath}.pra-restore-${stamp}.bak`;
    const tmpPath = join(dir, `restore-tmp-${stamp}.db`);
    const walPath = `${dbPath}-wal`;
    const shmPath = `${dbPath}-shm`;

    const countAll = async () => ({
      users: await db.user.count(),
      customers: await db.customer.count(),
      repairs: await db.repairRecord.count(),
      transactions: await db.transaction.count(),
    });

    // Tangkap skema database berjalan SEBELUM koneksi ditutup (D52).
    const expectedSchema = await captureSchema();

    // 1-3. Checkpoint WAL & tutup koneksi
    await db.$queryRawUnsafe("PRAGMA wal_checkpoint(TRUNCATE)");
    await db.$disconnect();

    let stage = 0; // 0 = belum pindah; 1 = db lama jadi salinan; 2 = file baru terpasang
    try {
      // 4. DB lama → salinan keamanan
      await rename(dbPath, safetyPath);
      stage = 1;
      // 5. Buang WAL/SHM lama (isinya sudah masuk file utama saat checkpoint)
      for (const p of [walPath, shmPath]) {
        try { await rm(p); } catch { /* belum ada — abaikan */ }
      }
      // 6. Tulis file baru secara atomik
      await writeFile(tmpPath, buf);
      await rename(tmpPath, dbPath);
      stage = 2;
      // 7. Verifikasi struktur via koneksi Prisma baru
      const counts = await countAll();
      const fileSchema = await captureSchema();
      const { tableProblems, missingColumns } = diffSchema(expectedSchema, fileSchema);
      if (tableProblems.length) {
        const detail =
          tableProblems.slice(0, 4).join("; ") + (tableProblems.length > 4 ? "; dkk" : "");
        throw new SchemaMismatch(
          `file bukan database aplikasi ini — tabel inti tidak ada: ${detail}. ` +
            `Pulihkan hanya file .db hasil "Unduh File Database (.db)" atau cadangan ` +
            `GitHub dari aplikasi ini.`
        );
      }
      if (missingColumns.length) {
        console.log(
          "[heal-db] file .db versi lama diterima — kolom berikut akan ditambah otomatis:",
          missingColumns.join("; ")
        );
      }
      // D55 — penyembuhan skema file lama: kolom hilang ditambahkan otomatis.
      // D84 — tabel yang belum ada di file (fitur lebih baru) juga dibuat
      // otomatis KOSONG; sebutkan di ringkasan agar pemilik tahu apa yang
      // ditambahkan sistem (transparansi, contoh: Attendance pra-D73).
      const heal = await ensureSchema({ force: true });
      const healedNote =
        (heal.columnsAdded.length
          ? ` Kolom usang ditambahkan otomatis: ${heal.columnsAdded.join(", ")}.`
          : "") +
        (heal.tablesCreated.length
          ? ` Tabel usang dibuat otomatis (kosong): ${heal.tablesCreated.join(", ")}.`
          : "");
      // 9a. Audit di database baru
      await db.auditLog.create({
        data: {
          action: "RESTORE_DATABASE_DB",
          details: `Pulihkan database dari file "${fileName}" (${Math.ceil(size / 1024)} KB) — isi: ${counts.users} pengguna, ${counts.customers} pelanggan, ${counts.repairs} tiket, ${counts.transactions} transaksi.${healedNote} Salinan database sebelumnya: ${safetyPath}`,
          performedBy: actorName,
        },
      });
      const sessionUser = await db.user.findUnique({
        where: { username: actorUsername },
        select: { id: true },
      });
      return {
        ok: true,
        summary: `Database diganti dengan isi "${fileName}" — ${counts.users} pengguna, ${counts.customers} pelanggan, ${counts.repairs} tiket servis, ${counts.transactions} transaksi.${healedNote}`,
        counts,
        healedColumns: heal.columnsAdded,
        safetyCopy: safetyPath,
        sessionInvalid: !sessionUser,
      };
    } catch (e) {
      // 8. ROLLBACK — kembalikan database lama apa pun yang terjadi
      const reason = e instanceof Error ? e.message : String(e);
      console.error("restore-db gagal — rollback dijalankan:", reason);
      try {
        await db.$disconnect();
        if (stage >= 1) {
          for (const p of [dbPath, walPath, shmPath]) {
            try { await rm(p); } catch { /* abaikan */ }
          }
          await rename(safetyPath, dbPath);
        }
        try { await rm(tmpPath); } catch { /* abaikan */ }
        await countAll(); // pastikan database asli hidup kembali
      } catch (rb) {
        console.error("ROLLBACK GAGAL — salinan keamanan:", safetyPath, rb);
        return {
          ok: false,
          status: 500,
          error: `Gagal memulihkan database dan rollback juga gagal. Database asli tersimpan aman sebagai salinan: ${safetyPath}. Hubungi admin untuk mengembalikannya manual.`,
        };
      }
      return {
        ok: false,
        status: 400,
        error:
          e instanceof SchemaMismatch
            ? `File ditolak — database TIDAK diubah (dikembalikan otomatis). ${reason}`
            : `File ditolak saat verifikasi — database TIDAK diubah (sudah dikembalikan otomatis). Penyebab: ${reason}`,
      };
    }
  } finally {
    busy = false;
  }
}
