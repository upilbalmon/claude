import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashPin, sanitizeUser } from "@/lib/pin-hash";

// POST /api/auth/unlock — PinUnlockScreen.kt: validasi PIN untuk membuka kunci sesi
export async function POST(req: NextRequest) {
  try {
    const { userId, pin } = (await req.json()) as { userId?: number; pin?: string };
    if (!userId || !pin) {
      return NextResponse.json({ status: "ERROR", message: "Data tidak lengkap" }, { status: 400 });
    }
    const user = await db.user.findUnique({ where: { id: userId } });
    if (!user) {
      return NextResponse.json({ status: "NOT_FOUND", message: "Pengguna tidak ditemukan" }, { status: 404 });
    }
    if (hashPin(pin, user.salt) !== user.pin) {
      return NextResponse.json({ status: "WRONG_PIN", message: "PIN salah!" });
    }
    return NextResponse.json({ status: "SUCCESS", user: sanitizeUser(user) });
  } catch (e) {
    console.error("unlock error", e);
    return NextResponse.json({ status: "ERROR", message: "Terjadi kesalahan server" }, { status: 500 });
  }
}
