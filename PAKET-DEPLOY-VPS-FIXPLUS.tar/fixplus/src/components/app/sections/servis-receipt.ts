// Helper teks & hitungan nota servis — port getFormattedRepairReceiptText (RepairSection.kt)
// dan notaTotal helper. Mode: "tanda_terima" & "nota" (NOTA PELUNASAN SERVIS).

export type Repair = {
  id: number;
  customerId: number | null;
  customerName: string;
  customerPhone: string;
  deviceModel: string;
  serialOrImei: string;
  damageDescription: string;
  status: string;
  technicianId: number | null;
  technicianName: string | null;
  serviceFee: number;
  usedPartsJson: string;
  requestedPartsJson?: string; // D28: part pesanan [{name,qty,estPrice,partId?,done?}]
  totalPrice: number;
  difficulty: string;
  notes: string;
  estimatedCost: number | null;
  downPayment: number | null;
  estimatedCompletionTime: string;
  createdByUser: string;
  pointsReward: number | null;
  createdAt: string;
  updatedAt: string;
  completedAt: string | null;
  warrantyDays: number;
};

export type SparePartLite = {
  id: number;
  name: string;
  sku: string;
  stock: number;
  costPrice: number;
  sellPrice: number;
};

type Settings = { shopName: string; address: string; phone: string; receiptFooter: string };

export function partsSumOf(parts: { sellPrice: number; qty: number }[]): number {
  return parts.reduce((s, p) => s + (Number(p.sellPrice) || 0) * (Number(p.qty) || 0), 0);
}

// nota tanda terima: sisa = est biaya - DP (minimum 0)
export function notaSisaBayar(repair: Repair): number {
  return Math.max(0, (repair.estimatedCost ?? 0) - (repair.downPayment ?? 0));
}

// nota pelunasan: total akhir = (jasa + part) - DP (minimum 0)
export function notaTotalPelunasan(repair: Repair): number {
  const parts = safeParts(repair.usedPartsJson);
  return Math.max(0, repair.serviceFee + partsSumOf(parts) - (repair.downPayment ?? 0));
}

function safeParts(json: string): { name: string; alias?: string | null; qty: number; sellPrice: number; isExternal?: boolean }[] {
  try {
    const arr = JSON.parse(json);
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function fmtDate(dateStr: string): string {
  const d = new Date(dateStr);
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yyyy = d.getFullYear();
  const hh = String(d.getHours()).padStart(2, "0");
  const mi = String(d.getMinutes()).padStart(2, "0");
  return `${dd}/${mm}/${yyyy} ${hh}:${mi}`;
}

function rupiah(v: number): string {
  return `Rp ${Math.trunc(v).toLocaleString("id-ID")}`;
}

// Teks nota (dipakai tombol Salin Teks & Teks WA) — persis getFormattedRepairReceiptText
export function buildRepairReceiptText(
  repair: Repair,
  mode: "tanda_terima" | "nota",
  settings: Settings,
  cashierName: string,
  trackingUrl = "", // D26: link lacak servis online (tanda terima)
): string {
  const parts = safeParts(repair.usedPartsJson);
  const lines: string[] = [];
  lines.push(`========= ${settings.shopName.toUpperCase()} ========`);
  if (settings.address) lines.push(settings.address);
  lines.push(`Telp/WA: ${settings.phone}`);
  lines.push("----------------------------------------");

  if (mode === "tanda_terima") {
    lines.push("*TANDA TERIMA SERVIS*", "");
    lines.push(`No Servis: #${repair.id}`);
    lines.push(`Tgl Masuk: ${fmtDate(repair.createdAt)}`, "");
    lines.push("*PELANGGAN:*");
    lines.push(`Nama: ${repair.customerName}`);
    lines.push(`Telp: ${repair.customerPhone}`, "");
    lines.push("*PERANGKAT & KELUHAN:*");
    lines.push(`Model HP: ${repair.deviceModel}`);
    lines.push(`S/N: ${repair.serialOrImei || "-"}`);
    lines.push(`Kerusakan: ${repair.damageDescription}`, "");
    lines.push("----------------------------------------");
    lines.push("*ESTIMASI BIAYA:*");
    lines.push(`Est. Biaya: ${rupiah(repair.estimatedCost ?? 0)}`);
    lines.push(`Uang Muka (DP): ${rupiah(repair.downPayment ?? 0)}`);
    lines.push(`Sisa Bayar: ${rupiah(Math.max(0, (repair.estimatedCost ?? 0) - (repair.downPayment ?? 0)))}`);
    lines.push("----------------------------------------");
    if (trackingUrl) {
      // D26: link lacak online (sama dengan QR di struk)
      lines.push("*LACAK SERVIS ONLINE:*");
      lines.push(trackingUrl);
      lines.push("----------------------------------------");
    }
    lines.push("Harap simpan tanda terima ini untuk pengambilan barang. Terima kasih!");
  } else {
    lines.push("*NOTA PELUNASAN SERVIS*", "");
    lines.push(`No Servis: #${repair.id}`);
    lines.push(`Tgl Masuk: ${fmtDate(repair.createdAt)}`);
    lines.push(`Tgl Keluar: ${fmtDate(repair.updatedAt)}`, "");
    lines.push("*PELANGGAN:*");
    lines.push(`Nama: ${repair.customerName}`);
    lines.push(`Telp: ${repair.customerPhone}`, "");
    lines.push("*PERANGKAT:*");
    lines.push(`HP: ${repair.deviceModel}`);
    lines.push(`S/N: ${repair.serialOrImei || "-"}`, "");
    lines.push("----------------------------------------");
    lines.push("*RINCIAN BIAYA:*");
    lines.push(`- Jasa Servis: ${rupiah(repair.serviceFee)}`);
    for (const p of parts) {
      // D23 (D18/D19): nota memakai Nama di Struk (alias) bila diisi
      // D64: part external ditandai "(Toko Lain)" — sama dengan kartu tagihan Kasir
      lines.push(`- ${p.alias?.trim() || p.name}${p.isExternal ? " (Toko Lain)" : ""} (${p.qty}x): ${rupiah((Number(p.sellPrice) || 0) * (Number(p.qty) || 1))}`);
    }
    lines.push("----------------------------------------");
    const subtotal = repair.serviceFee + partsSumOf(parts);
    lines.push(`Subtotal: ${rupiah(subtotal)}`);
    lines.push(`DP / Uang Muka: -${rupiah(repair.downPayment ?? 0)}`);
    lines.push(`*TOTAL PELUNASAN: ${rupiah(Math.max(0, subtotal - (repair.downPayment ?? 0)))}*`);
    lines.push("----------------------------------------");
    lines.push("Status: *LUNAS*");
    lines.push(settings.receiptFooter);
    lines.push(repair.warrantyDays === 0 ? "Tanpa Garansi." : `Garansi servis ${repair.warrantyDays} hari.`);
  }
  lines.push("", "========================================");
  return lines.join("\n");
}
