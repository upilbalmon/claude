import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { resolveActor } from "@/lib/action-guard";
import { spareCategoryOf } from "@/lib/spare-category";
import { saranSku, skuUnik } from "@/lib/sku-utils";
import { bisaTransisiRequested, REQUESTED_BISA_EDIT } from "@/lib/belanja-utils";

type Params = { params: Promise<{ id: string }> };

// D61 — Tahap 6.2: alur status Barang Pesanan (Baru → Dipesan → Tersedia /
// Ditolak) + aksi lanjutan.
//
//  - Transisi divalidasi server (bisaTransisiRequested); "Ditolak" wajib alasan.
//  - Aksi "buatPart" (hanya status Tersedia, sekali saja): barang masuk KATALOG
//    Inventaris sebagai SparePart baru — SKU otomatis pola data ada (D22),
//    stok awal = qty pesanan, lalu partId mengaitkan hasilnya. Harga beli/jual
//    diisi saat aksi (harga nyata barang yang datang).

export async function PATCH(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return NextResponse.json({ error: "ID tidak valid" }, { status: 400 });
    }
    const row = await db.requestedItem.findUnique({ where: { id } });
    if (!row) {
      return NextResponse.json({ error: "Barang pesanan tidak ditemukan" }, { status: 404 });
    }

    const body = await req.json();
    const performedBy = String(body.performedBy ?? "Tidak diketahui");

    // ===== Aksi: masukkan ke inventaris (Tersedia → katalog) =====
    if (body.action === "buatPart") {
      if (row.status !== "Tersedia") {
        return NextResponse.json(
          { error: "Barang harus berstatus Tersedia sebelum dimasukkan ke inventaris" },
          { status: 400 }
        );
      }
      if (row.partId) {
        return NextResponse.json(
          { error: "Barang pesanan ini sudah dimasukkan ke inventaris" },
          { status: 409 }
        );
      }
      const costPrice = clampNum(body.costPrice, 0, 0);
      const sellPrice = clampNum(body.sellPrice, 0, 0);
      if (sellPrice < costPrice) {
        return NextResponse.json(
          { error: "Harga jual tidak boleh lebih kecil dari harga beli" },
          { status: 400 }
        );
      }

      const all = await db.sparePart.findMany({ select: { sku: true } });
      const name = String(body.name ?? row.itemName).trim() || row.itemName;
      const part = await db.sparePart.create({
        data: {
          name,
          sku: skuUnik(saranSku(name), all.map((p) => p.sku)),
          category: spareCategoryOf(body.category),
          stock: Math.max(1, row.qty),
          minStock: clampInt(body.minStock, 5, 0, 9999),
          costPrice,
          sellPrice,
          location: String(body.location ?? "").trim(),
        },
      });

      const updated = await db.requestedItem.update({
        where: { id },
        data: { partId: part.id },
      });

      await db.auditLog.create({
        data: {
          action: "TAMBAH_SPAREPART_DARI_PESANAN",
          details: `${part.name} (SKU ${part.sku}, stok ${part.stock}) — dari barang pesanan #${row.id}`,
          performedBy,
        },
      });

      return NextResponse.json({ ...updated, part });
    }

    // ===== Aksi status =====
    if (body.action === "status") {
      const target = String(body.status ?? "");
      if (!bisaTransisiRequested(row.status, target)) {
        return NextResponse.json(
          { error: `Barang pesanan berstatus "${row.status}" tidak bisa lanjut ke "${target}"` },
          { status: 400 }
        );
      }

      if (target === "Ditolak") {
        const reason = String(body.reason ?? "").trim();
        if (reason.length < 3) {
          return NextResponse.json(
            { error: "Alasan penolakan wajib diisi (minimal 3 karakter)" },
            { status: 400 }
          );
        }
        const updated = await db.requestedItem.update({
          where: { id },
          data: { status: "Ditolak", cancelReason: reason },
        });
        await db.auditLog.create({
          data: {
            action: "BARANG_PESANAN_STATUS",
            details: `${row.itemName} ×${row.qty} — ${row.customerName || "Umum"}: ${row.status} → Ditolak — Alasan: ${reason}`,
            performedBy,
          },
        });
        return NextResponse.json(updated);
      }

      const updated = await db.requestedItem.update({
        where: { id },
        data: { status: target },
      });
      await db.auditLog.create({
        data: {
          action: "BARANG_PESANAN_STATUS",
          details: `${row.itemName} ×${row.qty} — ${row.customerName || "Umum"}: ${row.status} → ${target}`,
          performedBy,
        },
      });
      return NextResponse.json(updated);
    }

    // ===== Mode edit =====
    if (!REQUESTED_BISA_EDIT.includes(row.status)) {
      return NextResponse.json(
        { error: `Hanya barang berstatus Baru/Dipesan yang bisa diedit (status kini: ${row.status})` },
        { status: 400 }
      );
    }

    const itemName = String(body.itemName ?? row.itemName).trim();
    if (!itemName) {
      return NextResponse.json({ error: "Nama barang wajib diisi" }, { status: 400 });
    }

    let customerId = row.customerId;
    let customerName = String(body.customerName ?? row.customerName).trim();
    let customerPhone = String(body.customerPhone ?? row.customerPhone).trim();
    if (body.customerId !== undefined) {
      if (body.customerId === null || String(body.customerId).trim() === "") {
        customerId = null;
      } else {
        const cid = Number(body.customerId);
        if (!Number.isInteger(cid)) {
          return NextResponse.json({ error: "ID pelanggan tidak valid" }, { status: 400 });
        }
        const cust = await db.customer.findUnique({ where: { id: cid } });
        if (!cust) {
          return NextResponse.json({ error: "Pelanggan tidak ditemukan" }, { status: 404 });
        }
        customerId = cid;
        if (!customerName) customerName = cust.name;
        if (!customerPhone) customerPhone = cust.phone;
      }
    }

    let repairRecordId = row.repairRecordId;
    if (body.repairRecordId !== undefined) {
      if (body.repairRecordId === null || String(body.repairRecordId).trim() === "") {
        repairRecordId = null;
      } else {
        const rid = Number(body.repairRecordId);
        if (!Number.isInteger(rid)) {
          return NextResponse.json({ error: "ID tiket servis tidak valid" }, { status: 400 });
        }
        const repair = await db.repairRecord.findUnique({ where: { id: rid } });
        if (!repair) {
          return NextResponse.json({ error: "Tiket servis tidak ditemukan" }, { status: 404 });
        }
        repairRecordId = rid;
      }
    }

    const updated = await db.requestedItem.update({
      where: { id },
      data: {
        itemName,
        brandOrSpec: body.brandOrSpec !== undefined ? String(body.brandOrSpec).trim() : row.brandOrSpec,
        qty: clampInt(body.qty, row.qty, 1, 999),
        estPrice: clampNum(body.estPrice, row.estPrice, 0),
        notes: body.notes !== undefined ? String(body.notes).trim() : row.notes,
        customerId,
        customerName,
        customerPhone,
        repairRecordId,
      },
    });

    await db.auditLog.create({
      data: {
        action: "EDIT_BARANG_PESANAN",
        details: `${updated.itemName}${updated.brandOrSpec ? ` (${updated.brandOrSpec})` : ""} ×${updated.qty} — ${updated.customerName || "Umum"}`,
        performedBy,
      },
    });

    return NextResponse.json(updated);
  } catch (e) {
    console.error("requested-items PATCH error", e);
    return NextResponse.json({ error: "Gagal memperbarui barang pesanan" }, { status: 500 });
  }
}

// DELETE — hanya Admin (D34). Catatan barang pesanan ringan (bukan dokumen
// penjualan), sehingga boleh dihapus kapan pun dengan jejak audit.
export async function DELETE(req: NextRequest, { params }: Params) {
  try {
    const id = Number((await params).id);
    if (!Number.isInteger(id)) {
      return NextResponse.json({ error: "ID tidak valid" }, { status: 400 });
    }
    const actor = await resolveActor(req.nextUrl.searchParams.get("requesterUsername"));
    if (!actor) {
      return NextResponse.json({ error: "Hanya Admin yang dapat menghapus data" }, { status: 403 });
    }
    const existing = await db.requestedItem.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: "Barang pesanan tidak ditemukan" }, { status: 404 });
    }

    await db.requestedItem.delete({ where: { id } });
    await db.auditLog.create({
      data: {
        action: "HAPUS_BARANG_PESANAN",
        details: `${existing.itemName}${existing.brandOrSpec ? ` (${existing.brandOrSpec})` : ""} ×${existing.qty} — ${existing.customerName || "Umum"}`,
        performedBy: actor.name,
      },
    });

    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("requested-items DELETE error", e);
    return NextResponse.json({ error: "Gagal menghapus barang pesanan" }, { status: 500 });
  }
}

function clampInt(v: unknown, fallback: number, min: number, max: number): number {
  const n = Math.trunc(Number(v));
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
}

function clampNum(v: unknown, fallback: number, min: number): number {
  const n = Number(v);
  return Number.isFinite(n) && n >= min ? n : fallback;
}
