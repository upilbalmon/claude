import { NextRequest, NextResponse } from "next/server";
import { resolveActor, errAction } from "@/lib/action-guard";
import { loadCreds, resolveMethod, tokenAndFolder, listBackupFiles } from "@/lib/gdrive";

// D67 — GET /api/gdrive/files?requesterUsername=&method=auto|oauth|sa
// Daftar file cadangan di folder Drive (terbaru dulu).
export async function GET(req: NextRequest) {
  const actor = await resolveActor(req.nextUrl.searchParams.get("requesterUsername"));
  if (!actor) return errAction("Akses ditolak — hanya Admin", 403);

  const methodRaw = req.nextUrl.searchParams.get("method") ?? "auto";
  const method = methodRaw === "oauth" || methodRaw === "sa" ? methodRaw : "auto";
  try {
    const c = await loadCreds();
    const kind = await resolveMethod(c, method);
    const { token, folderId } = await tokenAndFolder(kind, c);
    const files = await listBackupFiles(token, folderId);
    return NextResponse.json({ ok: true, method: kind, files });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("gdrive files error", e);
    return errAction(msg, 400);
  }
}
